<?php
namespace App\Http\Controllers\Nurse;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Auth;
use DB;
use Validator;
use Redirect;
use DateTime;
use DateTimeZone;
use Session;
use App\Models\SaveTelemedicalBookingDetail;
use App\Models\Patient;
use App\Models\BillingDetail;
use App\Models\Hospital;
use App\Models\Doctor;
use App\Models\Nurse;
use App\Models\NurseLoginToken;
use App\Models\PaidBillingDetail;
use App\Models\PatientAppointment;
use Illuminate\Pagination\LengthAwarePaginator;
use Illuminate\Support\Facades\Input;
use App\Models\UserNotification;
use App\Models\PatientLoginToken;
class NursePagesController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
   
    public function __construct()
    {
        $this->middleware('auth:nurse');
    }

    /** telemedical appoinment section*/

    public function telemedicalAppoinment(Request $request){         
        $value = Session::get('nurse_token');
        $nurse_id = Auth::user()->nurse_id;
        
        $login_token =NurseLoginToken::where(array('nurse_id'=>$nurse_id,'login_token'=>$value))->first();        
        if(isset($login_token->token_status) && $login_token->token_status == 0){ 
            Auth::guard('nurse')->logout();           
            return redirect('/nurse/login');
        }
        if(!Auth::check()){            
            return redirect('/nurse/login');
        } 
        
        $nurse_details = Nurse::where('nurse_id',$nurse_id)->first();
        $hospital_id = $nurse_details->hospital_id;
        $doctor_id = Doctor::where('hospital_id',$hospital_id)->select('doctor_id')->get();  
        $time_zone = $nurse_details->nurse_timezone;               
        $dtz = new DateTimeZone($time_zone);
        $time_in_sofia = new DateTime('now', $dtz);        
        $date_offset = $time_in_sofia->format('Z');
        $start_time = strtotime(date("Y-m-d"))-$date_offset;
        $end_time = strtotime(date("Y-m-d",strtotime("+1 day")))-$date_offset;

        $PatientAppointment_details = SaveTelemedicalBookingDetail::with("patient_detail")->with('patient_appoint')->select('save_telemedical_booking_detail.*','save_telemedical_booking_detail.id as st_id','save_telemedical_booking_detail.status as st_status')->whereHas('patient_appoint', function($q){$q->where('appointment_type',1);})->whereIn('doctor_id',$doctor_id)->orderBy('appointment_time', 'DESC')->paginate(20);

        foreach($PatientAppointment_details as $app)
        {
            SaveTelemedicalBookingDetail::where('id', $app->st_id)->update(['status' => 0]);
        }

        //$today_appointment=SaveTelemedicalBookingDetail::where('doctor_id',$doctor_id)->where('save_telemedical_booking_detail.approved_status','!=',2)->where('appointment_time','>=',$start_time)->where('appointment_time','<',$end_time)->get();

        /*$status = SaveTelemedicalBookingDetail::where('doctor_id',$doctor_id)->where('call_status','>',0)->count();  
        $disabled = 0;
        if($status > 0){
            $disabled = 1;
        }*/
        $disabled = 1;
        return view('nurse.telemedical_appointment')->with(array('controller'=> 'pages','PatientAppointment_details'=>$PatientAppointment_details,'page'=>'inner','page_type'=>'time_count','nurse_details'=>$nurse_details,'timezone'=>$time_zone,'disabled'=>$disabled));
    }

    /** telemedical appoinment section end*/

    /**  search patient view section */
    public function searchPatient(Request $request){
      	$value = Session::get('nurse_token');
        $nurse_id = Auth::user()->nurse_id;
        
        $login_token =NurseLoginToken::where(array('nurse_id'=>$nurse_id,'login_token'=>$value))->first();        
        if(isset($login_token->token_status) && $login_token->token_status == 0){ 
            Auth::guard('nurse')->logout();           
            return redirect('/nurse/login');
        }
        if(!Auth::check()){            
            return redirect('/nurse/login');
        } 
        
        $nurse_details = Nurse::where('nurse_id',$nurse_id)->first();  
        
        $time_zone = $nurse_details->nurse_timezone;                
        

        //$today_appointment=SaveTelemedicalBookingDetail::where('doctor_id',$doctor_id)->where('save_telemedical_booking_detail.approved_status','!=',2)->where('appointment_time','>=',$start_time)->where('appointment_time','<',$end_time)->get(); 

     	  return view('nurse.search_patient')->with(array('controller'=> 'pages', 'page_type'=>'time_count','nurse_details'=>$nurse_details,'timezone'=>$time_zone));

    }
    /**  search patient view end section */

    /**  search patient filter  section */
    public function patientSearchResult(Request $request){
     	$value = Session::get('nurse_token');
        $nurse_id = Auth::user()->nurse_id;
        
        $login_token =NurseLoginToken::where(array('nurse_id'=>$nurse_id,'login_token'=>$value))->first();        
        if(isset($login_token->token_status) && $login_token->token_status == 0){ 
            Auth::guard('nurse')->logout();           
            return redirect('/nurse/login');
        }
        if(!Auth::check()){            
            return redirect('/nurse/login');
        } 
        
        $nurse_details = Nurse::where('nurse_id',$nurse_id)->first();         
        $time_zone = $nurse_details->nurse_timezone;
        $hospital_id = $nurse_details->hospital_id;
        $doctor_id = Doctor::where('hospital_id',$hospital_id)->select('doctor_id')->get(); 
        $dtz = new DateTimeZone($time_zone);
        $time_in_sofia = new DateTime('now', $dtz);        
        $date_offset = $time_in_sofia->format('Z');
        $start_time = strtotime(date("Y-m-d"))-$date_offset;
        $end_time = strtotime(date("Y-m-d",strtotime("+1 day")))-$date_offset;

      	$validatedData = $request->validate([
	           'patient_name' => 'required_without_all:medical_record,surename,dob',
	     ]);

        $form_data =  $request->input();       
        $patient_name =  $request->input('patient_name');
        $medical_record =  $request->input('medical_record');
        $surename =  $request->input('surename');
       
        if(!empty($request->input('dob')))
        {
              $dob= str_replace('/', '-', $request->input('dob')); 
           $dob = strtotime($dob);
        }else{
            $dob = "";
        }           
         $medical_record=preg_replace("/[^0-9]/", '', $medical_record);
        $result = Patient::select('*')->whereHas('save_booking', function($q) use($doctor_id){$q->whereIn('doctor_id',$doctor_id);});
            if($patient_name!="" AND $medical_record!="" AND $surename!="" AND $dob!="" )
            {
            $result = $result->where('patient_first_name', 'like', '%'.$patient_name.'%')->where('patient_last_name',  'like', '%'.$surename.'%')->where('patient_date_of_birth','like','%'.$dob.'%')->where('patient_unique_id','like', '%'.$medical_record.'%')->paginate(5);
            }

            if($patient_name=="" AND $medical_record!="" AND $surename=="" AND $dob=="" )
            {
            $result =$result->where('patient_unique_id','like', '%'.$medical_record.'%')->paginate(5);                 
            }
            if($patient_name!="" AND $medical_record=="" AND $surename!="" AND $dob!="" )
            {
            $result = $result->where('patient_first_name', 'like', '%'.$patient_name.'%')->where('patient_last_name',  'like', '%'.$surename.'%')->where('patient_date_of_birth','like','%'.$dob.'%')->paginate(5);            
            }
        /*if($patient_name!="" AND $medical_record!="" AND $surename!="" AND $dob!="" )
        {
            $result = $result->where('patient_first_name', 'like', '%'.$patient_name.'%')->where('patient_unique_id',  'like', '%'.$medical_record.'%')->where('patient_last_name',  'like', '%'.$surename.'%')->where('patient_date_of_birth','like','%'.$dob.'%')->paginate(5);
            $result->appends(array('patient_name'=>Input::get('patient_name'),'medical_record'=>Input::get('medical_record'),'surename'=>Input::get('surename'),'dob'=>Input::get('dob')));
        }elseif($patient_name!="" AND $medical_record!="" AND $surename!=""){
            $result = $result->where('patient_first_name', 'like', '%'.$patient_name.'%')->where('patient_unique_id',  'like', '%'.$medical_record.'%')->where('patient_last_name',  'like', '%'.$surename.'%')->paginate(5);
            $result->appends(array('patient_name'=>Input::get('patient_name'),'medical_record'=>Input::get('medical_record'),'surename'=>Input::get('surename')));      
        }elseif($patient_name!="" AND $medical_record!=""){
            $result = $result->where('patient_first_name','like', '%'.$patient_name.'%')->where('patient_unique_id','like', '%'.$medical_record.'%')->paginate(5);
            $result->appends(array('patient_name'=>Input::get('patient_name'),'medical_record'=>Input::get('medical_record')));                                      
        }elseif($medical_record!="" AND $surename!="" AND $dob!="" ){
            $result = $result->where('patient_unique_id','like', '%'.$medical_record.'%')->where('patient_last_name','like', '%'.$surename.'%')->where('patient_date_of_birth','like','%'.$dob.'%')->paginate(5);
            $result->appends(array('medical_record'=>Input::get('medical_record'),'surename'=>Input::get('surename'),'dob'=>Input::get('dob')));                        
        }elseif($surename!="" AND $dob!="" ){
            $result = $result->where('patient_last_name','like', '%'.$surename.'%')->where('patient_date_of_birth','like','%'.$dob.'%')->paginate(5);
            $result->appends(array('surename'=>Input::get('surename'),'dob'=>Input::get('dob')));                         
        }elseif($medical_record!="" AND $surename!=""){
            $result = $result->where('patient_unique_id','like', '%'.$medical_record.'%')->where('patient_last_name','like', '%'.$surename.'%')->paginate(5);
            $result->appends(array('medical_record'=>Input::get('medical_record'),'surename'=>Input::get('surename')));                                      
        }elseif($medical_record!="" AND $dob!="" ){
            $result = $result->where('patient_unique_id','like', '%'.$medical_record.'%')->where('patient_date_of_birth','like','%'.$dob.'%')->paginate(5);
            $result->appends(array('medical_record'=>Input::get('medical_record'),'dob'=>Input::get('dob')));        
        }elseif($patient_name!="" AND $surename!="" ){
            $result = $result->where('patient_first_name','like', '%'.$patient_name.'%')->where('patient_last_name','like', '%'.$surename.'%')->paginate(5);
            $result->appends(array('patient_name'=>$request->input('patient_name'),'surename'=>$request->input('surename')));                    
        }elseif($patient_name!="" AND $dob!="" ){
            $result = $result->where('patient_first_name','like', '%'.$patient_name.'%')->where('patient_date_of_birth','like', '%'.$dob.'%')->paginate(5);
            $result->appends(array('patient_name'=>Input::get('patient_name'),'dob'=>Input::get('dob')));
        }elseif($patient_name!=""){
            $result = $result->where('patient_first_name','like', '%'.$patient_name.'%')->paginate(5);
            $result->appends(array('patient_name'=>Input::get('patient_name')));    
        }elseif($surename!=""){
            $result = $result->where('patient_last_name','like', '%'.$surename.'%')->paginate(5);
            $result->appends(array('surename'=>Input::get('surename')));    
        }elseif($medical_record!="") {
              $result = $result->where('patient_unique_id','like', '%'.$medical_record.'%')->paginate(5);
              $result->appends(array('medical_record'=>Input::get('medical_record')));
        }elseif($dob!=""){
            $result = $result->where('patient_date_of_birth','like', '%'.$dob.'%')->paginate(5);
            $result->appends(array('dob'=>Input::get('dob')));                         
        }*/

        if(count($result)>0)
        {         
          //$today_appointment=SaveTelemedicalBookingDetail::where('doctor_id',$doctor_id)->where('save_telemedical_booking_detail.approved_status','!=',2)->where('appointment_time','>=',$start_time)->where('appointment_time','<',$end_time)->get(); 

          $hospital_listing = Hospital::select('*')->get();

          return view('nurse.patient_search_result')->with(array('controller'=> 'pages', 'form_data'=>$form_data,'result'=>$result,'page_type'=>'time_count','nurse_details'=>$nurse_details,'timezone'=>$time_zone,"hospital_listing"=>$hospital_listing));
        }else{
          return Redirect::back()->withErrors(['Result Not found']);
        }
    }
      /**  search patient filter  section end */


    /* scheduling appointment modal */

    public function scheduleAppointment(Request $request){
        $value = Session::get('nurse_token');
        $nurse_id = Auth::user()->nurse_id;
        
        $login_token =NurseLoginToken::where(array('nurse_id'=>$nurse_id,'login_token'=>$value))->first();        
        if(isset($login_token->token_status) && $login_token->token_status == 0){ 
            Auth::guard('nurse')->logout();           
            return redirect('/nurse/login');
        }
        if(!Auth::check()){            
            return redirect('/nurse/login');
        } 
        
        $nurse_details = Nurse::where('nurse_id',$nurse_id)->first();         
        $time_zone = $nurse_details->nurse_timezone;
        $hospital_id = $nurse_details->hospital_id;
        $doctor_id = Doctor::where('hospital_id',$hospital_id)->select('doctor_id')->get(); 
        $dtz = new DateTimeZone($time_zone);     
        if(isset($_POST['appoint_date'])){
          $date = date('Y-m-d',strtotime($_POST['appoint_date'])); 
        }else{
          $date = date('Y-m-d',strtotime('now')); 
        }  
        $next_date = date('Y-m-d', strtotime('+1 day', strtotime($date)));
        $time_in_sofia = new DateTime($date, $dtz);        
        $date_offset = $time_in_sofia->format('Z');       
        $start_time = strtotime($date)-$date_offset;
        
        $end_time = strtotime($next_date)-$date_offset;

        if(isset($_POST['appointment_type'])){
          $appointment_type = $_POST['appointment_type'];
        }else{
          $appointment_type = 2;
        }       
        
        if($appointment_type == 2){
            $doctor_avail_time=Doctor::with(array('doctor_availability'=>function($q) use($start_time,$end_time) {$q->where('availability_date','>=',$start_time); $q->where('availability_date','<',$end_time); $q->where('type',2);}))->with('specialist_categories')->whereHas('doctor_availability', function($q) use($start_time,$end_time) {$q->where('availability_date','>=',$start_time); $q->where('availability_date','<',$end_time); $q->where('type',2);})->where('doctor_id',$doctor_id)->select("*")->first();
            if(isset($doctor_avail_time->doctor_id)){
                $doctor_avail_time = $doctor_avail_time->toArray();
            }
        }elseif($appointment_type == 1){
            $doctor_avail_time=Doctor::with(array('doctor_availability'=>function($q) use($start_time,$end_time) {$q->where('availability_date','>=',$start_time); $q->where('availability_date','<',$end_time);$q->where('type',1);}))->with('specialist_categories')->whereHas('doctor_availability', function($q) use($start_time,$end_time) {$q->where('availability_date','>=',$start_time); $q->where('availability_date','<',$end_time);$q->where('type',1);})->where('doctor_id',$doctor_id)->select("*")->first();
            if(isset($doctor_avail_time->doctor_id)){
                $doctor_avail_time = $doctor_avail_time->toArray();
            }
        }
        
        $doc_appoint_listing=SaveTelemedicalBookingDetail::where('save_telemedical_booking_detail.approved_status','!=',2)->where('save_telemedical_booking_detail.appointment_time','>=',$start_time)->where('save_telemedical_booking_detail.appointment_time','<',$end_time)->orderBy('save_telemedical_booking_detail.appointment_time','ASC')->get();

        $hospital_listing = Hospital::select('*')->get();
        $patient_detail = Patient::where('patient_unique_id',$_POST['patient_id'])->first();
       
        return view('nurse.add_new_appointment')->with(array('controller'=> 'doctor','doctor_avail_time'=>$doctor_avail_time,'nurse_details'=>$nurse_details,'doc_appoint_listing'=>$doc_appoint_listing,'timezone'=>$time_zone,'appoint_date'=>$date,'hospital_listing'=>$hospital_listing,'patient_detail'=>$patient_detail,'appointment_type'=>$appointment_type));
    
    }

    public function addNewAppointment(Request $request){
      $value = Session::get('doctor_token');
      $doctor_id = Auth::user()->doctor_id;
      $login_token =DoctorLoginToken::where(array('doctor_id'=>$doctor_id,'login_token'=>$value))->first();        
      if(isset($login_token->token_status) && $login_token->token_status == 0){ 
          Auth::guard('doctor')->logout();           
          return response()->json(['redirect'=>1,"redirect_url"=>asset('/doctor/login')],200);
      }
      if(!Auth::check()){            
          return response()->json(['redirect'=>1,"redirect_url"=>asset('/doctor/login')],200);
      } 
      $doctor_details = $request->user();               
      $time_zone = $doctor_details->doctor_timezone;


      if($_POST['appointment_type'] == 1){
            $validator = Validator::make($_POST, [ 
                    //~ 'appointment_time' => 'required', 
                    'appointment_type' => 'required',                 
                    'telemedical_consult_type' => 'required',                 
                    'telemedical_consult_time' => 'required'                  
                ]);
            }else{
              $validator = Validator::make($_POST, [ 
                    //~ 'appointment_time' => 'required', 
                    'appointment_type' => 'required'        
                ]);
            }
          if ($validator->fails()) { 
              $errorMsg=$validator->messages();       
              return response()->json(['success'=>0, 'message'=>$validator->messages()->first()], 401);            
          }   

          $telemedical=NULL;
          if($_POST['appointment_type'] == 1){            
            if(!empty($_POST['telemedical_type']))
            {
              $telemedical = $_POST['telemedical_type'];
            }
            
            else
            {
              return response()->json(['success'=>0,'message'=>'telemedical type missing.'],200); 
            }               
          }else{
            $telemedical = NULL;
          }

          $telemedical_consult_type = NULL;
          if(isset($_POST['telemedical_consult_type'])){
            $telemedical_consult_type = $_POST['telemedical_consult_type'];
          }

          $telemedical_consult_time = NULL;
          if(isset($_POST['telemedical_consult_time'])){
            $telemedical_consult_time = $_POST['telemedical_consult_time'];
          }
        
          $PatientAppointment = new PatientAppointment([
              'appointment_id'              => $this->generateAUniqueNumber(),
              'patient_id'                  => $_POST['patient_id'],
              'appointment_type'            => $_POST['appointment_type'],
              'telemedical_type'            => $telemedical,  
              'telemedical_consult_type'    => $telemedical_consult_type, 
              'telemedical_consult_time'    => $telemedical_consult_time, 
              'appoint_booking_status'      => 0,
              'appoint_created_date'        => strtotime("now"),    
              'status'                      => 1                
          ]); 

          $PatientAppointment->save();

          $check_appointment_id=false;
          if(!empty($PatientAppointment->appointment_id))
          {
            $fetch_appointment=DB::table('appointment_details')->where('appointment_id',$PatientAppointment->appointment_id)->first(); 
            if($fetch_appointment->appointment_type == 1){          
              if($fetch_appointment->telemedical_consult_time==2)
              {
                $check_appointment_id=true;
              }
            }else{
              $check_appointment_id=true;
            }
            //~ echo '<pre>'; print_r($fetch_appointment->telemedical_consult_time); die('here');
          }
          
          if($check_appointment_id)
          {
            $validator = Validator::make($_POST, [                             
              'patient_id' => 'required',
              'appoint_date' => 'required|date', 
              'appoint_time'   => 'required',                 
            ]);           
          }
          else
          {             
            $validator = Validator::make($_POST, [               
              'booking_name' => 'required', 
              'mobile_number' => 'required',                  
              //~ 'symptoms ' => 'required',                  
              'terms_conditions' => 'required',                 
              'appoint_date' => 'required|date', 
              'appoint_time'   => 'required',                 
              'hospital_name' => 'required',
              'sharing_status' => 'required',
              'patient_id' => 'required'                  
            ]);
                
          }

          if ($validator->fails()) { 
              $errorMsg=$validator->messages();       
              return response()->json(['success'=>0, 'message'=>$validator->messages()->first()], 401);            
          }

          $appointment_date = $_POST['appoint_date']." ".$_POST['appoint_time'];          

          if(!empty($_POST['symptoms'])){
            $symptoms = trim($_POST['symptoms']);
          }else{
            $symptoms = NULL;
          }

          $patient_id = $_POST['patient_id'];          
          
          if(!empty($_POST['booking_name'])){
            $booking_name = $_POST['booking_name'];
          }else{
            $booking_name = NULL;
          }
          
          if(!empty($_POST['mobile_number'])){
            $mobile_number = $_POST['mobile_number'];
          }else{
            $mobile_number = NULL;
          }
          
          if(!empty($_POST['terms_conditions'])){
            $terms_conditions = $_POST['terms_conditions'];
          }else{
            $terms_conditions = NULL;
          }
          
          if(!empty($appointment_date)){   
            
                $dtz = new DateTimeZone($time_zone);     
                $date = date('Y-m-d H:i:s',strtotime($appointment_date));                  
                $time_in_sofia = new DateTime($date, $dtz);        
                $date_offset = $time_in_sofia->format('Z');       
                $appointment_time = strtotime($date)-$date_offset;             
          }else{
            $appointment_time = NULL;
          }
          
          if(!empty($_POST['hospital_name'])){
            $hospital_name = $_POST['hospital_name'];
          }else{
            $hospital_name = NULL;
          }

          if(!empty($_POST['hospital_id'])){
            $hospital_id = $_POST['hospital_id'];
          }else{
            $hospital_id = 0;
          }
          
          if(!empty($_POST['sharing_status'])){
            $sharing_status = $_POST['sharing_status'];
          }else{
            $sharing_status = NULL;
          }

          if(!empty($_POST['speciality_id'])){
            $specialist_id = $_POST['speciality_id'];
          }else{
            $specialist_id = 0;
          }

          $status = 0;

          if(isset($PatientAppointment->appointment_id)){
            $booking_count = SaveTelemedicalBookingDetail::where('appointment_id',$PatientAppointment->appointment_id)->get();
            if(count($booking_count) > 0){
              $status = 1;
              $_POST['submit_id'] = $booking_count[0]['booking_id'];
            }
          }

          $booking_exists=SaveTelemedicalBookingDetail::where('save_telemedical_booking_detail.patient_id',$_POST['patient_id'])->where('save_telemedical_booking_detail.appointment_time',$appointment_time)->where('appointment_id','!=',$PatientAppointment->appointment_id)->where('approved_status','!=',2)->count();

          if($booking_exists == 0){
            if(((isset($_POST['submit_status']) && $_POST['submit_status'] == 1) && (isset($_POST['submit_id']) && !empty($_POST['submit_id']))) || ($status == 1)){
              
              //~ SaveTelemedicalBookingDetail::where('booking_id', $_POST['submit_id'])->update(['appointment_id'=> $_POST['appointment_id'],'booking_name' => trim($_POST['booking_name']),'patient_id'   => $_POST['patient_id'],'hospital_name'=> $_POST['hospital_name'],'mobile_number'=> trim($_POST['mobile_number']),'symptoms'  => $symptoms,'terms_conditions'=> $_POST['terms_conditions'],'sharing_status'=> $_POST['sharing_status'],'appointment_time'=> date('Y-m-d H:i:s',strtotime($_POST['appointment_time']))]);
              
              SaveTelemedicalBookingDetail::where('booking_id', $_POST['submit_id'])->update(['appointment_id'=> $PatientAppointment->appointment_id,'booking_name' => trim($booking_name),'patient_id'=> $_POST['patient_id'],'hospital_id'=>$hospital_id,'specialist_id'=> $specialist_id,'hospital_name'=> trim($hospital_name),'mobile_number'=> trim($mobile_number),'symptoms' => trim($symptoms),'terms_conditions'=> $terms_conditions,'sharing_status'=> $sharing_status]);
              return response()->json(['success'=>1,'message'=>'Booking updated successfully.','id'=>$_POST['submit_id']],200);
            }else{
              
              $save_telemedical_booking_detail = new SaveTelemedicalBookingDetail([                
                'booking_id'    => $this->generateBUniqueNumber(),
                'appointment_id'  => $PatientAppointment->appointment_id,
                'booking_name'    => trim($booking_name),
                'patient_id'    => $_POST['patient_id'],
                'hospital_id'   => $hospital_id,
                'doctor_id'     => $doctor_id,
                'specialist_id'   => $specialist_id,
                'hospital_name'   => trim($hospital_name), 
                'mobile_number'   => trim($mobile_number),
                'symptoms'      => $symptoms,
                'terms_conditions'  => $terms_conditions, 
                'appointment_time'  => $appointment_time,
                'sharing_status'  => $sharing_status, 
                'approved_status' => 0,
                'status'      => 1,
                'created_at'    => strtotime("now")                             
              ]); 

              $save_telemedical_booking_detail->save();
              if(isset($PatientAppointment->appointment_id)){
                PatientAppointment::where('appointment_id', $PatientAppointment->appointment_id)->update(['appoint_booking_status' => 1]);
              }
              return response()->json(['success'=>1,'message'=>'Booking added successfully.','id'=>$save_telemedical_booking_detail->booking_id],200);
            }
          }else{
            return response()->json(['success'=>0,'message'=>'You already have booking with another doctor.'],200);
          }
    }

    public function billings(Request $request,$id=''){        
        $value = Session::get('nurse_token');
        $nurse_id = Auth::user()->nurse_id;
        
        $login_token =NurseLoginToken::where(array('nurse_id'=>$nurse_id,'login_token'=>$value))->first();        
        if(isset($login_token->token_status) && $login_token->token_status == 0){ 
            Auth::guard('nurse')->logout();           
            return redirect('/nurse/login');
        }
        if(!Auth::check()){            
            return redirect('/nurse/login');
        } 

        
        $nurse_details = Nurse::where('nurse_id',$nurse_id)->first();

        $hospital_id = $nurse_details->hospital_id;        
        $time_zone = $nurse_details->nurse_timezone;                   
        $dtz = new DateTimeZone($time_zone);
        $time_in_sofia = new DateTime('now', $dtz);        
        $date_offset = $time_in_sofia->format('Z');
        $start_time = strtotime(date("Y-m-d"))-$date_offset;
        $end_time = strtotime(date("Y-m-d",strtotime("+1 day")))-$date_offset;

        //$today_appointment=SaveTelemedicalBookingDetail::where('doctor_id',$doctor_id)->where('save_telemedical_booking_detail.approved_status','!=',2)->where('appointment_time','>=',$start_time)->where('appointment_time','<',$end_time)->get(); 
        if($id != ''){
          $billing_count = BillingDetail::where('hospital_id',$hospital_id)->where('patient_id',$id)->orderBy('billing_date','DESC')->count();
          $outstanding_count = BillingDetail::where('hospital_id',$hospital_id)->where('patient_id',$id)->whereRaw('payable_amount-paid_amount > 0')->orderBy('billing_date','DESC')->count();
          $paid_count = BillingDetail::where('hospital_id',$hospital_id)->where('patient_id',$id)->whereRaw('payable_amount-paid_amount = 0')->orderBy('billing_date','DESC')->count();
      }else{
          $billing_count = BillingDetail::where('hospital_id',$hospital_id)->orderBy('billing_date','DESC')->count();
          $outstanding_count = BillingDetail::where('hospital_id',$hospital_id)->whereRaw('payable_amount-paid_amount > 0')->orderBy('billing_date','DESC')->count();
          $paid_count = BillingDetail::where('hospital_id',$hospital_id)->whereRaw('payable_amount-paid_amount = 0')->orderBy('billing_date','DESC')->count();
      }
        if(isset($_GET['type'])){        
            if($_GET['type'] == "all_page"){
                $page = $_GET['page'];
                $limit = 20;            
            }else{
                $page = $_GET['all_page_no'];
                $limit = 20;            
            }      
            if($_GET['type'] == "out_billings"){
              $out_page = $_GET['page'];
              $limit = 20;          
            }else{
              $out_page = $_GET['out_page'];
              $limit = 20;          
            }

            if($_GET['type'] == "paid_billings"){
                $paid_page = $_GET['page'];
                $limit = 20;           
            }else{
                $paid_page = $_GET['paid_page'];
                $limit = 20;            
            }        
        }else{
              $page = 1;
              $out_page =1;
              $paid_page = 1;
              $limit = 20;          
        }
        if($id != ''){
            if(isset($_GET['sort_id'])){
            if($_GET['sort_id'] == 1){
              $billing_detail = BillingDetail::where('hospital_id',$hospital_id)->where('patient_id',$id)->orderBy('billing_date','DESC')->paginate($limit, ['*'],'page',$page);
              $outstanding_detail = BillingDetail::where('hospital_id',$hospital_id)->where('patient_id',$id)->whereRaw('payable_amount-paid_amount > 0')->orderBy('billing_date','DESC')->paginate($limit, ['*'],'page',$out_page);
              $paid_detail = BillingDetail::where('hospital_id',$hospital_id)->where('patient_id',$id)->whereRaw('payable_amount-paid_amount = 0')->orderBy('billing_date','DESC')->paginate($limit, ['*'],'page',$paid_page);
            }elseif($_GET['sort_id'] == 2){
              $billing_detail = BillingDetail::where('hospital_id',$hospital_id)->where('patient_id',$id)->orderBy('payable_amount','DESC')->paginate($limit, ['*'],'page',$page);
              $outstanding_detail = BillingDetail::where('hospital_id',$hospital_id)->where('patient_id',$id)->whereRaw('payable_amount-paid_amount > 0')->orderBy('payable_amount','DESC')->paginate($limit, ['*'],'page',$out_page);
              $paid_detail = BillingDetail::where('hospital_id',$hospital_id)->where('patient_id',$id)->whereRaw('payable_amount-paid_amount = 0')->orderBy('payable_amount','DESC')->paginate($limit, ['*'],'page',$paid_page);
            }elseif($_GET['sort_id'] == 3){
              
              $billing_detail = BillingDetail::where('hospital_id',$hospital_id)->where('patient_id',$id)->orderBy('payable_amount','ASC')->paginate($limit, ['*'],'page',$page);
              $outstanding_detail = BillingDetail::where('hospital_id',$hospital_id)->where('patient_id',$id)->whereRaw('payable_amount-paid_amount > 0')->orderBy('payable_amount','ASC')->paginate($limit, ['*'],'page',$out_page);
              $paid_detail = BillingDetail::where('hospital_id',$hospital_id)->where('patient_id',$id)->whereRaw('payable_amount-paid_amount = 0')->orderBy('payable_amount','ASC')->paginate($limit, ['*'],'page',$paid_page);
            }
          }else{
            $billing_detail = BillingDetail::where('hospital_id',$hospital_id)->where('patient_id',$id)->orderBy('billing_date','DESC')->paginate($limit, ['*'],'page',$page);
            $outstanding_detail = BillingDetail::where('hospital_id',$hospital_id)->where('patient_id',$id)->whereRaw('payable_amount-paid_amount > 0')->orderBy('billing_date','DESC')->paginate($limit, ['*'],'page',$out_page);
            $paid_detail = BillingDetail::where('hospital_id',$hospital_id)->where('patient_id',$id)->whereRaw('payable_amount-paid_amount = 0')->orderBy('billing_date','DESC')->paginate($limit, ['*'],'page',$paid_page);
          }
      }else{
          if(isset($_GET['sort_id'])){
            if($_GET['sort_id'] == 1){
              $billing_detail = BillingDetail::where('hospital_id',$hospital_id)->orderBy('billing_date','DESC')->paginate($limit, ['*'],'page',$page);
              $outstanding_detail = BillingDetail::where('hospital_id',$hospital_id)->whereRaw('payable_amount-paid_amount > 0')->orderBy('billing_date','DESC')->paginate($limit, ['*'],'page',$out_page);
              $paid_detail = BillingDetail::where('hospital_id',$hospital_id)->whereRaw('payable_amount-paid_amount = 0')->orderBy('billing_date','DESC')->paginate($limit, ['*'],'page',$paid_page);
            }elseif($_GET['sort_id'] == 2){
              $billing_detail = BillingDetail::where('hospital_id',$hospital_id)->orderBy('payable_amount','DESC')->paginate($limit, ['*'],'page',$page);
              $outstanding_detail = BillingDetail::where('hospital_id',$hospital_id)->whereRaw('payable_amount-paid_amount > 0')->orderBy('payable_amount','DESC')->paginate($limit, ['*'],'page',$out_page);
              $paid_detail = BillingDetail::where('hospital_id',$hospital_id)->whereRaw('payable_amount-paid_amount = 0')->orderBy('payable_amount','DESC')->paginate($limit, ['*'],'page',$paid_page);
            }elseif($_GET['sort_id'] == 3){
              
              $billing_detail = BillingDetail::where('hospital_id',$hospital_id)->orderBy('payable_amount','ASC')->paginate($limit, ['*'],'page',$page);
              $outstanding_detail = BillingDetail::where('hospital_id',$hospital_id)->whereRaw('payable_amount-paid_amount > 0')->orderBy('payable_amount','ASC')->paginate($limit, ['*'],'page',$out_page);
              $paid_detail = BillingDetail::where('hospital_id',$hospital_id)->whereRaw('payable_amount-paid_amount = 0')->orderBy('payable_amount','ASC')->paginate($limit, ['*'],'page',$paid_page);
            }
          }else{
            $billing_detail = BillingDetail::where('hospital_id',$hospital_id)->orderBy('billing_date','DESC')->paginate($limit, ['*'],'page',$page);
            $outstanding_detail = BillingDetail::where('hospital_id',$hospital_id)->whereRaw('payable_amount-paid_amount > 0')->orderBy('billing_date','DESC')->paginate($limit, ['*'],'page',$out_page);
            $paid_detail = BillingDetail::where('hospital_id',$hospital_id)->whereRaw('payable_amount-paid_amount = 0')->orderBy('billing_date','DESC')->paginate($limit, ['*'],'page',$paid_page);
          }
      }

        if(count($billing_detail) > 0){
            foreach($billing_detail as $billing_det){
              BillingDetail::where('billing_id', $billing_det->billing_id)->update(['seen_status' => 1]);
            }
        }

        if($request->ajax()){
            return view('nurse.all_billings_inner')->with(array('controller'=> 'pages','nurse_details'=>$nurse_details,'timezone'=>$time_zone,'billing_detail'=>$billing_detail,'outstanding_detail'=>$outstanding_detail,'paid_detail'=>$paid_detail,'billing_count'=>$billing_count,'page_type'=>'billing','id'=>$id));
        }else{
            return view('nurse.view_all_billings')->with(array('controller'=> 'pages','nurse_details'=>$nurse_details,'timezone'=>$time_zone,'billing_detail'=>$billing_detail,'outstanding_detail'=>$outstanding_detail,'paid_detail'=>$paid_detail,'billing_count'=>$billing_count,'outstanding_count'=>$outstanding_count,'paid_count'=>$paid_count,'page_type'=>'billing','id'=>$id));
        }
    }

    public function disputeBillings(Request $request){
        $value = Session::get('nurse_token');
        $nurse_id = Auth::user()->nurse_id;
        
        $login_token =NurseLoginToken::where(array('nurse_id'=>$nurse_id,'login_token'=>$value))->first();        
        if(isset($login_token->token_status) && $login_token->token_status == 0){ 
            Auth::guard('nurse')->logout();           
            return redirect('/nurse/login');
        }
        if(!Auth::check()){            
            return redirect('/nurse/login');
        } 
        
        $nurse_details = Nurse::where('nurse_id',$nurse_id)->first();
        $hospital_id = $nurse_details->hospital_id;
        $doctor_id = Doctor::where('hospital_id',$hospital_id)->select('doctor_id')->get();      
        if(isset($_GET['page'])){
            $page = $_GET['page'];
            $limit = 20;           
        }else{
            $page = 1;
            $limit = 20;            
        }    
          $disputed_billing = BillingDetail::with(array('doctor','nurse'))->where('hospital_id',$hospital_id)->where('disputed',1)->orderBy('billing_date','DESC')->paginate($limit, ['*'],'page',$page);  
              $time_zone = $nurse_details->nurse_timezone;  
            if($request->ajax()){
            return view('nurse.dispute_billing_inner')->with(array('controller'=> 'pages','nurse_details'=>$nurse_details,'timezone'=>$time_zone,"disputed_billing"=>$disputed_billing,"disputed_billing_count"=>$disputed_billing->total()));
            }
            else{
            return view('nurse.dispute_billing')->with(array('controller'=> 'pages','nurse_details'=>$nurse_details,'timezone'=>$time_zone,"disputed_billing"=>$disputed_billing,"disputed_billing_count"=>$disputed_billing->total()));
            }
            }

    public function disputeBillingDetail(Request $request,$id){
        $value = Session::get('nurse_token');
        $nurse_id = Auth::user()->nurse_id;
        
        $login_token =NurseLoginToken::where(array('nurse_id'=>$nurse_id,'login_token'=>$value))->first();        
        if(isset($login_token->token_status) && $login_token->token_status == 0){ 
            Auth::guard('nurse')->logout();           
            return redirect('/nurse/login');
        }
        if(!Auth::check()){            
            return redirect('/nurse/login');
        } 
        
        $nurse_details = Nurse::where('nurse_id',$nurse_id)->first();
        $hospital_id = $nurse_details->hospital_id;
        $doctor_id = Doctor::where('hospital_id',$hospital_id)->select('doctor_id')->get();        
        $time_zone = $nurse_details->nurse_timezone;   
        $billing_detail = BillingDetail::with(array('doctor','nurse','hospital','employee','billing_service','doctor.specialist_categories','nurse.specialist_categories','employee.specialist_categories','hospital.specialist_categories'))->where('billing_id',$id)->where('disputed',1)->first();  
        //$today_appointment=SaveTelemedicalBookingDetail::where('doctor_id',$doctor_id)->where('save_telemedical_booking_detail.approved_status','!=',2)->where('appointment_time','>=',$start_time)->where('appointment_time','<',$end_time)->get(); 
        return view('nurse.dispute_billing_detail')->with(array('controller'=> 'pages','nurse_details'=>$nurse_details,'timezone'=>$time_zone,"billing_detail"=>$billing_detail));
    }

    public function billingDetail(Request $request,$id,$pid=''){
        $value = Session::get('nurse_token');
        $nurse_id = Auth::user()->nurse_id;
        
        $login_token =NurseLoginToken::where(array('nurse_id'=>$nurse_id,'login_token'=>$value))->first();        
        if(isset($login_token->token_status) && $login_token->token_status == 0){ 
            Auth::guard('nurse')->logout();           
            return redirect('/nurse/login');
        }
        if(!Auth::check()){            
            return redirect('/nurse/login');
        } 
        
        $nurse_details = Nurse::where('nurse_id',$nurse_id)->first();
        $hospital_id = $nurse_details->hospital_id;
        $doctor_id = Doctor::where('hospital_id',$hospital_id)->select('doctor_id')->get();        
        $time_zone = $nurse_details->nurse_timezone;
        $billing_detail = BillingDetail::with(array('doctor','nurse','hospital','employee','billing_service','doctor.specialist_categories','nurse.specialist_categories','employee.specialist_categories','hospital.specialist_categories'))->where('billing_id',$id)->first();  
        return view('nurse.billing_detail')->with(array('controller'=> 'pages','nurse_details'=>$nurse_details,'timezone'=>$time_zone,'billing_detail'=>$billing_detail,'page_type'=>'billing','pid'=>$pid));
    }


    public function payBilling(Request $request){
      try{  
           $value = Session::get('nurse_token');
            $nurse_id = Auth::user()->nurse_id;
            
            $login_token =NurseLoginToken::where(array('nurse_id'=>$nurse_id,'login_token'=>$value))->first();        
            if(isset($login_token->token_status) && $login_token->token_status == 0){ 
                Auth::guard('nurse')->logout();           
                return redirect('/nurse/login');
            }
            if(!Auth::check()){            
                return redirect('/nurse/login');
            } 
            
            $nurse_details = Nurse::where('nurse_id',$nurse_id)->first();
            $hospital_id = $nurse_details->hospital_id;
            $doctor_id = Doctor::where('hospital_id',$hospital_id)->select('doctor_id')->get();
            $PayBilling = new PaidBillingDetail([
              'transaction_id'  => $_POST['transaction_id'],
              'billing_id'      => $_POST['billing_id'],
              'patient_id'      => $_POST['patient_id'],
              'doctor_id'       => $doctor_id,             
              'created_date'    => strtotime("now")                       
            ]); 

            $PayBilling->save();
              $update_amt = BillingDetail::where('billing_id',$_POST['billing_id'])->update(['paid_amount'=>DB::raw('paid_amount + '.$_POST['amt']),'cash_card'=>"card","paid_date"=>strtotime("now")]);
            $UserNotification = new UserNotification([                
              'notification_id'   => $this->generateNUniqueNumber(),              
              'assignee_type'     => 4,                    
              'patient_id'        => $_POST['patient_id'], 
              'event_id'          => $_POST['billing_id'],
              'notification_type' => "bill",
              'change_type'       => "paid",
              'created_date'      => strtotime('now'),
              'status'            => 0                                          
          ]);
          $UserNotification->save();

          $login_token = PatientLoginToken::where('patient_id',$_POST['patient_id'])->where('token_status',1)->get();
          $msg = "You paid a bill"; 
          
          if(count($login_token) > 0 && $login_token[0]->device_type != 2){            
              $device_token = $login_token[0]->device_token;
              $path = base_path()."/ios_notifcation/all_notifications.php";                            
              $nid = $_POST['billing_id'];
              $type= 'bill';
              exec ('php '.$path.' "'.$msg.'" '.$nid.' '.$type.' '.$device_token.' > /dev/null &');
          }

          $url = url('/patient/send_mail/'.str_replace(" ", "_", $msg).'/'.$_POST['patient_id'].'');   
          $cmd  = "curl --max-time 60 ";   
          $cmd .= "'" . $url . "'";   
          $cmd .= " > /dev/null 2>&1 &";    
          exec($cmd, $output, $exit); 
           //print_r(DB::connection('mysql')->getQueryLog());
          return response()->json(['success'=>1,'message'=>'Bill paid successfully.','data'=>""],200);

        }catch(Exception $e) {
            return response()->json(['error'=>1,"message"=>$e->getMessage()],200);       
        } 
    }
    // Pay billing by cash
       public function payBillingCash(Request $request){ 
         try{  
           $value = Session::get('nurse_token');
            $nurse_id = Auth::user()->nurse_id;
            
            $login_token =NurseLoginToken::where(array('nurse_id'=>$nurse_id,'login_token'=>$value))->first();        
            if(isset($login_token->token_status) && $login_token->token_status == 0){ 
                Auth::guard('nurse')->logout();           
                return redirect('/nurse/login');
            }
            if(!Auth::check()){            
                return redirect('/nurse/login');
            } 
            
            $nurse_details = Nurse::where('nurse_id',$nurse_id)->first();
            $hospital_id = $nurse_details->hospital_id;
            $doctor_id = Doctor::where('hospital_id',$hospital_id)->select('doctor_id')->get();
            $PayBilling = new PaidBillingDetail([
              'billing_id'      => $_POST['billing_id'],
              'patient_id'      => $_POST['patient_id'],
              'doctor_id'       => $doctor_id,             
              'created_date'    => strtotime("now")                       
            ]); 

            $PayBilling->save();
            $update_amt = BillingDetail::where('billing_id',$_POST['billing_id'])->update(['paid_amount'=>DB::raw('paid_amount + '.$_POST['amt']),'cash_card'=>"card","paid_date"=>strtotime("now")]);
            $UserNotification = new UserNotification([                
            'notification_id'   => $this->generateNUniqueNumber(),              
            'assignee_type'     => 4,                    
            'patient_id'        => $_POST['patient_id'], 
            'event_id'          => $_POST['billing_id'],
            'notification_type' => "bill",
            'change_type'       => "paid",
            'created_date'      => strtotime('now'),
            'status'            => 0                                          
            ]);
            $UserNotification->save();

          $login_token = PatientLoginToken::where('patient_id',$_POST['patient_id'])->where('token_status',1)->get();
          $msg = "You paid a bill"; 
          
          if(count($login_token) > 0 && $login_token[0]->device_type != 2){            
              $device_token = $login_token[0]->device_token;
              $path = base_path()."/ios_notifcation/all_notifications.php";                            
              $nid = $_POST['billing_id'];
              $type= 'bill';
              exec ('php '.$path.' "'.$msg.'" '.$nid.' '.$type.' '.$device_token.' > /dev/null &');
          }

          $url = url('/patient/send_mail/'.str_replace(" ", "_", $msg).'/'.$_POST['patient_id'].'');   
          $cmd  = "curl --max-time 60 ";   
          $cmd .= "'" . $url . "'";   
          $cmd .= " > /dev/null 2>&1 &";    
          exec($cmd, $output, $exit); 
           //print_r(DB::connection('mysql')->getQueryLog());
          return response()->json(['success'=>1,'message'=>'Bill paid successfully.','data'=>""],200);

        }catch(Exception $e) {
            return response()->json(['error'=>1,"message"=>$e->getMessage()],200);       
        }

       }


    public function settings(Request $request){
     	$value = Session::get('nurse_token');
        $nurse_id = Auth::user()->nurse_id;
        
        $login_token =NurseLoginToken::where(array('nurse_id'=>$nurse_id,'login_token'=>$value))->first();        
        if(isset($login_token->token_status) && $login_token->token_status == 0){ 
            Auth::guard('nurse')->logout();           
            return redirect('/nurse/login');
        }
        if(!Auth::check()){            
            return redirect('/nurse/login');
        } 
        
        $nurse_details = Nurse::where('nurse_id',$nurse_id)->first();
        $hospital_id = $nurse_details->hospital_id;
        $doctor_id = Doctor::where('hospital_id',$hospital_id)->select('doctor_id')->get();
         $time_zone = $nurse_details->nurse_timezone;

        //$today_appointment=SaveTelemedicalBookingDetail::where('doctor_id',$doctor_id)->where('save_telemedical_booking_detail.approved_status','!=',2)->where('appointment_time','>=',$start_time)->where('appointment_time','<',$end_time)->get(); 
        return view('nurse.settings')->with(array('controller'=> 'pages','nurse_details'=>$nurse_details,'timezone'=>$time_zone,'page_type'=>'settings'));
    }

    private function commoncurl($url,$post_data){
        $ch1 = curl_init();       
        curl_setopt($ch1, CURLOPT_URL,$url);
        curl_setopt($ch1, CURLOPT_HEADER, 0);
        curl_setopt($ch1, CURLOPT_POST, 1);
        curl_setopt($ch1, CURLOPT_POSTFIELDS, $post_data);  
        curl_setopt($ch1, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch1, CURLOPT_SSL_VERIFYPEER, 0);
        $output = curl_exec($ch1);  
        //echo "<pre>"; print_R($output);     
        curl_close ($ch1);
        $output= json_decode($output,true);
        
        return $output;
    }

    protected function generateAUniqueNumber() {
        $number = mt_rand(1000000000, 9999999999); // better than rand()
        // call the same function if the uniwue id exists already
        if ($this->uniqueANumberExists($number)) {
            return $this->generateAUniqueNumber();
        }
        // otherwise, it's valid and can be used
        return strval($number);
    }

    protected function uniqueANumberExists($number) {
        // query the database and return a boolean       
        return PatientAppointment::whereappointment_id($number)->exists();
    }

    protected function generateBUniqueNumber() {
        $number = mt_rand(1000000000, 9999999999); // better than rand()
        // call the same function if the uniwue id exists already
        if ($this->uniqueBNumberExists($number)) {
            return $this->generateBUniqueNumber();
        }
        // otherwise, it's valid and can be used
        return strval($number);
    }

    protected function uniqueBNumberExists($number) {
        // query the database and return a boolean       
        return SaveTelemedicalBookingDetail::wherebooking_id($number)->exists();
    }
    /*  public function healthDiary(Request $request){


      if(!Auth::check()){            
            return redirect('/doctor/login');
        }
        $user = $request->user();
        return view('patien.health_diary')->with(array('controller'=> 'pages','user'=>$user,'page'=>'dashboard','page_type'=>'extra_links'));
     }*/
public function AddBillingDispute(Request $request){
            try
            {   
            $value = Session::get('nurse_token');
            $nurse_id = Auth::user()->nurse_id;

            $login_token =NurseLoginToken::where(array('nurse_id'=>$nurse_id,'login_token'=>$value))->first();        
            if(isset($login_token->token_status) && $login_token->token_status == 0){ 
            Auth::guard('nurse')->logout();           
            return redirect('/nurse/login');
            }
            if(!Auth::check()){            
            return redirect('/nurse/login');
            } 


            $billing_id = isset($request->billing_id) ? $request->billing_id:'0'; 
            $dispute = isset($request->dispute) ? $request->dispute:'';   
            // DB::enableQueryLog();
            BillingDetail::where('billing_id', $billing_id)->update(['disputed' => $dispute]);
            // print_r(DB::connection('mysql')->getQueryLog());
            return response()->json(['success'=>1,"message"=>"success"],200);
            }
            catch(Exception $e)
            {
            return response()->json(['error'=>1,"message"=>$e->getMessage()],200);   
            }
     }

  protected function generateNUniqueNumber() {
        $number = mt_rand(1000000000, 9999999999); // better than rand()
        // call the same function if the uniwue id exists already
        if ($this->uniqueNNumberExists($number)) {
            return $this->generateNUniqueNumber();
        }
        // otherwise, it's valid and can be used
        return strval($number);
    }

    protected function uniqueNNumberExists($number) {
        // query the database and return a boolean         
        return UserNotification::wherenotification_id($number)->exists();
    }


  }
