<?php
namespace App\Http\Controllers\Nurse;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Auth;
use DB;
use Validator;
use Redirect;
use DateTime;
use DateTimeZone;
use Session;
use Hash;
use App\Models\PatientLoginToken;
use App\Models\Patient;
use App\Models\Hospital;
use App\Models\SaveTelemedicalBookingDetail;
use App\Models\DoctorAvailability;
use App\Models\PatientAppointment;
use App\Models\CallSession;
use App\Models\HealthHistory;
use App\Models\Doctor;
use App\Models\Nurse;
use App\Models\NurseLoginToken;
use App\Models\PatientHealthDiary;

//use Edujugon\PushNotification\PushNotification;

class NurseDashboardController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
       
        $this->middleware('auth:nurse');  
    }
    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */
    /******
    Dashboard view
    *******/
    public function index(Request $request)
    {    

        $value = Session::get('nurse_token');
        $nurse_id = Auth::user()->nurse_id;
        $login_token =NurseLoginToken::where(array('nurse_id'=>$nurse_id,'login_token'=>$value))->first();        
        if(isset($login_token->token_status) && $login_token->token_status == 0){ 
            Auth::guard('nurse')->logout();           
            return redirect('/nurse/login');
        }
        if(!Auth::check()){            
            return redirect('/nurse/login');
        }        
        $nurse_details = Nurse::where('nurse_id',$nurse_id)->first();  
        $time_zone = $nurse_details->nurse_timezone;
        //echo "<pre>"; print_R($doctor_availability); exit;
        return view('nurse.dashboard')->with(array('controller'=> 'nurse','appointments'=>array(),'today_appointments_count'=>0,'page'=>'inner','doctor_availability'=>array(),'nurse_details'=>$nurse_details,'timezone'=>$time_zone,'disabled'=>0,'page_type'=>'appointments','patient_count'=>0,'appointment_cnt'=>0));     
        
    }//Ends dashboard function

    /******
    My schedule view
    *******/
    public function allAppointments(Request $request)
    {
        //~ $user = $request->user();
        
        //~ return view('patient.dashboard')->with(array('controller'=> 'patient','user'=>$user));

        $value = Session::get('nurse_token');
        $nurse_id = Auth::user()->nurse_id;
        $login_token =NurseLoginToken::where(array('nurse_id'=>$nurse_id,'login_token'=>$value))->first();        
        if(isset($login_token->token_status) && $login_token->token_status == 0){ 
            Auth::guard('nurse')->logout();           
            return redirect('/nurse/login');
        }
        if(!Auth::check()){            
            return redirect('/nurse/login');
        }        
        $nurse_details = Nurse::where('nurse_id',$nurse_id)->first();
        $time_zone = $nurse_details->nurse_timezone;               

        return view('nurse.all_appointments')->with(array('controller'=> 'nurse','today_appointments_count'=>0,'page'=>'inner','page_type'=>'appointments','timezone'=>$time_zone,'nurse_details'=>$nurse_details));
    
    } //Ends My schedule function
    
    /******
    My schedule pagination ajax
    *******/
    public function allAppointmentsAjax(Request $request,$time="")
    {
        $value = Session::get('nurse_token');
        $nurse_id = Auth::user()->nurse_id;
        $login_token =NurseLoginToken::where(array('nurse_id'=>$nurse_id,'login_token'=>$value))->first();        
        if(isset($login_token->token_status) && $login_token->token_status == 0){ 
            Auth::guard('nurse')->logout();           
            return response()->json(['redirect'=>1,"redirect_url"=>asset('/nurse/login')],200);
        }
        if(!Auth::check()){            
            return response()->json(['redirect'=>1,"redirect_url"=>asset('/nurse/login')],200);
        }

        $nurse_details = Nurse::where('nurse_id',$nurse_id)->first();
        $hospital_id = $nurse_details->hospital_id;
        $doctor_id = Doctor::where('hospital_id',$hospital_id)->select('doctor_id')->get();
        $time_zone = $nurse_details->nurse_timezone;
        $dtz = new DateTimeZone($time_zone);
        $time_in_sofia = new DateTime('now', $dtz);        
        $date_offset = $time_in_sofia->format('Z');
        $start_time = strtotime(date("Y-m-d"))-$date_offset;
        $end_time = strtotime(date("Y-m-d",strtotime("+1 day")))-$date_offset;

        if($time == ""){         

            $appointments=SaveTelemedicalBookingDetail::select('save_telemedical_booking_detail.*','appointment_details.*','patients.*','save_telemedical_booking_detail.id as st_id','save_telemedical_booking_detail.status as st_status')->leftJoin('appointment_details', 'appointment_details.appointment_id','=', 'save_telemedical_booking_detail.appointment_id')->leftJoin('patients', 'save_telemedical_booking_detail.patient_id','=', 'patients.patient_unique_id')->where('save_telemedical_booking_detail.approved_status','!=',2)->whereIn('save_telemedical_booking_detail.doctor_id',$doctor_id)->orderBy('save_telemedical_booking_detail.appointment_time','DESC')->paginate(20);
        }else{
            $query=SaveTelemedicalBookingDetail::select('save_telemedical_booking_detail.*','appointment_details.*','patients.*','save_telemedical_booking_detail.id as st_id','save_telemedical_booking_detail.status as st_status')->leftJoin('appointment_details', 'appointment_details.appointment_id','=', 'save_telemedical_booking_detail.appointment_id')->leftJoin('patients', 'save_telemedical_booking_detail.patient_id','=', 'patients.patient_unique_id');
                if($time === '1') {                                
                    $query->where('save_telemedical_booking_detail.appointment_time', '>=', $start_time)->where('save_telemedical_booking_detail.appointment_time', '<', $end_time)->where('save_telemedical_booking_detail.approved_status','!=',2)->whereIn('save_telemedical_booking_detail.doctor_id',$doctor_id);
                }else if($time === '2'){
                   $query->where('save_telemedical_booking_detail.appointment_time', '>', $end_time)->where('save_telemedical_booking_detail.approved_status','!=',2)->whereIn('save_telemedical_booking_detail.doctor_id',$doctor_id);
                }else if($time === '3'){
                    $query->where('save_telemedical_booking_detail.appointment_time', '<', $start_time)->where('save_telemedical_booking_detail.approved_status','!=',2)->whereIn('save_telemedical_booking_detail.doctor_id',$doctor_id);
                }
            $appointments = $query->orderBy('save_telemedical_booking_detail.appointment_time','DESC')->paginate(20);
         //~ echo '<pre>'; print_r($appointments); die('here');
        }
        foreach($appointments as $app)
        {
            SaveTelemedicalBookingDetail::where('id', $app->st_id)->update(['status' => 0]);
        }
       
       // $today_appointment=SaveTelemedicalBookingDetail::whereI('doctor_id',$doctor_id)->where('save_telemedical_booking_detail.approved_status','!=',2)->where('appointment_time','>=',$start_time)->where('appointment_time','<',$end_time)->get();
        // $status = SaveTelemedicalBookingDetail::where('doctor_id',$doctor_id)->where('call_status','>',0)->count();        
        // $disabled = 0;
        // if($status > 0){
        //     $disabled = 1;
        // }
        $disabled = 1;
        return view('nurse.all_appointments_ajax')->with(array('controller'=> 'nurse','appointments'=>$appointments,'today_appointments_count'=>0,'page'=>'inner','disabled'=>$disabled,'nurse_details'=>$nurse_details,'timezone'=>$time_zone));
    
    }//Ends My schedule pagination ajax function

    public function appointmentDetail(Request $request,$id)
    {    
        $value = Session::get('nurse_token');
        $nurse_id = Auth::user()->nurse_id;
        $login_token =NurseLoginToken::where(array('nurse_id'=>$nurse_id,'login_token'=>$value))->first();        
        if(isset($login_token->token_status) && $login_token->token_status == 0){ 
            Auth::guard('nurse')->logout();           
            return response()->json(['redirect'=>1,"redirect_url"=>asset('/nurse/login')],200);
        }
        if(!Auth::check()){            
            return response()->json(['redirect'=>1,"redirect_url"=>asset('/nurse/login')],200);
        }          
        
        $nurse_details = Nurse::where('nurse_id',$nurse_id)->first();       
        $time_zone = $nurse_details->nurse_timezone; 
        $dtz = new DateTimeZone($time_zone);
        $time_in_sofia = new DateTime('now', $dtz);        
        $date_offset = $time_in_sofia->format('Z');
        $start_time = strtotime(date("Y-m-d"))-$date_offset;
        $end_time = strtotime(date("Y-m-d",strtotime("+1 day")))-$date_offset;       

        $appoint_detail=SaveTelemedicalBookingDetail::with(array("patient_detail","doctor.specialist_categories","patient_appoint","hospital_detail"))->where("save_telemedical_booking_detail.booking_id",$id)->get();
        // Get diary attachement details
            if(!empty($appoint_detail)){
            $health_diary_array=explode(',', $appoint_detail[0]->health_diary);

            $diary_details=PatientHealthDiary::whereIn('patient_health_diary.diary_id', $health_diary_array)->leftJoin('health_diary_attachments', 'patient_health_diary.diary_id','=', 'health_diary_attachments.diary_id')->groupBy('patient_health_diary.diary_id')->get();
            }else{
            $diary_details="";
            }

        return view('nurse.appointment_detail')->with(array('controller'=> 'doctor','page_type'=>'extra_links','page'=>'inner','appointment'=>$appoint_detail,'nurse_details'=>$nurse_details,'timezone'=>$time_zone,'today_appointments_count'=>0,"diary_details"=>$diary_details));
    }

    public function resheduleDetail(Request $request){
        $value = Session::get('nurse_token');
        $nurse_id = Auth::user()->nurse_id;
        $login_token =NurseLoginToken::where(array('nurse_id'=>$nurse_id,'login_token'=>$value))->first();        
        if(isset($login_token->token_status) && $login_token->token_status == 0){ 
            Auth::guard('nurse')->logout();           
            return response()->json(['redirect'=>1,"redirect_url"=>asset('/nurse/login')],200);
        }
        if(!Auth::check()){            
            return response()->json(['redirect'=>1,"redirect_url"=>asset('/nurse/login')],200);
        }                
        $nurse_details = Nurses::where('nurse_id',$nurse_id)->first();
        $time_zone = $nurse_details->nurse_timezone;
        $dtz = new DateTimeZone($time_zone);     
        $date = date('Y-m-d',strtotime($_POST['appoint_date']));   
        $next_date = date('Y-m-d', strtotime('+1 day', strtotime($date)));
        $time_in_sofia = new DateTime($date, $dtz);        
        $date_offset = $time_in_sofia->format('Z');       
        $start_time = strtotime($date)-$date_offset;
        
        $end_time = strtotime($next_date)-$date_offset;

        $appoint_detail=SaveTelemedicalBookingDetail::with(array("patient_detail","doctor.specialist_categories","patient_appoint"))->where("save_telemedical_booking_detail.booking_id",$_POST['book_id'])->first();
        
        if($appoint_detail->patient_appoint->appointment_type == 2){
            $doctor_avail_time=Doctor::with(array('doctor_availability'=>function($q) use($start_time,$end_time) {$q->where('availability_date','>=',$start_time); $q->where('availability_date','<',$end_time); $q->where('type',2);}))->with('specialist_categories')->whereHas('doctor_availability', function($q) use($start_time,$end_time) {$q->where('availability_date','>=',$start_time); $q->where('availability_date','<',$end_time); $q->where('type',2);})->where('doctor_id',$appoint_detail->doctor_id)->select("*")->first();
            if(isset($doctor_avail_time->doctor_id)){
                $doctor_avail_time = $doctor_avail_time->toArray();
            }
        }elseif($appoint_detail->patient_appoint->appointment_type == 1){
            $doctor_avail_time=Doctor::with(array('doctor_availability'=>function($q) use($start_time,$end_time) {$q->where('availability_date','>=',$start_time); $q->where('availability_date','<',$end_time);$q->where('type',1);}))->with('specialist_categories')->whereHas('doctor_availability', function($q) use($start_time,$end_time) {$q->where('availability_date','>=',$start_time); $q->where('availability_date','<',$end_time);$q->where('type',1);})->where('doctor_id',$appoint_detail->doctor_id)->select("*")->first();
            if(isset($doctor_avail_time->doctor_id)){
                $doctor_avail_time = $doctor_avail_time->toArray();
            }
        }
        
        $doc_appoint_listing=SaveTelemedicalBookingDetail::where('save_telemedical_booking_detail.approved_status','!=',2)->where('save_telemedical_booking_detail.appointment_time','>=',$start_time)->where('save_telemedical_booking_detail.appointment_time','<',$end_time)->orderBy('save_telemedical_booking_detail.appointment_time','ASC')->where('doctor_id',$appoint_detail->doctor_id)->get();
       
        return view('nurse.reshedule')->with(array('controller'=> 'nurse','appointment'=>$appoint_detail,'doctor_avail_time'=>$doctor_avail_time,'nurse_details'=>$nurse_details,'doc_appoint_listing'=>$doc_appoint_listing,'timezone'=>$time_zone,'appoint_date'=>$_POST['appoint_date']));
    
    }  


    public function cancelBooking(Request $request){       
        $value = Session::get('nurse_token');
        $nurse_id = Auth::user()->nurse_id;
        $login_token =NurseLoginToken::where(array('nurse_id'=>$nurse_id,'login_token'=>$value))->first();        
        if(isset($login_token->token_status) && $login_token->token_status == 0){ 
            Auth::guard('nurse')->logout();           
            return response()->json(['redirect'=>1,"redirect_url"=>asset('/nurse/login')],200);
        }
        if(!Auth::check()){            
            return response()->json(['redirect'=>1,"redirect_url"=>asset('/nurse/login')],200);
        }       

        $update_status = SaveTelemedicalBookingDetail::where('booking_id',$_POST['book_id'])->update(['approved_status'=>2]);
        if($update_status > 0){
            return response()->json(['success'=>1], 200);
        }else{
            return response()->json(['success'=>0,'message'=>'Something went wrong'], 200);
        }        
    }

    /******
    set Availability function
    *******/
    public function saveAppointments(Request $request)
    {     
        $value = Session::get('nurse_token');
        $patient_id = Auth::user()->doctor_id;
        $login_token =NurseLoginToken::where(array('doctor_id'=>$patient_id,'login_token'=>$value))->first();        
        if(isset($login_token->token_status) && $login_token->token_status == 0){ 
            Auth::guard('nurse')->logout();           
            return response()->json(['redirect'=>1,"redirect_url"=>asset('/nurse/login')],200);
        }
        if(!Auth::check()){            
            return response()->json(['redirect'=>1,"redirect_url"=>asset('/nurse/login')],200);
        }
        $user = $request->user();
        
        $doctor_id= $user->doctor_id;

        $combined_time = array();
        $hosp_start_time=$_POST['hosp_start_time'];         
        $hosp_end_time=$_POST['hosp_end_time'];         
        $hidden_date_hosp=$_POST['hidden_date_hosp'];
        $hidden_start_date = $hidden_date_hosp.' '.$hosp_start_time;    
        $doctor_details = Doctor::where('doctor_id',$doctor_id)->first();
        $target_time_zone = new DateTimeZone($doctor_details->doctor_timezone);  
        $date_time = new DateTime('now', $target_time_zone);  
        $offset = $date_time->format('Z');        
        $hidden_start_hosp1= strtotime($hidden_start_date) - $offset;     
        $hidden_end_date = $hidden_date_hosp.' '.$hosp_end_time;             
        $hidden_end_hosp1= strtotime($hidden_end_date) - $offset;
        $hidden_hosp_type=$_POST['hidden_hosp_type'];
        $combined_time[] = $hidden_start_hosp1.'-'.$hidden_end_hosp1;
        $encode_time = json_encode($combined_time);        
        $final_date =  strtotime($hidden_start_date) - $offset;         
        //echo $date = strtotime(date('Y-m-d')) - $date_offset;
        $doctor_availability=DoctorAvailability::where('doctor_id',$doctor_id)->select('*')->get();
        $count = 0;
       
        if($hidden_end_hosp1 == $hidden_start_hosp1){
            return response()->json(['success'=>2], 200);
        }
        if($hidden_end_hosp1 < $hidden_start_hosp1){
            return response()->json(['success'=>3], 200);
        }
        if(count($doctor_availability) > 0){
            foreach($doctor_availability as $doc_avail){ 
                $avail_time = $doc_avail['availability_time'][0];               
                $exploded_time = explode("-",$avail_time);               
                if(($hidden_start_hosp1 >= $exploded_time[0] && $hidden_end_hosp1 <= $exploded_time[1]) || ($hidden_start_hosp1 >= $exploded_time[0] && $hidden_start_hosp1 < $exploded_time[1]) || ($hidden_end_hosp1 > $exploded_time[0] && $hidden_end_hosp1 <= $exploded_time[1]) || ($hidden_start_hosp1 < $exploded_time[0] && $hidden_end_hosp1 > $exploded_time[1])){
                    $count = 1;
                    break;
                }
                
            }
            if($count == 0){
                $DoctorAvailability = new DoctorAvailability([                
                    'availability_id'   => $this->generateUniqueNumber(),
                    'doctor_id'         => $doctor_id, 
                    'availability_date' => $final_date,
                    'availability_time' => $combined_time,
                    'type'              => $hidden_hosp_type,
                    'created_date'      => strtotime('now')                                               
                ]);
                $DoctorAvailability->save(); 
                return response()->json(['success'=>1], 200);
            }else{
                return response()->json(['success'=>0], 200);
            }
        }else{
            $DoctorAvailability = new DoctorAvailability([                
                'availability_id'   => $this->generateUniqueNumber(),
                'doctor_id'         => $doctor_id, 
                'availability_date' => $final_date,
                'availability_time' => $combined_time,
                'type'              => $hidden_hosp_type,
                'created_date'      => strtotime('now')                                               
            ]);
            $DoctorAvailability->save(); 
            return response()->json(['success'=>1], 200);
        }      
        
    }//Ends of set availability function


    public function availabilityBooking(Request $request){
        $value = Session::get('nurse_token');
        $patient_id = Auth::user()->doctor_id;
        $login_token =NurseLoginToken::where(array('doctor_id'=>$patient_id,'login_token'=>$value))->first();        
        if(isset($login_token->token_status) && $login_token->token_status == 0){ 
            Auth::guard('nurse')->logout();           
            return response()->json(['redirect'=>1,"redirect_url"=>asset('/nurse/login')],200);
        }
        if(!Auth::check()){            
            return response()->json(['redirect'=>1,"redirect_url"=>asset('/nurse/login')],200);
        }
        $user = $request->user();
        
        $doctor_id= $user->doctor_id;

        $doctor_details = Doctor::where('doctor_id',$doctor_id)->first();

        $time_zone = $doctor_details->doctor_timezone;
        $dtz = new DateTimeZone($time_zone);     
        $date = date('Y-m-d',strtotime($_POST['date']));   
        $next_date = date('Y-m-d', strtotime('+1 day', strtotime($date)));
        $time_in_sofia = new DateTime($date, $dtz);        
        $date_offset = $time_in_sofia->format('Z');       
        $start_time = strtotime($date)-$date_offset;
        $end_time = strtotime($next_date)-$date_offset;
        
        //echo $date = strtotime(date('Y-m-d')) - $date_offset;
        $doctor_availability=DoctorAvailability::where('doctor_id',$doctor_id)->select('*')->where('availability_date','>=',$start_time)->where('availability_date','<',$end_time)->get(); 
        $farray = [];       
        if(count($doctor_availability) > 0){                                                    
            date_default_timezone_set($doctor_details->doctor_timezone);                                    
            foreach($doctor_availability as $key=>$avail_time){                                                     
                $doctor_break = explode("-",$avail_time['availability_time'][0]);
                $farray[$key]['start_time'] = date('H:i',$doctor_break[0]);
                $farray[$key]['end_time'] = date('H:i',$doctor_break[1]);                                       
            }
            return response()->json(['success'=>1,'data'=>$farray], 200);
        }else{
            return response()->json(['success'=>1], 200);
        }

    }
    
    

    public function updateAppointments(Request $request){
        try{
            $value = Session::get('nurse_token');
            $patient_id = Auth::user()->doctor_id;
            $login_token =NurseLoginToken::where(array('doctor_id'=>$patient_id,'login_token'=>$value))->first();        
            if(isset($login_token->token_status) && $login_token->token_status == 0){ 
                Auth::guard('nurse')->logout();           
                return response()->json(['redirect'=>1,"redirect_url"=>asset('/nurse/login')],200);
            }
            if(!Auth::check()){            
                return response()->json(['redirect'=>1,"redirect_url"=>asset('/nurse/login')],200);
            }
            $user = $request->user();
            $doctor_id= $user->doctor_id;
            $doctor_details = Doctor::where('doctor_id',$doctor_id)->first();
            $appoint_time = $_POST['appoint_date']." ".$_POST['appoint_time'];

            $time_zone = $doctor_details->doctor_timezone;
            $dtz = new DateTimeZone($time_zone);     
            $date = date('Y-m-d H:i',strtotime($appoint_time));                   
            $time_in_sofia = new DateTime($date, $dtz);        
            $date_offset = $time_in_sofia->format('Z');       
            $appointment_time = strtotime($date)-$date_offset;         
            $update_time = SaveTelemedicalBookingDetail::where('booking_id',$_POST['book_id'])->update(['appointment_time'=>$appointment_time]);
            return response()->json(['success'=>1], 200);
        }catch(Exception $e) {
            return response()->json(['error'=>1,"message"=>$e->getMessage()],200);       
        } 
    }

    public function accountSetting(Request $request){
        try{
            $value = Session::get('nurse_token');
            $nurse_id = Auth::user()->nurse_id;
            $login_token =NurseLoginToken::where(array('nurse_id'=>$nurse_id,'login_token'=>$value))->first();        
            if(isset($login_token->token_status) && $login_token->token_status == 0){ 
                Auth::guard('nurse')->logout();           
                return redirect('/nurse/login');
            }
            if(!Auth::check()){            
                return redirect('/nurse/login');
            }        
            $nurse_details    = Nurse::where('nurse_id',$nurse_id)->first();  
            $time_zone        = $nurse_details->nurse_timezone;
            $nurseEmail       = $nurse_details->nurse_email;
            $nursePassword    = $nurse_details->nurse_password;
            $FormEmail        = $_POST['email'];
            $FormPassword     = $_POST['crt_password'];
      
            if($FormEmail !=  $nurseEmail){
                return response()->json(['success'=>0, 'message'=>"Email doesn't match with existing email"]);
            }else{
                $validatorAccount = Validator::make($request->all(),[
                    'email'=>'required|email',
                    'crt_password'=>'required',
                    'new_password'=>'required',
                    'cnfrm_password'=>'required|same:new_password'
                ]);
                if ($validatorAccount->fails()) {    
                    return response()->json(['success'=>0, 'message'=>$validatorAccount->messages()->first()], 200);
                }
            }

            if(Hash::check($FormPassword, $nursePassword))
            {
                Nurse::where('nurse_id', $nurse_id)->update(['nurse_password' => bcrypt($_POST['new_password'])]);
                return response()->json(['success'=>1,'message'=>'Password successfully updated']);
            }else{
                return response()->json(['success'=>0,'message'=>'Your current password does not match']);
            } 
        }catch(Exception $e){
            return response()->json(['error'=>1,"message"=>$e->getMessage()],200);       
        }     
    } 

     public function updateTimeZone(Request $request,$time_zone,$dst){
        $value = Session::get('nurse_token');
        $patient_id = Auth::user()->doctor_id;
        $login_token =NurseLoginToken::where(array('doctor_id'=>$patient_id,'login_token'=>$value))->first();        
        if(isset($login_token->token_status) && $login_token->token_status == 0){ 
            Auth::guard('nurse')->logout();           
            return response()->json(['redirect'=>1,"redirect_url"=>asset('/nurse/login')],200);
        }
        if(!Auth::check()){            
            return response()->json(['redirect'=>1,"redirect_url"=>asset('/nurse/login')],200);
        }
        $user = $request->user();
        $doctor_id= $user->doctor_id;
        if($dst == 1){
             $time_zone_name = timezone_name_from_abbr("", $time_zone*60,1); 
             if(empty($time_zone_name)){
                $time_zone_name = timezone_name_from_abbr("", $time_zone*60,0); 
             }
        }else{
            $time_zone_name = timezone_name_from_abbr("", $time_zone*60,1); 
             if(empty($time_zone_name)){
                $time_zone_name = timezone_name_from_abbr("", $time_zone*60,0); 
             }
        } 
        $update_time = Doctor::where('doctor_id',$doctor_id)->update(['doctor_timezone'=>$time_zone_name]);
        return response()->json(['success'=>1,"redirect_url"=>route('doctor.dashboard')], 200);      
    }

    public function saveTeleAppointments(Request $request)
    {                   
        echo "<pre>"; print_r($_POST); die('here');
    }

    protected function generateUniqueNumber() {
        $number = mt_rand(1000000000, 9999999999); // better than rand()
        // call the same function if the uniwue id exists already
        if ($this->uniqueNumberExists($number)) {
            return $this->generateUniqueNumber();
        }
        // otherwise, it's valid and can be used
        return strval($number);
    }

    protected function uniqueNumberExists($number) {
        // query the database and return a boolean         
        return CallSession::wherecall_id($number)->exists();
    }
       public function Getpatientdetail(Request $request){
                // Get patient details
                $value = Session::get('token');
                $doctor_id = Auth::user()->doctor_id;
                $login_token =DoctorLoginToken::where(array('doctor_id'=>$doctor_id,'login_token'=>$value))->first();        
                if(isset($login_token->token_status) && $login_token->token_status == 0){ 
                Auth::guard('doctor')->logout();           
                return response()->json(['redirect'=>1,"redirect_url"=>asset('/doctor/login')],200);
                }
                if(!Auth::check()){            
                return response()->json(['redirect'=>1,"redirect_url"=>asset('/doctor/login')],200);
                }

                $p_id=$request->patient_id;
                $mainarray=array();
                $patient_details = Patient::where('patient_unique_id',$p_id)->first();
                if(!empty($patient_details)){        
                $mainarray['name'] = $patient_details['patient_first_name']. ' '.$patient_details['patient_middle_name'].' '.$patient_details['patient_last_name'];
                $mainarray['gender'] =($patient_details['patient_gender'] == '1')? 'Female':'Male';
           
                $now = time(); 
                if(!empty($patient_details['patient_date_of_birth'])  && $patient_details['patient_date_of_birth']!=NULL){
                $mainarray['patient_date_of_birth'] = date('d F Y',$patient_details['patient_date_of_birth']);            
                $difference =  $now - $patient_details['patient_date_of_birth']; 
                //There are 31556926 seconds in a year.
                $age = floor($difference / 31556926);
                $mainarray['patient_age']=$age;

                }else{
                $mainarray['patient_date_of_birth'] = "--";     
                $mainarray['patient_age']=0; 
                }

            if($patient_details['patient_profile_img'] != "" && (file_exists(getcwd().'uploads/patient/'.$patient_details['patient_profile_img']))){
            $mainarray['patient_profile_img'] = asset('uploads/patient/'.$patient_details['patient_profile_img']);
            }
            else{
            $mainarray['patient_profile_img'] = asset('admin/doctor/images/profile.svg');
            }
                  $mainarray['languages'] =(!empty($patient_details['patient_languages']))? $patient_details['patient_languages']:'--';     
                $mainarray['patient_blood_type'] =(!empty($patient_details['patient_blood_type']))? $patient_details['patient_blood_type']:'NA';
                $mainarray['state_of_origin'] =(!empty($patient_details['patient_origin_state']))? $patient_details['patient_origin_state']:'--';
                $mainarray['patient_martial_status'] =($patient_details['patient_martial_status'] == '1')? 'Married':'Single';
                $mainarray['patient_address'] =(!empty($patient_details['patient_address']))? $patient_details['patient_address']:'--';
                
               return response()->json(['success'=>1,"patients_data"=> $mainarray],200);
                }
                else{
              return response()->json(['success'=>0,"patients_data"=>""],200);
                }


                }

}
