<?php
namespace App\Http\Controllers\Nurse;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Auth;
use DB;
use Validator;
use Redirect;
use DateTime;
use DateTimeZone;
use Session;
use File;
use App\Models\PatientLoginToken;
use App\Models\Patient;
use App\Models\HealthHistory;
use App\Models\HealthHistoryAttachments;
use App\Models\Doctor;
use App\Models\Nurse;
use App\Models\NurseLoginToken;
use App\Models\BillingDetail;
use App\Models\BillingService;
use App\Models\HealthHistoryMedication;

class NurseHealthHistoryController extends Controller
{
	/**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
       
        $this->middleware('auth:nurse');  
    }
    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */

        /******
    Medical Record List view
    *******/
    public function medicalRecordList(Request $request,$id)
    {    

        $value = Session::get('nurse_token');
        $nurse_id = Auth::user()->nurse_id;
        
        $login_token =NurseLoginToken::where(array('nurse_id'=>$nurse_id,'login_token'=>$value))->first();        
        if(isset($login_token->token_status) && $login_token->token_status == 0){ 
            Auth::guard('nurse')->logout();           
            return redirect('/nurse/login');
        }
        if(!Auth::check()){            
            return redirect('/nurse/login');
        } 
        
        $nurse_details = Nurse::where('nurse_id',$nurse_id)->first();
        $hospital_id = $nurse_details->hospital_id;
        $doctor_id = Doctor::where('hospital_id',$hospital_id)->select('doctor_id')->get();
        $time_zone = $nurse_details->nurse_timezone;             
        $dtz = new DateTimeZone($time_zone);
        $time_in_sofia = new DateTime('now', $dtz);        
        $date_offset = $time_in_sofia->format('Z');
        $start_time = strtotime(date("Y-m-d"))-$date_offset;
        $end_time = strtotime(date("Y-m-d",strtotime("+1 day")))-$date_offset;

        $health_history=HealthHistory::with(array('patient','doctor','nurse','employee','hospital','history_attachments','doctor.doctor_hospital_details','nurse.nurse_hospital_details','employee.employee_hospital_details'))->where('hospital_id',$hospital_id)->where('patient_id',$id)->orderBy('created_date','DESC')->paginate(20);  

        $patient_details = Patient::where('patient_unique_id',$id)->first();
        //echo "<pre>"; print_R($doctor_availability); exit;
        if($request->ajax()){
            return view('nurse.history_inner')->with(array('controller'=> 'nurse','health_history'=>$health_history,'page'=>'inner','nurse_details'=>$nurse_details,'timezone'=>$time_zone,'page_type'=>'health_history','patient_detail'=>$patient_details)); 
        }else{        
            return view('nurse.medical_record')->with(array('controller'=> 'nurse','health_history'=>$health_history,'page'=>'inner','nurse_details'=>$nurse_details,'timezone'=>$time_zone,'page_type'=>'health_history','patient_detail'=>$patient_details)); 
        }          
        
    }//Ends medical record function

    /******
    View Medical Record view
    *******/
    public function viewRecord(Request $request,$id)
    {    

        $value = Session::get('nurse_token');
        $nurse_id = Auth::user()->nurse_id;
        
        $login_token =NurseLoginToken::where(array('nurse_id'=>$nurse_id,'login_token'=>$value))->first();        
        if(isset($login_token->token_status) && $login_token->token_status == 0){ 
            Auth::guard('nurse')->logout();           
            return redirect('/nurse/login');
        }
        if(!Auth::check()){            
            return redirect('/nurse/login');
        } 
        
        $nurse_details = Nurse::where('nurse_id',$nurse_id)->first();
        $hospital_id = $nurse_details->hospital_id;
        $doctor_id = Doctor::where('hospital_id',$hospital_id)->select('doctor_id')->get();
        $time_zone = $nurse_details->nurse_timezone;                  
        $dtz = new DateTimeZone($time_zone);
        $time_in_sofia = new DateTime('now', $dtz);        
        $date_offset = $time_in_sofia->format('Z');
        $start_time = strtotime(date("Y-m-d"))-$date_offset;
        $end_time = strtotime(date("Y-m-d",strtotime("+1 day")))-$date_offset;    

        
        $health_history=HealthHistory::with(array('patient','doctor','nurse','employee','hospital','history_attachments','doctor_update','nurse_update','employee_update','hospital_update','history_medication'))->where('health_history.history_id',$id)->first();

        $billing_detail = BillingDetail::where('history_id',$id)->orderBy('billing_date','DESC')->paginate(5);
        if($request->ajax()){
            return view('nurse.health_history_bill_inner')->with(array('controller'=> 'nurse','page'=>'inner','nurse_details'=>$nurse_details,'timezone'=>$time_zone,'page_type'=>'health_history','health_history'=>$health_history,'billing_detail'=>$billing_detail)); 
        }else{
            return view('nurse.view_medical_record')->with(array('controller'=> 'nurse','page'=>'inner','nurse_details'=>$nurse_details,'timezone'=>$time_zone,'page_type'=>'health_history','health_history'=>$health_history,'billing_detail'=>$billing_detail)); 
        }
           
        
    }//Ends view record function

    /******
    Add Medical Record view
    *******/
    public function addRecord(Request $request,$id)
    {    

        $value = Session::get('nurse_token');
        $nurse_id = Auth::user()->nurse_id;        
        $login_token =NurseLoginToken::where(array('nurse_id'=>$nurse_id,'login_token'=>$value))->first();        
        if(isset($login_token->token_status) && $login_token->token_status == 0){ 
            Auth::guard('nurse')->logout();           
            return redirect('/nurse/login');
        }
        if(!Auth::check()){            
            return redirect('/nurse/login');
        }         
        $nurse_details = Nurse::where('nurse_id',$nurse_id)->first();
        $hospital_id = $nurse_details->hospital_id;
        $doctor_id = Doctor::where('hospital_id',$hospital_id)->select('doctor_id')->get();
        $time_zone = $nurse_details->nurse_timezone;   
             
        $patient_details = Patient::where('patient_unique_id',$id)->first();        
        //echo "<pre>"; print_R($doctor_availability); exit;
        return view('nurse.add_medical_record')->with(array('controller'=> 'nurse','page'=>'inner','nurse_details'=>$nurse_details,'timezone'=>$time_zone,'page_type'=>'appointments','patient_detail'=>$patient_details,'patient_id'=>$id));    
        
    }//Ends add record function

    /******
    Edit Medical Record view
    *******/
    public function editRecord(Request $request,$id)
    {    

        $value = Session::get('nurse_token');
        $nurse_id = Auth::user()->nurse_id;
        
        $login_token =NurseLoginToken::where(array('nurse_id'=>$nurse_id,'login_token'=>$value))->first();        
        if(isset($login_token->token_status) && $login_token->token_status == 0){ 
            Auth::guard('nurse')->logout();           
            return redirect('/nurse/login');
        }
        if(!Auth::check()){            
            return redirect('/nurse/login');
        } 
        
        $nurse_details = Nurse::where('nurse_id',$nurse_id)->first();
        $hospital_id = $nurse_details->hospital_id;
        $doctor_id = Doctor::where('hospital_id',$hospital_id)->select('doctor_id')->get();
        $time_zone = $nurse_details->nurse_timezone;                   
        $dtz = new DateTimeZone($time_zone);
        $time_in_sofia = new DateTime('now', $dtz);        
        $date_offset = $time_in_sofia->format('Z');
        $start_time = strtotime(date("Y-m-d"))-$date_offset;
        $end_time = strtotime(date("Y-m-d",strtotime("+1 day")))-$date_offset;       

        $patient_details = Patient::where('patient_unique_id',$id)->first();
        $health_history=HealthHistory::with(array('patient','doctor','history_attachments','doctor_update'))->where('health_history.history_id',$id)->first();
        //echo "<pre>"; print_R($doctor_availability); exit;
        return view('nurse.edit_medical_record')->with(array('controller'=> 'nurse','page'=>'inner','nurse_details'=>$nurse_details,'timezone'=>$time_zone,'page_type'=>'appointments','patient_detail'=>$patient_details,'health_history'=>$health_history));    
        
    }//Ends edit record function

    public function saveMedicalRecord(Request $request){
        try{             
            //echo "<pre>"; print_R($_FILES); exit;
        	$value = Session::get('nurse_token');
            $nurse_id = Auth::user()->nurse_id;
            
            $login_token =NurseLoginToken::where(array('nurse_id'=>$nurse_id,'login_token'=>$value))->first();        
            if(isset($login_token->token_status) && $login_token->token_status == 0){ 
                Auth::guard('nurse')->logout();           
                return response()->json(['redirect'=>1,"redirect_url"=>asset('/nurse/login')],200);
            }
            if(!Auth::check()){            
                return response()->json(['redirect'=>1,"redirect_url"=>asset('/nurse/login')],200);
            } 
            
            $nurse_details = Nurse::where('nurse_id',$nurse_id)->first();
            $hospital_id = $nurse_details->hospital_id;
            $doctor_id = Doctor::where('hospital_id',$hospital_id)->select('doctor_id')->get();
            $time_zone = $nurse_details->nurse_timezone;          
            $medical_time = strtotime("now");
            if(isset($_POST['edit']) && $_POST['edit'] == 1){
                $validator = Validator::make($_POST, [                  
                   /* 'temperature' => 'required',                 
                    'temprature_type' => 'required',              
                    'pulse_rate' => 'required',               
                    'resp_rate' => 'required',               
                    'bp_syt' => 'required',
                    'bp_dia' => 'required',  */
                    'history_id' => 'required',           
                    'record_attach'=>'image|max:10000'                              
                ], [
                    'record_attach.max' => 'Image size should be as less then 10 Mb',
                ]);
                if($validator->fails()){
                    return response()->json(['success'=>0, 'message'=>$validator->messages()->first()], 200);
                }

                $update_health_history = HealthHistory::where('history_id',$_POST['history_id'])->update(['temperature'=> $_POST['temperature'],'temprature_type'=> $_POST['temprature_type'],'measuring_type'=> $_POST['degree_type'],'pulse'=> $_POST['pulse_rate'],'respiratory_rate'=> $_POST['resp_rate'],'bp_sys'=> $_POST['bp_syt'],'bp_dia'=> $_POST['bp_dia'],'general_notes'=> $_POST['general_notes'],'plan'=> $_POST['plan'],'cvs_det'=> $_POST['cvs'],'respiratory_det'=> $_POST['resp_analysis'],'abdomen_det'=> $_POST['abd_rate'],'cns_det'=> $_POST['cns'],'rbc_det'=> $_POST['rbc'],'wbc_det'=> $_POST['wbc'],'hb_det'=> $_POST['hb_rate'],'hmt_det'=> $_POST['hb_per'],'plt_det'=> $_POST['plt'],'ch_ldl_det'=> $_POST['chl_mil'],'ch_hdl_det'=> $_POST['chl_ldl'],'updated_date'=> $medical_time,'updated_doc'=> NULL ,'updated_nurse'=> $nurse_id,'updated_employee'=> NULL,'updated_hospital'=> NULL,'musculoskeletal'=> $_POST['musculoskeletal'],'heent'=> $_POST['heent'],'urinary'=> $_POST['urinary'],'other_system'=> $_POST['other_system'],'weight'=> $_POST['weight'],'height'=> $_POST['height']]);
            }else{
                $validator = Validator::make($_POST, [                  
                   /* 'temperature' => 'required',                 
                    'temprature_type' => 'required',              
                    'pulse_rate' => 'required',               
                    'resp_rate' => 'required',               
                    'bp_syt' => 'required',   
                    'bp_dia' => 'required', */           
                    'record_attach'=>'image|max:10000'                              
                ], [
                    'record_attach.max' => 'Image size should be as less then 10 Mb',
                ]);
                if($validator->fails()){
                    return response()->json(['success'=>0, 'message'=>$validator->messages()->first()], 200);
                }

                if(!empty($_POST['general_notes']) && trim($_POST['general_notes']) != ""){
                    $general_notes = trim($_POST['general_notes']);
                }else{
                    $general_notes = NULL;
                }

                if(!empty($_POST['plan']) && trim($_POST['plan']) != ""){
                    $plan = trim($_POST['plan']);
                }else{
                    $plan = NULL;
                }

                if(!empty($_POST['cvs']) && trim($_POST['cvs']) != ""){
                    $cvs = trim($_POST['cvs']);
                }else{
                    $cvs = NULL;
                }

                if(!empty($_POST['resp_analysis']) && trim($_POST['resp_analysis']) != ""){
                    $resp_analysis = trim($_POST['resp_analysis']);
                }else{
                    $resp_analysis = NULL;
                }

                if(!empty($_POST['abd_rate']) && trim($_POST['abd_rate']) != ""){
                    $abd_rate = trim($_POST['abd_rate']);
                }else{
                    $abd_rate = NULL;
                }

                if(!empty($_POST['cns']) && trim($_POST['cns']) != ""){
                    $cns = trim($_POST['cns']);
                }else{
                    $cns = NULL;
                }

                if(!empty($_POST['rbc']) && trim($_POST['rbc']) != ""){
                    $rbc = trim($_POST['rbc']);
                }else{
                    $rbc = NULL;
                }

                if(!empty($_POST['wbc']) && trim($_POST['wbc']) != ""){
                    $wbc = trim($_POST['wbc']);
                }else{
                    $wbc = NULL;
                }

                if(!empty($_POST['plt']) && trim($_POST['plt']) != ""){
                    $plt = trim($_POST['plt']);
                }else{
                    $plt = NULL;
                }

                if(!empty($_POST['hb_rate']) && trim($_POST['hb_rate']) != ""){
                    $hb_rate = trim($_POST['hb_rate']);
                }else{
                    $hb_rate = NULL;
                }

                if(!empty($_POST['hb_per']) && trim($_POST['hb_per']) != ""){
                    $hb_per = trim($_POST['hb_per']);
                }else{
                    $hb_per = NULL;
                }

                if(!empty($_POST['hb_per']) && trim($_POST['hb_per']) != ""){
                    $hb_per = trim($_POST['hb_per']);
                }else{
                    $hb_per = NULL;
                }

                if(!empty($_POST['chl_mil']) && trim($_POST['chl_mil']) != ""){
                    $chl_mil = trim($_POST['chl_mil']);
                }else{
                    $chl_mil = NULL;
                }

                if(!empty($_POST['chl_ldl']) && trim($_POST['chl_ldl']) != ""){
                    $chl_ldl = trim($_POST['chl_ldl']);
                }else{
                    $chl_ldl = NULL;
                }
                 if(!empty($_POST['musculoskeletal']) && trim($_POST['musculoskeletal']) != ""){
                $musculoskeletal = trim($_POST['musculoskeletal']);
                }else{
                $musculoskeletal = NULL;
                }
                if(!empty($_POST['urinary']) && trim($_POST['urinary']) != ""){
                $urinary = trim($_POST['urinary']);
                }else{
                $urinary = NULL;
                }
                if(!empty($_POST['heent']) && trim($_POST['heent']) != ""){
                 $heent = trim($_POST['heent']);
                }else{
                 $heent = NULL;
                }
                if(!empty($_POST['other_system']) && trim($_POST['other_system']) != ""){
                $other_system = trim($_POST['other_system']);
                }else{
                $other_system = NULL;
                }


                $HealthHistory = new HealthHistory([                
                    'history_id'        => $this->generateUniqueNumber(),
                    'nurse_id'          => $nurse_id,
                    'hospital_id'       => $hospital_id,
                    'assignee_type'     => 2,
                    'patient_id'        => $_POST['patient_id'], 
                    'temperature'       => trim($_POST['temperature']),
                    'temprature_type'   => trim($_POST['temprature_type']),
                    'measuring_type'    => trim($_POST['degree_type']),
                    'pulse'             => trim($_POST['pulse_rate']),
                    'respiratory_rate'  => trim($_POST['resp_rate']),
                    'bp_sys'            => trim($_POST['bp_syt']),
                    'bp_dia'            => trim($_POST['bp_dia']),
                    'general_notes'     => $general_notes,
                    'plan'              => $plan,
                    'cvs_det'           => $cvs,
                    'respiratory_det'   => $resp_analysis,
                    'abdomen_det'       => $abd_rate,
                    'cns_det'           => $cns,
                    'rbc_det'           => $rbc,
                    'wbc_det'           => $wbc,
                    'hb_det'            => $hb_rate,
                    'hmt_det'           => $hb_per,
                    'plt_det'           => $plt,
                    'ch_ldl_det'        => $chl_mil,
                    'ch_hdl_det'        => $chl_ldl,
                    'created_date'      => $medical_time,
                    'updated_date'      => $medical_time,
                    'updated_nurse'     => $nurse_id ,
                    'urinary'           =>$urinary,
                    'heent'           =>$heent,
                    'other_system'      =>$other_system,
                    'musculoskeletal'   =>$musculoskeletal,
                    'height'            => trim($_POST['height']),
                    'weight'            => trim($_POST['weight'])                                               
                ]);
                $HealthHistory->save(); 
            }       
            $current_time = strtotime("now");  

            if(isset($_POST['imagesLength']) && $_POST['imagesLength'] > 0){
                $_POST['attach_type'] = json_decode($_POST['attach_type']);
                $_POST['centre_name'] = json_decode($_POST['centre_name']);
                $status = 0;
                $attach_arr = array();
                for($i=1;$i <= $_POST['imagesLength'];$i++)
                {

                    if(isset($_FILES['attachments'.$i.''])){  
                        $extension = $request->file('attachments'.$i.'')->getClientOriginalExtension();                       
                        $filename =  $_FILES['attachments'.$i.'']['name'];                          
                        $destinationPath = public_path().'/admin/nurse/uploads/hhistory';
                        if(isset($_POST['edit']) && $_POST['edit'] == 1){
                            $history_id = $_POST['history_id'];
                        }else{
                            $history_id = $HealthHistory->history_id;
                        }
                        
                        
                        if(!is_dir($destinationPath."/".$history_id))
                        {
                            mkdir($destinationPath."/".$history_id);
                            chmod($destinationPath."/".$history_id, 0777);
                            $status = 1;
                        }         
                        
                        if(isset($_POST['edit']) && $_POST['edit'] == 1){
                            if($status == 1){                                
                                if(file_exists($destinationPath."/".$history_id."/".$request->file('attachments'.$i.'')->getClientOriginalName())){                   
                                    $files = glob($destinationPath."/".$history_id . '/*');
                                    foreach ($files as $file) {
                                        if (is_dir($file)) {
                                            rmdir($file);
                                        } else {
                                            unlink($file);
                                        }
                                    }                                
                                    rmdir($destinationPath."/".$history_id);
                                    HealthHistoryAttachments::where('patient_history_id',$history_id)->delete(); 
                                    return response()->json(['success'=>0, 'message'=>'File with same name already exists'], 200);
                                }
                                
                            }else{
                                if(file_exists($destinationPath."/".$history_id."/".$request->file('attachments'.$i.'')->getClientOriginalName())){                   
                                    if(count($attach_arr) > 0){                                        
                                        foreach ($attach_arr as $file) {
                                            $attachments= HealthHistoryAttachments::where('patient_attachment_id',$file)->first();
                                            if(file_exists($destinationPath."/".$history_id."/".$attachments->patient_attachment_name)){
                                                unlink($destinationPath."/".$history_id."/".$attachments->patient_attachment_name);
                                            }
                                        } 
                                        $count = count(glob($destinationPath."/".$history_id . '/*')); 
                                        if($count == 0){
                                            rmdir($destinationPath."/".$history_id);
                                        }                          
                                        HealthHistoryAttachments::where('patient_attachment_id',$attachments->patient_attachment_id)->delete();
                                    }    
                                    return response()->json(['success'=>0, 'message'=>'File with same name already exists'], 200);
                                }
                                
                            }
                            
                        }else{
                            if(file_exists($destinationPath."/".$history_id."/".$request->file('attachments'.$i.'')->getClientOriginalName())){                            
                                HealthHistory::where('history_id',$history_id)->delete();
                                HealthHistoryAttachments::where('patient_history_id',$history_id)->delete();
                                $files = glob($destinationPath."/".$history_id . '/*');
                                foreach ($files as $file) {
                                    if (is_dir($file)) {
                                        rmdir($file);
                                    } else {
                                        unlink($file);
                                    }
                                }
                                rmdir($destinationPath."/".$history_id);
                                return response()->json(['success'=>0, 'message'=>'File with same name already exists'], 200);
                            }
                        }
                        $request->file('attachments'.$i.'')->move($destinationPath."/".$history_id, $filename);                         
                                               
                        //echo "<pre>"; print_R($_POST['centre_name'][$i-1]); exit;
                        $HealthHistoryAttachments = new HealthHistoryAttachments([                
                            'patient_attachment_id'     => $this->generateUniqueNumber(),
                            'patient_history_id'        => $history_id, 
                            'patient_id'                => $_POST['patient_id'],
                            'patient_lab_name'         => $_POST['centre_name'][$i-1],
                            'attachment_type'           => $_POST['attach_type'][$i-1],                              
                            'patient_attachment_name'   => $filename,   
                            'type'                      => 1,                                       
                            'created_at'                => $current_time                                              
                        ]);
                        $HealthHistoryAttachments->save(); 
                        array_push($attach_arr, $HealthHistoryAttachments->patient_attachment_id);

                    }
                }
             
            }            

            if(isset($_POST['medi_name'])){  
                $_POST['medi_name'] = json_decode($_POST['medi_name']);
                $_POST['medi_type'] = json_decode($_POST['medi_type']);
                $_POST['medi_procedure'] = json_decode($_POST['medi_procedure']);
                $_POST['medi_quantity'] = json_decode($_POST['medi_quantity']); 

                if(isset($_POST['edit']) && $_POST['edit'] == 1){
                    $history_id = $_POST['history_id'];
                }else{
                    $history_id = $HealthHistory->history_id;
                }                
                foreach($_POST['medi_name'] as $key=>$medi_name){
                    $HealthHistoryMedication = new HealthHistoryMedication([        
                        'health_history_id'     =>  $history_id, 
                        'patient_id'            =>  $_POST['patient_id'],
                        'nurse_id'              =>  $nurse_id, 
                        'medi_name'             =>  $medi_name, 
                        'medi_type'             =>  $_POST['medi_type'][$key],                
                        'medi_procedure'        =>  $_POST['medi_procedure'][$key],
                        'quantity'              =>  $_POST['medi_quantity'][$key],
                        'created_date'                => $current_time                                            
                    ]);
                    $HealthHistoryMedication->save();
                }
            }



            if(isset($_POST['record_attach_len']) && $_POST['record_attach_len'] > 0){

                for($i=0;$i < $_POST['record_attach_len'];$i++)
                {
                    if(isset($_FILES['record_attach'.$i.''])){
                        $extension = $request->file('record_attach'.$i.'')->getClientOriginalExtension();                       
                        $filename =  $_FILES['record_attach'.$i.'']['name'];    
                        $destinationPath = public_path().'/admin/nurse/uploads/hhistory';
                        if(isset($_POST['edit']) && $_POST['edit'] == 1){
                            $history_id = $_POST['history_id'];
                        }else{
                            $history_id = $HealthHistory->history_id;
                        }

                        if(!is_dir($destinationPath."/".$history_id))
                        {
                            mkdir($destinationPath."/".$history_id);
                            chmod($destinationPath."/".$history_id, 0777);                            
                        } 

                        if(!is_dir($destinationPath."/".$history_id."/original_record"))
                        {
                            mkdir($destinationPath."/".$history_id."/original_record");
                            chmod($destinationPath."/".$history_id."/original_record", 0777);
                            $status = 1;
                        } 
                        
                        if(file_exists($destinationPath."/".$history_id."/original_record".$request->file('record_attach'.$i.'')->getClientOriginalName())){                            
                            HealthHistory::where('history_id',$history_id)->delete();
                            HealthHistoryAttachments::where('patient_history_id',$history_id)->delete();
                            $files = glob($destinationPath."/".$history_id . '/original_record' . '/*');
                            foreach ($files as $file) {
                                if (is_dir($file)) {
                                    rmdir($file);
                                } else {
                                    unlink($file);
                                }
                            }
                            rmdir($destinationPath."/".$history_id);
                            return response()->json(['success'=>0, 'message'=>'File with same name already exists'], 200);
                        }                                 
                        
                        $request->file('record_attach'.$i.'')->move($destinationPath."/".$history_id."/original_record", $filename);
                        $current_time = strtotime("now");
                        $HealthHistoryAttachments = new HealthHistoryAttachments([                
                            'patient_attachment_id'     => $this->generateUniqueNumber(),
                            'patient_history_id'        => $history_id, 
                            'patient_id'                => $_POST['patient_id'], 
                            'patient_attachment_name'   => $filename,   
                            'type'                      => 2,              
                            'created_at'                => $current_time                                              
                        ]);
                        $HealthHistoryAttachments->save(); 
                    }
                }
            } 
            return response()->json(['success'=>1], 200);
        }catch(Exception $e) {
            return response()->json(['error'=>1,"message"=>$e->getMessage()],200);       
        } 

    }

    public function saveBillDetails(Request $request){
        try{  
            $value = Session::get('nurse_token');
            $nurse_id = Auth::user()->nurse_id;
            
            $login_token =NurseLoginToken::where(array('nurse_id'=>$nurse_id,'login_token'=>$value))->first();        
            if(isset($login_token->token_status) && $login_token->token_status == 0){ 
                Auth::guard('nurse')->logout();           
                return response()->json(['redirect'=>1,"redirect_url"=>asset('/nurse/login')],200);
            }
            if(!Auth::check()){            
                return response()->json(['redirect'=>1,"redirect_url"=>asset('/nurse/login')],200);
            } 
            
            $nurse_details = Nurse::where('nurse_id',$nurse_id)->first();
            $hospital_id = $nurse_details->hospital_id;
            $doctor_id = Doctor::where('hospital_id',$hospital_id)->select('doctor_id')->get();
            $time_zone = $nurse_details->nurse_timezone; 
            $validator = Validator::make($_POST, [                                
                'patient_id'    => 'required',
                'history_id'    => 'required',               
                'total'         => 'required'          
              ]);
            if($validator->fails()){
                return response()->json(['success'=>0, 'message'=>$validator->messages()->first()], 200);
            }

            if(count($_POST['ser_nm']) < count($_POST['bill_amt'])){
                return response()->json(['success'=>0, 'message'=>'Please enter all the service name'], 200);
            }

            if(count($_POST['ser_nm']) > count($_POST['bill_amt'])){
                return response()->json(['success'=>0, 'message'=>'Please enter all the bill amounts.'], 200);
            }
                             
            $dtz = new DateTimeZone($time_zone);
            $time_in_sofia = new DateTime('now', $dtz);        
            $date_offset = $time_in_sofia->format('Z');
            $bill_time = strtotime("now");            

            $BillingDetail = new BillingDetail([                
                'billing_id'        => $this->generateUniqueNumber(),
                'nurse_id'          => $nurse_id, 
                'hospital_id'       => $nurse_details->hospital_id,
                'assignee_type'     => 2,
                'patient_id'        => $_POST['patient_id'], 
                'invoice_number'    => $this->generateUniqueNumber(),
                'payable_amount'    => $_POST['total'],
                'history_id'        => $_POST['history_id'],
                'billing_date'      => $bill_time                                                              
            ]);
            $BillingDetail->save(); 

            foreach($_POST['ser_nm'] as $key=>$ser_nm){
                $BillingService = new BillingService([                
                    'pbilling_id'       => $BillingDetail->billing_id,
                    'service_name'      => trim($ser_nm), 
                    'service_amount'    => trim($_POST['bill_amt'][$key]),                     
                    'service_date'      => $bill_time                                                              
                ]);
                $BillingService->save(); 
            }

            return response()->json(['success'=>1,"message"=>"Billing added successfully"],200);   


        }catch(Exception $e) {
            return response()->json(['error'=>1,"message"=>$e->getMessage()],200);       
        } 
    }

    public function deleteHistoryImages(Request $request,$attach_id){
        try{
            $value = Session::get('nurse_token');
            $nurse_id = Auth::user()->nurse_id;
            
            $login_token =NurseLoginToken::where(array('nurse_id'=>$nurse_id,'login_token'=>$value))->first();        
            if(isset($login_token->token_status) && $login_token->token_status == 0){ 
                Auth::guard('nurse')->logout();           
                return response()->json(['redirect'=>1,"redirect_url"=>asset('/nurse/login')],200);
            }
            if(!Auth::check()){            
                return response()->json(['redirect'=>1,"redirect_url"=>asset('/nurse/login')],200);
            } 
            
            $nurse_details = Nurse::where('nurse_id',$nurse_id)->first();
            $hospital_id = $nurse_details->hospital_id;
            $doctor_id = Doctor::where('hospital_id',$hospital_id)->select('doctor_id')->get();
            $time_zone = $nurse_details->nurse_timezone; 
            
            $image_det = HealthHistoryAttachments::where('patient_attachment_id',$attach_id)->get();        
            if(count($image_det) > 0){                                              
                $path = public_path('/admin/doctor/uploads/hhistory');
                if(file_exists($path."/".$image_det[0]->patient_history_id."/".$image_det[0]->patient_attachment_name)){
                    unlink($path."/".$image_det[0]->patient_history_id."/".$image_det[0]->patient_attachment_name);
                }
                HealthHistoryAttachments::where('patient_attachment_id',$attach_id)->delete();                                         

                return response()->json(['success'=>1],200);
            }else{
                return response()->json(['success'=>0,'message'=>"Image not found"],200);
            }     
        }catch(Exception $e) {
             return response()->json(['error'=>1,"message"=>$e->getMessage()],200);  
        }

    }

    public function deleteHistoryMedication(Request $request,$medi_id){
        try{
            $value = Session::get('nurse_token');
            $nurse_id = Auth::user()->nurse_id;
            
            $login_token =NurseLoginToken::where(array('nurse_id'=>$nurse_id,'login_token'=>$value))->first();        
            if(isset($login_token->token_status) && $login_token->token_status == 0){ 
                Auth::guard('nurse')->logout();           
                return response()->json(['redirect'=>1,"redirect_url"=>asset('/nurse/login')],200);
            }
            if(!Auth::check()){            
                return response()->json(['redirect'=>1,"redirect_url"=>asset('/nurse/login')],200);
            } 
            
            $nurse_details = Nurse::where('nurse_id',$nurse_id)->first();
            $hospital_id = $nurse_details->hospital_id;
            $doctor_id = Doctor::where('hospital_id',$hospital_id)->select('doctor_id')->get();
            $time_zone = $nurse_details->nurse_timezone; 
            
            $image_det = HealthHistoryMedication::where('id',$medi_id)->get();        
            if(count($image_det) > 0){                             
                HealthHistoryMedication::where('id',$medi_id)->delete();
                return response()->json(['success'=>1],200);
            }else{
                return response()->json(['success'=>0,'message'=>"Medicine not found"],200);
            }     
        }catch(Exception $e) {
             return response()->json(['error'=>1,"message"=>$e->getMessage()],200);  
        }

    }

    protected function generateUniqueNumber() {
        $number = mt_rand(1000000000, 9999999999); // better than rand()
        // call the same function if the uniwue id exists already
        if ($this->uniqueNumberExists($number)) {
            return $this->generateUniqueNumber();
        }
        // otherwise, it's valid and can be used
        return strval($number);
    }

    protected function uniqueNumberExists($number) {
        // query the database and return a boolean         
        return HealthHistory::wherehistory_id($number)->exists();
    }
}

