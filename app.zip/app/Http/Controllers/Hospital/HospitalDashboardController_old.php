<?php
namespace App\Http\Controllers\Hospital;

use App\Http\Controllers\Controller;
use App\Models\Administrator;
use Illuminate\Http\Request;
use Auth;
use DB;
use Validator;
use Redirect;
use DateTime;
use DateTimeZone;
use Session;
use Hash;
use App\Models\PatientLoginToken;
use App\Models\Patient;
use App\Models\Hospital;
use App\Models\SaveTelemedicalBookingDetail;
use App\Models\DoctorAvailability;
use App\Models\PatientAppointment;
use App\Models\CallSession;
use App\Models\HealthHistory;
use App\Models\Doctor;
use App\Models\HospitalLoginToken;

//use Edujugon\PushNotification\PushNotification;

class HospitalDashboardController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
       
        $this->middleware('auth:administrator');  
    }
    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */
    /******
    Dashboard view
    *******/
    public function index(Request $request)
    {    

        $value = Session::get('hospital_token');
        $hospital_id = Auth::user()->hospital_id;
        $login_token =HospitalLoginToken::where(array('hosp_id'=>$hospital_id,'login_token'=>$value))->first();        
        if(isset($login_token->token_status) && $login_token->token_status == 0){ 
            Auth::guard('hospital')->logout();           
            return redirect('/hospital/login');
        }
        if(!Auth::check()){            
            return redirect('/hospital/login');
        }        
        $hospital_details = Hospital::where('hosp_id',$hospital_id)->first();  
        $administrator_details = Administrator::where('hospital_id',$hospital_id)->first();  
        
        $time_zone = isset($hospital_details->hosp_timezone)?$hospital_details->hosp_timezone:date_default_timezone_get();
        //echo "<pre>"; print_R($doctor_availability); exit;
        return view('hospital.dashboard')->with(array('controller'=> 'hospital','appointments'=>array(),'today_appointments_count'=>0,'page'=>'inner','doctor_availability'=>array(),'hospital_details'=>$hospital_details,'timezone'=>$time_zone,'disabled'=>0,'page_type'=>'appointments','patient_count'=>0,'appointment_cnt'=>0,'administrator_details'=>$administrator_details));     
        
    }//Ends dashboard function

  
     /****** Appointment Detail of a doctor*******/

     public function allAppointments(Request $request,$id)
     {    
         $doctor_id = $id;
         $value = Session::get('hospital_token');
         $hospital_id = Auth::user()->hospital_id;
         $login_token =HospitalLoginToken::where(array('hosp_id'=>$hospital_id,'login_token'=>$value))->first();        
         if(isset($login_token->token_status) && $login_token->token_status == 0){ 
             Auth::guard('hospital')->logout();           
             return redirect('/hospital/login');
         }
         if(!Auth::check()){            
             return redirect('/hospital/login');
         }        
         $hospital_details = Hospital::where('hosp_id',$hospital_id)->first();  
         $administrator_details = Administrator::where('hospital_id',$hospital_id)->first();  
         
         $time_zone = isset($hospital_details->hosp_timezone)?$hospital_details->hosp_timezone:date_default_timezone_get(); 
         $dtz = new DateTimeZone($time_zone);
         $time_in_sofia = new DateTime('now', $dtz);        
         $date_offset = $time_in_sofia->format('Z');
         $start_time = strtotime(date("Y-m-d"))-$date_offset;
         $end_time = strtotime(date("Y-m-d",strtotime("+1 day")))-$date_offset; 
 
         //Get Doctor details
         $doctor_details = Doctor::where('doctor_id',$doctor_id)->first();
         $time_zone = $doctor_details->doctor_timezone; 
         $dtz = new DateTimeZone($time_zone);
         $time_in_sofia = new DateTime('today', $dtz);                 
         $start_time = $time_in_sofia->getTimestamp();
         $one_day_after = $time_in_sofia->modify('+1 day');
         $end_time = $one_day_after->getTimestamp();        
 
             $query=SaveTelemedicalBookingDetail::select('save_telemedical_booking_detail.*','appointment_details.*','patients.*','save_telemedical_booking_detail.id as st_id','save_telemedical_booking_detail.status as st_status')->leftJoin('appointment_details', 'appointment_details.appointment_id','=', 'save_telemedical_booking_detail.appointment_id')->leftJoin('patients', 'save_telemedical_booking_detail.patient_id','=', 'patients.patient_unique_id');
 
             $query->where('save_telemedical_booking_detail.approved_status','!=',2)->where('save_telemedical_booking_detail.doctor_id',$doctor_id);
 
             $appointments = $query->orderBy('save_telemedical_booking_detail.appointment_time','DESC')->paginate(20);        
             foreach($appointments as $app)
             {
             SaveTelemedicalBookingDetail::where('id', $app->st_id)->update(['status' => 0]);
             }
 
             $today_appointment=SaveTelemedicalBookingDetail::where('doctor_id',$doctor_id)->where('save_telemedical_booking_detail.approved_status','!=',2)->where('appointment_time','>=',$start_time)->where('appointment_time','<',$end_time)->get();
             $status = SaveTelemedicalBookingDetail::where('doctor_id',$doctor_id)->where('call_status','>',0)->count();        
             $disabled = 0;
             if($status > 0){
             $disabled = 1;
             }                  
 
             $update_data = SaveTelemedicalBookingDetail::where('doctor_id',$doctor_id)->update(['call_status'=>0,'allowed_status'=>0]); 
             DoctorAvailability::where('doctor_id', $doctor_id)->update(['booking_status' => 0]);
 
             return view('hospital.all_appointments')->with(array('controller'=> 'admin','today_appointments_count'=>$today_appointment->count(),'administrator_details'=>$administrator_details,'page'=>'inner','page_type'=>'appointments','timezone'=>$time_zone,'doctor_details'=>$doctor_details,'hospital_details'=>$hospital_details,'appointments'=>$appointments,'disabled'=>$disabled));
             }
    
    /******
    My schedule pagination ajax
    *******/
    public function allAppointmentsAjax(Request $request,$time="")
    {
        $value = Session::get('nurse_token');
        $hospital_id = Auth::user()->hospital_id;
        $login_token =HospitalLoginToken::where(array('hosp_id'=>$hospital_id,'login_token'=>$value))->first();        
        if(isset($login_token->token_status) && $login_token->token_status == 0){ 
            Auth::guard('hospital')->logout();           
            return redirect('/hospital/login');
        }
        if(!Auth::check()){            
            return redirect('/hospital/login');
        }   
        $user = $request->user();

        $doctor_id=$user->doctor_id;
        $hospital_details = Hospital::where('hosp_id',$hospital_id)->first();  
        $administrator_details = Administrator::where('hospital_id',$hospital_id)->first();  
        
        $time_zone = $hospital_details->hosp_timezone;
        $dtz = new DateTimeZone($time_zone);
        $time_in_sofia = new DateTime('now', $dtz);        
        $date_offset = $time_in_sofia->format('Z');
        $start_time = strtotime(date("Y-m-d"))-$date_offset;
        $end_time = strtotime(date("Y-m-d",strtotime("+1 day")))-$date_offset;

        if($time == ""){            
            $appointments=SaveTelemedicalBookingDetail::select('save_telemedical_booking_detail.*','appointment_details.*','patients.*','save_telemedical_booking_detail.id as st_id','save_telemedical_booking_detail.status as st_status')->leftJoin('appointment_details', 'appointment_details.appointment_id','=', 'save_telemedical_booking_detail.appointment_id')->leftJoin('patients', 'save_telemedical_booking_detail.patient_id','=', 'patients.patient_unique_id')->where('save_telemedical_booking_detail.approved_status','!=',2)->where('save_telemedical_booking_detail.doctor_id',$doctor_id)->orderBy('save_telemedical_booking_detail.appointment_time','DESC')->paginate(5);
        }else{
            $query=SaveTelemedicalBookingDetail::select('save_telemedical_booking_detail.*','appointment_details.*','patients.*','save_telemedical_booking_detail.id as st_id','save_telemedical_booking_detail.status as st_status')->leftJoin('appointment_details', 'appointment_details.appointment_id','=', 'save_telemedical_booking_detail.appointment_id')->leftJoin('patients', 'save_telemedical_booking_detail.patient_id','=', 'patients.patient_unique_id');
                if($time === '1') {                                
                    $query->where('save_telemedical_booking_detail.appointment_time', '>=', $start_time)->where('save_telemedical_booking_detail.appointment_time', '<', $end_time)->where('save_telemedical_booking_detail.approved_status','!=',2)->where('save_telemedical_booking_detail.doctor_id',$doctor_id);
                }else if($time === '2'){
                   $query->where('save_telemedical_booking_detail.appointment_time', '>', $end_time)->where('save_telemedical_booking_detail.approved_status','!=',2)->where('save_telemedical_booking_detail.doctor_id',$doctor_id);
                }else if($time === '3'){
                    $query->where('save_telemedical_booking_detail.appointment_time', '<', $start_time)->where('save_telemedical_booking_detail.approved_status','!=',2)->where('save_telemedical_booking_detail.doctor_id',$doctor_id);
                }
            $appointments = $query->orderBy('save_telemedical_booking_detail.appointment_time','DESC')->paginate(5);
         //~ echo '<pre>'; print_r($appointments); die('here');
        }
        foreach($appointments as $app)
        {
            SaveTelemedicalBookingDetail::where('id', $app->st_id)->update(['status' => 0]);
        }
       
        $today_appointment=SaveTelemedicalBookingDetail::where('doctor_id',$doctor_id)->where('save_telemedical_booking_detail.approved_status','!=',2)->where('appointment_time','>=',$start_time)->where('appointment_time','<',$end_time)->get();
        $status = SaveTelemedicalBookingDetail::where('doctor_id',$doctor_id)->where('call_status','>',0)->count();        
        $disabled = 0;
        if($status > 0){
            $disabled = 1;
        }
        return view('hospital.all_appointments_ajax')->with(array('controller'=> 'doctor','appointments'=>$appointments,'today_appointments_count'=>$today_appointment->count(),'page'=>'inner','disabled'=>$disabled,'hospital_details'=>$hospital_details,'timezone'=>$time_zone));
    
    }//Ends My schedule pagination ajax function

    public function appointmentDetail(Request $request,$id)
    {    
        $value = Session::get('nurse_token');
        $patient_id = Auth::user()->doctor_id;
        $login_token =NurseLoginToken::where(array('doctor_id'=>$patient_id,'login_token'=>$value))->first();        
        if(isset($login_token->token_status) && $login_token->token_status == 0){ 
            Auth::guard('nurse')->logout();           
            return response()->json(['redirect'=>1,"redirect_url"=>asset('/nurse/login')],200);
        }
        if(!Auth::check()){            
            return response()->json(['redirect'=>1,"redirect_url"=>asset('/nurse/login')],200);
        }   
        
        $user = $request->user();
        $doctor_id=$user->doctor_id;
        $doctor_details = Doctor::where('doctor_id',$doctor_id)->first();
        $time_zone = $doctor_details->doctor_timezone; 
        $dtz = new DateTimeZone($time_zone);
        $time_in_sofia = new DateTime('now', $dtz);        
        $date_offset = $time_in_sofia->format('Z');
        $start_time = strtotime(date("Y-m-d"))-$date_offset;
        $end_time = strtotime(date("Y-m-d",strtotime("+1 day")))-$date_offset;       

        $appoint_detail=SaveTelemedicalBookingDetail::with(array("patient_detail","doctor.specialist_categories","patient_appoint","hospital_detail"))->where("save_telemedical_booking_detail.booking_id",$id)->get();
        $today_appointment=SaveTelemedicalBookingDetail::where('doctor_id',$doctor_id)->where('save_telemedical_booking_detail.approved_status','!=',2)->where('appointment_time','>=',$start_time)->where('appointment_time','<',$end_time)->get();

        return view('doctor.appointment_detail')->with(array('controller'=> 'doctor','page_type'=>'extra_links','page'=>'inner','appointment'=>$appoint_detail,'doctor_details'=>$doctor_details,'timezone'=>$time_zone,'today_appointments_count'=>$today_appointment->count()));
    }

    public function resheduleDetail(Request $request){
        $value = Session::get('nurse_token');
        $patient_id = Auth::user()->doctor_id;
        $login_token =NurseLoginToken::where(array('doctor_id'=>$patient_id,'login_token'=>$value))->first();        
        if(isset($login_token->token_status) && $login_token->token_status == 0){ 
            Auth::guard('nurse')->logout();           
            return response()->json(['redirect'=>1,"redirect_url"=>asset('/nurse/login')],200);
        }
        if(!Auth::check()){            
            return response()->json(['redirect'=>1,"redirect_url"=>asset('/nurse/login')],200);
        } 
        $user = $request->user();

        $doctor_id=$user->doctor_id;        
        $doctor_details = Doctor::where('doctor_id',$doctor_id)->first();
        $time_zone = $doctor_details->doctor_timezone;
        $dtz = new DateTimeZone($time_zone);     
        $date = date('Y-m-d',strtotime($_POST['appoint_date']));   
        $next_date = date('Y-m-d', strtotime('+1 day', strtotime($date)));
        $time_in_sofia = new DateTime($date, $dtz);        
        $date_offset = $time_in_sofia->format('Z');       
        $start_time = strtotime($date)-$date_offset;
        
        $end_time = strtotime($next_date)-$date_offset;

        $appoint_detail=SaveTelemedicalBookingDetail::with(array("patient_detail","doctor.specialist_categories","patient_appoint"))->where("save_telemedical_booking_detail.booking_id",$_POST['book_id'])->first();
        
        if($appoint_detail->patient_appoint->appointment_type == 2){
            $doctor_avail_time=Doctor::with(array('doctor_availability'=>function($q) use($start_time,$end_time) {$q->where('availability_date','>=',$start_time); $q->where('availability_date','<',$end_time); $q->where('type',2);}))->with('specialist_categories')->whereHas('doctor_availability', function($q) use($start_time,$end_time) {$q->where('availability_date','>=',$start_time); $q->where('availability_date','<',$end_time); $q->where('type',2);})->where('doctor_id',$appoint_detail->doctor_id)->select("*")->first();
            if(isset($doctor_avail_time->doctor_id)){
                $doctor_avail_time = $doctor_avail_time->toArray();
            }
        }elseif($appoint_detail->patient_appoint->appointment_type == 1){
            $doctor_avail_time=Doctor::with(array('doctor_availability'=>function($q) use($start_time,$end_time) {$q->where('availability_date','>=',$start_time); $q->where('availability_date','<',$end_time);$q->where('type',1);}))->with('specialist_categories')->whereHas('doctor_availability', function($q) use($start_time,$end_time) {$q->where('availability_date','>=',$start_time); $q->where('availability_date','<',$end_time);$q->where('type',1);})->where('doctor_id',$appoint_detail->doctor_id)->select("*")->first();
            if(isset($doctor_avail_time->doctor_id)){
                $doctor_avail_time = $doctor_avail_time->toArray();
            }
        }
        
        $doc_appoint_listing=SaveTelemedicalBookingDetail::where('save_telemedical_booking_detail.approved_status','!=',2)->where('save_telemedical_booking_detail.appointment_time','>=',$start_time)->where('save_telemedical_booking_detail.appointment_time','<',$end_time)->orderBy('save_telemedical_booking_detail.appointment_time','ASC')->get();
       
        return view('doctor.reshedule')->with(array('controller'=> 'doctor','appointment'=>$appoint_detail,'doctor_avail_time'=>$doctor_avail_time,'doctor_details'=>$doctor_details,'doc_appoint_listing'=>$doc_appoint_listing,'timezone'=>$time_zone,'appoint_date'=>$_POST['appoint_date']));
    
    }

    /******
    Tokbox connection and saving details in database
    *******/
    public function tokBoxConnection(Request $request){    

        $value = Session::get('nurse_token');
        $patient_id = Auth::user()->doctor_id;
        $login_token =NurseLoginToken::where(array('doctor_id'=>$patient_id,'login_token'=>$value))->first();        
        if(isset($login_token->token_status) && $login_token->token_status == 0){ 
            Auth::guard('nurse')->logout();           
            return response()->json(['redirect'=>1,"redirect_url"=>asset('/nurse/login')],200);
        }
        if(!Auth::check()){            
            return response()->json(['redirect'=>1,"redirect_url"=>asset('/nurse/login')],200);
        } 
        $user = $request->user();

        $doctor_id=$user->doctor_id;
         
        $opentok = new OpenTok('46168842', '065fb63f9d3141a2ca29e791972a59667656ccbd');
        // Create a session that attempts to use peer-to-peer streaming:
        $session = $opentok->createSession();

        // A session that uses the OpenTok Media Router, which is required for archiving:
        $session = $opentok->createSession(array( 'mediaMode' => MediaMode::ROUTED ));

        // A session with a location hint:
        $session = $opentok->createSession();

        // An automatically archived session:
        $sessionOptions = array(            
            'mediaMode' => MediaMode::ROUTED
        );
        $session = $opentok->createSession($sessionOptions);


        // Store this sessionId in the database for later use
        $sessionId = $session->getSessionId();
        
        // Generate a Token from just a sessionId (fetched from a database)
        $token = $opentok->generateToken($sessionId);
        // Generate a Token by calling the method on the Session (returned from createSession)
        $token = $session->generateToken();
        
        // Set some options in a token
        $token = $session->generateToken(array(
            'role'       => Role::MODERATOR,
            'expireTime' => time()+(7 * 24 * 60 * 60), // in one week
            'data'       => 'name=Johnny'
        ));

        Doctor::where('doctor_id', $doctor_id)->update(['doctor_tokbox_id' => $sessionId,'doctor_tokbox_token' => $token]);   
        SaveTelemedicalBookingDetail::where('appointment_id',$_POST['appoint_id'])->update(['call_status'=>1]);   
        $patient_det = SaveTelemedicalBookingDetail::where('appointment_id',$_POST['appoint_id'])->first();
        $call_id = $this->generateUniqueNumber();    
        $CallSession = new CallSession([                
            'call_id'    => $call_id,
            'doct_id'   => $doctor_id,
            'patient_id'  => $patient_det->patient_id, 
            'appoint_id'  => $_POST['appoint_id'],
            'call_status'  => "1",  
            'patient_call_status'   => "1"                                                    
        ]);
        $CallSession->save();     

        return response()->json(['success'=>1,"doctor_id"=>$doctor_id,"call_id"=>$call_id],200);


    }//Ends tokbox connection function

    /******
    Calling Patient view screen
    *******/
    public function callingPatient(Request $request,$call_id,$a_id,$id,$p_id,$type){          
        $value = Session::get('nurse_token');
        $patient_id = Auth::user()->doctor_id;
        $login_token =NurseLoginToken::where(array('doctor_id'=>$patient_id,'login_token'=>$value))->first();        
        if(isset($login_token->token_status) && $login_token->token_status == 0){ 
            Auth::guard('nurse')->logout();           
            return redirect('/nurse/login');
        }
        if(!Auth::check()){            
            return redirect('/nurse/login');
        } 
        $user = $request->user();
        
        $doctor_id= $user->doctor_id;
        $doctor_details = Doctor::where('doctor_id',$doctor_id)->first();
        $data = Doctor::where('doctor_id', $id)->first();
        $call_status = CallSession::where('call_id',$call_id)->first();
        CallSession::where('call_id',$call_id)->where('appoint_id',$a_id)->update(['call_status'=>0]);
        $patient_details = Patient::where('patient_unique_id',$p_id)->first();

        if(isset($call_status->call_id) && $call_status->call_status == 0){
            SaveTelemedicalBookingDetail::where('appointment_id',$a_id)->update(['call_status'=>0,'allowed_status'=>0]);                          
            return view('doctor.tokbox')->with(array('expire'=>1,'controller'=> 'doctor','sessionId'=>$data->doctor_tokbox_id,'token'=>$data->doctor_tokbox_token,'page'=>'inner','type'=>$type,'a_id'=>$a_id,'d_id'=>$id,'call_id'=>$call_id,'patient_details'=>$patient_details));
        }
        return view('doctor.tokbox')->with(array('controller'=> 'doctor','sessionId'=>$data->doctor_tokbox_id,'token'=>$data->doctor_tokbox_token,'page'=>'inner','type'=>$type,'a_id'=>$a_id,'d_id'=>$id,'call_id'=>$call_id,'doctor_details'=>$doctor_details,'patient_details'=>$patient_details));
    }//Ends calling patient function

    /******
    Intialize Call Screen before calling screen
    *******/
    public function initiatingCall(Request $request,$a_id){
        if(!Auth::check()){            
            return redirect('/nurse/login');
        }
        $user = $request->user();
        
        $doctor_id= $user->doctor_id;

        return view('doctor.initiating_call')->with(array('a_id'=>$a_id));
    }//Ends intialize calling function

     /******
    Check if call is going on or not for particular appointment
    *******/
    public function checkConnection(Request $request){
        $value = Session::get('nurse_token');
        $patient_id = Auth::user()->doctor_id;
        $login_token =NurseLoginToken::where(array('doctor_id'=>$patient_id,'login_token'=>$value))->first();        
        if(isset($login_token->token_status) && $login_token->token_status == 0){ 
            Auth::guard('nurse')->logout();           
            return response()->json(['redirect'=>1,"redirect_url"=>asset('/nurse/login')],200);
        }
        if(!Auth::check()){            
            return response()->json(['redirect'=>1,"redirect_url"=>asset('/nurse/login')],200);
        } 
        
        $user = $request->user();
        
        $doctor_id= $user->doctor_id;

        $patient_appoint = SaveTelemedicalBookingDetail::where('appointment_id',$_POST['appoint_id'])->get(); 
        if(count($patient_appoint) > 0){
         return response()->json(['success'=>1,"appoint"=>$patient_appoint[0]->call_status],200);
        }else{
            return response()->json(['success'=>0],200);
        }
    }//Ends of specific call connection function

     /******
    Check if any call is going on or not
    *******/
    public function checkAppointConnection(Request $request){
        $value = Session::get('nurse_token');
        $patient_id = Auth::user()->doctor_id;
        $login_token =NurseLoginToken::where(array('doctor_id'=>$patient_id,'login_token'=>$value))->first();        
        if(isset($login_token->token_status) && $login_token->token_status == 0){ 
            Auth::guard('nurse')->logout();           
            return response()->json(['redirect'=>1,"redirect_url"=>asset('/nurse/login')],200);
        }
        if(!Auth::check()){            
            return response()->json(['redirect'=>1,"redirect_url"=>asset('/nurse/login')],200);
        }
        $user = $request->user();
        
        $doctor_id= $user->doctor_id;

        $status = SaveTelemedicalBookingDetail::where('doctor_id',$doctor_id)->where('call_status','>',0)->count();        
        $disabled = 0;
        if($status > 0){
            $disabled = 1;            
        }
        return response()->json(['success'=>1,'appoint'=>$disabled],200);
    }//Ends of call connection function


    /******
    Making connection and sending notification to device
    *******/
    public function makeTokboxConnect(Request $request){
        $value = Session::get('nurse_token');
        $patient_id = Auth::user()->doctor_id;
        $login_token =NurseLoginToken::where(array('doctor_id'=>$patient_id,'login_token'=>$value))->first();        
        if(isset($login_token->token_status) && $login_token->token_status == 0){ 
            Auth::guard('nurse')->logout();           
            return response()->json(['redirect'=>1,"redirect_url"=>asset('/nurse/login')],200);
        }
        if(!Auth::check()){            
            return response()->json(['redirect'=>1,"redirect_url"=>asset('/nurse/login')],200);
        }
        $user = $request->user();        
        $doctor_id= $user->doctor_id;     
        
        $doctor_det = Doctor::where('doctor_id', $_POST['doctor_id'])->first();        
        $time_zone = $doctor_det->doctor_timezone;
        date_default_timezone_set($time_zone);
        $appoint_det = PatientAppointment::where('appointment_id',$_POST['appoint_id'])->first();
             

        if(!empty($doctor_det->doctor_tokbox_id) && !empty($doctor_det->doctor_tokbox_token)){
            $sessionId = $doctor_det->doctor_tokbox_id;
            $token = $doctor_det->doctor_tokbox_token;
            if(!empty($appoint_det->telemedical_type))
            {                
                if($appoint_det->telemedical_type == 1){
                    $api_key = 46168842;
                    $login_token = PatientLoginToken::where('patient_id',$_POST['patient_id'])->where('token_status',1)->get();

                    if(count($login_token) > 0 && $login_token[0]->device_type != 2){
                        $device_token = $login_token[0]->device_token;
                        $path = "/var/www/html/projects/renderhealth/ios_notifcation/notification.php";
                        $type= 'audio';
                        exec ('php '.$path.' '.$_POST['doctor_id'].' '.$type.' '.$_POST['appoint_id'].' '.$api_key.' '.$device_token.' '.$doctor_det->doctor_first_name.' > /dev/null &');
                    }else{
                        SaveTelemedicalBookingDetail::where('appointment_id',$_POST['appoint_id'])->update(['allowed_status'=>1]);
                    }
                    
                }else{   
                    $api_key = 46168842;
                    $login_token = PatientLoginToken::where('patient_id',$_POST['patient_id'])->where('token_status',1)->get();
                   
                    if(count($login_token) > 0 && $login_token[0]->device_type != 2){
                        $device_token = $login_token[0]->device_token;                       
                        $path = "/var/www/html/projects/renderhealth/ios_notifcation/notification.php";
                        $type= 'video';
                        exec ('php '.$path.' '.$_POST['doctor_id'].' '.$type.' '.$_POST['appoint_id'].' '.$api_key.' '.$device_token.' '.$doctor_det->doctor_first_name.' > /dev/null &');
                    }else{
                        SaveTelemedicalBookingDetail::where('appointment_id',$_POST['appoint_id'])->update(['allowed_status'=>1]);
                    }                  
                }
            }
        }
    }//Ends of making connection function

    public function silentNotification(){       
        // $device_token = '86C6E590D8839FE6A8584AD8546CC94561FBF21E9DBE92F82784E85A5F2B0823';    
        // $path = "/var/www/html/projects/renderhealth/ios_notifcation/silent_notify.php";    
        //exec ('php '.$path.' '.$_POST['appoint_id'].' '.$device_token.' > /dev/null &');
    }
    
    /******
    Update status on call diconnect
    *******/
    public function disconnectStatus(Request $request){
        $value = Session::get('nurse_token');
        $patient_id = Auth::user()->doctor_id;
        $login_token =NurseLoginToken::where(array('doctor_id'=>$patient_id,'login_token'=>$value))->first();        
        if(isset($login_token->token_status) && $login_token->token_status == 0){ 
            Auth::guard('nurse')->logout();           
            return response()->json(['redirect'=>1,"redirect_url"=>asset('/nurse/login')],200);
        }
        if(!Auth::check()){            
            return response()->json(['redirect'=>1,"redirect_url"=>asset('/nurse/login')],200);
        }
        $user = $request->user();
        
        $doctor_id= $user->doctor_id;

        $status = SaveTelemedicalBookingDetail::where('appointment_id',$_POST['appoint_id'])->where('call_status',1)->count();
        
        if($status > 0){
            SaveTelemedicalBookingDetail::where('appointment_id',$_POST['appoint_id'])->update(['call_status'=>0,'allowed_status'=>0]);
            return response()->json(['success'=>1], 200);
        }
        
    }//Ends of diconnect function

    /******
    Update status on call diconnect
    *******/
    public function disconnectConnectStatus(Request $request){
        $value = Session::get('nurse_token');
        $patient_id = Auth::user()->doctor_id;
        $login_token =NurseLoginToken::where(array('doctor_id'=>$patient_id,'login_token'=>$value))->first();        
        if(isset($login_token->token_status) && $login_token->token_status == 0){ 
            Auth::guard('nurse')->logout();           
            return response()->json(['redirect'=>1,"redirect_url"=>asset('/nurse/login')],200);
        }
        if(!Auth::check()){            
            return response()->json(['redirect'=>1,"redirect_url"=>asset('/nurse/login')],200);
        }
        $user = $request->user();
        
        $doctor_id= $user->doctor_id;

        SaveTelemedicalBookingDetail::where('appointment_id',$_POST['appoint_id'])->update(['call_status'=>0,'allowed_status'=>0]);        
        return response()->json(['success'=>1], 200);        
    }//Ends of diconnect function

    /******
    Update status of allowed devices
    *******/
    public function updateAllowedStatus(Request $request){
        $value = Session::get('nurse_token');
        $patient_id = Auth::user()->doctor_id;
        $login_token =NurseLoginToken::where(array('doctor_id'=>$patient_id,'login_token'=>$value))->first();        
        if(isset($login_token->token_status) && $login_token->token_status == 0){ 
            Auth::guard('nurse')->logout();           
            return response()->json(['redirect'=>1,"redirect_url"=>asset('/nurse/login')],200);
        }
        if(!Auth::check()){            
            return response()->json(['redirect'=>1,"redirect_url"=>asset('/nurse/login')],200);
        }
        $user = $request->user();       

        SaveTelemedicalBookingDetail::where('appointment_id',$_POST['appoint_id'])->update(['allowed_status'=>0]);
        return response()->json(['success'=>1], 200);        
    }//Ends of diconnect function

    /******
    Update status on call connect
    *******/
    public function changeStatus(Request $request){
        $value = Session::get('nurse_token');
        $patient_id = Auth::user()->doctor_id;
        $login_token =NurseLoginToken::where(array('doctor_id'=>$patient_id,'login_token'=>$value))->first();        
        if(isset($login_token->token_status) && $login_token->token_status == 0){ 
            Auth::guard('nurse')->logout();           
            return response()->json(['redirect'=>1,"redirect_url"=>asset('/nurse/login')],200);
        }
        if(!Auth::check()){            
            return response()->json(['redirect'=>1,"redirect_url"=>asset('/nurse/login')],200);
        }
        $user = $request->user();
        
        $doctor_id= $user->doctor_id;

        SaveTelemedicalBookingDetail::where('appointment_id',$_POST['appoint_id'])->update(['call_status'=>2]);
        return response()->json(['success'=>1], 200);
    }//Ends of call connect function


    /******
    set Availability function
    *******/
    public function saveAppointments(Request $request)
    {     
        $value = Session::get('nurse_token');
        $patient_id = Auth::user()->doctor_id;
        $login_token =NurseLoginToken::where(array('doctor_id'=>$patient_id,'login_token'=>$value))->first();        
        if(isset($login_token->token_status) && $login_token->token_status == 0){ 
            Auth::guard('nurse')->logout();           
            return response()->json(['redirect'=>1,"redirect_url"=>asset('/nurse/login')],200);
        }
        if(!Auth::check()){            
            return response()->json(['redirect'=>1,"redirect_url"=>asset('/nurse/login')],200);
        }
        $user = $request->user();
        
        $doctor_id= $user->doctor_id;

        $combined_time = array();
        $hosp_start_time=$_POST['hosp_start_time'];         
        $hosp_end_time=$_POST['hosp_end_time'];         
        $hidden_date_hosp=$_POST['hidden_date_hosp'];
        $hidden_start_date = $hidden_date_hosp.' '.$hosp_start_time;    
        $doctor_details = Doctor::where('doctor_id',$doctor_id)->first();
        $target_time_zone = new DateTimeZone($doctor_details->doctor_timezone);  
        $date_time = new DateTime('now', $target_time_zone);  
        $offset = $date_time->format('Z');        
        $hidden_start_hosp1= strtotime($hidden_start_date) - $offset;     
        $hidden_end_date = $hidden_date_hosp.' '.$hosp_end_time;             
        $hidden_end_hosp1= strtotime($hidden_end_date) - $offset;
        $hidden_hosp_type=$_POST['hidden_hosp_type'];
        $combined_time[] = $hidden_start_hosp1.'-'.$hidden_end_hosp1;
        $encode_time = json_encode($combined_time);        
        $final_date =  strtotime($hidden_start_date) - $offset;         
        //echo $date = strtotime(date('Y-m-d')) - $date_offset;
        $doctor_availability=DoctorAvailability::where('doctor_id',$doctor_id)->select('*')->get();
        $count = 0;
       
        if($hidden_end_hosp1 == $hidden_start_hosp1){
            return response()->json(['success'=>2], 200);
        }
        if($hidden_end_hosp1 < $hidden_start_hosp1){
            return response()->json(['success'=>3], 200);
        }
        if(count($doctor_availability) > 0){
            foreach($doctor_availability as $doc_avail){ 
                $avail_time = $doc_avail['availability_time'][0];               
                $exploded_time = explode("-",$avail_time);               
                if(($hidden_start_hosp1 >= $exploded_time[0] && $hidden_end_hosp1 <= $exploded_time[1]) || ($hidden_start_hosp1 >= $exploded_time[0] && $hidden_start_hosp1 < $exploded_time[1]) || ($hidden_end_hosp1 > $exploded_time[0] && $hidden_end_hosp1 <= $exploded_time[1]) || ($hidden_start_hosp1 < $exploded_time[0] && $hidden_end_hosp1 > $exploded_time[1])){
                    $count = 1;
                    break;
                }
                
            }
            if($count == 0){
                $DoctorAvailability = new DoctorAvailability([                
                    'availability_id'   => $this->generateUniqueNumber(),
                    'doctor_id'         => $doctor_id, 
                    'availability_date' => $final_date,
                    'availability_time' => $combined_time,
                    'type'              => $hidden_hosp_type,
                    'created_date'      => strtotime('now')                                               
                ]);
                $DoctorAvailability->save(); 
                return response()->json(['success'=>1], 200);
            }else{
                return response()->json(['success'=>0], 200);
            }
        }else{
            $DoctorAvailability = new DoctorAvailability([                
                'availability_id'   => $this->generateUniqueNumber(),
                'doctor_id'         => $doctor_id, 
                'availability_date' => $final_date,
                'availability_time' => $combined_time,
                'type'              => $hidden_hosp_type,
                'created_date'      => strtotime('now')                                               
            ]);
            $DoctorAvailability->save(); 
            return response()->json(['success'=>1], 200);
        }      
        
    }//Ends of set availability function


    public function availabilityBooking(Request $request){
        $value = Session::get('nurse_token');
        $patient_id = Auth::user()->doctor_id;
        $login_token =NurseLoginToken::where(array('doctor_id'=>$patient_id,'login_token'=>$value))->first();        
        if(isset($login_token->token_status) && $login_token->token_status == 0){ 
            Auth::guard('nurse')->logout();           
            return response()->json(['redirect'=>1,"redirect_url"=>asset('/nurse/login')],200);
        }
        if(!Auth::check()){            
            return response()->json(['redirect'=>1,"redirect_url"=>asset('/nurse/login')],200);
        }
        $user = $request->user();
        
        $doctor_id= $user->doctor_id;

        $doctor_details = Doctor::where('doctor_id',$doctor_id)->first();

        $time_zone = $doctor_details->doctor_timezone;
        $dtz = new DateTimeZone($time_zone);     
        $date = date('Y-m-d',strtotime($_POST['date']));   
        $next_date = date('Y-m-d', strtotime('+1 day', strtotime($date)));
        $time_in_sofia = new DateTime($date, $dtz);        
        $date_offset = $time_in_sofia->format('Z');       
        $start_time = strtotime($date)-$date_offset;
        $end_time = strtotime($next_date)-$date_offset;
        
        //echo $date = strtotime(date('Y-m-d')) - $date_offset;
        $doctor_availability=DoctorAvailability::where('doctor_id',$doctor_id)->select('*')->where('availability_date','>=',$start_time)->where('availability_date','<',$end_time)->get(); 
        $farray = [];       
        if(count($doctor_availability) > 0){                                                    
            date_default_timezone_set($doctor_details->doctor_timezone);                                    
            foreach($doctor_availability as $key=>$avail_time){                                                     
                $doctor_break = explode("-",$avail_time['availability_time'][0]);
                $farray[$key]['start_time'] = date('H:i',$doctor_break[0]);
                $farray[$key]['end_time'] = date('H:i',$doctor_break[1]);                                       
            }
            return response()->json(['success'=>1,'data'=>$farray], 200);
        }else{
            return response()->json(['success'=>1], 200);
        }

    }
    
    public function cancelBooking(Request $request){
        $value = Session::get('nurse_token');
        $patient_id = Auth::user()->doctor_id;
        $login_token =NurseLoginToken::where(array('doctor_id'=>$patient_id,'login_token'=>$value))->first();        
        if(isset($login_token->token_status) && $login_token->token_status == 0){ 
            Auth::guard('nurse')->logout();           
            return response()->json(['redirect'=>1,"redirect_url"=>asset('/nurse/login')],200);
        }
        if(!Auth::check()){            
            return response()->json(['redirect'=>1,"redirect_url"=>asset('/nurse/login')],200);
        }
        $user = $request->user();

        $update_status = SaveTelemedicalBookingDetail::where('booking_id',$_POST['book_id'])->update(['approved_status'=>2]);
        if($update_status > 0){
            return response()->json(['success'=>1], 200);
        }else{
            return response()->json(['success'=>0,'message'=>'Something went wrong'], 200);
        }        
    }

    public function updateAppointments(Request $request){
        try{
            $value = Session::get('nurse_token');
            $patient_id = Auth::user()->doctor_id;
            $login_token =NurseLoginToken::where(array('doctor_id'=>$patient_id,'login_token'=>$value))->first();        
            if(isset($login_token->token_status) && $login_token->token_status == 0){ 
                Auth::guard('nurse')->logout();           
                return response()->json(['redirect'=>1,"redirect_url"=>asset('/nurse/login')],200);
            }
            if(!Auth::check()){            
                return response()->json(['redirect'=>1,"redirect_url"=>asset('/nurse/login')],200);
            }
            $user = $request->user();
            $doctor_id= $user->doctor_id;
            $doctor_details = Doctor::where('doctor_id',$doctor_id)->first();
            $appoint_time = $_POST['appoint_date']." ".$_POST['appoint_time'];

            $time_zone = $doctor_details->doctor_timezone;
            $dtz = new DateTimeZone($time_zone);     
            $date = date('Y-m-d H:i',strtotime($appoint_time));                   
            $time_in_sofia = new DateTime($date, $dtz);        
            $date_offset = $time_in_sofia->format('Z');       
            $appointment_time = strtotime($date)-$date_offset;         
            $update_time = SaveTelemedicalBookingDetail::where('booking_id',$_POST['book_id'])->update(['appointment_time'=>$appointment_time]);
            return response()->json(['success'=>1], 200);
        }catch(Exception $e) {
            return response()->json(['error'=>1,"message"=>$e->getMessage()],200);       
        } 
    }

    public function accountSetting(Request $request){
        try{
            $value = Session::get('token');
            $doctor_id = Auth::user()->doctor_id;
            $login_token =NurseLoginToken::where(array('doctor_id'=>$doctor_id,'login_token'=>$value))->first();        
            if(isset($login_token->token_status) && $login_token->token_status == 0){ 
                Auth::guard('nurse')->logout();           
                return response()->json(['redirect'=>1,"redirect_url"=>asset('/nurse/login')],200);
            }
            if(!Auth::check()){            
                return response()->json(['redirect'=>1,"redirect_url"=>asset('/nurse/login')],200);
            }
            
            $doctor_details     = Doctor::where('doctor_id',$doctor_id)->first();
            $doctorEmail       = $doctor_details->doctor_email;
            $doctorPassword    = $doctor_details->doctor_password;
            $FormEmail          = $_POST['email'];
            $FormPassword       = $_POST['crt_password'];
      
            if($FormEmail !=  $doctorEmail){
                return response()->json(['success'=>0, 'message'=>"Email doesn't match with existing email"]);
            }else{
                $validatorAccount = Validator::make($request->all(),[
                    'email'=>'required|email',
                    'crt_password'=>'required',
                    'new_password'=>'required',
                    'cnfrm_password'=>'required|same:new_password'
                ]);
                if ($validatorAccount->fails()) {    
                    return response()->json(['success'=>0, 'message'=>$validatorAccount->messages()->first()], 200);
                }
            }

            if(Hash::check($FormPassword, $doctorPassword))
            {
                Doctor::where('doctor_id', $doctor_id)->update(['doctor_password' => bcrypt($_POST['new_password'])]);
                return response()->json(['success'=>1,'message'=>'Password successfully updated']);
            }else{
                return response()->json(['success'=>0,'message'=>'Your current password does not match']);
            } 
        }catch(Exception $e){
            return response()->json(['error'=>1,"message"=>$e->getMessage()],200);       
        }     
    } 

     public function updateTimeZone(Request $request,$time_zone,$dst){
        $value = Session::get('hospital_token');
        $hospital_id = Auth::user()->hospital_id;
        $login_token =HospitalLoginToken::where(array('hosp_id'=>$hospital_id,'login_token'=>$value))->first();        
        if(isset($login_token->token_status) && $login_token->token_status == 0){ 
            Auth::guard('hospital')->logout();           
            return redirect('/hospital/login');
        }
        if(!Auth::check()){            
            return redirect('/hospital/login');
        }        
            $user = $request->user();
        if($dst == 1){
             $time_zone_name = timezone_name_from_abbr("", $time_zone*60,1); 
             if(empty($time_zone_name)){
                $time_zone_name = timezone_name_from_abbr("", $time_zone*60,0); 
             }
        }else{
            $time_zone_name = timezone_name_from_abbr("", $time_zone*60,1); 
             if(empty($time_zone_name)){
                $time_zone_name = timezone_name_from_abbr("", $time_zone*60,0); 
             }
        } 
        $update_time = Hospital::where('hosp_id',$hospital_id)->update(['hosp_timezone'=>$time_zone_name]);
        return response()->json(['success'=>1,"redirect_url"=>route('hospital.dashboard')], 200);      
    }

    public function saveTeleAppointments(Request $request)
    {                   
        echo "<pre>"; print_r($_POST); die('here');
    }

    protected function generateUniqueNumber() {
        $number = mt_rand(1000000000, 9999999999); // better than rand()
        // call the same function if the uniwue id exists already
        if ($this->uniqueNumberExists($number)) {
            return $this->generateUniqueNumber();
        }
        // otherwise, it's valid and can be used
        return strval($number);
    }

    protected function uniqueNumberExists($number) {
        // query the database and return a boolean         
        return CallSession::wherecall_id($number)->exists();
    }
  /******listing of all Doctors *******/

  public function AllDoctors(Request $request)
  {
    $value = Session::get('hospital_token');
    $hospital_id = Auth::user()->hospital_id;
    $login_token =HospitalLoginToken::where(array('hosp_id'=>$hospital_id,'login_token'=>$value))->first();        
    if(isset($login_token->token_status) && $login_token->token_status == 0){ 
        Auth::guard('hospital')->logout();           
        return redirect('/hospital/login');
    }
    if(!Auth::check()){            
        return redirect('/hospital/login');
    }        
    $hospital_details = Hospital::where('hosp_id',$hospital_id)->first();  
    $administrator_details = Administrator::where('hospital_id',$hospital_id)->first();  
    
    $time_zone = isset($hospital_details->hosp_timezone)?$hospital_details->hosp_timezone:date_default_timezone_get(); 
      $dtz = new DateTimeZone($time_zone);
      $time_in_sofia = new DateTime('now', $dtz);        
      $date_offset = $time_in_sofia->format('Z');
      $start_time = strtotime(date("Y-m-d"))-$date_offset;
      $end_time = strtotime(date("Y-m-d",strtotime("+1 day")))-$date_offset;
    //   $statesNigeria = StatesNigeria::all();
      //get pagination params
      if(isset($_GET['type']))
      {        
          if($_GET['type'] == "doc_page")
          {
              $doc_page = $_GET['page'];
              $limit = 20;            
          }
      }
      else
      {
        $doc_page = 1;
        $limit = 20;          
      }

    //   $countries = Country::all();
    //    //get All speciality categories
    //   $specialist_categories = Speciality::select('*')->get();
    // $specialist_categories_nurse = SpecialistCategories::select('*')->where('type_of_user', '=' ,2)->get();
      //get all doctors
      $all_doctors = Doctor::where('active_status', '!=' , 2)->orderBy('doctor_id', 'desc')->paginate($limit, ['*'],'page',$doc_page);

      if($request->ajax())
      {
           return view('hospital.hospital_doctors_ajax')->with(array('controller'=>'admin','hospital_details'=>$hospital_details,'administrator_details'=>$administrator_details,'all_doctors'=>$all_doctors));
      }
      else
      {
          return view('hospital.hospital_doctors')->with(array('controller'=>'admin','hospital_details'=>$hospital_details,'administrator_details'=>$administrator_details,'all_doctors'=>$all_doctors));
      }       
      
  }
}
