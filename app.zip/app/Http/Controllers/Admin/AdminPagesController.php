<?php
namespace App\Http\Controllers\Admin;


use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Auth;
use DB;
use Validator;
use Redirect;
use DateTime;
use DateTimeZone;
use Session;
use Hash;
use Mail;
use App\Models\PatientLoginToken;
use App\Models\Patient;
use App\Models\Hospital;
use App\Models\SaveTelemedicalBookingDetail;
use App\Models\DoctorAvailability;
use App\Models\PatientAppointment;
use App\Models\CallSession;
use App\Models\HealthHistory;
use App\Models\Doctor;
use App\Models\Admin;
use App\Models\AdminLoginToken;
use App\Models\Country;
use App\Models\State;
use App\Models\DoctorHospitalDetail;
use App\Models\Employee;
use App\Models\BillingDetail;
use App\Models\BillingService;
use App\Models\HealthHistoryMedication;
use App\Models\UserNotification;
use App\Models\PatientNotificationSetting;
use App\Models\HealthHistoryAttachments;
use App\Models\PaidBillingDetail;
class AdminPagesController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
   
    public function __construct()
    {
        $this->middleware('auth:admin');
    }
     /******listing of all Disputed Doctors *******/

    public function AllDisputedDoctors(Request $request)
    {
        //get token from session
        $value = Session::get('admin_token');

        //get user id from auth
        $admin_id = Auth::user()->id;

        //check login status of user
        $login_token = AdminLoginToken::where(array('admin_id'=>$admin_id,'login_token'=>$value))->first();        
        if(isset($login_token->token_status) && $login_token->token_status == 0){ 
            Auth::guard('admin')->logout();           
            return redirect('/admin/login');
        }
        if(!Auth::check()){            
            return redirect('/admin/login');
        }

        $user = $request->user();
        $admin_id = $user->id;

        //get details of logged in user
        $admin_details = Admin::where('id',$admin_id)->first();  
        $time_zone = $admin_details->admin_timezone;                 
        $dtz = new DateTimeZone($time_zone);
        $time_in_sofia = new DateTime('now', $dtz);        
        $date_offset = $time_in_sofia->format('Z');
        $start_time = strtotime(date("Y-m-d"))-$date_offset;
        $end_time = strtotime(date("Y-m-d",strtotime("+1 day")))-$date_offset;

        //get pagination params
        if(isset($_GET['type']))
        {        
            if($_GET['type'] == "doc_page")
            {
                $doc_page = $_GET['page'];
                $limit = 5;            
            }
        }
        else
        {
          $doc_page = 1;
          $limit = 5;          
        }
        //DB::enableQueryLog();

         $all_doctors = BillingDetail::with(array('doctor'))->where('disputed',1)->groupBy('doctor_id')->paginate($limit, ['*'],'page',$doc_page); 
         //print_r(DB::connection('mysql')->getQueryLog());
         //die;
        //get all doctors
       // $all_doctors = Doctor::where('active_status', '!=' , 2)->where('disputed', '=' , 1)->orderBy('doctor_id', 'desc')->paginate($limit, ['*'],'page',$doc_page);

        if($request->ajax())
        {
             return view('admin.admin_disputed_billing_ajax')->with(array('controller'=>'pages','admin_details'=>$admin_details,'all_doctors'=>$all_doctors));
        }
        else
        {
            return view('admin.admin_disputed_billing')->with(array('controller'=>'pages','admin_details'=>$admin_details,'all_doctors'=>$all_doctors));
        }       
        
    }
     /******
    Dispute Billing View
    *******/
    public function Disputedbilling(Request $request,$id=''){
       $value = Session::get('admin_token');

            //get user id from auth
            $admin_id = Auth::user()->id;
           $doctor_id=$id;
            //check login status of user
            $login_token = AdminLoginToken::where(array('admin_id'=>$admin_id,'login_token'=>$value))->first();        
            if(isset($login_token->token_status) && $login_token->token_status == 0){ 
                Auth::guard('admin')->logout();           
                return redirect('/admin/login');
            }
            if(!Auth::check()){            
                return redirect('/admin/login');
            }
        $admin_details = Admin::where('id',$admin_id)->first();  
        $time_zone = $admin_details->admin_timezone;                   
        $dtz = new DateTimeZone($time_zone);
        $time_in_sofia = new DateTime('now', $dtz);        
        $date_offset = $time_in_sofia->format('Z');
        $start_time = strtotime(date("Y-m-d"))-$date_offset;
        $end_time = strtotime(date("Y-m-d",strtotime("+1 day")))-$date_offset;

        if(isset($_GET['page'])){
            $page = $_GET['page'];
            $limit = 5;           
        }else{
            $page = 1;
            $limit = 5;            
        }  
           $disputed_billing_count = BillingDetail::where('disputed',1)->orderBy('billing_date','DESC');

        $disputed_billing = BillingDetail::where('doctor_id',$doctor_id)->where('disputed',1)->orderBy('billing_date','DESC')->paginate($limit, ['*'],'page',$page);
        $today_appointment=SaveTelemedicalBookingDetail::where('doctor_id',$doctor_id)->where('save_telemedical_booking_detail.approved_status','!=',2)->where('appointment_time','>=',$start_time)->where('appointment_time','<',$end_time)->get(); 

        if($request->ajax()){
        return view('admin.dispute_billing_inner')->with(array('controller'=> 'pages','admin_details'=>$admin_details,'timezone'=>$time_zone,'today_appointments_count'=>$today_appointment->count(),"disputed_billing"=>$disputed_billing,"disputed_billing_count"=>$disputed_billing->total()));
        }
        else{
        return view('admin.dispute_billing')->with(array('controller'=> 'pages','admin_details'=>$admin_details,'timezone'=>$time_zone,'today_appointments_count'=>$today_appointment->count(),"disputed_billing"=>$disputed_billing,"disputed_billing_count"=>$disputed_billing_count->count()));
        }  

   
    }
    /******
    Dispute Billing Detail
    *******/
    public function disputeBillingDetail(Request $request,$id){
    	  $value = Session::get('admin_token');
     	$admin_id = Auth::user()->id;
           $doctor_id=$id;
            //check login status of user
            $login_token = AdminLoginToken::where(array('admin_id'=>$admin_id,'login_token'=>$value))->first();        
            if(isset($login_token->token_status) && $login_token->token_status == 0){ 
                Auth::guard('admin')->logout();           
                return redirect('/admin/login');
            }
            if(!Auth::check()){            
                return redirect('/admin/login');
            }
        $admin_details = Admin::where('id',$admin_id)->first();  
        $time_zone = $admin_details->admin_timezone;                   
        $dtz = new DateTimeZone($time_zone);
        $time_in_sofia = new DateTime('now', $dtz);        
        $date_offset = $time_in_sofia->format('Z');
        $start_time = strtotime(date("Y-m-d"))-$date_offset;
        $end_time = strtotime(date("Y-m-d",strtotime("+1 day")))-$date_offset;
       $billing_detail = BillingDetail::with(array('doctor','nurse','hospital','employee','billing_service','doctor.specialist_categories','nurse.specialist_categories','employee.specialist_categories','hospital.specialist_categories'))->where('billing_id',$id)->where('disputed',1)->first(); 

      $today_appointment=SaveTelemedicalBookingDetail::where('doctor_id',$billing_detail['doctor_id'])->where('save_telemedical_booking_detail.approved_status','!=',2)->where('appointment_time','>=',$start_time)->where('appointment_time','<',$end_time)->get(); 
 
      
      return view('doctor.dispute_billing_detail')->with(array('controller'=> 'pages','admin_details'=>$admin_details,'timezone'=>$time_zone,"billing_detail"=>$billing_detail,'today_appointments_count'=>$today_appointment->count()));
    }


    /**  search patient view section */
    public function searchPatient(Request $request){
           $value = Session::get('admin_token');

            //get user id from auth
            $admin_id = Auth::user()->id;
            
            //check login status of user
            $login_token = AdminLoginToken::where(array('admin_id'=>$admin_id,'login_token'=>$value))->first();        
            if(isset($login_token->token_status) && $login_token->token_status == 0){ 
                Auth::guard('admin')->logout();           
                return redirect('/admin/login');
            }
            if(!Auth::check()){            
                return redirect('/admin/login');
            }
            $user = $request->user();

            $admin_id = $user->id;
            //get details of logged in user
            $admin_details = Admin::where('id',$admin_id)->first(); 

        //$today_appointment=SaveTelemedicalBookingDetail::where('doctor_id',$doctor_id)->where('save_telemedical_booking_detail.approved_status','!=',2)->where('appointment_time','>=',$start_time)->where('appointment_time','<',$end_time)->get(); 
           //$disputed_billing = BillingDetail::where('doctor_id',$doctor_id)->where('disputed',1)->orderBy('billing_date','DESC')->get();

          return view('admin.search_patient')->with(array('controller'=> 'pages', 'page_type'=>'search','admin_details'=>$admin_details));

    }
    /**  search patient view end section */

      public function patientSearchResult(Request $request)
    {
        try
        {
            //print_r($_REQUEST);
             //get token from session
            $value = Session::get('admin_token');
            $form_data =  $request->input();   
            //get user id from auth
            $admin_id = Auth::user()->id;

            //check login status of user
            $login_token = AdminLoginToken::where(array('admin_id'=>$admin_id,'login_token'=>$value))->first();        
            if(isset($login_token->token_status) && $login_token->token_status == 0){ 
                Auth::guard('admin')->logout();           
                return redirect('/admin/login');
            }
            if(!Auth::check()){            
                return redirect('/admin/login');
            }
            $user = $request->user();

            $admin_id = $user->id;
            //get details of logged in user
            $admin_details = Admin::where('id',$admin_id)->first(); 

            //get pagination params
            if(isset($_GET['type']))
            {        
                if($_GET['type'] == "mem_page")
                {
                    $mem_page = $_GET['page'];
                    $limit = 5;            
                }
            }
            else
            {
              $mem_page = 1;
              $limit = 5;          
            }

            $patient_name = isset($request->patient_name) ? $request->patient_name:'';
            $patient_surname = isset($request->surename) ? $request->surename:'';
              $request->dob= str_replace('/', '-', $request->dob); 
            $patient_dob = isset($request->dob) ? strtotime($request->dob):'';
            $patient_recno = isset($request->medical_record) ? $request->medical_record:'';
            $patient_recno=preg_replace("/[^0-9]/", '', $patient_recno);
            //get search data
         // DB::enableQueryLog();
           $result = Patient::select('*');
                 // If all fields are filled by user
           if($patient_name!="" AND $patient_recno!="" AND $patient_surname!="" AND $patient_dob!="" )
            {
              $result = $result->where('patient_first_name', 'like', '%'.$patient_name.'%')->where('patient_last_name',  'like', '%'.$patient_surname.'%')->where('patient_date_of_birth','like','%'.$patient_dob.'%')->where('patient_unique_id','like', '%'.$patient_recno.'%')->paginate($limit, ['*'],'page',$mem_page);

            }
            // If patient Id is filled
            if($patient_name=="" AND $patient_recno!="" AND $patient_surname=="" AND $patient_dob=="" )
            {            
             
            $result = $result->where('patient_unique_id','like', '%'.$patient_recno.'%')->paginate($limit, ['*'],'page',$mem_page);
          
            }
            // If Patient Id is empty
            if($patient_name!="" AND $patient_recno=="" AND $patient_surname!="" AND $patient_dob!="" )
            {
            $result = $result->where('patient_first_name', 'like', '%'.$patient_name.'%')->where('patient_last_name',  'like', '%'.$patient_surname.'%')->where('patient_date_of_birth','like','%'.$patient_dob.'%')->paginate($limit, ['*'],'page',$mem_page);                
            }
             return view('admin.admin_patient_search')->with(array('controller'=>'pages','admin_details'=>$admin_details,'all_patients'=>$result, 'form_data'=>$form_data));
           
        }
        catch(Exception $e)
        {
            return response()->json(['error'=>1,"message"=>$e->getMessage()],200);   
        }
    }
    /******
    Save Billing Details
    *******/
    public function saveBillDetails(Request $request){
        try{  
            $value = Session::get('admin_token');
            $admin_id = Auth::user()->id;  
            //check login status of user
            $login_token = AdminLoginToken::where(array('admin_id'=>$admin_id,'login_token'=>$value))->first();        
            if(isset($login_token->token_status) && $login_token->token_status == 0){ 
                Auth::guard('admin')->logout();           
                return redirect('/admin/login');
            }
            if(!Auth::check()){            
                return redirect('/admin/login');
            }
            $admin_details = Admin::where('id',$admin_id)->first();   
            $time_zone = $admin_details->admin_timezone;            
            $dtz = new DateTimeZone($time_zone);     
            $date = date('Y-m-d H:i:s',strtotime("now"));                   
            $time_in_sofia = new DateTime($date, $dtz);        
            $date_offset = $time_in_sofia->format('Z');       
            $billing_time = strtotime($date)-$date_offset;  
            $validator = Validator::make($_POST, [                                
                'patient_id'    => 'required',
                'history_id'    => 'required',               
                'total'         => 'required'          
              ]);
            if($validator->fails()){
                return response()->json(['success'=>0, 'message'=>$validator->messages()->first()], 200);
            }
            if(count($_POST['ser_nm']) < count($_POST['bill_amt'])){
                return response()->json(['success'=>0, 'message'=>'Please enter all the service name'], 200);
            }
            if(count($_POST['ser_nm']) > count($_POST['bill_amt'])){
                return response()->json(['success'=>0, 'message'=>'Please enter all the bill amounts.'], 200);
            }
           

          $health_history=HealthHistory::with(array('patient','doctor','history_attachments','doctor.doctor_hospital_details','nurse.nurse_hospital_details','employee.employee_hospital_details'))->where('history_id',$_POST['history_id'])->where('patient_id',$_POST['patient_id'])->first();        
                    
            $BillingDetail = new BillingDetail([                
                'billing_id'        => $this->generateUniqueNumber(),
                'doctor_id'         => $health_history->doctor_id,
                'hospital_id'       => $health_history->hospital_id,
                'assignee_type'     =>  1, 
                'patient_id'        => $_POST['patient_id'], 
                'invoice_number'    => $this->generateUniqueNumber(),
                'payable_amount'    => $_POST['total'],
                'history_id'        => $_POST['history_id'],
                'billing_date'      => $billing_time                                                              
            ]);
            $BillingDetail->save(); 
     

            foreach($_POST['ser_nm'] as $key=>$ser_nm){
                $BillingService = new BillingService([                
                    'pbilling_id'       => $BillingDetail->billing_id,
                    'service_name'      => trim($ser_nm), 
                    'service_amount'    => trim($_POST['bill_amt'][$key]),                     
                    'service_date'      => $billing_time                                                              
                ]);
                $BillingService->save(); 
            }

            $UserNotification = new UserNotification([                
                'notification_id'   => $this->generateNUniqueNumber(),
                'doctor_id'         => $health_history->doctor_id, 
                'assignee_type'     => 1,                    
                'patient_id'        => $_POST['patient_id'], 
                'event_id'          => $BillingDetail->billing_id,
                'notification_type' => "bill",
                'change_type'       => "added",
                'created_date'      => strtotime('now'),
                'status'            => 0                                          
            ]);
            $UserNotification->save(); 

            $login_token = PatientLoginToken::where('patient_id',$_POST['patient_id'])->where('token_status',1)->get();

            $msg = "Dr.".$health_history->doctor->doctor_first_name." ".$health_history->doctor->doctor_last_name." added a new bill"; 
            $patients_notification = PatientNotificationSetting::where('patient_id', $_POST['patient_id'])->first();
            if(isset($patients_notification->patient_id)){
                if($patients_notification->patient_bill_push == 1){
                    if(count($login_token) > 0 && $login_token[0]->device_type != 2){            
                        $device_token = $login_token[0]->device_token;
                        $path = base_path()."/ios_notifcation/all_notifications.php";
                        $nid = $BillingDetail->billing_id;
                        $type= 'bill';
                        exec ('php '.$path.' "'.$msg.'" '.$nid.' '.$type.' '.$device_token.' > /dev/null &');
                    }
                }

                if($patients_notification->patient_bill_sms == 1){
                    //send email notification
                    $url = url('/doctor/send_mail/'.str_replace(" ", "_", $msg).'/'.$_POST['patient_id'].'');   
                    $cmd  = "curl --max-time 60 ";   
                    $cmd .= "'" . $url . "'";   
                    $cmd .= " > /dev/null 2>&1 &";    
                    exec($cmd, $output, $exit); 
                }
            }
            return response()->json(['success'=>1,"message"=>"Billing added successfully"],200);   


        }catch(Exception $e) {
            return response()->json(['error'=>1,"message"=>$e->getMessage()],200);       
        } 
    }

protected function generateUniqueNumber() {
        $number = mt_rand(1000000000, 9999999999); // better than rand()
        // call the same function if the uniwue id exists already
        if ($this->uniqueNumberExists($number)) {
            return $this->generateUniqueNumber();
        }
        // otherwise, it's valid and can be used
        return strval($number);
    }

    protected function uniqueNumberExists($number) {
        // query the database and return a boolean         
        return HealthHistory::wherehistory_id($number)->exists();
    }

  protected function generateNUniqueNumber() {
        $number = mt_rand(1000000000, 9999999999); // better than rand()
        // call the same function if the uniwue id exists already
        if ($this->uniqueNNumberExists($number)) {
            return $this->generateNUniqueNumber();
        }
        // otherwise, it's valid and can be used
        return strval($number);
    }
    /**  search patient view end section */

    protected function uniqueNNumberExists($number) {
        // query the database and return a boolean         
        return UserNotification::wherenotification_id($number)->exists();
    }
    /******
    Pay Billing
    *******/
    public function payBilling(Request $request){
      try{  
            $value = Session::get('admin_token');
             $admin_id = Auth::user()->id;  
            //check login status of user
            $login_token = AdminLoginToken::where(array('admin_id'=>$admin_id,'login_token'=>$value))->first();        
            if(isset($login_token->token_status) && $login_token->token_status == 0){ 
                Auth::guard('admin')->logout();           
                return redirect('/admin/login');
            }
            if(!Auth::check()){            
                return redirect('/admin/login');
            }
                $admin_details = Admin::where('id',$admin_id)->first();   
               $time_zone = $admin_details->admin_timezone;            
            $dtz = new DateTimeZone($time_zone);     
            $date = date('Y-m-d H:i:s',strtotime("now"));                   
            $time_in_sofia = new DateTime($date, $dtz);        
            $date_offset = $time_in_sofia->format('Z');       
            $billing_time = strtotime($date)-$date_offset; 
                DB::enableQueryLog();
                $PayBilling = new PaidBillingDetail([
                'transaction_id'  => $_POST['transaction_id'],
                'billing_id'      => $_POST['billing_id'],
                'patient_id'      => $_POST['patient_id'],
                'doctor_id'       => $_POST['doctor_id'],             
                'created_date'    => $billing_time                       
                ]); 
 
              $PayBilling->save();        
              $update_amt = BillingDetail::where('billing_id',$_POST['billing_id'])->update(['paid_amount'=>DB::raw('paid_amount + '.$_POST['amt']),'cash_card'=>"card","paid_date"=>$billing_time]);
             $UserNotification = new UserNotification([                
              'notification_id'   => $this->generateNUniqueNumber(),              
              'assignee_type'     => 4,                    
              'patient_id'        => $_POST['patient_id'], 
              'event_id'          => $_POST['billing_id'],
              'notification_type' => "bill",
              'change_type'       => "paid",
              'created_date'      => strtotime('now'),
              'status'            => 0                                          
          ]);
          $UserNotification->save();

          $login_token = PatientLoginToken::where('patient_id',$_POST['patient_id'])->where('token_status',1)->get();
          $msg = "You paid a bill"; 
          
          if(count($login_token) > 0 && $login_token[0]->device_type != 2){            
              $device_token = $login_token[0]->device_token;
              $path = base_path()."/ios_notifcation/all_notifications.php";                            
              $nid = $_POST['billing_id'];
              $type= 'bill';
              exec ('php '.$path.' "'.$msg.'" '.$nid.' '.$type.' '.$device_token.' > /dev/null &');
          }

          $url = url('/patient/send_mail/'.str_replace(" ", "_", $msg).'/'.$_POST['patient_id'].'');   
          $cmd  = "curl --max-time 60 ";   
          $cmd .= "'" . $url . "'";   
          $cmd .= " > /dev/null 2>&1 &";    
          exec($cmd, $output, $exit); 
           //print_r(DB::connection('mysql')->getQueryLog());
          return response()->json(['success'=>1,'message'=>'Bill paid successfully.','data'=>$_POST['transaction_id']],200);

      }catch(Exception $e) {
            return response()->json(['error'=>1,"message"=>$e->getMessage()],200);       
      } 
    }
// Pay billing by cash
       public function payBillingCash(Request $request){ 
            try{             
          $value = Session::get('admin_token');
             $admin_id = Auth::user()->id;  
            //check login status of user
            $login_token = AdminLoginToken::where(array('admin_id'=>$admin_id,'login_token'=>$value))->first();        
            if(isset($login_token->token_status) && $login_token->token_status == 0){ 
                Auth::guard('admin')->logout();           
                return redirect('/admin/login');
            }
            if(!Auth::check()){            
                return redirect('/admin/login');
            }
            $admin_details = Admin::where('id',$admin_id)->first();   
            $time_zone = $admin_details->admin_timezone;            
            $dtz = new DateTimeZone($time_zone);     
            $date = date('Y-m-d H:i:s',strtotime("now"));                   
            $time_in_sofia = new DateTime($date, $dtz);        
            $date_offset = $time_in_sofia->format('Z');       
            $billing_time = strtotime($date)-$date_offset;  
            //DB::enableQueryLog();
          $update_amt = BillingDetail::where('billing_id',$_POST['billing_id'])->update(['paid_amount'=> DB::raw('paid_amount + '.$_POST['amt']),'paid_date'=>$billing_time,'cash_card'=>"cash","paid_date"=>$billing_time]);
         //print_r(DB::connection('mysql')->getQueryLog());
          $UserNotification = new UserNotification([                
              'notification_id'   => $this->generateNUniqueNumber(),              
              'assignee_type'     => 4,                    
              'patient_id'        => $_POST['patient_id'], 
              'event_id'          => $_POST['billing_id'],
              'notification_type' => "bill",
              'change_type'       => "paid",
              'created_date'      => strtotime('now'),
              'status'            => 0                                          
          ]);
          $UserNotification->save();

          $login_token = PatientLoginToken::where('patient_id',$_POST['patient_id'])->where('token_status',1)->get();
          $msg = "You paid a bill"; 
          
          if(count($login_token) > 0 && $login_token[0]->device_type != 2){            
              $device_token = $login_token[0]->device_token;
              $path = base_path()."/ios_notifcation/all_notifications.php";                            
              $nid = $_POST['billing_id'];
              $type= 'bill';
              exec ('php '.$path.' "'.$msg.'" '.$nid.' '.$type.' '.$device_token.' > /dev/null &');
          }

          $url = url('/patient/send_mail/'.str_replace(" ", "_", $msg).'/'.$_POST['patient_id'].'');   
          $cmd  = "curl --max-time 60 ";   
          $cmd .= "'" . $url . "'";   
          $cmd .= " > /dev/null 2>&1 &";    
          exec($cmd, $output, $exit); 

          return response()->json(['success'=>1,"message"=>"Bill paid successfully"],200);

        }catch(Exception $e) {
            return response()->json(['error'=>1,"message"=>$e->getMessage()],200);       
        }

       }




}
