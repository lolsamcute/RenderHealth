<?php
namespace App\Http\Controllers\Admin;


use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Auth;
use DB;
use Validator;
use Redirect;
use DateTime;
use DateTimeZone;
use Session;
use Hash;
use Mail;
use App\Models\PatientLoginToken;
use App\Models\Patient;
use App\Models\Hospital;
use App\Models\SaveTelemedicalBookingDetail;
use App\Models\HospitalHour;
use App\Models\DoctorAvailability;
use App\Models\PatientAppointment;
use App\Models\CallSession;
use App\Models\HealthHistory;
use App\Models\Doctor;
use App\Models\Nurse;
use App\Models\Admin;
use App\Models\AdminLoginToken;
use App\Models\Country;
use App\Models\PossibleDiagnosis;
use App\Models\Hmolist;
use App\Models\ServiceOffered;
use App\Models\State;
use App\Models\StatesNigeria;
use App\Models\LocalGovernment;
use App\Models\CityNigeria;
use App\Models\Facility;
use App\Models\Speciality;
use App\Models\DoctorHospitalDetail;
use App\Models\PatientsDependent;
use App\Models\Employee;
use App\Models\BillingDetail;

use App\Models\SpecialistCategories;
use App\Models\Administrator;

use App\Models\BillingService;
use App\Models\HealthHistoryMedication;
use App\Models\UserNotification;
use App\Models\PatientNotificationSetting;
use App\Models\HealthHistoryAttachments;
use App\Models\PatientHealthDiary;
use Twilio\Rest\Client;
//use Edujugon\PushNotification\PushNotification;

class AdminDashboardController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
       
        $this->middleware('auth:admin',['except' => ['SendMailTest']]);
    }
    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */
    /******
    Dashboard view
    *******/
    public function index(Request $request)
    {

        //get token from session
        $value = Session::get('admin_token');

        //get user id from auth
        $admin_id = Auth::user()->id;

        //check login status of user
        $login_token = AdminLoginToken::where(array('admin_id'=>$admin_id,'login_token'=>$value))->first();        
        if(isset($login_token->token_status) && $login_token->token_status == 0){ 
            Auth::guard('admin')->logout();           
            return redirect('/admin/login');
        }
        if(!Auth::check()){            
            return redirect('/admin/login');
        }

        $user = $request->user();
        $admin_id = $user->id;
        //get details of logged in user
        $admin_details = Admin::where('id',$admin_id)->first();  
        $time_zone = $admin_details->admin_timezone;                 
        $dtz = new DateTimeZone($time_zone);
        $time_in_sofia = new DateTime('now', $dtz);        
        $date_offset = $time_in_sofia->format('Z');
        $start_time = strtotime(date("Y-m-d"))-$date_offset;
        $end_time = strtotime(date("Y-m-d",strtotime("+1 day")))-$date_offset;
        $statesNigeria = StatesNigeria::all();
        //get pagination params
        if(isset($_GET['type']))
        {        
            if($_GET['type'] == "mem_page")
            {
                $mem_page = $_GET['page'];
                $limit = 20;            
            }
        }
        else
        {
          $mem_page = 1;
          $limit = 20;          
        }

        //get all patients
        $all_patients = Patient::orderBy('patients.id', 'desc')->paginate($limit, ['*'],'page',$mem_page);
        $hospitals = Hospital::get();
        if($request->ajax())
        {
             return view('admin.admin_members_ajax')->with(array('controller'=>'admin','admin_details'=>$admin_details,'all_patients'=>$all_patients,'hospitals'=>$hospitals,'statesNigeria'=>$statesNigeria));
        }
        else
        {
            return view('admin.dashboard')->with(array('controller'=>'admin','admin_details'=>$admin_details,'all_patients'=>$all_patients,'hospitals'=>$hospitals,'statesNigeria'=>$statesNigeria));
        }
        
        
    }

    //Update timezone on admin's login
    public function updateTimeZone(Request $request,$time_zone,$dst)
    {
        //get token from session
        $value = Session::get('admin_token');
        //get user id from auth
        $admin_id = Auth::user()->id;
        //check login status of user
        $login_token = AdminLoginToken::where(array('admin_id'=>$admin_id,'login_token'=>$value))->first();        
        if(isset($login_token->token_status) && $login_token->token_status == 0){ 
            Auth::guard('admin')->logout();           
            return response()->json(['redirect'=>1,"redirect_url"=>asset('/admin/login')],200);
        }
        if(!Auth::check()){            
            return response()->json(['redirect'=>1,"redirect_url"=>asset('/admin/login')],200);
        }
        $user = $request->user();
        $admin_id= $user->id;

        //get timezone name from seconds
        if($dst == 1){
             $time_zone_name = timezone_name_from_abbr("", $time_zone*60,1); 
             if(empty($time_zone_name)){
                $time_zone_name = timezone_name_from_abbr("", $time_zone*60,0); 
             }
        }else{
            $time_zone_name = timezone_name_from_abbr("", $time_zone*60,1); 
             if(empty($time_zone_name)){
                $time_zone_name = timezone_name_from_abbr("", $time_zone*60,0); 
             }
        } 

        //update timezone name for admin
        $update_time = Admin::where('id',$admin_id)->update(['admin_timezone'=>$time_zone_name]);
        return response()->json(['success'=>1,"redirect_url"=>route('admin.dashboard')], 200);      
    }

    /******
    Listing Hospitals/Labs
    *******/
    public function AllHospitals(Request $request)
    {
        $value = Session::get('admin_token');
        $admin_id = Auth::user()->id;
        $login_token = AdminLoginToken::where(array('admin_id'=>$admin_id,'login_token'=>$value))->first();        
        if(isset($login_token->token_status) && $login_token->token_status == 0){ 
            Auth::guard('admin')->logout();           
            return redirect('/admin/login');
        }
        if(!Auth::check()){            
            return redirect('/admin/login');
        }
        $user = $request->user();
        $admin_id = $user->id;
        $admin_details = Admin::where('id',$admin_id)->first();  
        $time_zone = $admin_details->admin_timezone;                 
        $dtz = new DateTimeZone($time_zone);
        $time_in_sofia = new DateTime('now', $dtz);        
        $date_offset = $time_in_sofia->format('Z');
        $start_time = strtotime(date("Y-m-d"))-$date_offset;
        $end_time = strtotime(date("Y-m-d",strtotime("+1 day")))-$date_offset;

        //get pagination params
        if(isset($_GET['type']))
        {        
            if($_GET['type'] == "pen_page")
            {
                $pen_page = $_GET['page'];
                $limit = 20;            
            }
            else
            {
                $pen_page = $_GET['pen_page'];
                $limit = 20;            
            }      
            if($_GET['type'] == "all_page")
            {
                $all_page = $_GET['page'];
                $limit = 20;          
            }
            else
            {
                $all_page = $_GET['all_page'];
                $limit = 20;          
            }
        }
        else
        {
          $all_page = 1;
          $pen_page =1;
          $limit = 20;          
        }

       //get all approved hospitals and their associated doctors,nurses,admins

        $all_hospitals = Hospital::select('hospitals.hosp_name','hospitals.hosp_state','hospitals.hosp_country','hospitals.hosp_id','hospitals.hosp_address','hospitals.hosp_phone','doctors.hospital_id',DB::raw('(select COUNT(doctors.id)  FROM doctors WHERE hospital_id= hospitals.hosp_id  ) as doctorsCount' ),DB::raw('(select COUNT(nurses.id)  FROM nurses WHERE hospital_id= hospitals.hosp_id  ) as nurseCount' ),DB::raw('(select COUNT(administrators.id)  FROM administrators WHERE hospital_id= hospitals.hosp_id  ) as administratorsCount' ))->leftJoin('doctors', 'hospitals.hosp_id', '=', 'doctors.hospital_id')->where('hospitals.pending_status',1)->groupBy('hospitals.hosp_id')->orderBy('hospitals.id','desc')->paginate($limit, ['*'],'page',$all_page);
       
         //get all pending hospitals/labs

        $pending_hospitals = Hospital::where('pending_status',0)->orderBy('id', 'desc')->paginate($limit, ['*'],'page',$pen_page);

        //get count of pending hospitals 

        $pending_hospitals_count = Hospital::where('pending_status',0)->count();

        //get all countries

        $countries = Country::all();
        $statesNigeria = StatesNigeria::all();
        $Hmolist = Hmolist::all();
        $serviceofferd = ServiceOffered::all();
        $facility = Facility::all();
        $speciality = Speciality::all();
        $timeList =  array(['value' => "9am",'name' => "9:00am"],
        ['value' => "9am",'name' => "9:00am"],
        ['value' => "10am",'name' => "10:00am"],
        ['value' => "11am",'name' => "11:00am"],
        ['value' => "12pm",'name' => "12:00pm"],
        ['value' => "1pm",'name' => "1:00pm"],
        ['value' => "2pm",'name' => "2:00pm"],
        ['value' => "3pm",'name' => "3:00pm"],
        ['value' => "4pm",'name' => "4:00pm"],
        ['value' => "5pm",'name' => "5:00pm"],
        ['value' => "6pm",'name' => "6:00pm"],
        ['value' => "7pm",'name' => "7:00pm"],
        ['value' => "8pm",'name' => "8:00pm"],
        ['value' => "9pm",'name' => "9:00pm"],
        ['value' => "10pm",'name' => "10:00pm"],
        ['value' => "11pm",'name' => "11:00pm"],
        ['value' => "12am",'name' => "12:00am"],
        ['value' => "1am",'name' => "1:00am"],
        ['value' => "2am",'name' => "2:00am"],
        ['value' => "3am",'name' => "3:00am"],
        ['value' => "4am",'name' => "4:00am"],
        ['value' => "5am",'name' => "5:00am"],
        ['value' => "6am",'name' => "6:00am"],
        ['value' => "7am",'name' => "7:00am"],
        ['value' => "8am",'name' => "8:00am"]);
        
        if($request->ajax())
        {
            return view('admin.admin_hospitals_ajax')->with(array('controller'=> 'admin','admin_details'=>$admin_details,'all_hospitals'=>$all_hospitals,'pending_hospitals'=>$pending_hospitals,'pending_hospitals_count'=>$pending_hospitals_count,'countries'=>$countries,'serviceofferd'=>$serviceofferd,'statesNigeria'=>$statesNigeria,'facility'=>$facility,'speciality'=>$speciality,'timeList'=>$timeList,'Hmolist'=>$Hmolist));
        }
        else
        {
            return view('admin.admin_hospitals')->with(array('controller'=> 'admin','admin_details'=>$admin_details,'all_hospitals'=>$all_hospitals,'pending_hospitals'=>$pending_hospitals,'pending_hospitals_count'=>$pending_hospitals_count,'countries'=>$countries,'serviceofferd'=>$serviceofferd,'statesNigeria'=>$statesNigeria,'facility'=>$facility,'speciality'=>$speciality,'timeList'=>$timeList,'Hmolist'=>$Hmolist));
        }

    
    } //Ends Listing Hospitals/Labs

    //Accept hospital request

    public function AcceptHospitalRequest(Request $request)
    {
        try
        {
            //get token from session
            $value = Session::get('admin_token');

            //get user id from auth
            $admin_id = Auth::user()->id;

            //check login status of user
            $login_token = AdminLoginToken::where(array('admin_id'=>$admin_id,'login_token'=>$value))->first();        
            if(isset($login_token->token_status) && $login_token->token_status == 0){ 
                Auth::guard('admin')->logout();           
                return redirect('/admin/login');
            }
            if(!Auth::check()){            
                return redirect('/admin/login');
            }
            if($request->rowid!='' && $request->hospital_id!='')
            {
                //update pending_status to 1 to approve hospital request
                $update_sts = Hospital::where('id',$request->rowid)->update(['pending_status'=>1]); 

                return response()->json(['success'=>1,'message'=>'Request Approved Successfully.'],200);
            }
            else
            {
               return response()->json(['error'=>1,"message"=>"Parametres missing"],200);
            }

            
        }
        catch(Exception $e)
        {
            return response()->json(['error'=>1,"message"=>$e->getMessage()],200);   
        }
        
    }

    //Ignore hospital request
    public function IgnoreHospitalRequest(Request $request)
    {
        try
        {
            //get token from session
            $value = Session::get('admin_token');

            //get user id from auth
            $admin_id = Auth::user()->id;

            //check login status of user
            $login_token = AdminLoginToken::where(array('admin_id'=>$admin_id,'login_token'=>$value))->first();        
            if(isset($login_token->token_status) && $login_token->token_status == 0){ 
                Auth::guard('admin')->logout();           
                return redirect('/admin/login');
            }
            if(!Auth::check()){            
                return redirect('/admin/login');
            }
            if($request->rowid!='' && $request->hospital_id!='')
            {
                //update pending_status to 2 to ignore hospital request
                $update_sts = Hospital::where('id',$request->rowid)->update(['pending_status'=>2]); 

                return response()->json(['success'=>1,'message'=>'Request Ignored Successfully.'],200);
            }
            else
            {
               return response()->json(['error'=>1,"message"=>"Parametres missing"],200);
            }

            
        }
        catch(Exception $e)
        {
            return response()->json(['error'=>1,"message"=>$e->getMessage()],200);   
        }
    }

    
    //Add new hospital
    public function AddNewHospital(Request $request)
    {
        try
        {
            //get token from session
            $value = Session::get('admin_token');

            //get user id from auth
            $admin_id = Auth::user()->id;

            //check login status of user
            $login_token = AdminLoginToken::where(array('admin_id'=>$admin_id,'login_token'=>$value))->first();        
            if(isset($login_token->token_status) && $login_token->token_status == 0){ 
                Auth::guard('admin')->logout();           
                return redirect('/admin/login');
            }
            if(!Auth::check()){            
                return redirect('/admin/login');
            }
            
         
            $name_of_facility = isset($request->name_of_facility) ? $request->name_of_facility:'';
            $hosp_email = isset($request->hosp_email) ? $request->hosp_email:'';
            $hosp_phone = isset($request->hosp_phone) ? $request->hosp_phone:'';
            $hosp_address = isset($request->hosp_address) ? $request->hosp_address:'';
            $hosp_state = isset($request->hosp_state) ? $request->hosp_state:'';
            $lga = isset($request->lga) ? $request->lga:'';
            $hosp_city = isset($request->hosp_city) ? $request->hosp_city:'';
            $type_of_facility = isset($request->type_of_facility) ? $request->type_of_facility:'';
            $hosp_speciality = isset($request->hosp_speciality) ? $request->hosp_speciality:'';
            $hospital_id = isset($request->hospital_id) ? $request->hospital_id:'';
            $serviceofferd = isset($request->serviceofferd) ? implode(',',$request->serviceofferd):NULL;
            $hmo = isset($request->hmo) ? json_encode($request->hmo):NULL;
            $point_first_name = isset($request->point_first_name) ? $request->point_first_name:'';
            $point_surname = isset($request->point_surname) ? $request->point_surname:'';
            $point_email = isset($request->point_email) ? $request->point_email:'';
            $point_phone = isset($request->point_phone) ? $request->point_phone:'';
            $point2_first_name = isset($request->point2_first_name) ? $request->point2_first_name:'';
            $point2_surname = isset($request->point2_surname) ? $request->point2_surname:'';
            $point2_email = isset($request->point2_email) ? $request->point2_email:'';
            $point2_phone = isset($request->point2_phone) ? $request->point2_phone:'';
            $hosp_city = isset($request->hosp_city) ? $request->hosp_city:'';
            $timezone = isset($request->timezone) ? $request->timezone:''; 
            // $hospital_address = isset($request->hospital_address) ? $request->hospital_address:'';
            // $hospital_state = isset($request->hospital_state) ? $request->hospital_state:'';
            // $hospital_country = isset($request->hospital_country) ? $request->hospital_country:'';
            $hospital_sts = 1;
            #validations
            if($name_of_facility=='')
            {
                return response()->json(['error'=>1,"message"=>"Please provide hospital name facility."],200);   
            }
            else if($hosp_email=='')
            {
                return response()->json(['error'=>1,"message"=>"Please provide hospital email."],200);
            }
            else if($hosp_phone=='')
            {
                return response()->json(['error'=>1,"message"=>"Please provide hospital phone number."],200);
            }
            else if(!is_numeric($hosp_phone))
            {
                return response()->json(['error'=>1,"message"=>"Please provide numeric phone number."],200);
            }
           
            else if($hosp_address=='')
            {
                return response()->json(['error'=>1,"message"=>"Please provide hospital address."],200);
            }
            else if($hosp_state==''|| $hosp_state=='0')
            {
                return response()->json(['error'=>1,"message"=>"Please provide hospital state."],200);
            }
            else if($lga=='' || $lga=='0')
            {
                return response()->json(['error'=>1,"message"=>"Please provide hospital LGA."],200);
            }
            else if($type_of_facility==''|| $type_of_facility=='0')
            {
                return response()->json(['error'=>1,"message"=>"Please provide hospital type of facility."],200);
            }
            

            //for now generate random hosp_id
            $hosp_id = time();

            //check for existing hospital 
            $exist_hospital = Hospital::where('hosp_id',$hosp_id)->count();

            if($exist_hospital > 0)
            {
                return response()->json(['error'=>1,"message"=>"Hospital already exists."],200); 
            }
            else
            {
                if($timezone!="")
                {
                    $timezone_name = timezone_name_from_abbr("", $timezone*60, false);  	
                }
                else{
                    $timezone_name=date_default_timezone_get();
                }
                
                //save details in hospitals table
                $hospital = new Hospital([
                'hosp_id'  => $hosp_id,
                'hosp_name' => $name_of_facility,
                'hosp_email' => $hosp_email,
                'hosp_phone' => $hosp_phone,
                'hosp_address' => $hosp_address,
                'hosp_state' => $hosp_state,
                'lga' => $lga,
                'hosp_city' => $hosp_city,
                'type_of_facility' => $type_of_facility,
                'hosp_speciality' => $hosp_speciality,
                'pending_status' => $hospital_sts,
                'serviceofferd'=>$serviceofferd,
                'point_first_name' => $point_first_name,
                'point_surname' => $point_surname,
                'point_email' => $point_email,
                'point_phone' => $point_phone,
                'point2_first_name' => $point2_first_name,
                'point2_surname' => $point2_surname,
                'point2_email' => $point2_email,
                'point2_phone' => $point2_phone,
                'hosp_city' => $hosp_city,
                'hmo' => $hmo,
                'hosp_timezone'=>$timezone_name,
                'hosp_created_date'=> strtotime("now")                      
                ]); 

                $hospital->save();
                if($request->hours){
                    foreach($request->hours as $key => $times){
                        $list[$key] = json_encode($times);
                    }
                    $list['hospital_id'] = $hospital->hosp_id;
                    $hospitalHour = new HospitalHour($list); 
                    $hospitalHour->save();
                }
                $send_email_from = isset($_ENV['send_email_from'])?trim($_ENV['send_email_from']):"";
               
                $get_email = Hospital::select('hosp_name','hosp_email','point_email','point2_email')->where('hosp_id',$hosp_id)->get();
                $data = array('name'=>$get_email[0]->hosp_name,'email'=>$get_email[0]->hosp_email,"type"=>"hospital");    
                $email =trim($get_email[0]->hosp_email);
                $point_email =trim($get_email[0]->point_email?$get_email[0]->point_email:'');
                $point2_email =trim($get_email[0]->point2_email?$get_email[0]->point2_email:'');
                $res = Mail::send('admin.signupemail', $data, function ($message) use ($email,$send_email_from)  {
                $message->to($email)->subject('Account Registration');
                if($send_email_from!=''){ 
                    $message->from($send_email_from,'Render Health');
                }              
                });
                  // Send message on phone
                  $message= $this->registrationmessage($hosp_id,5);
              
                  $this->sendMessage($message,'+918699499852');
                
               
                return response()->json(['success'=>1,'message'=>'Hospital added successfully.'],200);
            }

            
        }
        catch(Exception $e)
        {
            return response()->json(['error'=>1,"message"=>$e->getMessage()],200);   
        }
    }

    //Get states of a particular country
    
    public function GetStates(Request $request)
    {
        try
        {
            $countryId = isset($request->countryId) ? $request->countryId:'';

             //get token from session
            $value = Session::get('admin_token');

            //get user id from auth
            $admin_id = Auth::user()->id;

            //check login status of user
            $login_token = AdminLoginToken::where(array('admin_id'=>$admin_id,'login_token'=>$value))->first();        
            if(isset($login_token->token_status) && $login_token->token_status == 0){ 
                Auth::guard('admin')->logout();           
                return redirect('/admin/login');
            }
            if(!Auth::check()){            
                return redirect('/admin/login');
            }

            $getStates = State::where('country_id',$countryId)->get();

            

            if(count($getStates)>0)
            {
                $stateHtml='<option value="0" data-id="0">Select State</option>';
                foreach($getStates as $getState)
                {
                    $stateHtml.="<option data-id='".$getState['id']."' value='".$getState['name']."'>" . $getState['name'] . "</option>";
                }
            }
            else
            {
                $stateHtml='<option value="0" data-id="0">Select State</option>';
            }

            return response()->json(['success'=>1,"data"=>$stateHtml],200);
        }
        catch(Exception $e)
        {
            return response()->json(['error'=>1,"message"=>$e->getMessage()],200);   
        }
    }

     //Get LGAs of a particular State
    
     public function Get_LGACity(Request $request)
     {
         try
         {
             $stateId = isset($request->stateId) ? $request->stateId:'';
 
              //get token from session
             $value = Session::get('admin_token');
 
             //get user id from auth
             $admin_id = Auth::user()->id;
 
             //check login status of user
             $login_token = AdminLoginToken::where(array('admin_id'=>$admin_id,'login_token'=>$value))->first();        
             if(isset($login_token->token_status) && $login_token->token_status == 0){ 
                 Auth::guard('admin')->logout();           
                 return redirect('/admin/login');
             }
             if(!Auth::check()){            
                 return redirect('/admin/login');
             }
             //LGA
             $getLGAs = LocalGovernment::where('state_id',$stateId)->get();
             if(count($getLGAs)>0)
             {
                 $stateHtmlLGA='<option value="0" data-id="0">Select LGA</option>';
                 foreach($getLGAs as $getLGA)
                 {
                     $stateHtmlLGA.="<option data-id='".$getLGA['id']."' value='".$getLGA['name']."'>" . $getLGA['name'] . "</option>";
                 }
             }
             else
             {
                 $stateHtmlLGA='<option value="0" data-id="0">Select LGA</option>';
             }
             //City
             $getCities = CityNigeria::where('state_id',$stateId)->get();
             if(count($getCities)>0)
             {
                 $stateHtmlCity='<option value="0" data-id="0">Select City</option>';
                 foreach($getCities as $getCity)
                 {
                     $stateHtmlCity.="<option data-id='".$getCity['id']."' value='".$getCity['name']."'>" . $getCity['name'] . "</option>";
                 }
             }
             else
             {
                 $stateHtmlCity='<option value="0" data-id="0">Select City</option>';
             }
 
             return response()->json(['success'=>1,"datalga"=>$stateHtmlLGA,"datacity"=>$stateHtmlCity],200);
         }
         catch(Exception $e)
         {
             return response()->json(['error'=>1,"message"=>$e->getMessage()],200);   
         }
     }

    //Get hospital detail and members of given hospital
    
    public function HospitalDetail(Request $request,$id)
    {
        //get token from session
        $value = Session::get('admin_token');

        //get user id from auth
        $admin_id = Auth::user()->id;

        //check login status of user
        $login_token = AdminLoginToken::where(array('admin_id'=>$admin_id,'login_token'=>$value))->first();        
        if(isset($login_token->token_status) && $login_token->token_status == 0){ 
            Auth::guard('admin')->logout();           
            return redirect('/admin/login');
        }
        if(!Auth::check()){            
            return redirect('/admin/login');
        }

        //get pagination params
         if(isset($_GET['type']))
         {        
            if($_GET['type'] == "doc_page")
            {
                $doc_page = $_GET['page'];
                $limit = 20;            
            }
            else
            {
                $doc_page = $_GET['doc_page'];
                $limit =20;            
            }      
            if($_GET['type'] == "nurse_page")
            {
                $nurse_page = $_GET['page'];
                $limit = 20;          
            }
            else
            {
                $nurse_page = $_GET['nurse_page'];
                $limit = 20;          
            }
             if($_GET['type'] == "ad_page")
            {
                $ad_page = $_GET['page'];
                $limit = 20;          
            }
            else
            {
                $ad_page = $_GET['ad_page'];
                $limit = 20;          
            }
        }
        else
        {
          $doc_page = 1;
          $nurse_page =1;
          $ad_page =1;
          $limit = 20;          
        }
        $user = $request->user();
        $admin_id = $user->id;
        //get details of logged in user
        $admin_details = Admin::where('id',$admin_id)->first(); 

        //get details of hospital with details of members
        $hospital_detail = Hospital::where(array('hosp_id'=>$id))->first();

        //get All speciality categories
        $specialist_categories = Speciality::all();
        
        $specialist_categories_nurse = SpecialistCategories::select('*')->where('type_of_user', '=' ,2)->get();
        //get All Nurses of a hospital
        $hospital_nurses = Nurse::where(array('hospital_id'=>$id))->where('active_status', '!=' , 2)->orderBy('nurse_id', 'desc')->paginate($limit, ['*'],'page',$doc_page);

        //get All Administrator of a hospital
        $hospital_admins = Administrator::where(array('hospital_id'=>$id))->where('pending_status', '!=' , 2)->orderBy('admin_id', 'desc')->paginate($limit, ['*'],'page',$doc_page);

        $hospital_doctors = Doctor::where('hospital_id',$id)->where('active_status', '!=' , 2)->orderBy('doctor_id', 'desc')->paginate($limit, ['*'],'page',$doc_page);
         $countries = Country::all();
        if($request->ajax())
        {
            return view('admin.admin_hospital_detail_ajax')->with(array('controller'=> 'admin','hospital_detail'=>$hospital_detail,'hospital_doctors'=>$hospital_doctors,'admin_details'=>$admin_details,'hospital_nurses'=>$hospital_nurses,'specialist_categories'=>$specialist_categories,'hospital_admins'=>$hospital_admins,"countries"=>$countries,"specialist_categories_nurse"=>$specialist_categories_nurse));
        }

        return view('admin.admin_hospital_detail')->with(array('controller'=> 'admin','hospital_detail'=>$hospital_detail,'hospital_doctors'=>$hospital_doctors,'admin_details'=>$admin_details,'hospital_nurses'=>$hospital_nurses,'specialist_categories'=>$specialist_categories,'hospital_admins'=>$hospital_admins,"countries"=>$countries,"specialist_categories_nurse"=>$specialist_categories_nurse));
    }

    //Change doctor's active status
    public function ChangeDoctorStatus(Request $request)
    {
        try
        {
            //get token from session
            $value = Session::get('admin_token');

            //get user id from auth
            $admin_id = Auth::user()->id;

            //check login status of user
            $login_token = AdminLoginToken::where(array('admin_id'=>$admin_id,'login_token'=>$value))->first();        
            if(isset($login_token->token_status) && $login_token->token_status == 0){ 
                Auth::guard('admin')->logout();           
                return redirect('/admin/login');
            }
            if(!Auth::check()){            
                return redirect('/admin/login');
            }
            if($request->doctor_id!='')
            {
                //update active status of doctor
                $update_sts =0;
                $get_detail = Doctor::where('doctor_id',$request->doctor_id)->first();
                

                if(!empty($get_detail))
                {
                   $sts =  $get_detail['active_status'];
                   if($sts==0)
                   {
                     $update_sts = 1;
                   }
                   else if($sts==1)
                   {
                     $update_sts = 0;
                   }
                    $update_sts_doc = Doctor::where('doctor_id',$request->doctor_id)->update(['active_status'=>$update_sts]); 
                }
                return response()->json(['success'=>1,'message'=>'Status updated successfully.','update_sts'=>$update_sts],200);
            }
            else
            {
               return response()->json(['error'=>1,"message"=>"Parametres missing"],200);
            }

            
        }
        catch(Exception $e)
        {
            return response()->json(['error'=>1,"message"=>$e->getMessage()],200);   
        }
    }

    //remove doctor
    public function RemoveDoctor(Request $request)
    {
        try
        {
            //get token from session
            $value = Session::get('admin_token');

            //get user id from auth
            $admin_id = Auth::user()->id;

            //check login status of user
            $login_token = AdminLoginToken::where(array('admin_id'=>$admin_id,'login_token'=>$value))->first();        
            if(isset($login_token->token_status) && $login_token->token_status == 0){ 
                Auth::guard('admin')->logout();           
                return redirect('/admin/login');
            }
            if(!Auth::check()){            
                return redirect('/admin/login');
            }
            if($request->doctor_id!='')
            {
                //update pending_status to 1 to approve hospital request
                $update_sts = Doctor::where('doctor_id',$request->doctor_id)->update(['active_status'=>2]); 

                return response()->json(['success'=>1,'message'=>'Doctor removed Successfully.'],200);
            }
            else
            {
               return response()->json(['error'=>1,"message"=>"Parametres missing"],200);
            }

            
        }
        catch(Exception $e)
        {
            return response()->json(['error'=>1,"message"=>$e->getMessage()],200);   
        }
        
    }

    //end of remove doctor

    //update doctor manage access
    public function UpdateDoctorDetails(Request $request)
    {
        try
        {
            //get token from session
            $value = Session::get('admin_token');

            //get user id from auth
            $admin_id = Auth::user()->id;

            //check login status of user
            $login_token = AdminLoginToken::where(array('admin_id'=>$admin_id,'login_token'=>$value))->first();        
            if(isset($login_token->token_status) && $login_token->token_status == 0){ 
                Auth::guard('admin')->logout();           
                return redirect('/admin/login');
            }
            if(!Auth::check()){            
                return redirect('/admin/login');
            }

            $access_for_hospital = isset($request->access_for_hospital) ? $request->access_for_hospital:'';
            $entry_patient_record = isset($request->entry_patient_record) ? $request->entry_patient_record:'';
            $update_doctor_id = isset($request->update_doctor_id) ? $request->update_doctor_id:'';
            $active_status_doc = isset($request->active_status_doc) ? $request->active_status_doc:'';
            $appointment_access = isset($request->appointment_access) ? 1:0;
            $patient_queue_access = isset($request->patient_queue_access) ? 1:0;
            $health_record_access = isset($request->health_record_access) ? 1:0;
            $billings_access = isset($request->billings_access) ? 1:0;
            $teleconsulation_access = isset($request->teleconsulation_access) ? 1:0;
            $inventory_management_access = isset($request->inventory_management_access) ? 1:0;

            if($access_for_hospital!='')
            {
                if(count($access_for_hospital)==2)
                {
                    $access_for_hospital_val = 3; //access for both 
                }
                elseif(count($access_for_hospital)==1)
                {
                    $access_for_hospital_val = $access_for_hospital[0];
                }
            }
            else
            {
                $access_for_hospital_val=0;
            }

            if($entry_patient_record!='')
            {
                $entry_patient_record_val = $entry_patient_record;
            }
            else
            {
                $entry_patient_record_val = 0;
            }


            if($active_status_doc==" ")
            {
                $active_status_doc = 0;
            }
            else if($active_status_doc=="on") 
            {
                $active_status_doc = 1;
            }


            if($update_doctor_id!='')
            {
                //update status access_to_hospital ,access_to_patient_record 
                //$update_sts = Doctor::where('doctor_id',$update_doctor_id)->update(['access_to_hospital'=>$access_for_hospital_val]); 
                //$update_sts = Doctor::where('doctor_id',$update_doctor_id)->update(['access_to_patient_record'=>$entry_patient_record_val]); 

                 $update_sts = Doctor::where('doctor_id',$update_doctor_id)->update([
                'appointment_access'=>$appointment_access,
                'patient_queue_access'=>$patient_queue_access,
                'health_record_access'=>$health_record_access,
                'billings_access'=>$billings_access,
                'teleconsulation_access'=>$teleconsulation_access,
                'inventory_management_access'=>$inventory_management_access,
                'access_to_hospital' =>  $access_for_hospital_val,
                'access_to_patient_record'=> $entry_patient_record_val,
                'active_status'=> $active_status_doc,
                ]);

                return response()->json(['success'=>1,'message'=>'Doctor access updated Successfully.'],200);
            }
            else
            {
               return response()->json(['error'=>1,"message"=>"Parametres missing"],200);
            }

            
        }
        catch(Exception $e)
        {
            return response()->json(['error'=>1,"message"=>$e->getMessage()],200);   
        }
        
    }

    //search patient/member

    public function SearchPatient(Request $request)
    {
        try
        {
             //get token from session
            $value = Session::get('admin_token');

            //get user id from auth
            $admin_id = Auth::user()->id;

            //check login status of user
            $login_token = AdminLoginToken::where(array('admin_id'=>$admin_id,'login_token'=>$value))->first();        
            if(isset($login_token->token_status) && $login_token->token_status == 0){ 
                Auth::guard('admin')->logout();           
                return redirect('/admin/login');
            }
            if(!Auth::check()){            
                return redirect('/admin/login');
            }
            $user = $request->user();

            $admin_id = $user->id;
            //get details of logged in user
            $admin_details = Admin::where('id',$admin_id)->first(); 

            //get pagination params
            if(isset($_GET['type']))
            {        
                if($_GET['type'] == "mem_page")
                {
                    $mem_page = $_GET['page'];
                    $limit = 5;            
                }
            }
            else
            {
              $mem_page = 1;
              $limit = 5;          
            }

        $patient_name = isset($request->patient_name) ? $request->patient_name:'';
        $patient_surname = isset($request->patient_surname) ? $request->patient_surname:'';
        $request->patient_dob= str_replace('/', '-', $request->patient_dob); 
       $patient_dob = isset($request->patient_dob) ? strtotime($request->patient_dob):'';
      $patient_recno = isset($request->patient_recno) ? $request->patient_recno:'';
        $patient_recno=preg_replace("/[^0-9]/", '', $patient_recno);
            //get search data
       
         $result = Patient::select('*');
          //print_r($result);
            if($patient_name!="" AND $patient_recno!="" AND $patient_surname!="" AND $patient_dob!="" )
            {
              $result = $result->where('patient_first_name', 'like', '%'.$patient_name.'%')->where('patient_last_name',  'like', '%'.$patient_surname.'%')->where('patient_date_of_birth','like','%'.$patient_dob.'%')->where('patient_unique_id','like', '%'.$patient_recno.'%')->paginate($limit, ['*'],'page',$mem_page);

            }
            if($patient_name=="" AND $patient_recno!="" AND $patient_surname=="" AND $patient_dob=="" )
            {               
            $result = $result->where('patient_unique_id','like', '%'.$patient_recno.'%')->paginate($limit, ['*'],'page',$mem_page);         
            }
              if($patient_name!="" AND $patient_recno=="" AND $patient_surname!="" AND $patient_dob!="" )
            {
            $result = $result->where('patient_first_name', 'like', '%'.$patient_name.'%')->where('patient_last_name',  'like', '%'.$patient_surname.'%')->where('patient_date_of_birth','like','%'.$patient_dob.'%')->paginate($limit, ['*'],'page',$mem_page);               
            }            
            if($request->ajax())
            {
                 return view('admin.admin_members_search_ajax')->with(array('controller'=>'admin','admin_details'=>$admin_details,'all_patients'=>$result));
            }  
        }
        catch(Exception $e)
        {
            return response()->json(['error'=>1,"message"=>$e->getMessage()],200);   
        }
    }

     /******
    listing of all employees
    *******/
    public function AllEmployees(Request $request)
    {
        //get token from session
        $value = Session::get('admin_token');

        //get user id from auth
        $admin_id = Auth::user()->id;

        //check login status of user
        $login_token = AdminLoginToken::where(array('admin_id'=>$admin_id,'login_token'=>$value))->first();        
        if(isset($login_token->token_status) && $login_token->token_status == 0){ 
            Auth::guard('admin')->logout();           
            return redirect('/admin/login');
        }
        if(!Auth::check()){            
            return redirect('/admin/login');
        }

        $user = $request->user();
        if($user->role_type == 'employee'){
            return abort(404);
        }
        $admin_id = $user->id;

        //get details of logged in user
        $admin_details = Admin::where('id',$admin_id)->first();  
        $time_zone = $admin_details->admin_timezone;                 
        $dtz = new DateTimeZone($time_zone);
        $time_in_sofia = new DateTime('now', $dtz);        
        $date_offset = $time_in_sofia->format('Z');
        $start_time = strtotime(date("Y-m-d"))-$date_offset;
        $end_time = strtotime(date("Y-m-d",strtotime("+1 day")))-$date_offset;

        //get pagination params
        if(isset($_GET['type']))
        {        
            if($_GET['type'] == "emp_page")
            {
                $emp_page = $_GET['page'];
                $limit = 20;            
            }
        }
        else
        {
          $emp_page = 1;
          $limit = 20;          
        }

        //get all patients
        $all_employees = Admin::where('active_status', '!=' , 2)->where('role_type','employee')->orderBy('employee_id', 'desc')->paginate($limit, ['*'],'page',$emp_page);
        $countries = Country::all();
        $statesNigeria = StatesNigeria::all();
        if($request->ajax())
        {
             return view('admin.admin_employees_ajax')->with(array('controller'=>'admin','admin_details'=>$admin_details,'all_employees'=>$all_employees,'countries'=>$countries,'statesNigeria'=>$statesNigeria));
        }
        else
        {
            return view('admin.admin_employees')->with(array('controller'=>'admin','admin_details'=>$admin_details,'all_employees'=>$all_employees,'countries'=>$countries,'statesNigeria'=>$statesNigeria));
        }
        
        
    }

    //Change employee's active status
    public function ChangeEmployeeStatus(Request $request)
    {
        try
        {
            //get token from session
            $value = Session::get('admin_token');

            //get user id from auth
            $admin_id = Auth::user()->id;

            //check login status of user
            $login_token = AdminLoginToken::where(array('admin_id'=>$admin_id,'login_token'=>$value))->first();        
            if(isset($login_token->token_status) && $login_token->token_status == 0){ 
                Auth::guard('admin')->logout();           
                return redirect('/admin/login');
            }
            if(!Auth::check()){            
                return redirect('/admin/login');
            }
            if($request->emp_id!='')
            {
                //update active status of doctor
                $update_sts =0;
                $get_detail = Admin::where('employee_id',$request->emp_id)->first();
                

                if(!empty($get_detail))
                {
                   $sts =  $get_detail['active_status'];
                   if($sts==0)
                   {
                     $update_sts = 1;
                   }
                   else if($sts==1)
                   {
                     $update_sts = 0;
                   }
                    $update_sts_doc = Admin::where('employee_id',$request->emp_id)->update(['active_status'=>$update_sts]); 
                }
                return response()->json(['success'=>1,'message'=>'Status updated successfully.','update_sts'=>$update_sts],200);
            }
            else
            {
               return response()->json(['error'=>1,"message"=>"Parametres missing"],200);
            }

            
        }
        catch(Exception $e)
        {
            return response()->json(['error'=>1,"message"=>$e->getMessage()],200);   
        }
    }

    //remove employee
    public function RemoveEmployee(Request $request)
    {
        try
        {
            //get token from session
            $value = Session::get('admin_token');

            //get user id from auth
            $admin_id = Auth::user()->id;

            //check login status of user
            $login_token = AdminLoginToken::where(array('admin_id'=>$admin_id,'login_token'=>$value))->first();        
            if(isset($login_token->token_status) && $login_token->token_status == 0){ 
                Auth::guard('admin')->logout();           
                return redirect('/admin/login');
            }
            if(!Auth::check()){            
                return redirect('/admin/login');
            }
            if($request->emp_id!='')
            {
                //update status
                $update_sts = Admin::where('employee_id',$request->emp_id)->update(['active_status'=>2]); 

                return response()->json(['success'=>1,'message'=>'Employee removed Successfully.'],200);
            }
            else
            {
               return response()->json(['error'=>1,"message"=>"Parametres missing"],200);
            }

            
        }
        catch(Exception $e)
        {
            return response()->json(['error'=>1,"message"=>$e->getMessage()],200);   
        }
        
    }

    //end of remove employee

    //update employee manage access
    public function UpdateEmployeeDetails(Request $request)
    {
        try
        {
            //get token from session
            $value = Session::get('admin_token');

            //get user id from auth
            $admin_id = Auth::user()->id;

            //check login status of user
            $login_token = AdminLoginToken::where(array('admin_id'=>$admin_id,'login_token'=>$value))->first();        
            if(isset($login_token->token_status) && $login_token->token_status == 0){ 
                Auth::guard('admin')->logout();           
                return redirect('/admin/login');
            }
            if(!Auth::check()){            
                return redirect('/admin/login');
            }

            $access_for_hospital = isset($request->access_for_hospital) ? $request->access_for_hospital:'';
            $entry_patient_record = isset($request->entry_patient_record) ? $request->entry_patient_record:'';
            $update_emp_id = isset($request->update_emp_id) ? $request->update_emp_id:'';
            $active_status_emp = isset($request->active_status_emp) ? $request->active_status_emp:'';


            if($access_for_hospital!='')
            {
                if(count($access_for_hospital)==2)
                {
                    $access_for_hospital_val = 3; //access for both 
                }
                elseif(count($access_for_hospital)==1)
                {
                    $access_for_hospital_val = $access_for_hospital[0];
                }
            }
            else
            {
                $access_for_hospital_val=0;
            }

            if($entry_patient_record!='')
            {
                $entry_patient_record_val = $entry_patient_record;
            }
            else
            {
                $entry_patient_record_val = 0;
            }

            
            if($active_status_emp==" ")
            {
                $active_status_emp = 0;
            }
            else if($active_status_emp=="on") 
            {
                $active_status_emp = 1;
            }


            if($update_emp_id!='')
            {
                //update status access_to_hospital ,access_to_patient_record 


               // $update_sts = Employee::where('employee_id',$update_emp_id)->update(['access_to_hospital'=>$access_for_hospital_val,'access_to_patient_record'=>$entry_patient_record_val,'active_status'=>$active_status_emp]); 

               
                $update_sts = Admin::where('employee_id',$update_emp_id)->update([
                'access_to_hospital' =>  $access_for_hospital_val,
                'access_to_patient_record'=> $entry_patient_record_val,
                'active_status'=> $active_status_emp,
                ]);

                
                /*$update_sts = Employee::where('employee_id',$update_emp_id)->update(['access_to_patient_record'=>$entry_patient_record_val]); 
                $update_sts = Employee::where('employee_id',$update_emp_id)->update(['active_status'=>$active_status_emp]); */

                return response()->json(['success'=>1,'message'=>'Employee access updated Successfully.'],200);
            }
            else
            {
               return response()->json(['error'=>1,"message"=>"Parametres missing"],200);
            }

            
        }
        catch(Exception $e)
        {
            return response()->json(['error'=>1,"message"=>$e->getMessage()],200);   
        }
        
    }
    //search patient/member
    public function SearchEmployee(Request $request)
    {
        try
        {
             //get token from session
            $value = Session::get('admin_token');

            //get user id from auth
            $admin_id = Auth::user()->id;

            //check login status of user
            $login_token = AdminLoginToken::where(array('admin_id'=>$admin_id,'login_token'=>$value))->first();        
            if(isset($login_token->token_status) && $login_token->token_status == 0){ 
                Auth::guard('admin')->logout();           
                return redirect('/admin/login');
            }
            if(!Auth::check()){            
                return redirect('/admin/login');
            }

            $user = $request->user();
            $admin_id = $user->id;

            //get details of logged in user

            $admin_details = Admin::where('id',$admin_id)->first(); 

            //get pagination params

            if(isset($_GET['type']))
            {        
                if($_GET['type'] == "emp_page")
                {
                    $emp_page = $_GET['page'];
                    $limit = 5;            
                }
            }
            else
            {
              $emp_page = 1;
              $limit = 5;          
            }

            $name_or_id = isset($request->name_or_id) ? $request->name_or_id:'';
            
            $result = Admin::select('*');



           if($name_or_id!="") 
           {

                //echo $name_or_id;
               // $result = $result->where('active_status', '!=' , 2)->where('employee_id','like', '%'.$name_or_id.'%')->orWhere('employee_first_name','like', '%'.$name_or_id.'%')->paginate($limit, ['*'],'page',$emp_page);

                $result = DB::table('admins')
                ->select('*')
                ->where(function($query) use ($name_or_id) {
                    $query->where('employee_id', 'like', '%' . $name_or_id . '%')
                    ->orWhere('first_name', 'like', '%' . $name_or_id . '%');
                })
                ->Where('active_status', '!=' , 2)
                ->paginate($limit, ['*'],'page',$emp_page);

               
                $array = json_decode(json_encode($result), True);

                
               /*ss*/
               // $result = Employee::where(function($query) use ($param){
                //$query->where('employee_first_name','like', '%'.$name_or_id.'%')
                //->orWhere('employee_id','like', '%'.$name_or_id.'%');
                //})->where('active_status', '!=' , 2)->paginate($limit, ['*'],'page',$emp_page);
                  
           }
            
            if($request->ajax())
            {
                return view('admin.admin_employees_search_ajax')->with(array('controller'=>'admin','admin_details'=>$admin_details,'all_employees'=>$array));
            }


        }
        catch(Exception $e)
        {
            return response()->json(['error'=>1,"message"=>$e->getMessage()],200);   
        }
    }


    //add new employee

    public function AddNewEmployee(Request $request)
    {
        try
        {
            //get token from session
            $value = Session::get('admin_token');

            //get user id from auth
            $admin_id = Auth::user()->id;

            //check login status of user
            $login_token = AdminLoginToken::where(array('admin_id'=>$admin_id,'login_token'=>$value))->first();        
            if(isset($login_token->token_status) && $login_token->token_status == 0){ 
                Auth::guard('admin')->logout();           
                return redirect('/admin/login');
            }
            if(!Auth::check()){            
                return redirect('/admin/login');
            }

            $employee_title = isset($request->employee_title) ? $request->employee_title:'';
            $first_name = isset($request->first_name) ? $request->first_name:'';
            $middle_name = isset($request->middle_name) ? $request->middle_name:'';
            $surname = isset($request->surname) ? $request->surname:'';
            $emp_ph = isset($request->employee_phone) ? $request->employee_phone:'';
            $password = isset($request->password) ? $request->password:'';
            $alternative_phone = isset($request->employee_alternative_phone) ? $request->employee_alternative_phone:'';
            $emp_id = isset($request->emp_id) ? $request->emp_id:'';
            $employee_email = isset($request->employee_email) ? $request->employee_email:'';
            $emp_address = isset($request->emp_address) ? $request->emp_address:'';
            $employee_country = isset($request->employee_country) ? $request->employee_country:'';
            $employee_state = isset($request->employee_state) ? $request->employee_state:'';
            $employee_city = isset($request->employee_city) ? $request->employee_city:'';
            $date = $request->day;
            $month =$request->month;
            $month = date('m',strtotime($month));
            $year = $request->years;
            //  $date.$month.$year;
            $emp_dob = $year.'-'.$month.'-'.$date;
            $state_of_origin = isset($request->state_of_origin) ? $request->state_of_origin:'';
            $position = isset($request->position) ? $request->position:'';
            $nextofkin_first_name = isset($request->nextofkin_first_name) ? $request->nextofkin_first_name:'';
            $nextofkin_surname = isset($request->nextofkin_surname) ? $request->nextofkin_surname:'';
            $nextofkin_phone = isset($request->nextofkin_phone) ? $request->nextofkin_phone:'';
            $reference_first_name = isset($request->reference_first_name) ? $request->reference_first_name:'';
            $reference_surname = isset($request->reference_surname) ? $request->reference_surname:'';
            $reference_phone = isset($request->reference_phone) ? $request->reference_phone:'';
            $reference2_first_name = isset($request->reference2_first_name) ? $request->reference2_first_name:'';
            $reference2_surname = isset($request->reference2_surname) ? $request->reference2_surname:'';
            $reference2_phone = isset($request->reference2_phone) ? $request->reference2_phone:'';
            $emp_role = isset($request->emp_role) ? $request->emp_role:'';
            $emp_status = isset($request->emp_status) ? $request->emp_status:'';
            $emp_gender = isset($request->emp_gender) ? $request->emp_gender:'';
            $emp_marital_status = isset($request->emp_marital_status) ? $request->emp_marital_status:'';
            $access_for_hospital = isset($request->access_for_hospital) ? $request->access_for_hospital:'';
            $entry_patient_record = isset($request->entry_patient_record) ? $request->entry_patient_record:'';
            $username = isset($request->username) ? $request->username:'';
            $employee_languages = isset($request->languages) ? $request->languages:'';
            $employee_education_school = isset($request->employee_education_school) ? $request->employee_education_school:'';
            $timezone = isset($request->timezone) ? $request->timezone:'';  
			
            #validations
            if($first_name=='')
            {
                return response()->json(['error'=>1,"message"=>"Please provide employee first name."],200);   
            }
            if($surname=='')
            {
                return response()->json(['error'=>1,"message"=>"Please provide employee surname."],200);   
            }
            else if($employee_email=='')
            {
                return response()->json(['error'=>1,"message"=>"Please provide employee email address."],200);
            }
            else if($emp_ph=='')
            {
                return response()->json(['error'=>1,"message"=>"Please provide employee phone number."],200);
            }
            else if(!is_numeric($emp_ph))
            {
                return response()->json(['error'=>1,"message"=>"Please provide numeric employee phone number."],200);
            }
            else if($emp_address=='')
            {
                return response()->json(['error'=>1,"message"=>"Please provide employee address."],200);
            }
            else if($emp_id=='')
            {
                return response()->json(['error'=>1,"message"=>"Please provide employee ID."],200);
            }
            // else if($employee_country=='')
            // {
            //     return response()->json(['error'=>1,"message"=>"Please provide employee country."],200);
            // }
            else if($employee_state=='')
            {
                return response()->json(['error'=>1,"message"=>"Please provide employee state."],200);
            }
            else if($emp_status=='')
            {
                return response()->json(['error'=>1,"message"=>"Please provide employee address."],200);
            }
            else if($emp_role=='')
            {
                return response()->json(['error'=>1,"message"=>"Please provide employee address."],200);
            }
            else if(count($access_for_hospital)<=0)
            {
                return response()->json(['error'=>1,"message"=>"Please choose access for hospital."],200);
            }
            else if($entry_patient_record=='')
            {
                return response()->json(['error'=>1,"message"=>"Please choose access for patient record ."],200);
            }
          

            //for now generate random hosp_id
           // $emp_id = time();

            //check for existing employee 
            $exist_emp = Admin::where('employee_id',$emp_id)->count();

            if($exist_emp > 0)
            {
                return response()->json(['error'=>1,"message"=>"Employee already exists."],200); 
            }
            else
            {

                if($timezone!="")
                {
                    $timezone_name = timezone_name_from_abbr("", $timezone*60, false);  	
                }
                else{
                    $timezone_name=date_default_timezone_get();
                }
                if($access_for_hospital!='')
                {
                    if(count($access_for_hospital)==2)
                    {
                        $access_for_hospital_val = 3; //access for both 
                    }
                    elseif(count($access_for_hospital)==1)
                    {
                        $access_for_hospital_val = $access_for_hospital[0];
                    }
                }
                else
                {
                    $access_for_hospital_val=0;
                }

                if($entry_patient_record!='')
                {
                    $entry_patient_record_val = $entry_patient_record;
                }
                else
                {
                    $entry_patient_record_val = 0;
                }

                //upload image
                $imageName = time().'.'.request()->image->getClientOriginalExtension();

                request()->image->move(public_path('employeeimages'), $imageName);


                //save details in employee table
                $employee = new Admin([
                'employee_title'=>$employee_title,
                'employee_id'  => $emp_id,
                'first_name' => $first_name,
                'employee_middle_name' => $middle_name,
                'last_name' => $surname,
                'password' => bcrypt($password),
                'email' => $employee_email,
                'employee_phone' => $emp_ph,
                'employee_alternative_phone' => $alternative_phone,
                'employee_address' => $emp_address,
                'employee_country' => $employee_country,
                'employee_state' => $employee_state,
                'employee_city'=>$employee_city,
                'employee_dob' => $emp_dob,
                'employee_gender' => $emp_gender,
                'employee_marital_status' => $emp_marital_status,
                'state_of_origin' => $state_of_origin,
                'position' => $position,
                'nextofkin_first_name' => $nextofkin_first_name,
                'nextofkin_surname' => $nextofkin_surname,
                'nextofkin_phone' => $nextofkin_phone,
                'reference_first_name' => $reference_first_name,
                'reference_surname' => $reference_surname,
                'reference_phone' => $reference_phone,
                'reference2_first_name' => $reference2_first_name,
                'reference2_surname' => $reference2_surname,
                'reference2_phone' => $reference2_phone,
                'employee_role' => $emp_role,
                'employee_picture' => $imageName,
                'active_status' => $emp_status,
                'access_to_hospital'=> $access_for_hospital_val,
                'access_to_patient_record'=> $entry_patient_record_val,
                'username'=> $username,
                'employee_created_date'=> strtotime("now"),
                'employee_education_school'=>$employee_education_school,
                'employee_languages'=>$employee_languages,  
                'admin_timezone'=>$timezone_name,  
                'role_type'=>'employee',                  
                ]); 

                $employee->save();

                return response()->json(['success'=>1,'message'=>'Employee added successfully.'],200);
            }

            //return response()->json(['success'=>1,'message'=>'Employee added successfully.'],200);
        }
        catch(Exception $e)
        {
            return response()->json(['error'=>1,"message"=>$e->getMessage()],200);   
        }
    }


      /******listing of all Doctors *******/

    public function AllDoctors(Request $request)
    {
        //get token from session
        $value = Session::get('admin_token');

        //get user id from auth
        $admin_id = Auth::user()->id;

        //check login status of user
        $login_token = AdminLoginToken::where(array('admin_id'=>$admin_id,'login_token'=>$value))->first();        
        if(isset($login_token->token_status) && $login_token->token_status == 0){ 
            Auth::guard('admin')->logout();           
            return redirect('/admin/login');
        }
        if(!Auth::check()){            
            return redirect('/admin/login');
        }

        $user = $request->user();
        $admin_id = $user->id;
        $all_hospitals = Hospital::select('*')->get(); 
        //print_r($all_hospitals);die;

        //get details of logged in user
        $admin_details = Admin::where('id',$admin_id)->first();  
        $time_zone = $admin_details->admin_timezone;                 
        $dtz = new DateTimeZone($time_zone);
        $time_in_sofia = new DateTime('now', $dtz);        
        $date_offset = $time_in_sofia->format('Z');
        $start_time = strtotime(date("Y-m-d"))-$date_offset;
        $end_time = strtotime(date("Y-m-d",strtotime("+1 day")))-$date_offset;
        $statesNigeria = StatesNigeria::all();
        //get pagination params
        if(isset($_GET['type']))
        {        
            if($_GET['type'] == "doc_page")
            {
                $doc_page = $_GET['page'];
                $limit = 20;            
            }
        }
        else
        {
          $doc_page = 1;
          $limit = 20;          
        }

        $countries = Country::all();
         //get All speciality categories
        $specialist_categories = Speciality::select('*')->get();
      $specialist_categories_nurse = SpecialistCategories::select('*')->where('type_of_user', '=' ,2)->get();
        //get all doctors
        $all_doctors = Doctor::where('active_status', '!=' , 2)->orderBy('doctor_id', 'desc')->paginate($limit, ['*'],'page',$doc_page);

        if($request->ajax())
        {
             return view('admin.admin_doctors_ajax')->with(array('controller'=>'admin','admin_details'=>$admin_details,'all_doctors'=>$all_doctors,"countries"=>$countries,'statesNigeria'=>$statesNigeria));
        }
        else
        {
            return view('admin.admin_doctors')->with(array('controller'=>'admin','admin_details'=>$admin_details,'all_doctors'=>$all_doctors,'all_hospitals'=>$all_hospitals,'specialist_categories'=>$specialist_categories,"countries"=>$countries,"specialist_categories_nurse"=>$specialist_categories_nurse,'statesNigeria'=>$statesNigeria));
        }       
        
    }

     /****** Appointment Detail of a doctor*******/

    public function allAppointments(Request $request,$id)
    {    
        $doctor_id = $id;
        //get token from session
        $value = Session::get('admin_token');
        //get user id from auth
        $admin_id = Auth::user()->id;
        //check login status of user
        $login_token = AdminLoginToken::where(array('admin_id'=>$admin_id,'login_token'=>$value))->first();        
        if(isset($login_token->token_status) && $login_token->token_status == 0){ 
            Auth::guard('admin')->logout();           
            return redirect('/admin/login');
        }
        if(!Auth::check()){            
            return redirect('/admin/login');
        }

        $user = $request->user();
        $admin_id = $user->id;

        //get details of logged in user
        $admin_details = Admin::where('id',$admin_id)->first();  
        $time_zone = $admin_details->admin_timezone;                 
        $dtz = new DateTimeZone($time_zone);
        $time_in_sofia = new DateTime('now', $dtz);        
        $date_offset = $time_in_sofia->format('Z');
        $start_time = strtotime(date("Y-m-d"))-$date_offset;
        $end_time = strtotime(date("Y-m-d",strtotime("+1 day")))-$date_offset; 

        //Get Doctor details
        $doctor_details = Doctor::where('doctor_id',$doctor_id)->first();
        $time_zone = $doctor_details->doctor_timezone; 
        $dtz = new DateTimeZone($time_zone);
        $time_in_sofia = new DateTime('today', $dtz);                 
        $start_time = $time_in_sofia->getTimestamp();
        $one_day_after = $time_in_sofia->modify('+1 day');
        $end_time = $one_day_after->getTimestamp();        

            $query=SaveTelemedicalBookingDetail::select('save_telemedical_booking_detail.*','appointment_details.*','patients.*','save_telemedical_booking_detail.id as st_id','save_telemedical_booking_detail.status as st_status')->leftJoin('appointment_details', 'appointment_details.appointment_id','=', 'save_telemedical_booking_detail.appointment_id')->leftJoin('patients', 'save_telemedical_booking_detail.patient_id','=', 'patients.patient_unique_id');

            $query->where('save_telemedical_booking_detail.approved_status','!=',2)->where('save_telemedical_booking_detail.doctor_id',$doctor_id);

            $appointments = $query->orderBy('save_telemedical_booking_detail.appointment_time','DESC')->paginate(20);        
            foreach($appointments as $app)
            {
            SaveTelemedicalBookingDetail::where('id', $app->st_id)->update(['status' => 0]);
            }

            $today_appointment=SaveTelemedicalBookingDetail::where('doctor_id',$doctor_id)->where('save_telemedical_booking_detail.approved_status','!=',2)->where('appointment_time','>=',$start_time)->where('appointment_time','<',$end_time)->get();
            $status = SaveTelemedicalBookingDetail::where('doctor_id',$doctor_id)->where('call_status','>',0)->count();        
            $disabled = 0;
            if($status > 0){
            $disabled = 1;
            }                  

            $update_data = SaveTelemedicalBookingDetail::where('doctor_id',$doctor_id)->update(['call_status'=>0,'allowed_status'=>0]); 
            DoctorAvailability::where('doctor_id', $doctor_id)->update(['booking_status' => 0]);

            return view('admin.all_appointments')->with(array('controller'=> 'admin','today_appointments_count'=>$today_appointment->count(),'page'=>'inner','page_type'=>'appointments','timezone'=>$time_zone,'doctor_details'=>$doctor_details,'admin_details'=>$admin_details,'appointments'=>$appointments,'disabled'=>$disabled));
            }


     /******My schedule pagination ajax *******/

    public function allAppointmentsAjax(Request $request, $time="")
    {
       // echo "$time";
       // die;
        //get token from session
        $value = Session::get('admin_token');
        //get user id from auth
        $admin_id = Auth::user()->id;
        //check login status of user
        $login_token = AdminLoginToken::where(array('admin_id'=>$admin_id,'login_token'=>$value))->first();        
        if(isset($login_token->token_status) && $login_token->token_status == 0){ 
            Auth::guard('admin')->logout();           
            return redirect('/admin/login');
        }
        if(!Auth::check()){            
            return redirect('/admin/login');
        }

        $user = $request->user();
        $admin_id = $user->id;

        //get details of logged in user
        $admin_details = Admin::where('id',$admin_id)->first();  
        $time_zone = $admin_details->admin_timezone;                 
        $dtz = new DateTimeZone($time_zone);
        $time_in_sofia = new DateTime('now', $dtz);        
        $date_offset = $time_in_sofia->format('Z');
        $start_time = strtotime(date("Y-m-d"))-$date_offset;
        $end_time = strtotime(date("Y-m-d",strtotime("+1 day")))-$date_offset; 

         /*$doctor_id= '123456';
               echo 
        $doctor_details = Doctor::where('doctor_id',$request->doctor_id)->first();
        $time_zone = $doctor_details->doctor_timezone;
        $dtz = new DateTimeZone($time_zone);
        $time_in_sofia = new DateTime('today', $dtz);                 
        $start_time = $time_in_sofia->getTimestamp();
        $one_day_after = $time_in_sofia->modify('+1 day');
        $end_time = $one_day_after->getTimestamp();*/

        if($time == ""){            
            $appointments=SaveTelemedicalBookingDetail::select('save_telemedical_booking_detail.*','appointment_details.*','patients.*','save_telemedical_booking_detail.id as st_id','save_telemedical_booking_detail.status as st_status')->leftJoin('appointment_details', 'appointment_details.appointment_id','=', 'save_telemedical_booking_detail.appointment_id')->leftJoin('patients', 'save_telemedical_booking_detail.patient_id','=', 'patients.patient_unique_id')->where('save_telemedical_booking_detail.approved_status','!=',2)->where('save_telemedical_booking_detail.doctor_id',$request->doctor_id)->orderBy('save_telemedical_booking_detail.appointment_time','DESC')->paginate(20);
        }else{
            //echo $request->doctor_id;
            $query=SaveTelemedicalBookingDetail::select('save_telemedical_booking_detail.*','appointment_details.*','patients.*','save_telemedical_booking_detail.id as st_id','save_telemedical_booking_detail.status as st_status')->leftJoin('appointment_details', 'appointment_details.appointment_id','=', 'save_telemedical_booking_detail.appointment_id')->leftJoin('patients', 'save_telemedical_booking_detail.patient_id','=', 'patients.patient_unique_id');
                if($time == '1') {                                
                    $query->where('save_telemedical_booking_detail.appointment_time', '>=', $start_time)->where('save_telemedical_booking_detail.appointment_time', '<', $end_time)->where('save_telemedical_booking_detail.approved_status','!=',2)->where('save_telemedical_booking_detail.doctor_id',$request->doctor_id);
                }else if($time == '2'){
                   $query->where('save_telemedical_booking_detail.appointment_time', '>', $end_time)->where('save_telemedical_booking_detail.approved_status','!=',2)->where('save_telemedical_booking_detail.doctor_id',$request->doctor_id);
                }else if($time == '3'){
                    DB::enableQueryLog();
                    $query->where('save_telemedical_booking_detail.appointment_time', '<', $start_time)->where('save_telemedical_booking_detail.approved_status','!=',2)->where('save_telemedical_booking_detail.doctor_id',$request->doctor_id);




                }
            $appointments = $query->orderBy('save_telemedical_booking_detail.appointment_time','DESC')->paginate(20);
                //print_r(DB::connection('mysql')->getQueryLog());
         //~ echo '<pre>'; print_r($appointments); die('here');
        }
        foreach($appointments as $app)
        {
            SaveTelemedicalBookingDetail::where('id', $app->st_id)->update(['status' => 0]);
        }
       
        $today_appointment=SaveTelemedicalBookingDetail::where('doctor_id',$request->doctor_id)->where('save_telemedical_booking_detail.approved_status','!=',2)->where('appointment_time','>=',$start_time)->where('appointment_time','<',$end_time)->get();
        $status = SaveTelemedicalBookingDetail::where('doctor_id',$request->doctor_id)->where('call_status','>',0)->count();        
        $disabled = 0;
        if($status > 0){
            $disabled = 1;
        }
        return view('admin.all_appointments_ajax')->with(array('controller'=> 'admin','appointments'=>$appointments,'today_appointments_count'=>$today_appointment->count(),'page'=>'inner','disabled'=>$disabled,'timezone'=>$time_zone));
    
    }//Ends My schedule pagination ajax function

     /******My New Doctor from super admin *******/
     public function AddNewDoctor(Request $request)
    {
        try
        { 
            //get token from session
            $value = Session::get('admin_token');

            //get user id from auth
            $admin_id = Auth::user()->id;

            //check login status of user
            $login_token = AdminLoginToken::where(array('admin_id'=>$admin_id,'login_token'=>$value))->first();        
            if(isset($login_token->token_status) && $login_token->token_status == 0){ 
                Auth::guard('admin')->logout();           
                return redirect('/admin/login');
            }
            if(!Auth::check()){            
                return redirect('/admin/login');
            }


            $doctor_title = isset($request->doctor_title) ? $request->doctor_title:'';
            $doctor_first_name = isset($request->doctor_first_name) ? $request->doctor_first_name:'';
            $doctor_middle_name = isset($request->doctor_middle_name) ? $request->doctor_middle_name:'';
            $doctor_last_name = isset($request->doctor_last_name) ? $request->doctor_last_name:'';
            $doctor_email = isset($request->doctor_email) ? $request->doctor_email:'';
            $doctor_phone = isset($request->doctor_phone) ? $request->doctor_phone:'';
            $doctor_gender = isset($request->doctor_gender) ? $request->doctor_gender:'';
            $date = $request->day;
            $month =$request->month;
            $month = date('m',strtotime($month));
            $year = $request->years;
            //  $date.$month.$year;
            $doctor_dob = $year.'-'.$month.'-'.$date; 
            $doctor_role = isset($request->doctor_role) ? $request->doctor_role:'doctor';
            $doctor_speciality = isset($request->doctor_speciality) ? $request->doctor_speciality:'';
            $mdcn_register_no = isset($request->mdcn_register_no) ? $request->mdcn_register_no:'';
            $folio_number = isset($request->folio_number) ? $request->folio_number:'';
            $biography = isset($request->biography) ? $request->biography:'';
			$dr_id = isset($request->doctor_id) ? $request->doctor_id:'';
            $doctor_username = isset($request->doctor_username) ? $request->doctor_username:'';
            $doctor_password = isset($request->doctor_password) ? $request->doctor_password:'';

			$dr_last_name = isset($request->dr_last_name) ? $request->dr_last_name:'';
			$dr_email = isset($request->dr_email) ? $request->dr_email:'';
			$dr_ph = isset($request->dr_ph) ? $request->dr_ph:'';
			$dr_state = isset($request->dr_state) ? $request->dr_state:'';
			$dr_status = isset($request->dr_status) ? $request->dr_status:'';
			$dr_country = isset($request->dr_country) ? $request->dr_country:'';
			$edu_school = isset($request->edu_school) ? $request->edu_school:'';
			$degree = isset($request->degree) ? $request->degree:'';
            $languages = isset($request->languages) ? $request->languages:'';
			$speciality = isset($request->speciality) ? $request->speciality:'';
			$religion = isset($request->religion) ? $request->religion:'';
			$ethnicity = isset($request->ethnicity) ? $request->ethnicity:'';
			$years_practised = isset($request->years_practised) ? $request->years_practised:'';
			$folio_number = isset($request->folio_number) ? $request->folio_number:'';
			$dr_info = isset($request->dr_info) ? $request->dr_info:'';
			$password = isset($request->dr_password) ? $request->dr_password:''; 
			$hosp_id = isset($request->hosp_id) ? $request->hosp_id:'';
			$dataId = isset($request->dataId) ? $request->dataId:'';  
			$telemedical = isset($request->teleconsultation) ? $request->teleconsultation:'';
            $dr_marital_status = isset($request->dr_marital_status) ? $request->dr_marital_status:'';
            $lga = isset($request->lga) ? $request->lga:'';
            $doctor_city = isset($request->doctor_city) ? $request->doctor_city:'';
            $doctor_address = isset($request->doctor_address) ? $request->doctor_address:'';
			$dr_gender = isset($request->dr_gender) ? $request->dr_gender:'';  
            $timezone = isset($request->timezone) ? $request->timezone:'';  
            //check for existing employee 
            $exist_dr = Doctor::where('doctor_id',$dr_id)->count();

            if($exist_dr > 0)
            {
                return response()->json(['error'=>1,"message"=>"Doctor already exists."],200); 
            }
            else
            {

                //upload image
                $imageName = time().'.'.request()->image->getClientOriginalExtension();

                request()->image->move(public_path('doctorimages'), $imageName);
			if($timezone!="")
			{
			$timezone_name = timezone_name_from_abbr("", $timezone*60, false);  	
			}
			else{
			$timezone_name=date_default_timezone_get();
			}

				
                //echo $speciality;die;
                //save details in employee table
                $doctor = new Doctor([
                'doctor_id'  => $dr_id,
                'hospital_id'  => $hosp_id,
                'doctor_title'=>$doctor_title,
                'doctor_middle_name'=>$doctor_middle_name,
                'doctor_speciality'=>$doctor_speciality,
                'doctor_first_name' => $doctor_first_name,
                'doctor_last_name' => $doctor_last_name,
                'doctor_email' => $doctor_email,
                'doctor_phone' => $doctor_phone,
                'doctor_dob'=>$doctor_dob,
                'doctor_role'=>$doctor_role,
                'doctor_speciality'=>$doctor_speciality,
                'mdcn_register_no'=>$mdcn_register_no,
                'biography'=>$biography,
                'doctor_username'=>$doctor_username,
                'doctor_state' => $dr_state,
                'doctor_country' => $dr_country,
                'doctor_education_school' => $edu_school,
                'doctor_degree' => $degree,                
                'doctor_languages' => $languages,
                'doctor_religion' => $religion,
                'doctor_ethnicity' => $ethnicity,
                'doctor_years_practised' => $years_practised,
                'folio_number' => $folio_number,
                'doctor_info' => $dr_info,
                'doctor_picture' => $imageName,
                'active_status' => 1,
                'telemedical' => $telemedical,
                'doctor_gender' => $doctor_gender,
                'marital_status' => $dr_marital_status,
                'doctor_timezone'=>  $timezone_name,
                'doctor_created_date'=> strtotime("now") ,
                'doctor_password' => bcrypt($doctor_password),
                'doctor_state'=> $dr_state,      
                'doctor_address'=> $doctor_address,              
                'lga'=> $lga,  
                'doctor_city'=> $doctor_city,                     
                ]);
                //print_r($doctor); die; 
                $doctor->save();
                $send_email_from = isset($_ENV['send_email_from'])?trim($_ENV['send_email_from']):'';
                $get_email = Doctor::select('doctor_email','doctor_first_name','doctor_last_name','doctor_password')->where('doctor_id',$dr_id)->get();
                $data = array('name'=>$get_email[0]->doctor_first_name,'email'=>$get_email[0]->doctor_email,'password'=>$password,"type"=>"doctor");    
               $email = trim($get_email[0]->doctor_email);
                $res = Mail::send('admin.signupemail', $data, function ($message) use ($email,$send_email_from)  {
                $message->to($email)->subject('Account Registration');
                $message->from($send_email_from,'Render Health');
                });
                // Send message on phone
                $message= $this->registrationmessage($dr_id,1);
                      //$message='Welcome To Render Health.Thank you for signing up with Render Health.'; 
                  $this->sendMessage($message,'+918699499852');  
                return response()->json(['success'=>1,'message'=>'Doctor added successfully.'],200);
            }

            //return response()->json(['success'=>1,'message'=>'Employee added successfully.'],200);
        }
        catch(Exception $e)
        {
            return response()->json(['error'=>1,"message"=>$e->getMessage()],200);   
        }
    }


     //search Doctor
    public function SearchDoctor(Request $request)
    {
       try
        {
             //get token from session
            $value = Session::get('admin_token');
            //get user id from auth
            $admin_id = Auth::user()->id;
            //check login status of user
            $login_token = AdminLoginToken::where(array('admin_id'=>$admin_id,'login_token'=>$value))->first();        
            if(isset($login_token->token_status) && $login_token->token_status == 0){ 
                Auth::guard('admin')->logout();           
                return redirect('/admin/login');
            }
            if(!Auth::check()){            
                return redirect('/admin/login');
            }

            $user = $request->user();
            $admin_id = $user->id;
            //get details of logged in user
            $admin_details = Admin::where('id',$admin_id)->first(); 
            //get pagination params
            if(isset($_GET['type']))
            {        
                if($_GET['type'] == "emp_page")
                {
                    $emp_page = $_GET['page'];
                    $limit = 5;            
                }
            }
            else
            {
              $emp_page = 1;
              $limit = 5;          
            }

            $name_or_id = isset($request->name_or_id) ? $request->name_or_id:'';            
            $result = Doctor::select('*');
           if($name_or_id!="") 
           {
                $result = DB::table('doctors')
                ->select('*')
                ->where(function($query) use ($name_or_id) {
                    $query->where('doctor_id', 'like', '%' . $name_or_id . '%')
                    ->orWhere('doctor_first_name', 'like', '%' . $name_or_id . '%');
                })
                ->Where('active_status', '!=' , 2)
                ->paginate($limit, ['*'],'page',$emp_page);
               
                $array = json_decode(json_encode($result), True);                  
           }
            
            if($request->ajax())
            {
                return view('admin.admin_doctor_search_ajax')->with(array('controller'=>'admin','admin_details'=>$admin_details,'all_doctors'=>$array));
            }


        }
        catch(Exception $e)
        {
            return response()->json(['error'=>1,"message"=>$e->getMessage()],200);   
        }
    }

    /******My New Member from super admin *******/
     public function AddNewMember(Request $request)
    {
       
        try
        { 
            $unique_number = mt_rand(1000000000, 9999999999); 
            //get token from session
            $value = Session::get('admin_token');

            //get user id from auth
            $admin_id = Auth::user()->id;

            //check login status of user
            $login_token = AdminLoginToken::where(array('admin_id'=>$admin_id,'login_token'=>$value))->first();        
            if(isset($login_token->token_status) && $login_token->token_status == 0){ 
                Auth::guard('admin')->logout();           
                return redirect('/admin/login');
            }
            if(!Auth::check()){            
                return redirect('/admin/login');
            }
             
            $patient_title = isset($request->patient_title) ? $request->patient_title:'';
            $patient_address = isset($request->patient_address) ? $request->patient_address:'';
            $patient_gender = isset($request->patient_gender) ? $request->patient_gender:'';
            $patient_martial_status = isset($request->patient_martial_status) ? $request->patient_martial_status:'';
            $patient_origin_state = isset($request->patient_origin_state) ? $request->patient_origin_state:'';
            $patient_blood_type = isset($request->patient_blood_type) ? $request->patient_blood_type:'';
            $religion = isset($request->religion) ? $request->religion:'';
            $patient_languages = isset($request->languages) ? $request->languages:'';
            $patient_insurance = isset($request->patient_insurance) ? $request->patient_insurance:'';
            $patient_visited_hospital = isset($request->patient_visited_hospital) ? $request->patient_visited_hospital:'';
            $next_first_name = isset($request->next_first_name) ? $request->next_first_name:'';
            $next_surname = isset($request->next_surname) ? $request->next_surname:'';
            $next_phone = isset($request->next_phone) ? $request->next_phone:'';
            $member_username = isset($request->patient_username) ? $request->patient_username:'';
            $patient_first_name = isset($request->patient_first_name) ? $request->patient_first_name:'';
            $patient_middle_name = isset($request->patient_middle_name) ? $request->patient_middle_name:'';
            $patient_last_name = isset($request->patient_last_name) ? $request->patient_last_name:'';
            $patient_email = isset($request->patient_email) ? $request->patient_email:'';
            $patient_phone = isset($request->patient_phone) ? $request->patient_phone:'';
            $patient_state = isset($request->patient_state) ? $request->patient_state:'';
            $lga = isset($request->lga) ? $request->lga:'';
            $patient_city = isset($request->patient_city) ? $request->patient_city:'';
            $patient_password = isset($request->patient_password) ? $request->patient_password:'';
            $edu_school = isset($request->edu_school) ? $request->edu_school:'';
            $unique_number = $unique_number;
            $date = $request->day;
            $month =$request->month;
            $month = date('m',strtotime($month));
            $year = $request->years;
            //  $date.$month.$year;
            $patient_dob = $year.'-'.$month.'-'.$date;     
            //check for existing employee 
            $member_id = Patient::where('patient_unique_id',$unique_number)->count();

            if($member_id > 0)
            {
                return response()->json(['error'=>1,"message"=>"member already exists."],200); 
            }
            else
            {

                //save details in Member/Patient table
                $member = new Patient([
                'patient_title'=>$patient_title,
                'patient_address'  => $patient_address,
                'patient_gender'  => $patient_gender,
                'patient_martial_status'  => $patient_martial_status,
                'patient_origin_state'  => $patient_origin_state,
                'patient_blood_type'  => $patient_blood_type,
                'religion'  => $religion,
                'patient_languages'  => $patient_languages,
                'patient_insurance'  => $patient_insurance,
                'patient_visited_hospital'  => $patient_visited_hospital,
                'next_first_name'  => $next_first_name,
                'next_surname'  => $next_surname,
                'next_phone'  => $next_phone,
                'patient_unique_id'  => $unique_number,
                'patient_username'=>$member_username,
                'patient_password' => bcrypt($patient_password),
                'patient_first_name' => $patient_first_name,
                'patient_middle_name' => $patient_middle_name,
                'patient_last_name' => $patient_last_name,
                'patient_email' => $patient_email,
                'patient_phone' => $patient_phone,
                'patient_date_of_birth' => strtotime($patient_dob),
                'patient_martial_status'=>2,
                'doctor_timezone'=>  date_default_timezone_get(),
                'created_at'=> strtotime("now") ,  
                'patient_state'=> $patient_state,                  
                'lga'=> $lga,  
                'patient_city'=> $patient_city,  
                'edu_school'=>$edu_school,
                ]); 
                $member->save();
                //dependent table
                foreach($request->dependentname as $name => $valname){
                    $array[$name]['name'] = $valname;
                }
                foreach($request->dependentday as $day => $valday){
                    $array[$day]['day'] = $valday;
                }
                foreach($request->dependentmonth as $month => $valmonth){
                    $array[$month]['month'] = $valmonth;
                }
                foreach($request->dependentyears as $years => $valyears){
                    $array[$years]['years'] = $valyears;
                }
                foreach($request->dependentrelationship as $relationship => $valrelationship){
                    $array[$relationship]['relationship'] = $valrelationship;
                }
                // $array['patients_id'] = 123;
                foreach($array as $key => $value){
                    $value['patients_id'] = $member->id;
                    $PatientsDependent = new PatientsDependent($value); 
                    $PatientsDependent->save();
                }
                $send_email_from = isset($_ENV['send_email_from'])?trim($_ENV['send_email_from']):"";
               
                $get_email = Patient::select('patient_first_name','patient_middle_name','patient_last_name','patient_email')->where('patient_unique_id',$unique_number)->get();
                $data = array('name'=>$get_email[0]->patient_first_name,'email'=>$get_email[0]->patient_email,'password'=>$_POST['patient_password'],"type"=>"patient");    
                $email =trim($get_email[0]->patient_email);
               
                $res = Mail::send('admin.signupemail1', $data, function ($message) use ($email,$send_email_from)  {
                $message->to($email)->subject('Account Registration');
                if($send_email_from!=''){ 
                    $message->from($send_email_from,'Render Health');
                }              
                });
                 // Send message on phone
                $message= $this->registrationmessage($unique_number,4);
              
                  $this->sendMessage($message,'+918699499852'); 
                return response()->json(['success'=>1,'message'=>'Member added successfully.'],200);
            }

            //return response()->json(['success'=>1,'message'=>'Employee added successfully.'],200);
        }
        catch(Exception $e)
        {
            return response()->json(['error'=>1,"message"=>$e->getMessage()],200);   
        }
    }

     //search Hospital
    public function SearchHospital(Request $request)
    {

       try
        {
             //get token from session
            $value = Session::get('admin_token');
            //get user id from auth
            $admin_id = Auth::user()->id;
            //check login status of user
            $login_token = AdminLoginToken::where(array('admin_id'=>$admin_id,'login_token'=>$value))->first();        
            if(isset($login_token->token_status) && $login_token->token_status == 0){ 
                Auth::guard('admin')->logout();           
                return redirect('/admin/login');
            }
            if(!Auth::check()){            
                return redirect('/admin/login');
            }

            $user = $request->user();
            $admin_id = $user->id;
            //get details of logged in user
            $admin_details = Admin::where('id',$admin_id)->first(); 
            //get pagination params
            if(isset($_GET['type']))
            {        
                if($_GET['type'] == "emp_page")
                {
                    $emp_page = $_GET['page'];
                    $limit = 5;            
                }
            }
            else
            {
              $emp_page = 1;
              $limit = 5;          
            }

            $name_or_id = isset($request->name_or_id) ? $request->name_or_id:'';            
            $result = Hospital::select('*');
           if($name_or_id!="") 
           {

                $result = DB::table('hospitals')
                ->select('hosp_name','hosp_state','hosp_country','hosp_id','hosp_address','hosp_phone',DB::raw('(select COUNT(doctors.id)  FROM doctors WHERE hospital_id= hosp_id  ) as doctorsCount' ),DB::raw('(select COUNT(nurses.id)  FROM nurses WHERE hospital_id= hosp_id  ) as nurseCount' ),DB::raw('(select COUNT(administrators.id)  FROM administrators WHERE hospital_id= hosp_id  ) as administratorsCount' ))
                ->where(function($query) use ($name_or_id) {
                    $query->where('hosp_id', 'like', '%' . $name_or_id . '%')
                    ->orWhere('hosp_name', 'like', '%' . $name_or_id . '%');
                })
                ->Where('pending_status', '!=' ,'')
                ->paginate($limit, ['*'],'page',$emp_page);
               
                $array = json_decode(json_encode($result), True);                  
           }
            //print_r($array); die;
            if($request->ajax())
            {
                return view('admin.admin_hospital_search_ajax')->with(array('controller'=>'admin','admin_details'=>$admin_details,'all_hospitals'=>$array));
            }


        }
        catch(Exception $e)
        {
            return response()->json(['error'=>1,"message"=>$e->getMessage()],200);   
        }
    }

    /******My New Nurse from super admin Hospital Tab *******/
     public function AddNewNurse(Request $request)
    {
        try
        { 
            //get token from session
            $value = Session::get('admin_token');

            //get user id from auth
            $admin_id = Auth::user()->id;

            //check login status of user
            $login_token = AdminLoginToken::where(array('admin_id'=>$admin_id,'login_token'=>$value))->first();        
            if(isset($login_token->token_status) && $login_token->token_status == 0){ 
                Auth::guard('admin')->logout();           
                return redirect('/admin/login');
            }
            if(!Auth::check()){            
                return redirect('/admin/login');
            }


            $nurse_title = isset($request->nurse_title) ? $request->nurse_title:'';
            $nurse_first_name = isset($request->nurse_first_name) ? $request->nurse_first_name:'';
            $nurse_middle_name = isset($request->nurse_middle_name) ? $request->nurse_middle_name:'';
            $nurse_last_name = isset($request->nurse_last_name) ? $request->nurse_last_name:'';
            $nurse_email = isset($request->nurse_email) ? $request->nurse_email:'';
            $nurse_ph = isset($request->nurse_phone) ? $request->nurse_phone:'';
            $nurse_role = isset($request->nurse_role) ? $request->nurse_role:'nurse';
            $date = $request->day;
            $month =$request->month;
            $month = date('m',strtotime($month));
            $year = $request->years;
            //  $date.$month.$year;
            $nurse_dob = $year.'-'.$month.'-'.$date; 
            $nurse_username = isset($request->nurse_username) ? $request->nurse_username:'';
            $nurse_last_name = isset($request->nurse_last_name) ? $request->nurse_last_name:'';
            $nurse_id = isset($request->nurse_id) ? $request->nurse_id:'';
            $nurse_state = isset($request->nurse_state) ? $request->nurse_state:'';
            $nurse_status = isset($request->nurse_status) ? $request->nurse_status:'';
            $nurse_country = isset($request->nurse_country) ? $request->nurse_country:'';
            $edu_school = isset($request->edu_school) ? $request->edu_school:'';
            $degree = isset($request->degree) ? $request->degree:'';
            $languages = isset($request->languages) ? $request->languages:'';
            $speciality = isset($request->speciality) ? $request->speciality:'';
            $religion = isset($request->religion) ? $request->religion:'';
            $ethnicity = isset($request->ethnicity) ? $request->ethnicity:'';
            $years_practised = isset($request->years_practised) ? $request->years_practised:'';
            $folio_number = isset($request->folio_number) ? $request->folio_number:'';
            $nurse_info = isset($request->nurse_info) ? $request->nurse_info:'';
            $password = isset($request->nurse_password) ? $request->nurse_password:''; 
            $hosp_id = isset($request->hosp_id) ? $request->hosp_id:'';
            $nurse_marital_status = isset($request->nurse_marital_status) ? $request->nurse_marital_status:'';
           $nurse_gender = isset($request->nurse_gender) ? $request->nurse_gender:'';  
             $timezone = isset($request->timezone) ? $request->timezone:'';  
            //check for existing Nurse 
            $exist_nurse = Nurse::where('nurse_id',$nurse_id)->count();

            if($exist_nurse > 0)
            {
                return response()->json(['error'=>1,"message"=>"Nurse already exists."],200); 
            }
            else
            {
				if($timezone!="")
				{
				$timezone_name = timezone_name_from_abbr("", $timezone*60, false);  	
				}
				else{
				$timezone_name=date_default_timezone_get();
				}

                //upload image
                $imageName = time().'.'.request()->image->getClientOriginalExtension();

                request()->image->move(public_path('nurseimages'), $imageName);

                //echo $speciality;die;
                //save details in employee table
                $nurse = new Nurse([
                'nurse_title'  => $nurse_title,
                'nurse_id'  => $nurse_id,
                'hospital_id'  => $hosp_id,
                'nurse_speciality'=>$speciality,
                'nurse_first_name' => $nurse_first_name,
                'nurse_middle_name'=>$nurse_middle_name,
                'nurse_last_name' => $nurse_last_name,
                'nurse_email' => $nurse_email,
                'nurse_phone' => $nurse_ph,
                'nurse_dob' => $nurse_dob,
                'nurse_state' => $nurse_state,
                'nurse_role' => $nurse_role,
                'nurse_username'=>$nurse_username,
                'nurse_country' => $nurse_country,
                'nurse_education_school' => $edu_school,
                'nurse_degree' => $degree,                
                'nurse_languages' => $languages,
                'nurse_religion' => $religion,
                'nurse_ethnicity' => $ethnicity,
                'nurse_years_practised' => $years_practised,
                'folio_number' => $folio_number,
                'nurse_info' => $nurse_info,
                'nurse_picture' => $imageName,
                'nurse_gender' => $nurse_gender,
                'nurse_marital_status' => $nurse_marital_status,
                'active_status' => 1,
                'nurse_timezone'=>  $timezone_name,
                'nurse_created_date'=> strtotime("now") ,
                'nurse_password' => bcrypt($password)                     
                ]); 
                $nurse->save();
                $send_email_from = isset($_ENV['send_email_from'])?trim($_ENV['send_email_from']):'';
                $get_email = Nurse::select('nurse_email','nurse_first_name','nurse_last_name','nurse_password')->where('nurse_id',$nurse_id)->get();
                $data = array('name'=>$get_email[0]->nurse_first_name.' '.$get_email[0]->nurse_last_name,'email'=>$get_email[0]->nurse_email,'password'=>$password,"type"=>"nurse");    
                $email = trim($get_email[0]->nurse_email);
                $res = Mail::send('admin.signupemail', $data, function ($message) use ($email,$send_email_from)  {
                $message->to($email)->subject('Account Registration');
                $message->from($send_email_from,'Render Health');
                });
                // Send message on phone
                $message= $this->registrationmessage($nurse_id,2);
               // $message='Welcome To Render Health.Thank you for signing up with Render Health.'; 
                     $this->sendMessage($message,'+918699499852'); 
                return response()->json(['success'=>1,'message'=>'Nurse added successfully.'],200);
            }

            //return response()->json(['success'=>1,'message'=>'Employee added successfully.'],200);
        }
        catch(Exception $e)
        {
            return response()->json(['error'=>1,"message"=>$e->getMessage()],200);   
        }
    }

     //update Nurse manage access
    public function UpdateNurseDetails(Request $request)
    {
        try
        {
            //get token from session
            $value = Session::get('admin_token');

            //get user id from auth
            $admin_id = Auth::user()->id;

            //check login status of user
            $login_token = AdminLoginToken::where(array('admin_id'=>$admin_id,'login_token'=>$value))->first();        
            if(isset($login_token->token_status) && $login_token->token_status == 0){ 
                Auth::guard('admin')->logout();           
                return redirect('/admin/login');
            }
            if(!Auth::check()){            
                return redirect('/admin/login');
            }

            $access_for_hospital = isset($request->access_for_hospital) ? $request->access_for_hospital:'';
            $entry_patient_record = isset($request->entry_patient_record) ? $request->entry_patient_record:'';
            $update_nurse_id = isset($request->update_nurse_id) ? $request->update_nurse_id:'';
            $active_status_nurse = isset($request->active_status_nurse) ? $request->active_status_nurse:'';


            if($access_for_hospital!='')
            {
                if(count($access_for_hospital)==2)
                {
                    $access_for_hospital_val = 3; //access for both 
                }
                elseif(count($access_for_hospital)==1)
                {
                    $access_for_hospital_val = $access_for_hospital[0];
                }
            }
            else
            {
                $access_for_hospital_val=0;
            }

            if($entry_patient_record!='')
            {
                $entry_patient_record_val = $entry_patient_record;
            }
            else
            {
                $entry_patient_record_val = 0;
            }


            if($active_status_nurse==" ")
            {
                $active_status_nurse = 0;
            }
            else if($active_status_nurse=="on") 
            {
                $active_status_nurse = 1;
            }


            if($update_nurse_id!='')
            {
                //update status access_to_hospital ,access_to_patient_record 
                //$update_sts = Doctor::where('doctor_id',$update_doctor_id)->update(['access_to_hospital'=>$access_for_hospital_val]); 
                //$update_sts = Doctor::where('doctor_id',$update_doctor_id)->update(['access_to_patient_record'=>$entry_patient_record_val]); 

                 $update_sts = Nurse::where('nurse_id',$update_nurse_id)->update([
                'access_to_hospital' =>  $access_for_hospital_val,
                'access_to_patient_record'=> $entry_patient_record_val,
                'active_status'=> $active_status_nurse,
                ]);

                return response()->json(['success'=>1,'message'=>'Nurse access updated Successfully.'],200);
            }
            else
            {
               return response()->json(['error'=>1,"message"=>"Parametres missing"],200);
            }

            
        }
        catch(Exception $e)
        {
            return response()->json(['error'=>1,"message"=>$e->getMessage()],200);   
        }
        
    }

    //remove Nurse
    public function RemoveNurse(Request $request)
    {
        try
        {
            //get token from session
            $value = Session::get('admin_token');

            //get user id from auth
            $admin_id = Auth::user()->id;

            //check login status of user
            $login_token = AdminLoginToken::where(array('admin_id'=>$admin_id,'login_token'=>$value))->first();        
            if(isset($login_token->token_status) && $login_token->token_status == 0){ 
                Auth::guard('admin')->logout();           
                return redirect('/admin/login');
            }
            if(!Auth::check()){            
                return redirect('/admin/login');
            }
            if($request->nurse_id!='')
            {
                //update pending_status to 1 to approve hospital request
                $update_sts = Nurse::where('nurse_id',$request->nurse_id)->update(['active_status'=>2]); 

                return response()->json(['success'=>1,'message'=>'Nurse removed Successfully.'],200);
            }
            else
            {
               return response()->json(['error'=>1,"message"=>"Parametres missing"],200);
            }

            
        }
        catch(Exception $e)
        {
            return response()->json(['error'=>1,"message"=>$e->getMessage()],200);   
        }
        
    }

    //end of remove Nurse

     /******My New Administrator from super admin Hospital Tab *******/
     public function AddNewAdmin(Request $request)
    {
        try
        { 
            //get token from session
            $value = Session::get('admin_token');

            //get user id from auth
            $admin_id = Auth::user()->id;

            //check login status of user
            $login_token = AdminLoginToken::where(array('admin_id'=>$admin_id,'login_token'=>$value))->first();        
            if(isset($login_token->token_status) && $login_token->token_status == 0){ 
                Auth::guard('admin')->logout();           
                return redirect('/admin/login');
            }
            if(!Auth::check()){            
                return redirect('/admin/login');
            }

            $admin_title = isset($request->admin_title) ? $request->admin_title:'';
            $admin_first_name = isset($request->admin_first_name) ? $request->admin_first_name:'';
            $admin_middle_name = isset($request->admin_middlename) ? $request->admin_middlename:'';
            $admin_last_name = isset($request->admin_last_name) ? $request->admin_last_name:'';
            $admin_email = isset($request->admin_email) ? $request->admin_email:'';
            $admin_gender = isset($request->admin_gender) ? $request->admin_gender:'';
            $date = $request->day;
            $month =$request->month;
            $month = date('m',strtotime($month));
            $year = $request->years;
            //  $date.$month.$year;
            $admin_dob = $year.'-'.$month.'-'.$date;
            $admin_role = isset($request->admin_role) ? $request->admin_role:'admin';
            $admin_username = isset($request->admin_username) ? $request->admin_username:'';
            $admin_name = isset($request->admin_name) ? $request->admin_name:'';
            $admin_ph = isset($request->admin_ph) ? $request->admin_ph:'';
            $administrator_id = isset($request->admin_id) ? $request->admin_id:'';
            $admin_state = isset($request->admin_state) ? $request->admin_state:'';
            $admin_country = isset($request->admin_country) ? $request->admin_country:'';
            $admin_info = isset($request->admin_info) ? $request->admin_info:'';
            $password = isset($request->admin_password) ? $request->admin_password:''; 
            $hospital_id = isset($request->hosp_id) ? $request->hosp_id:'';
            $admin_status = isset($request->admin_status) ? $request->admin_status:'';
            $admin_marital_status = isset($request->admin_marital_status) ? $request->admin_marital_status:'';
           $timezone = isset($request->timezone) ? $request->timezone:'';
            //check for existing Administrator 
            $exist_admin = Administrator::where('admin_id',$administrator_id)->count();

            if($exist_admin > 0)
            {
                return response()->json(['error'=>1,"message"=>"Administrator already exists."],200); 
            }
            else
            {
            	if($timezone!="")
				{
				$timezone_name = timezone_name_from_abbr("", $timezone*60, false);  	
				}
				else{
				$timezone_name=date_default_timezone_get();
				}


                //upload image
                $imageName = time().'.'.request()->image->getClientOriginalExtension();

                request()->image->move(public_path('administratorimages'), $imageName);

                //echo $speciality;die;
                //save details in employee table
                $administrator = new Administrator([
                'administrator_title'  => $admin_title,
                'administrator_role'  => $admin_role,
                'administrator_username'  => $admin_username,
                'hospital_id'  => $hospital_id,
                'admin_id'=>$administrator_id,
                'administrator_dob'=>$admin_dob,
                'administrator_name' => $admin_first_name." ".$admin_middle_name." ".$admin_last_name,
                'administrator_email' => $admin_email,
                'administrator_phone' => $admin_ph,
                'administrator_state' => $admin_state,
                'administrator_country' => $admin_country,
                'administrator_info' => $admin_info,
                'administrator_picture' => $imageName,
                'active_status' => 1,
                'administrator_gender' => $admin_gender,
                'administrator_marital_status' => $admin_marital_status,
                'administrator_timezone'=>  $timezone_name,
                'administrator_created_date'=> strtotime("now") ,
                'administrator_password' => bcrypt($password)                     
                ]); 
                $administrator->save();
                 $send_email_from = isset($_ENV['send_email_from'])?trim($_ENV['send_email_from']):'';
                $get_email = Administrator::select('administrator_email','administrator_name','administrator_password')->where('admin_id',$administrator_id)->get();
                $data = array('name'=>$get_email[0]->administrator_name,'email'=>$get_email[0]->administrator_email,'password'=>$password,"type"=>"admin");    
                $email = trim($get_email[0]->administrator_email);
                $res = Mail::send('admin.signupemail', $data, function ($message) use ($email,$send_email_from)  {
                $message->to($email)->subject('Account Registration');
                $message->from($send_email_from,'Render Health');
                });
                     // Send message on phone
                $message= $this->registrationmessage($administrator_id,3);
                // $message='Welcome To Render Health.Thank you for signing up with Render Health.'; 
                $this->sendMessage($message,'+918699499852'); 
                return response()->json(['success'=>1,'message'=>'Administrator added successfully.'],200);
            }

            //return response()->json(['success'=>1,'message'=>'Employee added successfully.'],200);
        }
        catch(Exception $e)
        {
            return response()->json(['error'=>1,"message"=>$e->getMessage()],200);   
        }
    }

    /*********Update Administrator access details***********/
    public function UpdateAdminDetails(Request $request)
    {
        try
        {
            //get token from session
            $value = Session::get('admin_token');

            //get user id from auth
            $admin_id = Auth::user()->id;

            //check login status of user
            $login_token = AdminLoginToken::where(array('admin_id'=>$admin_id,'login_token'=>$value))->first();        
            if(isset($login_token->token_status) && $login_token->token_status == 0){ 
                Auth::guard('admin')->logout();           
                return redirect('/admin/login');
            }
            if(!Auth::check()){            
                return redirect('/admin/login');
            }

           
            $entry_patient_record = isset($request->entry_patient_record) ? $request->entry_patient_record:'';
            $update_admin_id = isset($request->update_admin_id) ? $request->update_admin_id:'';
            $active_status_admin = isset($request->active_status_admin) ? $request->active_status_admin:'';


            if($entry_patient_record!='')
            {
                $entry_patient_record_val = $entry_patient_record;
            }
            else
            {
                $entry_patient_record_val = 0;
            }


            if($active_status_admin==" ")
            {
                $active_status_admin = 0;
            }
            else if($active_status_admin=="on") 
            {
                $active_status_admin = 1;
            }


            if($update_admin_id!='')
            {
                 $update_sts = Administrator::where('admin_id',$update_admin_id)->update([
                'access_to_record'=> $entry_patient_record_val,
                'pending_status'=> $active_status_admin,
                ]);

                return response()->json(['success'=>1,'message'=>'Administrator access updated Successfully.'],200);
            }
            else
            {
               return response()->json(['error'=>1,"message"=>"Parametres missing"],200);
            }

            
        }
        catch(Exception $e)
        {
            return response()->json(['error'=>1,"message"=>$e->getMessage()],200);   
        }
        
    }


    //remove Administrator
    public function RemoveAdmin(Request $request)
    {
        try
        {
            //get token from session
            $value = Session::get('admin_token');

            //get user id from auth
            $admin_id = Auth::user()->id;

            //check login status of user
            $login_token = AdminLoginToken::where(array('admin_id'=>$admin_id,'login_token'=>$value))->first();        
            if(isset($login_token->token_status) && $login_token->token_status == 0){ 
                Auth::guard('admin')->logout();           
                return redirect('/admin/login');
            }
            if(!Auth::check()){            
                return redirect('/admin/login');
            }
            if($request->admin_id!='')
            {
                //update pending_status to 1 to approve hospital request
                $update_sts = Administrator::where('admin_id',$request->admin_id)->update(['pending_status'=>2]); 

                return response()->json(['success'=>1,'message'=>'Administrator removed Successfully.'],200);
            }
            else
            {
               return response()->json(['error'=>1,"message"=>"Parametres missing"],200);
            }

            
        }
        catch(Exception $e)
        {
            return response()->json(['error'=>1,"message"=>$e->getMessage()],200);   
        }
        
    }

    //end of remove doctor

    public function SendMailTest(Request $request,$id='')
    {
           
        $account_sid = getenv("TWILIO_SID");
        $auth_token = getenv("TWILIO_AUTH_TOKEN");
        $twilio_number = '+13345818589';
        $client = new Client($account_sid, $auth_token);
        $result= $client->messages->create('+918699499852', 
        ['from' => $twilio_number, 'body' => "klklkl"] );
        print($result->sid);
    }

     public function generateUniqueNumber(){
            $number = mt_rand(1000000000, 9999999999); // better than rand()
            // call the same function if the uniwue id exists already
            if ($this->uniqueNumberExists($number)) {
                return $this->generateUniqueNumber();
            }
            // otherwise, it's valid and can be used
            return strval($number);
        }


    protected function uniqueNumberExists($number) {
        // query the database and return a boolean         
        return HealthHistory::wherehistory_id($number)->exists();
    }

      /******listing of all Doctors *******/

    public function AllBillingDoctors(Request $request)
    {
        //get token from session
        $value = Session::get('admin_token');

        //get user id from auth
        $admin_id = Auth::user()->id;

        //check login status of user
        $login_token = AdminLoginToken::where(array('admin_id'=>$admin_id,'login_token'=>$value))->first();        
        if(isset($login_token->token_status) && $login_token->token_status == 0){ 
            Auth::guard('admin')->logout();           
            return redirect('/admin/login');
        }
        if(!Auth::check()){            
            return redirect('/admin/login');
        }

        $user = $request->user();
        $admin_id = $user->id;

        //get details of logged in user
        $admin_details = Admin::where('id',$admin_id)->first();  
        $time_zone = $admin_details->admin_timezone;                 
        $dtz = new DateTimeZone($time_zone);
        $time_in_sofia = new DateTime('now', $dtz);        
        $date_offset = $time_in_sofia->format('Z');
        $start_time = strtotime(date("Y-m-d"))-$date_offset;
        $end_time = strtotime(date("Y-m-d",strtotime("+1 day")))-$date_offset;

        //get pagination params
        if(isset($_GET['type']))
        {        
            if($_GET['type'] == "doc_page")
            {
                $doc_page = $_GET['page'];
                $limit = 5;            
            }
        }
        else
        {
          $doc_page = 1;
          $limit = 5;          
        }

        //get all doctors
        $all_doctors = Doctor::where('active_status', '!=' , 2)->orderBy('doctor_id', 'desc')->paginate($limit, ['*'],'page',$doc_page);

        if($request->ajax())
        {
             return view('admin.admin_billing_doctors_ajax')->with(array('controller'=>'admin','admin_details'=>$admin_details,'all_doctors'=>$all_doctors));
        }
        else
        {
            return view('admin.admin_billing_doctors')->with(array('controller'=>'admin','admin_details'=>$admin_details,'all_doctors'=>$all_doctors));
        }       
        
    }

   /******
    Billing View
    *******/
            public function billings(Request $request,$id=''){
            //get token from session
            $value = Session::get('admin_token');

            //get user id from auth
            $admin_id = Auth::user()->id;

            //check login status of user
            $login_token = AdminLoginToken::where(array('admin_id'=>$admin_id,'login_token'=>$value))->first();        
            if(isset($login_token->token_status) && $login_token->token_status == 0){ 
            Auth::guard('admin')->logout();           
            return redirect('/admin/login');
            }
            if(!Auth::check()){            
            return redirect('/admin/login');
            }
            // $user = $request->user();
            $admin_details = Admin::where('id',$admin_id)->first(); 

            $doctor_id= $id;

            $doctor_details = Doctor::where('doctor_id',$doctor_id)->first();

            $hospital_id =  $doctor_details->hospital_id; 

            $time_zone = $doctor_details->doctor_timezone;                 
            $dtz = new DateTimeZone($time_zone);
            $time_in_sofia = new DateTime('now', $dtz);        
            $date_offset = $time_in_sofia->format('Z');
            $start_time = strtotime(date("Y-m-d"))-$date_offset;
            $end_time = strtotime(date("Y-m-d",strtotime("+1 day")))-$date_offset;

            $today_appointment=SaveTelemedicalBookingDetail::where('doctor_id',$doctor_id)->where('save_telemedical_booking_detail.approved_status','!=',2)->where('appointment_time','>=',$start_time)->where('appointment_time','<',$end_time)->get(); 
            /*  if($id != ''){
            $billing_count = BillingDetail::where('hospital_id',$hospital_id)->where('patient_id',$id)->orderBy('billing_date','DESC')->count();
            $outstanding_count = BillingDetail::where('hospital_id',$hospital_id)->where('patient_id',$id)->whereRaw('payable_amount-paid_amount > 0')->orderBy('billing_date','DESC')->count();
            $paid_count = BillingDetail::where('hospital_id',$hospital_id)->where('patient_id',$id)->whereRaw('payable_amount-paid_amount = 0')->orderBy('paid_date','DESC')->count();
            }else{*/
            $billing_count = BillingDetail::where('doctor_id',$doctor_id)->orderBy('billing_date','DESC')->count();
            $outstanding_count = BillingDetail::where('doctor_id',$doctor_id)->whereRaw('payable_amount-paid_amount > 0')->orderBy('billing_date','DESC')->count();
            $paid_count = BillingDetail::where('doctor_id',$doctor_id)->whereRaw('payable_amount-paid_amount = 0')->orderBy('paid_date','DESC')->count();
            //}
            if(isset($_GET['type'])){     

            if($_GET['type'] == "all_page"){
            $page = $_GET['page'];
            $limit = 5;            
            }else{
            if(isset($_GET['all_page_no'])){
            $page = $_GET['all_page_no'];
            }
            else{
            $page = 1;
            }
            $limit = 5;            

            }      
            if($_GET['type'] == "out_billings"){
            $out_page = $_GET['page'];
            $limit = 5;          
            }else{
            if(isset($_GET['out_page'])){
            $out_page = $_GET['out_page']; 
            }
            else{
            $out_page =1;
            }

            $limit = 5;          
            }

            if($_GET['type'] == "paid_billings"){
            $paid_page = $_GET['page'];
            $limit = 5;           
            }else{
            if(isset($_GET['paid_page'])){
            $paid_page = $_GET['paid_page']; 
            }
            else{
            $paid_page = 1;
            }            
            $limit = 5;            
            }        
            }else{
            $page = 1;
            $out_page =1;
            $paid_page = 1;
            $limit = 5;          
            }

            if(isset($_GET['sort_id'])){
            if($_GET['sort_id'] == 1){
            $billing_detail = BillingDetail::where('doctor_id',$doctor_id)->orderBy('billing_date','DESC')->paginate($limit, ['*'],'page',$page);
            $outstanding_detail = BillingDetail::where('doctor_id',$doctor_id)->whereRaw('payable_amount-paid_amount > 0')->orderBy('billing_date','DESC')->paginate($limit, ['*'],'page',$out_page);
            $paid_detail = BillingDetail::where('doctor_id',$doctor_id)->whereRaw('payable_amount-paid_amount = 0')->orderBy('paid_date','DESC')->paginate($limit, ['*'],'page',$paid_page);
            }elseif($_GET['sort_id'] == 2){
            $billing_detail = BillingDetail::where('doctor_id',$doctor_id)->orderBy('payable_amount','DESC')->paginate($limit, ['*'],'page',$page);
            $outstanding_detail = BillingDetail::where('doctor_id',$doctor_id)->whereRaw('payable_amount-paid_amount > 0')->orderBy('payable_amount','DESC')->paginate($limit, ['*'],'page',$out_page);
            $paid_detail = BillingDetail::where('doctor_id',$doctor_id)->whereRaw('payable_amount-paid_amount = 0')->orderBy('paid_date','DESC')->paginate($limit, ['*'],'page',$paid_page);
            }elseif($_GET['sort_id'] == 3){

            $billing_detail = BillingDetail::where('doctor_id',$doctor_id)->orderBy('payable_amount','ASC')->paginate($limit, ['*'],'page',$page);
            $outstanding_detail = BillingDetail::where('doctor_id',$doctor_id)->whereRaw('payable_amount-paid_amount > 0')->orderBy('payable_amount','ASC')->paginate($limit, ['*'],'page',$out_page);
            $paid_detail = BillingDetail::where('doctor_id',$doctor_id)->whereRaw('payable_amount-paid_amount = 0')->orderBy('paid_date','ASC')->paginate($limit, ['*'],'page',$paid_page);
            }
            }else{
            $billing_detail = BillingDetail::where('doctor_id',$doctor_id)->orderBy('billing_date','DESC')->paginate($limit, ['*'],'page',$page);
            $outstanding_detail = BillingDetail::where('doctor_id',$doctor_id)->whereRaw('payable_amount-paid_amount > 0')->orderBy('billing_date','DESC')->paginate($limit, ['*'],'page',$out_page);
            $paid_detail = BillingDetail::where('doctor_id',$doctor_id)->whereRaw('payable_amount-paid_amount = 0')->orderBy('paid_date','DESC')->paginate($limit, ['*'],'page',$paid_page);
            }
            //}
            foreach($billing_detail as $billing_det){
            BillingDetail::where('billing_id', $billing_det->billing_id)->update(['seen_status' => 1]);
            }

            if($request->ajax()){
            return view('admin.all_billings_inner')->with(array('controller'=> 'admin','doctor_details'=>$doctor_details,'timezone'=>$time_zone,'billing_detail'=>$billing_detail,'outstanding_detail'=>$outstanding_detail,'paid_detail'=>$paid_detail,'billing_count'=>$billing_count,'page_type'=>'billing','id'=>$id));
            }else{

            return view('admin.view_all_billings')->with(array('controller'=> 'admin','doctor_details'=>$doctor_details,'timezone'=>$time_zone,'billing_detail'=>$billing_detail,'outstanding_detail'=>$outstanding_detail,'paid_detail'=>$paid_detail,'billing_count'=>$billing_count,'outstanding_count'=>$outstanding_count,'paid_count'=>$paid_count,'page_type'=>'billing','id'=>$id,'today_appointments_count'=>$today_appointment->count(),"admin_details"=>$admin_details));
            }
            }


             /******
    Billing View
    *******/
            public function Billingbyhospital(Request $request,$id=''){
            //get token from session
            $value = Session::get('admin_token');

            //get user id from auth
            $admin_id = Auth::user()->id;

            //check login status of user
            $login_token = AdminLoginToken::where(array('admin_id'=>$admin_id,'login_token'=>$value))->first();        
            if(isset($login_token->token_status) && $login_token->token_status == 0){ 
            Auth::guard('admin')->logout();           
            return redirect('/admin/login');
            }
            if(!Auth::check()){            
            return redirect('/admin/login');
            }
            // $user = $request->user();
            $admin_details = Admin::where('id',$admin_id)->first();            

            $hospital_id =  $id; 

            $time_zone = $admin_details->admin_timezone;                 
            $dtz = new DateTimeZone($time_zone);
            $time_in_sofia = new DateTime('now', $dtz);        
            $date_offset = $time_in_sofia->format('Z');
            $start_time = strtotime(date("Y-m-d"))-$date_offset;
            $end_time = strtotime(date("Y-m-d",strtotime("+1 day")))-$date_offset;          
            $billing_count = BillingDetail::where('hospital_id',$hospital_id)->orderBy('billing_date','DESC')->count();
            $outstanding_count = BillingDetail::where('hospital_id',$hospital_id)->whereRaw('payable_amount-paid_amount > 0')->orderBy('billing_date','DESC')->count();
            $paid_count = BillingDetail::where('hospital_id',$hospital_id)->whereRaw('payable_amount-paid_amount = 0')->orderBy('paid_date','DESC')->count();
            //}
            if(isset($_GET['type'])){     

            if($_GET['type'] == "all_page"){
            $page = $_GET['page'];
            $limit = 5;            
            }else{
            if(isset($_GET['all_page_no'])){
            $page = $_GET['all_page_no'];
            }
            else{
            $page = 1;
            }
            $limit = 5;            

            }      
            if($_GET['type'] == "out_billings"){
            $out_page = $_GET['page'];
            $limit = 5;          
            }else{
            if(isset($_GET['out_page'])){
            $out_page = $_GET['out_page']; 
            }
            else{
            $out_page =1;
            }

            $limit = 5;          
            }

            if($_GET['type'] == "paid_billings"){
            $paid_page = $_GET['page'];
            $limit = 5;           
            }else{
            if(isset($_GET['paid_page'])){
            $paid_page = $_GET['paid_page']; 
            }
            else{
            $paid_page = 1;
            }            
            $limit = 5;            
            }        
            }else{
            $page = 1;
            $out_page =1;
            $paid_page = 1;
            $limit = 5;          
            }

            if(isset($_GET['sort_id'])){
            if($_GET['sort_id'] == 1){
            $billing_detail = BillingDetail::where('hospital_id',$hospital_id)->orderBy('billing_date','DESC')->paginate($limit, ['*'],'page',$page);
            $outstanding_detail = BillingDetail::where('hospital_id',$hospital_id)->whereRaw('payable_amount-paid_amount > 0')->orderBy('billing_date','DESC')->paginate($limit, ['*'],'page',$out_page);
            $paid_detail = BillingDetail::where('hospital_id',$hospital_id)->whereRaw('payable_amount-paid_amount = 0')->orderBy('paid_date','DESC')->paginate($limit, ['*'],'page',$paid_page);
            }elseif($_GET['sort_id'] == 2){
            $billing_detail = BillingDetail::where('hospital_id',$hospital_id)->orderBy('payable_amount','DESC')->paginate($limit, ['*'],'page',$page);
            $outstanding_detail = BillingDetail::where('hospital_id',$hospital_id)->whereRaw('payable_amount-paid_amount > 0')->orderBy('payable_amount','DESC')->paginate($limit, ['*'],'page',$out_page);
            $paid_detail = BillingDetail::where('hospital_id',$hospital_id)->whereRaw('payable_amount-paid_amount = 0')->orderBy('paid_date','DESC')->paginate($limit, ['*'],'page',$paid_page);
            }elseif($_GET['sort_id'] == 3){

            $billing_detail = BillingDetail::where('hospital_id',$hospital_id)->orderBy('payable_amount','ASC')->paginate($limit, ['*'],'page',$page);
            $outstanding_detail = BillingDetail::where('hospital_id',$hospital_id)->whereRaw('payable_amount-paid_amount > 0')->orderBy('payable_amount','ASC')->paginate($limit, ['*'],'page',$out_page);
            $paid_detail = BillingDetail::where('hospital_id',$hospital_id)->whereRaw('payable_amount-paid_amount = 0')->orderBy('paid_date','ASC')->paginate($limit, ['*'],'page',$paid_page);
            }
            }else{
            $billing_detail = BillingDetail::where('hospital_id',$hospital_id)->orderBy('billing_date','DESC')->paginate($limit, ['*'],'page',$page);
            $outstanding_detail = BillingDetail::where('hospital_id',$hospital_id)->whereRaw('payable_amount-paid_amount > 0')->orderBy('billing_date','DESC')->paginate($limit, ['*'],'page',$out_page);
            $paid_detail = BillingDetail::where('hospital_id',$hospital_id)->whereRaw('payable_amount-paid_amount = 0')->orderBy('paid_date','DESC')->paginate($limit, ['*'],'page',$paid_page);
            }
            //}
            foreach($billing_detail as $billing_det){
            BillingDetail::where('billing_id', $billing_det->billing_id)->update(['seen_status' => 1]);
            }

            if($request->ajax()){
            return view('admin.all_billings_inner')->with(array('controller'=> 'admin','timezone'=>$time_zone,'billing_detail'=>$billing_detail,'outstanding_detail'=>$outstanding_detail,'paid_detail'=>$paid_detail,'billing_count'=>$billing_count,'page_type'=>'billing','id'=>$id,"admin_details"=>$admin_details));
            }else{

            return view('admin.view_all_billings')->with(array('controller'=> 'admin','timezone'=>$time_zone,'billing_detail'=>$billing_detail,'outstanding_detail'=>$outstanding_detail,'paid_detail'=>$paid_detail,'billing_count'=>$billing_count,'outstanding_count'=>$outstanding_count,'paid_count'=>$paid_count,'page_type'=>'billing','id'=>$id,"admin_details"=>$admin_details));
            }
            }

     /******
    Billing Detail
    *******/
    public function billingDetail(Request $request,$id,$did=''){
        //get token from session
        $value = Session::get('admin_token');

        //get user id from auth
        $admin_id = Auth::user()->id;

        //check login status of user
        $login_token = AdminLoginToken::where(array('admin_id'=>$admin_id,'login_token'=>$value))->first();        
        if(isset($login_token->token_status) && $login_token->token_status == 0){ 
            Auth::guard('admin')->logout();           
            return redirect('/admin/login');
        }
        if(!Auth::check()){            
            return redirect('/admin/login');
        }
    $admin_details = Admin::where('id',$admin_id)->first(); 
      /*$doctor_id= $did;
      $doctor_details = Doctor::where('doctor_id',$doctor_id)->first();  */
      $time_zone = $admin_details->admin_timezone;                 
      $dtz = new DateTimeZone($time_zone);
      $time_in_sofia = new DateTime('now', $dtz);        
      $date_offset = $time_in_sofia->format('Z');
      $start_time = strtotime(date("Y-m-d"))-$date_offset;
      $end_time = strtotime(date("Y-m-d",strtotime("+1 day")))-$date_offset;

    /*  $today_appointment=SaveTelemedicalBookingDetail::where('doctor_id',$doctor_id)->where('save_telemedical_booking_detail.approved_status','!=',2)->where('appointment_time','>=',$start_time)->where('appointment_time','<',$end_time)->get(); */
      $billing_detail = BillingDetail::with(array('doctor','nurse','hospital','employee','billing_service','doctor.specialist_categories','nurse.specialist_categories','employee.specialist_categories','hospital.specialist_categories'))->where('billing_id',$id)->first();  
      return view('admin.billing_detail')->with(array('controller'=> 'pages','admin_details'=>$admin_details,'timezone'=>$time_zone,'billing_detail'=>$billing_detail,'page_type'=>'billing','did'=>$did/*,'today_appointments_count'=>$today_appointment->count()*/));
    }
         /******
    Medical Record List view
    *******/
    public function medicalRecordList(Request $request,$id)
    {    
         $value = Session::get('admin_token');

        //get user id from auth
        $admin_id = Auth::user()->id;

        //check login status of user
        $login_token = AdminLoginToken::where(array('admin_id'=>$admin_id,'login_token'=>$value))->first();        
        if(isset($login_token->token_status) && $login_token->token_status == 0){ 
            Auth::guard('admin')->logout();           
            return redirect('/admin/login');
        }
        if(!Auth::check()){            
            return redirect('/admin/login');
        }
        $user = $request->user();
       $admin_details = Admin::where('id',$admin_id)->first(); 
        /*$doctor_details = Doctor::where('doctor_id',$doctor_id)->first();  
        $hospital_id = $doctor_details->hospital_id;
        $time_zone = $doctor_details->doctor_timezone;                 
        $dtz = new DateTimeZone($time_zone);
        $time_in_sofia = new DateTime('now', $dtz);        
        $date_offset = $time_in_sofia->format('Z');
        $start_time = strtotime(date("Y-m-d"))-$date_offset;
        $end_time = strtotime(date("Y-m-d",strtotime("+1 day")))-$date_offset;*/

        $health_history=HealthHistory::with(array('patient','doctor','history_attachments','doctor.doctor_hospital_details','nurse.nurse_hospital_details','employee.employee_hospital_details'))->where('patient_id',$id)->orderBy('created_date','DESC')->paginate(20);  

        $patient_details = Patient::where('patient_unique_id',$id)->first();
       // echo "<pre>"; print_R($health_history); exit;
        $doctor_details=array();
        if($request->ajax()){
            return view('admin.history_inner')->with(array('controller'=> 'admin','health_history'=>$health_history,'page'=>'inner','doctor_details'=>$doctor_details,'page_type'=>'health_history','patient_detail'=>$patient_details)); 
        }else{        
            return view('admin.medical_record')->with(array('controller'=> 'admin','health_history'=>$health_history,'page'=>'inner','doctor_details'=>$doctor_details,'page_type'=>'health_history','patient_detail'=>$patient_details,"admin_details"=>$admin_details)); 
        }          
        
    }//Ends medical record function


      /******
    View Medical Record view
    *******/
    public function viewRecord(Request $request,$id)
    {    

       $value = Session::get('admin_token');

        //get user id from auth
        $admin_id = Auth::user()->id;

        //check login status of user
        $login_token = AdminLoginToken::where(array('admin_id'=>$admin_id,'login_token'=>$value))->first();        
        if(isset($login_token->token_status) && $login_token->token_status == 0){ 
            Auth::guard('admin')->logout();           
            return redirect('/admin/login');
        }
        if(!Auth::check()){            
            return redirect('/admin/login');
        }
         $admin_details = Admin::where('id',$admin_id)->first();  
       /* $user = $request->user();
        $doctor_id= $user->doctor_id;
        $doctor_details = Doctor::where('doctor_id',$doctor_id)->first();  
        $time_zone = $doctor_details->doctor_timezone;                 
        $dtz = new DateTimeZone($time_zone);
        $time_in_sofia = new DateTime('now', $dtz);        
        $date_offset = $time_in_sofia->format('Z');
        $start_time = strtotime(date("Y-m-d"))-$date_offset;
        $end_time = strtotime(date("Y-m-d",strtotime("+1 day")))-$date_offset;    */
                    if(isset($_GET['page'])){
                    $page=$_GET['page'];
                    $limit=5;
                    }else{
                    $page=1;
                    $limit=5;
                    }
        
        $health_history=HealthHistory::with(array('patient','doctor','history_attachments','doctor_update','history_medication','hospital'))->where('health_history.history_id',$id)->first();

        $billing_detail = BillingDetail::where('patient_id',$health_history->patient->patient_unique_id)->where('history_id',$id)->orderBy('billing_date','DESC')->paginate($limit, ['*'],'page',$page);
        $doctor_details=array();
        if($request->ajax()){
            return view('admin.health_history_bill_inner')->with(array('controller'=> 'admin','page'=>'inner','admin_details'=>$admin_details,'page_type'=>'health_history','health_history'=>$health_history,'billing_detail'=>$billing_detail)); 
        }else{
            return view('admin.view_medical_record')->with(array('controller'=> 'admin','page'=>'inner','admin_details'=>$admin_details,'page_type'=>'health_history','health_history'=>$health_history,'billing_detail'=>$billing_detail)); 
        }
           
        
    }//Ends view record function

 /******
    Add Medical Record view
    *******/
    public function addRecord(Request $request,$id)
    {    

    $value = Session::get('admin_token');
    //get user id from auth
    $admin_id = Auth::user()->id;
    //check login status of user
    $login_token = AdminLoginToken::where(array('admin_id'=>$admin_id,'login_token'=>$value))->first();        
    if(isset($login_token->token_status) && $login_token->token_status == 0){ 
    Auth::guard('admin')->logout();           
    return redirect('/admin/login');
    }
    if(!Auth::check()){            
    return redirect('/admin/login');
    }
    $hospital_details = Hospital::all();
    $admin_details = Admin::where('id',$admin_id)->first();  
    $time_zone = $admin_details->admin_timezone;              
        $dtz = new DateTimeZone($time_zone);
        $time_in_sofia = new DateTime('now', $dtz);        
        $date_offset = $time_in_sofia->format('Z');
        $start_time = strtotime(date("Y-m-d"))-$date_offset;
        $end_time = strtotime(date("Y-m-d",strtotime("+1 day")))-$date_offset;      
        $possibleDiagnosis = PossibleDiagnosis::get();
        $patient_details = Patient::where('patient_unique_id',$id)->first();        
        //echo "<pre>"; print_R($doctor_availability); exit;
        return view('admin.add_medical_record')->with(array('controller'=> 'admin','page'=>'inner','admin_details'=>$admin_details,'timezone'=>$time_zone,'page_type'=>'appointments','patient_detail'=>$patient_details,'patient_id'=>$id,"hospital_details"=>$hospital_details,"possibleDiagnosis"=>$possibleDiagnosis));    
        
    }//


     /******
    Edit Medical Record view
    *******/
    public function editRecord(Request $request,$id)
    {    

         $value = Session::get('admin_token');

        //get user id from auth
        $admin_id = Auth::user()->id;

        //check login status of user
        $login_token = AdminLoginToken::where(array('admin_id'=>$admin_id,'login_token'=>$value))->first();        
        if(isset($login_token->token_status) && $login_token->token_status == 0){ 
            Auth::guard('admin')->logout();           
            return redirect('/admin/login');
        }
        if(!Auth::check()){            
            return redirect('/admin/login');
        }
         $admin_details = Admin::where('id',$admin_id)->first();  
        $time_zone = $admin_details->admin_timezone;                 
        $dtz = new DateTimeZone($time_zone);
        $time_in_sofia = new DateTime('now', $dtz);        
        $date_offset = $time_in_sofia->format('Z');
        $start_time = strtotime(date("Y-m-d"))-$date_offset;
        $end_time = strtotime(date("Y-m-d",strtotime("+1 day")))-$date_offset;
        $possibleDiagnosis = PossibleDiagnosis::get();
        $health_history=HealthHistory::with(array('patient','doctor','history_attachments','doctor_update'))->where('health_history.history_id',$id)->first();
        //echo "<pre>"; print_R($doctor_availability); exit;
        return view('admin.edit_medical_record')->with(array('controller'=> 'admin','page'=>'inner','page_type'=>'appointments','health_history'=>$health_history,'admin_details'=>$admin_details,'possibleDiagnosis'=>$possibleDiagnosis));    
        
    }//Ends edit record function

 public function saveMedicalRecord(Request $request){
     
            try{   
              
                   
      // echo "<pre>"; print_R($_POST); exit;
            $value = Session::get('admin_token');

            //get user id from auth
            $admin_id = Auth::user()->id;

            //check login status of user
            $login_token = AdminLoginToken::where(array('admin_id'=>$admin_id,'login_token'=>$value))->first();        
            if(isset($login_token->token_status) && $login_token->token_status == 0){ 
            Auth::guard('admin')->logout();           
            return redirect('/admin/login');
            }
            if(!Auth::check()){            
            return redirect('/admin/login');
            }

           /* $user = $request->user();            
            $doctor_details = Doctor::where('doctor_id',$doctor_id)->first();  
            $time_zone = $doctor_details->doctor_timezone;
            $hospital_id = $doctor_details->hospital_id;  */      
            $medical_time = strtotime("now");
            $date_of_consutaltion = $_POST['date_of_consutaltion'];
            if(isset($_POST['edit']) && $_POST['edit'] == 1){
                $validator = Validator::make($_POST, [                  
                   /* 'temperature' => 'required',                 
                    'temprature_type' => 'required',              
                    'pulse_rate' => 'required',               
                    'resp_rate' => 'required',               
                    'bp_syt' => 'required',
                    'bp_dia' => 'required',  */
                    'history_id' => 'required',           
                    'record_attach'=>'image|max:10000'                              
                ], [
                    'record_attach.max' => 'Image size should be as less then 10 Mb',
                ]);
                if($validator->fails()){
                    return response()->json(['success'=>0, 'message'=>$validator->messages()->first()], 200);
                }
               
               
                $update_health_history = HealthHistory::where('history_id',$_POST['history_id'])->update(['possible_diagnosis'=>$_POST['possible_diagnosis'],'date_of_consutaltion'=> $date_of_consutaltion,'temperature'=> $_POST['temperature'],'temprature_type'=> $_POST['temprature_type'],'measuring_type'=> $_POST['degree_type'],'pulse'=> $_POST['pulse_rate'],'respiratory_rate'=> $_POST['resp_rate'],'bp_sys'=> $_POST['bp_syt'],'bp_dia'=> $_POST['bp_dia'],'general_notes'=> $_POST['general_notes'],'plan'=> $_POST['plan'],'cvs_det'=> $_POST['cvs'],'respiratory_det'=> $_POST['resp_analysis'],'abdomen_det'=> $_POST['abd_rate'],'cns_det'=> $_POST['cns'],'rbc_det'=> $_POST['rbc'],'wbc_det'=> $_POST['wbc'],'hb_det'=> $_POST['hb_rate'],'hmt_det'=> $_POST['hb_per'],'plt_det'=> $_POST['plt'],'ch_ldl_det'=> $_POST['chl_mil'],'ch_hdl_det'=> $_POST['chl_ldl'],'updated_date'=> $medical_time,'updated_nurse'=> NULL,'updated_employee'=> NULL,'updated_hospital'=> NULL,'musculoskeletal'=> $_POST['musculoskeletal'],'heent'=> $_POST['heent'],'urinary'=> $_POST['urinary'],'other_system'=> $_POST['other_system'],'weight'=> $_POST['weight'],'height'=> $_POST['height']]);
                        // get health history record

                $health_history=HealthHistory::with(array('patient','doctor','history_attachments','doctor_update','history_medication'))->where('health_history.history_id',$_POST['history_id'])->first();
                   // if doctor exist send notification 
                if(isset($health_history->doctor)  && isset($health_history->doctor->doctor_id)){

                $doctor_id=$health_history->doctor->doctor_id;

                $UserNotification = new UserNotification([                
                'notification_id'   => $this->generateNUniqueNumber(),
                'doctor_id'       => $health_history->doctor->doctor_id, 
                'assignee_type'     => 1,                    
                'patient_id'        => $_POST['patient_id'], 
                'event_id'          => $_POST['history_id'],
                'notification_type' => "health_history",
                'change_type'       => "edited",
                'created_date'      => strtotime('now'),
                'status'            => 0                                          
                ]);
                $UserNotification->save(); 
                $login_token = PatientLoginToken::where('patient_id',$_POST['patient_id'])->where('token_status',1)->get();
                $patients_notification = PatientNotificationSetting::where('patient_id', $_POST['patient_id'])->first();
                $msg = "Dr.".$health_history->doctor->doctor_first_name." ".$health_history->doctor->doctor_last_name." edited a health history"; 
                if(isset($patients_notification->patient_id)){
                if($patients_notification->patient_history_push == 1){
                if(count($login_token) > 0 && $login_token[0]->device_type != 2){            
                $device_token = $login_token[0]->device_token;
                $path = base_path()."/ios_notifcation/all_notifications.php";                                       
                $nid = $_POST['history_id'];
                $type= 'health_history';
                exec ('php '.$path.' "'.$msg.'" '.$nid.' '.$type.' '.$device_token.' > /dev/null &');
                }
                }             

                if($patients_notification->patient_history_notification == 1){
                $url = url('/doctor/send_mail/'.str_replace(" ", "_", $msg).'/'.$_POST['patient_id'].'');   
                $cmd  = "curl --max-time 60 ";   
                $cmd .= "'" . $url . "'";   
                $cmd .= " > /dev/null 2>&1 &";    
                exec($cmd, $output, $exit); 
                }
                }
                }

            }else{

                $validator = Validator::make($_POST, [                  
                 /*   'temperature' => 'required',                 
                    'temprature_type' => 'required',              
                    'pulse_rate' => 'required',               
                    'resp_rate' => 'required',               
                    'bp_syt' => 'required',   
                    'bp_dia' => 'required',  */  
                    'doctor_id' => 'required',   
                    'hospital_id' => 'required',        
                    'record_attach'=>'image|max:10000'                              
                ], [
                    'record_attach.max' => 'Image size should be as less then 10 Mb',
                ]);
                if($validator->fails()){
                    return response()->json(['success'=>0, 'message'=>$validator->messages()->first()], 200);
                }

                if(!empty($_POST['general_notes']) && trim($_POST['general_notes']) != ""){
                    $general_notes = trim($_POST['general_notes']);
                }else{
                    $general_notes = NULL;
                }

                if(!empty($_POST['plan']) && trim($_POST['plan']) != ""){
                    $plan = trim($_POST['plan']);
                }else{
                    $plan = NULL;
                }

                if(!empty($_POST['cvs']) && trim($_POST['cvs']) != ""){
                    $cvs = trim($_POST['cvs']);
                }else{
                    $cvs = NULL;
                }

                if(!empty($_POST['resp_analysis']) && trim($_POST['resp_analysis']) != ""){
                    $resp_analysis = trim($_POST['resp_analysis']);
                }else{
                    $resp_analysis = NULL;
                }

                if(!empty($_POST['abd_rate']) && trim($_POST['abd_rate']) != ""){
                    $abd_rate = trim($_POST['abd_rate']);
                }else{
                    $abd_rate = NULL;
                }

                if(!empty($_POST['cns']) && trim($_POST['cns']) != ""){
                    $cns = trim($_POST['cns']);
                }else{
                    $cns = NULL;
                }

                if(!empty($_POST['rbc']) && trim($_POST['rbc']) != ""){
                    $rbc = trim($_POST['rbc']);
                }else{
                    $rbc = NULL;
                }

                if(!empty($_POST['wbc']) && trim($_POST['wbc']) != ""){
                    $wbc = trim($_POST['wbc']);
                }else{
                    $wbc = NULL;
                }

                if(!empty($_POST['plt']) && trim($_POST['plt']) != ""){
                    $plt = trim($_POST['plt']);
                }else{
                    $plt = NULL;
                }

                if(!empty($_POST['hb_rate']) && trim($_POST['hb_rate']) != ""){
                    $hb_rate = trim($_POST['hb_rate']);
                }else{
                    $hb_rate = NULL;
                }

                if(!empty($_POST['hb_per']) && trim($_POST['hb_per']) != ""){
                    $hb_per = trim($_POST['hb_per']);
                }else{
                    $hb_per = NULL;
                }

                if(!empty($_POST['hb_per']) && trim($_POST['hb_per']) != ""){
                    $hb_per = trim($_POST['hb_per']);
                }else{
                    $hb_per = NULL;
                }

                if(!empty($_POST['chl_mil']) && trim($_POST['chl_mil']) != ""){
                    $chl_mil = trim($_POST['chl_mil']);
                }else{
                    $chl_mil = NULL;
                }

                if(!empty($_POST['chl_ldl']) && trim($_POST['chl_ldl']) != ""){
                    $chl_ldl = trim($_POST['chl_ldl']);
                }else{
                    $chl_ldl = NULL;
                }

                if(!empty($_POST['musculoskeletal']) && trim($_POST['musculoskeletal']) != ""){
                $musculoskeletal = trim($_POST['musculoskeletal']);
                }else{
                $musculoskeletal = NULL;
                }
                if(!empty($_POST['urinary']) && trim($_POST['urinary']) != ""){
                $urinary = trim($_POST['urinary']);
                }else{
                $urinary = NULL;
                }
                if(!empty($_POST['heent']) && trim($_POST['heent']) != ""){
                 $heent = trim($_POST['heent']);
                }else{
                 $heent = NULL;
                }
                if(!empty($_POST['other_system']) && trim($_POST['other_system']) != ""){
                $other_system = trim($_POST['other_system']);
                }else{
                $other_system = NULL;
                }
              $doctor_id=$_POST['doctor_id'];
               $hospital_id=$_POST['hospital_id'];

                $HealthHistory = new HealthHistory([                
                    'history_id'        => $this->generateUniqueNumber(),
                    'doctor_id'         => $_POST['doctor_id'], 
                    'hospital_id'       => $_POST['hospital_id'],
                    'assignee_type'     => 1,
                    'patient_id'        => $_POST['patient_id'], 
                    'temperature'       => trim($_POST['temperature']),
                    'temprature_type'   => trim($_POST['temprature_type']),
                    'measuring_type'    => trim($_POST['degree_type']),
                    'pulse'             => trim($_POST['pulse_rate']),
                    'respiratory_rate'  => trim($_POST['resp_rate']),
                    'bp_sys'            => trim($_POST['bp_syt']),
                    'bp_dia'            => trim($_POST['bp_dia']),
                    'general_notes'     => $general_notes,
                    'plan'              => $plan,
                    'cvs_det'           => $cvs,
                    'respiratory_det'   => $resp_analysis,
                    'abdomen_det'       => $abd_rate,
                    'cns_det'           => $cns,
                    'rbc_det'           => $rbc,
                    'wbc_det'           => $wbc,
                    'hb_det'            => $hb_rate,                   
                    'hmt_det'           => $hb_per,
                    'plt_det'           => $plt,
                    'ch_ldl_det'        => $chl_mil,
                    'ch_hdl_det'        => $chl_ldl,
                    'created_date'      => $medical_time,
                    'updated_date'      => $medical_time,
                    'updated_doc'       => $doctor_id ,
                    'urinary'           =>$urinary,
                    'heent'           =>$heent,
                    'other_system'      =>$other_system,
                    'musculoskeletal'   =>$musculoskeletal,
                    'height'            => trim($_POST['height']),
                    'weight'            => trim($_POST['weight']),
                    'date_of_consutaltion'=> $date_of_consutaltion,
                    'possible_diagnosis'=>$_POST['possible_diagnosis'],                                      
                ]);
                $HealthHistory->save(); 
                

                if(isset($_POST['edit']) && $_POST['edit'] == 1){
                    $history_id = $_POST['history_id'];
                }else{
                    $history_id = $HealthHistory->history_id;
                }

                $UserNotification = new UserNotification([                
                    'notification_id'   => $this->generateNUniqueNumber(),
                    'doctor_id'         =>  $_POST['doctor_id'], 
                    'assignee_type'     => 1,                    
                    'patient_id'        => $_POST['patient_id'], 
                    'event_id'          => $history_id,
                    'notification_type' => "health_history",
                    'change_type'       => "added",
                    'created_date'      => strtotime('now'),
                    'status'            => 0                                          
                ]);
                $UserNotification->save(); 
                $health_history=HealthHistory::with(array('patient','doctor','history_attachments','doctor_update','history_medication'))->where('health_history.history_id',$history_id)->first();

                $login_token = PatientLoginToken::where('patient_id',$_POST['patient_id'])->where('token_status',1)->get();

                $msg ="Dr.".$health_history->doctor->doctor_first_name." ".$health_history->doctor->doctor_last_name." added a new health history";  

                $patients_notification = PatientNotificationSetting::where('patient_id', $_POST['patient_id'])->first();
                if(isset($patients_notification->patient_id)){
                    if($patients_notification->patient_history_push == 1){
                        if(count($login_token) > 0 && $login_token[0]->device_type != 2){            
                            $device_token = $login_token[0]->device_token;                    
                            $path = base_path()."/ios_notifcation/all_notifications.php";
                            $nid = $history_id;
                            $type= 'health_history';
                            exec ('php '.$path.' "'.$msg.'" '.$nid.' '.$type.' '.$device_token.' > /dev/null &');
                        }
                    }

                    if($patients_notification->patient_history_notification == 1){
                        //send email notification
                        $url = url('/doctor/send_mail/'.str_replace(" ", "_", $msg).'/'.$_POST['patient_id'].'');   
                        $cmd  = "curl --max-time 60 ";   
                        $cmd .= "'" . $url . "'";   
                        $cmd .= " > /dev/null 2>&1 &";    
                        exec($cmd, $output, $exit); 
                    }
                }

            }       
            $current_time = strtotime("now");  

            if(isset($_POST['imagesLength']) && $_POST['imagesLength'] > 0){
                $_POST['attach_type'] = json_decode($_POST['attach_type']);
                $_POST['centre_name'] = json_decode($_POST['centre_name']);
                $status = 0;
                $attach_arr = array();
                for($i=1;$i <= $_POST['imagesLength'];$i++)
                {

                    if(isset($_FILES['attachments'.$i.''])){  
                        $extension = $request->file('attachments'.$i.'')->getClientOriginalExtension();                       
                        $filename =  $_FILES['attachments'.$i.'']['name'];                          
                        $destinationPath = public_path().'/admin/doctor/uploads/hhistory';
                        if(isset($_POST['edit']) && $_POST['edit'] == 1){
                            $history_id = $_POST['history_id'];
                        }else{
                            $history_id = $HealthHistory->history_id;
                        }
                        
                        
                        if(!is_dir($destinationPath."/".$history_id))
                        {
                            mkdir($destinationPath."/".$history_id);
                            chmod($destinationPath."/".$history_id, 0777);
                            $status = 1;
                        }         
                        
                        if(isset($_POST['edit']) && $_POST['edit'] == 1){
                            if($status == 1){                                
                                if(file_exists($destinationPath."/".$history_id."/".$request->file('attachments'.$i.'')->getClientOriginalName())){                   
                                    $files = glob($destinationPath."/".$history_id . '/*');
                                    foreach ($files as $file) {
                                        if (is_dir($file)) {
                                            rmdir($file);
                                        } else {
                                            unlink($file);
                                        }
                                    }                                
                                    rmdir($destinationPath."/".$history_id);
                                    HealthHistoryAttachments::where('patient_history_id',$history_id)->delete(); 
                                    return response()->json(['success'=>0, 'message'=>'File with same name already exists'], 200);
                                }
                                
                            }else{
                                if(file_exists($destinationPath."/".$history_id."/".$request->file('attachments'.$i.'')->getClientOriginalName())){                   
                                    if(count($attach_arr) > 0){                                        
                                        foreach ($attach_arr as $file) {
                                            $attachments= HealthHistoryAttachments::where('patient_attachment_id',$file)->first();
                                            if(file_exists($destinationPath."/".$history_id."/".$attachments->patient_attachment_name)){
                                                unlink($destinationPath."/".$history_id."/".$attachments->patient_attachment_name);
                                            }
                                        } 
                                        $count = count(glob($destinationPath."/".$history_id . '/*')); 
                                        if($count == 0){
                                            rmdir($destinationPath."/".$history_id);
                                        }                          
                                        HealthHistoryAttachments::where('patient_attachment_id',$attachments->patient_attachment_id)->delete();
                                    }    
                                    return response()->json(['success'=>0, 'message'=>'File with same name already exists'], 200);
                                }
                                
                            }
                            
                        }else{
                            if(file_exists($destinationPath."/".$history_id."/".$request->file('attachments'.$i.'')->getClientOriginalName())){                            
                                HealthHistory::where('history_id',$history_id)->delete();
                                HealthHistoryAttachments::where('patient_history_id',$history_id)->delete();
                                $files = glob($destinationPath."/".$history_id . '/*');
                                foreach ($files as $file) {
                                    if (is_dir($file)) {
                                        rmdir($file);
                                    } else {
                                        unlink($file);
                                    }
                                }
                                rmdir($destinationPath."/".$history_id);
                                return response()->json(['success'=>0, 'message'=>'File with same name already exists'], 200);
                            }
                        }
                        $request->file('attachments'.$i.'')->move($destinationPath."/".$history_id, $filename);                         
                                               
                        //echo "<pre>"; print_R($_POST['centre_name'][$i-1]); exit;
                        $HealthHistoryAttachments = new HealthHistoryAttachments([                
                            'patient_attachment_id'     => $this->generateUniqueNumber(),
                            'patient_history_id'        => $history_id, 
                            'patient_id'                => $_POST['patient_id'],
                            'patient_lab_name'         => $_POST['centre_name'][$i-1],
                            'attachment_type'           => $_POST['attach_type'][$i-1],                              
                            'patient_attachment_name'   => $filename,   
                            'type'                      => 1,                                       
                            'created_at'                => $current_time                                              
                        ]);
                        $HealthHistoryAttachments->save(); 
                        array_push($attach_arr, $HealthHistoryAttachments->patient_attachment_id);

                    }
                }
             
            }            

            if(isset($_POST['medi_name'])){  
                $_POST['medi_name'] = json_decode($_POST['medi_name']);
                $_POST['medi_type'] = json_decode($_POST['medi_type']);
                $_POST['medi_procedure'] = json_decode($_POST['medi_procedure']);
                $_POST['medi_quantity'] = json_decode($_POST['medi_quantity']); 

                if(isset($_POST['edit']) && $_POST['edit'] == 1){
                    $history_id = $_POST['history_id'];
                }else{
                    $history_id = $HealthHistory->history_id;
                }                
                foreach($_POST['medi_name'] as $key=>$medi_name){
                    $HealthHistoryMedication = new HealthHistoryMedication([        
                        'health_history_id'     =>  $history_id, 
                        'patient_id'            =>  $_POST['patient_id'],
                        'doctor_id'             =>  $doctor_id, 
                        'medi_name'             =>  $medi_name, 
                        'medi_type'             =>  $_POST['medi_type'][$key],                
                        'medi_procedure'        =>  $_POST['medi_procedure'][$key],
                        'quantity'              =>  $_POST['medi_quantity'][$key],
                        'created_date'                => $current_time                                            
                    ]);
                    $HealthHistoryMedication->save();
                }
            }



            if(isset($_POST['record_attach_len']) && $_POST['record_attach_len'] > 0){

                for($i=0;$i < $_POST['record_attach_len'];$i++)
                {
                    if(isset($_FILES['record_attach'.$i.''])){
                        $extension = $request->file('record_attach'.$i.'')->getClientOriginalExtension();                       
                        $filename =  $_FILES['record_attach'.$i.'']['name'];    
                        $destinationPath = public_path().'/admin/doctor/uploads/hhistory';
                        if(isset($_POST['edit']) && $_POST['edit'] == 1){
                            $history_id = $_POST['history_id'];
                        }else{
                            $history_id = $HealthHistory->history_id;
                        }

                        if(!is_dir($destinationPath."/".$history_id))
                        {
                            mkdir($destinationPath."/".$history_id);
                            chmod($destinationPath."/".$history_id, 0777);                            
                        } 

                        if(!is_dir($destinationPath."/".$history_id."/original_record"))
                        {
                            mkdir($destinationPath."/".$history_id."/original_record");
                            chmod($destinationPath."/".$history_id."/original_record", 0777);
                            $status = 1;
                        } 
                        
                        if(file_exists($destinationPath."/".$history_id."/original_record".$request->file('record_attach'.$i.'')->getClientOriginalName())){                            
                            HealthHistory::where('history_id',$history_id)->delete();
                            HealthHistoryAttachments::where('patient_history_id',$history_id)->delete();
                            $files = glob($destinationPath."/".$history_id . '/original_record' . '/*');
                            foreach ($files as $file) {
                                if (is_dir($file)) {
                                    rmdir($file);
                                } else {
                                    unlink($file);
                                }
                            }
                            rmdir($destinationPath."/".$history_id);
                            return response()->json(['success'=>0, 'message'=>'File with same name already exists'], 200);
                        }                                 
                        
                        $request->file('record_attach'.$i.'')->move($destinationPath."/".$history_id."/original_record", $filename);
                        $current_time = strtotime("now");
                        $HealthHistoryAttachments = new HealthHistoryAttachments([                
                            'patient_attachment_id'     => $this->generateUniqueNumber(),
                            'patient_history_id'        => $history_id, 
                            'patient_id'                => $_POST['patient_id'], 
                            'patient_attachment_name'   => $filename,   
                            'type'                      => 2,              
                            'created_at'                => $current_time                                              
                        ]);
                        $HealthHistoryAttachments->save(); 
                    }
                }
                if(isset($_POST['edit']) && $_POST['edit'] == 1){
                    $history_id = $_POST['history_id'];
                }else{
                    $history_id = $HealthHistory->history_id;
                }               
            } 
            
            
            return response()->json(['success'=>1], 200);
        }catch(Exception $e) {
            return response()->json(['error'=>1,"message"=>$e->getMessage()],200);       
        } 

    }
      protected function generateNUniqueNumber() {
        $number = mt_rand(1000000000, 9999999999); // better than rand()
        // call the same function if the uniwue id exists already
        if ($this->uniqueNNumberExists($number)) {
            return $this->generateNUniqueNumber();
        }
        // otherwise, it's valid and can be used
        return strval($number);
    }

    protected function uniqueNNumberExists($number) {
        // query the database and return a boolean         
        return UserNotification::wherenotification_id($number)->exists();
    }


    public function Getdoctors(Request $request) {
   try
        {
            $hospital_id = isset($request->hospital_id) ? $request->hospital_id:'';

             //get token from session
            $value = Session::get('admin_token');

            //get user id from auth
            $admin_id = Auth::user()->id;

            //check login status of user
            $login_token = AdminLoginToken::where(array('admin_id'=>$admin_id,'login_token'=>$value))->first();        
            if(isset($login_token->token_status) && $login_token->token_status == 0){ 
                Auth::guard('admin')->logout();           
                return redirect('/admin/login');
            }
            if(!Auth::check()){            
                return redirect('/admin/login');
            }
          

         // DB::enableQueryLog();  
    $getdoctors=Doctor::where('hospital_id',$hospital_id)->orderBy('doctor_created_date','DESC')->get(); 

//print_r(DB::connection('mysql')->getQueryLog());

            
     
            if(count($getdoctors)>0)
            {
                $getDoctorHtml='<option value="0">Select Doctor</option>';
                foreach($getdoctors as $getDoctor)
                {                   
                    $getDoctorHtml.="<option  value='".$getDoctor['doctor_id']."'>" . $getDoctor['doctor_first_name'] .' '.$getDoctor['doctor_last_name'] . "</option>";
                }
            }
            else
            {
                $getDoctorHtml='<option value="0" >Select Doctor</option>';
            }

            return response()->json(['success'=>1,"data"=>$getDoctorHtml],200);
        }
        catch(Exception $e)
        {
            return response()->json(['error'=>1,"message"=>$e->getMessage()],200);   
        }
    }
    /******
    Dispute Billing View
    *******/
    public function disputeBillings(Request $request){
       $value = Session::get('admin_token');

            //get user id from auth
            $admin_id = Auth::user()->id;

            //check login status of user
            $login_token = AdminLoginToken::where(array('admin_id'=>$admin_id,'login_token'=>$value))->first();        
            if(isset($login_token->token_status) && $login_token->token_status == 0){ 
                Auth::guard('admin')->logout();           
                return redirect('/admin/login');
            }
            if(!Auth::check()){            
                return redirect('/admin/login');
            }
        $admin_details = Admin::where('id',$admin_id)->first();  
        $time_zone = $admin_details->admin_timezone;  

      $today_appointment=SaveTelemedicalBookingDetail::where('doctor_id',$doctor_id)->where('save_telemedical_booking_detail.approved_status','!=',2)->where('appointment_time','>=',$start_time)->where('appointment_time','<',$end_time)->get(); 
        return view('doctor.dispute_billing')->with(array('controller'=> 'pages','doctor_details'=>$doctor_details,'timezone'=>$time_zone,'today_appointments_count'=>$today_appointment->count()));
    }

    /******
    Dispute Billing Detail
    *******/
    public function disputeBillingDetail(Request $request){
        if(!Auth::check()){            
            return redirect('/doctor/login');
      }
      $user = $request->user();
      $doctor_id= $user->doctor_id;
      $doctor_details = Doctor::where('doctor_id',$doctor_id)->first();  
      $time_zone = $doctor_details->doctor_timezone;                 
      $dtz = new DateTimeZone($time_zone);
      $time_in_sofia = new DateTime('now', $dtz);        
      $date_offset = $time_in_sofia->format('Z');
      $start_time = strtotime(date("Y-m-d"))-$date_offset;
      $end_time = strtotime(date("Y-m-d",strtotime("+1 day")))-$date_offset;

      $today_appointment=SaveTelemedicalBookingDetail::where('doctor_id',$doctor_id)->where('save_telemedical_booking_detail.approved_status','!=',2)->where('appointment_time','>=',$start_time)->where('appointment_time','<',$end_time)->get(); 
      return view('doctor.dispute_billing_detail')->with(array('controller'=> 'pages','doctor_details'=>$doctor_details,'timezone'=>$time_zone,'today_appointments_count'=>$today_appointment->count()));
    }


     /******
    Listing Billing Hospitals
    *******/
    public function AllBillingHospitals(Request $request)
    {
        $value = Session::get('admin_token');
        $admin_id = Auth::user()->id;
        $login_token = AdminLoginToken::where(array('admin_id'=>$admin_id,'login_token'=>$value))->first();        
        if(isset($login_token->token_status) && $login_token->token_status == 0){ 
            Auth::guard('admin')->logout();           
            return redirect('/admin/login');
        }
        if(!Auth::check()){            
            return redirect('/admin/login');
        }
        $user = $request->user();
        $admin_id = $user->id;
        $admin_details = Admin::where('id',$admin_id)->first();  
        $time_zone = $admin_details->admin_timezone;                 
        $dtz = new DateTimeZone($time_zone);
        $time_in_sofia = new DateTime('now', $dtz);        
        $date_offset = $time_in_sofia->format('Z');
        $start_time = strtotime(date("Y-m-d"))-$date_offset;
        $end_time = strtotime(date("Y-m-d",strtotime("+1 day")))-$date_offset;

        //get pagination params
            if(isset($_GET['type']))
            {        
            
            $all_page = $_GET['page'];
            $limit = 5;            
            
            } else {
            $all_page = 1;
            $limit = 5;          
            }

       //get all approved hospitals and their associated doctors,nurses,admins

        $all_hospitals = Hospital::select('hospitals.hosp_name','hospitals.hosp_state','hospitals.hosp_country','hospitals.hosp_id','hospitals.hosp_address','hospitals.hosp_phone',DB::raw('COUNT(doctors.doctor_id) as doctorsCount'),'doctors.hospital_id')->leftJoin('doctors', 'hospitals.hosp_id', '=', 'doctors.hospital_id')->where('hospitals.pending_status',1)->groupBy('hospitals.hosp_id')->orderBy('hospitals.id','desc')->paginate($limit, ['*'],'page',$all_page);
       
         //get all pending hospitals/labs

       /// $pending_hospitals = Hospital::where('pending_status',0)->orderBy('id', 'desc')->paginate($limit, ['*'],'page',$pen_page);

        //get count of pending hospitals 

       // $pending_hospitals_count = Hospital::where('pending_status',0)->count();

        //get all countries

        $countries = Country::all();

        if($request->ajax())
        {
            return view('admin.admin_billing_hospitals_ajax')->with(array('controller'=> 'admin','admin_details'=>$admin_details,'all_hospitals'=>$all_hospitals,'countries'=>$countries));
        }
        else
        {
            return view('admin.admin_billing_hospitals')->with(array('controller'=> 'admin','admin_details'=>$admin_details,'all_hospitals'=>$all_hospitals,'countries'=>$countries));
        }

    
    } //Ends Listing Hospitals/Labs
      /******
    Appointment Detail
    *******/
    public function appointmentDetail(Request $request,$id)
    {    
        
        $value = Session::get('admin_token');
        $admin_id = Auth::user()->id;
        $login_token = AdminLoginToken::where(array('admin_id'=>$admin_id,'login_token'=>$value))->first();        
        if(isset($login_token->token_status) && $login_token->token_status == 0){ 
            Auth::guard('admin')->logout();           
            return redirect('/admin/login');
        }
        if(!Auth::check()){            
            return redirect('/admin/login');
        }
        $user = $request->user();
        $admin_id = $user->id;
        $admin_details = Admin::where('id',$admin_id)->first();  
        $time_zone = $admin_details->admin_timezone;                 
        $dtz = new DateTimeZone($time_zone);
        $time_in_sofia = new DateTime('now', $dtz);        
        $date_offset = $time_in_sofia->format('Z');
        $start_time = strtotime(date("Y-m-d"))-$date_offset;
        $end_time = strtotime(date("Y-m-d",strtotime("+1 day")))-$date_offset;
      

        $appoint_detail=SaveTelemedicalBookingDetail::with(array("patient_detail","doctor.specialist_categories","patient_appoint","hospital_detail","diary_detail","diary_detail.diary_attachment"))->where("save_telemedical_booking_detail.booking_id",$id)->get();
    // Get diary attachement details
            if(!empty($appoint_detail)){
            $health_diary_array=explode(',', $appoint_detail[0]->health_diary);

            $diary_details=PatientHealthDiary::whereIn('patient_health_diary.diary_id', $health_diary_array)->leftJoin('health_diary_attachments', 'patient_health_diary.diary_id','=', 'health_diary_attachments.diary_id')->groupBy('patient_health_diary.diary_id')->get();
            }else{
            $diary_details="";
            }

        return view('admin.appointment_detail')->with(array('controller'=> 'doctor','page_type'=>'extra_links','page'=>'inner','appointment'=>$appoint_detail,'admin_details'=>$admin_details,'timezone'=>$time_zone,"diary_details"=>$diary_details));
    }
     public function Getpatientdetail(Request $request){
                // Get patient details
               $value = Session::get('admin_token');
        $admin_id = Auth::user()->id;
        $login_token = AdminLoginToken::where(array('admin_id'=>$admin_id,'login_token'=>$value))->first();        
        if(isset($login_token->token_status) && $login_token->token_status == 0){ 
            Auth::guard('admin')->logout();           
            return redirect('/admin/login');
        }
        if(!Auth::check()){            
            return redirect('/admin/login');
        }

                $p_id=$request->patient_id;
                $mainarray=array();
                $patient_details = Patient::where('patient_unique_id',$p_id)->first();
                if(!empty($patient_details)){        
                $mainarray['name'] = $patient_details['patient_first_name']. ' '.$patient_details['patient_middle_name'].' '.$patient_details['patient_last_name'];
                $mainarray['gender'] =($patient_details['patient_gender'] == '1')? 'Female':'Male';
           
                $now = time(); 
                if(!empty($patient_details['patient_date_of_birth'])  && $patient_details['patient_date_of_birth']!=NULL){
                $mainarray['patient_date_of_birth'] = date('d F Y',$patient_details['patient_date_of_birth']);            
                $difference =  $now - $patient_details['patient_date_of_birth']; 
                //There are 31556926 seconds in a year.
                $age = floor($difference / 31556926);
                $mainarray['patient_age']=$age;

                }else{
                $mainarray['patient_date_of_birth'] = "--";     
                $mainarray['patient_age']=0; 
                }

            if($patient_details['patient_profile_img'] != "" && (file_exists(getcwd().'uploads/patient/'.$patient_details['patient_profile_img']))){
            $mainarray['patient_profile_img'] = asset('uploads/patient/'.$patient_details['patient_profile_img']);
            }
            else{
            $mainarray['patient_profile_img'] = asset('admin/doctor/images/profile.svg');
            }
                  $mainarray['languages'] =(!empty($patient_details['patient_languages']))? $patient_details['patient_languages']:'--';     
                $mainarray['patient_blood_type'] =(!empty($patient_details['patient_blood_type']))? $patient_details['patient_blood_type']:'NA';
                $mainarray['state_of_origin'] =(!empty($patient_details['patient_origin_state']))? $patient_details['patient_origin_state']:'--';
                $mainarray['patient_martial_status'] =($patient_details['patient_martial_status'] == '1')? 'Married':'Unmarried';
                $mainarray['patient_address'] =(!empty($patient_details['patient_address']))? $patient_details['patient_address']:'--';
                
               return response()->json(['success'=>1,"patients_data"=> $mainarray],200);
                }
                else{
              return response()->json(['success'=>0,"patients_data"=>""],200);
                }


                }
                 // Send messsage to user
      private function sendMessage($message, $recipients)
        {
        $account_sid = getenv("TWILIO_SID");
        $auth_token = getenv("TWILIO_AUTH_TOKEN");
        $twilio_number = getenv("TWILIO_NUMBER");
        $client = new Client($account_sid, $auth_token);

       /* $validation_request = $client->validationRequests
        ->create($recipients, // phoneNumber
        array(
        "friendlyName" => "Newuser"
        )
        );
        print($validation_request);
        if(!empty($validation_request->friendlyName)){*/
        $client->messages->create($recipients, ['from' => $twilio_number, 'body' => $message]);
  // }
       return 1;
    }
       protected function registrationmessage($id,$type){
        $message="";
            if($type==1){
                $get_email = Doctor::select('doctor_email','doctor_first_name','doctor_last_name','doctor_password')->where('doctor_id',$id)->get();
                $email=$get_email[0]->doctor_email;
            }
            elseif($type==2){
                $get_email = Nurse::select('nurse_email','nurse_first_name','nurse_last_name','nurse_password')->where('nurse_id',$id)->get();
                $email=$get_email[0]->nurse_email;
            }
            elseif($type==3){
                $get_email = Administrator::select('administrator_email','administrator_name','administrator_password')->where('admin_id',$id)->get();
                $email=$get_email[0]->administrator_email;
            }
            elseif($type==4){
                $get_email = Patient::select('patient_first_name','patient_middle_name','patient_last_name','patient_email')->where('patient_unique_id',$id)->get();
                $email=$get_email[0]->patient_email;
            }
            elseif($type==5){
                $get_email = Hospital::select('hosp_email')->where('hosp_id',$id)->get();
                $email=$get_email[0]->hosp_email;
            }
         
        if(!empty($id)){
        $message="Thank you for registering with Render Health \n";
        $message.= "Here are your details:\n";
        $message.= "Email: ".$email."\n";
        $message.= "Password: as chosen by you at the time of registration \n";
        $message.= "For any queries you can contact us at: contact@renderhealth.com \n";
        return $message;
    }
    }

    // Get information of Users (Nurse, Doctor & Administrator)
    public function ViewUser(Request $request)
    {
        try
        {
            $hospital_id = isset($request->hospital_id) ? $request->hospital_id:'';
            $id = isset($request->id) ? $request->id:'';
            $role = isset($request->role) ? $request->role:'';
            $getData = array();
            if($role === 'doctor'){
                $getData = Doctor::where(['hospital_id' => $hospital_id, 'doctor_id' => $id])->first(); 
            }else if($role === 'nurse'){
                $getData = Nurse::where(['hospital_id' => $hospital_id, 'nurse_id' => $id])->first(); 
            }else if($role === 'admin'){
                $getData = Administrator::where(['hospital_id' => $hospital_id, 'admin_id' => $id])->first(); 
            }else
            {
                $getData = NULl;
            }

            if(!empty($getData))
            {
                return response()->json(['error'=>0,"message"=>'Data has been find successfully!','data' => $getData],200); 
            }else
            {
                return response()->json(['error'=>1,"message"=>'Data not found!','data' => []],200); 
            }
        }
        catch(Exception $e)
        {
            return response()->json(['error'=>1,"message"=>'Invalid Request. Please try again!','data' => []],200);   
        }
    }
    
    // Edit User (Nurse, Doctor & Administrator) information
    public function EditUser(Request $request)
    {
        try
        { 
            //get token from session
            $value = Session::get('admin_token');

            //get user id from auth
            $admin_id = Auth::user()->id;

            //check login status of user
            $login_token = AdminLoginToken::where(array('admin_id'=>$admin_id,'login_token'=>$value))->first();        
            if(isset($login_token->token_status) && $login_token->token_status == 0){ 
                Auth::guard('admin')->logout();           
                return redirect('/admin/login');
            }
            if(!Auth::check()){            
                return redirect('/admin/login');
            }

            $role = isset($request->role) ? $request->role:'';
            if($role === 'doctor'){
                $dr_id = isset($request->doctor_id) ? $request->doctor_id:'';
                $hosp_id = isset($request->hosp_id) ? $request->hosp_id:'';
                $doctor = Doctor::where(array('doctor_id' => $dr_id , 'hospital_id' => $hosp_id))->first();
                $doctor->doctor_title = isset($request->doctor_title) ? $request->doctor_title:'';
                $doctor->doctor_first_name = isset($request->doctor_first_name) ? $request->doctor_first_name:'';
                $doctor->doctor_middle_name = isset($request->doctor_middle_name) ? $request->doctor_middle_name:'';
                $doctor->doctor_last_name = isset($request->doctor_last_name) ? $request->doctor_last_name:'';
                $doctor->doctor_email = isset($request->doctor_email) ? $request->doctor_email:'';
                $doctor->doctor_phone = isset($request->doctor_phone) ? $request->doctor_phone:'';
                $doctor->doctor_gender = isset($request->doctor_gender) ? $request->doctor_gender:'';
                $date = isset($request->day) ? $request->day : '';
                $month = isset($request->month) ? $request->month : '' ;
                // $month = date('m',strtotime($month));
                $year = isset($request->years) ? $request->years : '';
                $doctor->doctor_dob = $year.'-'.$month.'-'.$date; 
                $doctor->doctor_role = isset($request->doctor_role) ? $request->doctor_role:'doctor';
                $doctor->doctor_speciality = isset($request->doctor_speciality) ? $request->doctor_speciality:'';
                $doctor->mdcn_register_no = isset($request->mdcn_register_no) ? $request->mdcn_register_no:'';
                $doctor->folio_number = isset($request->folio_number) ? $request->folio_number:'';
                $doctor->biography = isset($request->biography) ? $request->biography:'';
                $doctor->doctor_username = isset($request->doctor_username) ? $request->doctor_username:'';
                $doctor->doctor_languages = isset($request->languages) ? $request->languages:'';
                $doctor->doctor_education_school = isset($request->edu_school) ? $request->edu_school:'';
                $doctor->doctor_years_practised = isset($request->years_practised) ? $request->years_practised:'';

                if(isset($request->doctor_password))
                {
                    $doctor->doctor_password = isset($request->doctor_password) ? bcrypt($request->doctor_password) :'';
                }
                
                if(request()->image!='undefined'){
                    //upload image
                    $imageName = time().'.'.request()->image->getClientOriginalExtension();
                    request()->image->move(public_path('doctorimages'), $imageName);
                    $doctor->doctor_picture = $imageName;
                }
                
                $doctor->save();
                return response()->json(['success'=>1,'message'=>'Doctor Updated successfully.'],200);
            }else if($role === 'nurse'){
                $nurse_id = isset($request->nurse_id) ? $request->nurse_id:'';
                $hosp_id = isset($request->hosp_id) ? $request->hosp_id:'';
                $nurse = Nurse::where(array('nurse_id' => $nurse_id , 'hospital_id' => $hosp_id))->first();
                $nurse->nurse_title = isset($request->nurse_title) ? $request->nurse_title:'';
                $nurse->nurse_first_name = isset($request->nurse_first_name) ? $request->nurse_first_name:'';
                $nurse->nurse_middle_name = isset($request->nurse_middle_name) ? $request->nurse_middle_name:'';
                $nurse->nurse_last_name = isset($request->nurse_last_name) ? $request->nurse_last_name:'';
                $nurse->nurse_email = isset($request->nurse_email) ? $request->nurse_email:'';
                $nurse->nurse_phone = isset($request->nurse_phone) ? $request->nurse_phone:'';
                $nurse->nurse_gender = isset($request->nurse_gender) ? $request->nurse_gender:'';
                $date = isset($request->day) ? $request->day : '';
                $month = isset($request->month) ? $request->month : '' ;
                // $month = date('m',strtotime($month));
                $year = isset($request->years) ? $request->years : '';
                $nurse->nurse_dob = $year.'-'.$month.'-'.$date; 
                $nurse->nurse_role = isset($request->nurse_role) ? $request->nurse_role : 'nurse';
                $nurse->nurse_username = isset($request->nurse_username) ? $request->nurse_username:'';
                $nurse->nurse_languages = isset($request->languages) ? $request->languages:'';
                $nurse->nurse_education_school = isset($request->edu_school) ? $request->edu_school:'';

                if(isset($request->nurse_password))
                {
                    $nurse->nurse_password = isset($request->nurse_password) ? bcrypt($request->nurse_password) :'';
                }
                
                if(isset($request->image)){
                    //upload image
                    $imageName = time().'.'.request()->image->getClientOriginalExtension();
                    request()->image->move(public_path('nurseimages'), $imageName);
                    $nurse->nurse_picture = $imageName;
                }
                
                $nurse->save();
                return response()->json(['success'=>1,'message'=>'Nurse has been updated successfully.'],200);
            }else if($role === 'admin'){
                $admin_id = isset($request->admin_id) ? $request->admin_id:'';
                $hosp_id = isset($request->hosp_id) ? $request->hosp_id:'';
                $administrator = Administrator::where(array('admin_id' => $admin_id , 'hospital_id' => $hosp_id))->first();
                $administrator->administrator_title = isset($request->admin_title) ? $request->admin_title:'';
                $admin_first_name = isset($request->admin_first_name) ? $request->admin_first_name:'';
                $admin_middle_name = isset($request->admin_middlename) ? $request->admin_middlename:'';
                $admin_last_name = isset($request->admin_last_name) ? $request->admin_last_name:'';
                $administrator->administrator_name = $admin_first_name." ".$admin_middle_name." ".$admin_last_name ;
                $administrator->administrator_email = isset($request->admin_email) ? $request->admin_email:'';
                $administrator->administrator_phone = isset($request->admin_ph) ? $request->admin_ph:'';
                $administrator->administrator_gender = isset($request->admin_gender) ? $request->admin_gender:'';
                $date = isset($request->day) ? $request->day : '';
                $month = isset($request->month) ? $request->month : '' ;
                $year = isset($request->years) ? $request->years : '';
                $administrator->administrator_dob = $year.'-'.$month.'-'.$date; 
                $administrator->administrator_role = isset($request->admin_role) ? $request->admin_role : 'admin';
                $administrator->administrator_username = isset($request->admin_username) ? $request->admin_username:'';
                
                if(isset($request->admin_password))
                {
                    $administrator->administrator_password = isset($request->admin_password) ? bcrypt($request->admin_password) :'';
                }
                
                if(isset($request->image)){
                    //upload image
                    $imageName = time().'.'.request()->image->getClientOriginalExtension();
                    request()->image->move(public_path('administratorimages'), $imageName);
                    $administrator->administrator_picture = $imageName;
                }
                
                $administrator->save();
                return response()->json(['success'=>1,'message'=>'Administrator has been updated successfully.'],200);
            }
        }
        catch(Exception $e)
        {
            return response()->json(['error'=>1,"message"=>$e->getMessage()],200);   
        }
    }
     // Get Deal Information
     public function HospitalDetailEdit(Request $request){
        $deals = Hospital::with('hospital_hours')->where('hosp_id',$request->hosp_id)->first();
        $state = StatesNigeria::where('name',isset($deals)?$deals->hosp_state:0)->first();
        $LocalGovernment = LocalGovernment::where('state_id',isset($state)?$state->id:0)->get();
        $deals['localGovernment'] = $LocalGovernment;
        $Facility = Facility::where('name',isset($deals)?$deals->type_of_facility:0)->first();
        $Speciality = Speciality::where('facility_id',isset($Facility)?$Facility->id:0)->get();
        $deals['speciality'] = $Speciality;
        return response()->json($deals);
    }
    //Add new hospital
    public function EditNewHospital(Request $request)
    {
      
        try
        {
            //get token from session
            $value = Session::get('admin_token');

            //get user id from auth
            $admin_id = Auth::user()->id;

            //check login status of user
            $login_token = AdminLoginToken::where(array('admin_id'=>$admin_id,'login_token'=>$value))->first();        
            if(isset($login_token->token_status) && $login_token->token_status == 0){ 
                Auth::guard('admin')->logout();           
                return redirect('/admin/login');
            }
            if(!Auth::check()){            
                return redirect('/admin/login');
            }
            
         
            $name_of_facility = isset($request->name_of_facility) ? $request->name_of_facility:'';
            $hosp_email = isset($request->hosp_email) ? $request->hosp_email:'';
            $hosp_phone = isset($request->hosp_phone) ? $request->hosp_phone:'';
            $hosp_address = isset($request->hosp_address) ? $request->hosp_address:'';
            $hosp_state = isset($request->hosp_state) ? $request->hosp_state:'';
            $lga = isset($request->lga) ? $request->lga:'';
            $hosp_city = isset($request->hosp_city) ? $request->hosp_city:'';
            $type_of_facility = isset($request->type_of_facility) ? $request->type_of_facility:'';
            $hosp_speciality = isset($request->hosp_speciality) ? $request->hosp_speciality:'';
            $hospital_id = isset($request->hospital_id) ? $request->hospital_id:'';
            $serviceofferd = isset($request->serviceofferd) ? implode(',',$request->serviceofferd):NULL;
            $hmo = isset($request->hmo) ? json_encode($request->hmo):NULL;
            $point_first_name = isset($request->point_first_name) ? $request->point_first_name:'';
            $point_surname = isset($request->point_surname) ? $request->point_surname:'';
            $point_email = isset($request->point_email) ? $request->point_email:'';
            $point_phone = isset($request->point_phone) ? $request->point_phone:'';
            $point2_first_name = isset($request->point2_first_name) ? $request->point2_first_name:'';
            $point2_surname = isset($request->point2_surname) ? $request->point2_surname:'';
            $point2_email = isset($request->point2_email) ? $request->point2_email:'';
            $point2_phone = isset($request->point2_phone) ? $request->point2_phone:'';
            $hosp_city = isset($request->hosp_city) ? $request->hosp_city:'';
            // $hospital_address = isset($request->hospital_address) ? $request->hospital_address:'';
            // $hospital_state = isset($request->hospital_state) ? $request->hospital_state:'';
            // $hospital_country = isset($request->hospital_country) ? $request->hospital_country:'';
            
            #validations
            if($name_of_facility=='')
            {
                return response()->json(['error'=>1,"message"=>"Please provide hospital name facility."],200);   
            }
            else if($hosp_email=='')
            {
                return response()->json(['error'=>1,"message"=>"Please provide hospital email."],200);
            }
            else if($hosp_phone=='')
            {
                return response()->json(['error'=>1,"message"=>"Please provide hospital phone number."],200);
            }
            else if(!is_numeric($hosp_phone))
            {
                return response()->json(['error'=>1,"message"=>"Please provide numeric phone number."],200);
            }
           
            else if($hosp_address=='')
            {
                return response()->json(['error'=>1,"message"=>"Please provide hospital address."],200);
            }
            else if($hosp_state==''|| $hosp_state=='0')
            {
                return response()->json(['error'=>1,"message"=>"Please provide hospital state."],200);
            }
            else if($lga=='' || $lga=='0')
            {
                return response()->json(['error'=>1,"message"=>"Please provide hospital LGA."],200);
            }
            else if($type_of_facility==''|| $type_of_facility=='0')
            {
                return response()->json(['error'=>1,"message"=>"Please provide hospital type of facility."],200);
            }
            

            //for now generate random hosp_id
            

            //check for existing hospital 
            $exist_hospital = Hospital::where('hosp_id',$request->hosp_id)->count();
            if($exist_hospital > 0)
            {
                $hospital = Hospital::where(array('hosp_id' => $request->hosp_id))->first();
                $hospital->hosp_name = $name_of_facility;
                $hospital->hosp_email = $hosp_email;
                $hospital->hosp_phone = $hosp_phone;
                $hospital->hosp_address = $hosp_address;
                $hospital->hosp_state = $hosp_state;
                $hospital->lga = $lga;
                $hospital->hosp_city = $hosp_city;
                $hospital->type_of_facility = $type_of_facility;
                $hospital->hosp_speciality = $hosp_speciality;
                $hospital->serviceofferd = $serviceofferd;
                $hospital->point_first_name = $point_first_name;
                $hospital->point_surname = $point_surname;
                $hospital->point_email = $point_email;
                $hospital->point_phone = $point_phone;
                $hospital->point2_first_name = $point2_first_name;
                $hospital->point2_surname = $point2_surname;
                $hospital->point2_email = $point2_email;
                $hospital->point2_phone = $point2_phone;
                $hospital->hosp_city = $hosp_city;
                $hospital->hmo = $hmo;                
                $hospital->save();
                if($request->hours){
                    $hospitalHours = HospitalHour::where(array('hospital_id' => $request->hosp_id))->first();
                    foreach($request->hours as $key => $times){
                        $hospitalHours[$key] = json_encode($times);
                    }
                    // dd($hospitalHour);
                    $hospitalHour['hospital_id'] = $request->hosp_id;
                    $hospitalHour = new HospitalHour([$hospitalHours]);
                   $hospitalHour->save();
                }
                return response()->json(['success'=>1,'message'=>'Hospital edited successfully.'],200);
            }
            else
            {
                return response()->json(['error'=>1,"message"=>"Hospital not exists."],200); 
            }   

        }
        catch(Exception $e)
        {
            return response()->json(['error'=>1,"message"=>$e->getMessage()],200);   
        }
    }

    // Use for remove
    public function RemoveHospital(Request $request){
        try
        {
            //get token from session
            $value = Session::get('admin_token');
            //get user id from auth
            $admin_id = Auth::user()->id;

            //check login status of user
            $login_token = AdminLoginToken::where(array('admin_id'=>$admin_id,'login_token'=>$value))->first();        
            if(isset($login_token->token_status) && $login_token->token_status == 0){ 
                Auth::guard('admin')->logout();           
                return redirect('/admin/login');
            }
            if(!Auth::check()){            
                return redirect('/admin/login');
            }
            $id = isset($request->id) ? $request->id:'';
            $hospital = Hospital::where(array('hosp_id' => $id))->first();
            $hospital->delete();
            return response()->json(['success'=>1,'message'=>'Hospital has been deleted successfully.'],200);
        }
        catch(Exception $e)
        {
            return response()->json(['error'=>1,"message"=>$e->getMessage()],200);   
        }
    }

     // Use for remove
     public function RemovePatient(Request $request){
        try
        {
            //get token from session
            $value = Session::get('admin_token');
            //get user id from auth
            $admin_id = Auth::user()->id;

            //check login status of user
            $login_token = AdminLoginToken::where(array('admin_id'=>$admin_id,'login_token'=>$value))->first();        
            if(isset($login_token->token_status) && $login_token->token_status == 0){ 
                Auth::guard('admin')->logout();           
                return redirect('/admin/login');
            }
            if(!Auth::check()){            
                return redirect('/admin/login');
            }
            $id = isset($request->id) ? $request->id:'';
            $hospital = Patient::where(array('patient_unique_id' => $id))->first();
            $hospital->delete();
            return response()->json(['success'=>1,'message'=>'Patients has been deleted successfully.'],200);
        }
        catch(Exception $e)
        {
            return response()->json(['error'=>1,"message"=>$e->getMessage()],200);   
        }
    }

    //get facility wise list speciality
    
    public function GetFacilityWiseSpeciality(Request $request)
    {
        try
        {
            $facilityId = isset($request->facilityId) ? $request->facilityId:'';

             //get token from session
            $value = Session::get('admin_token');

            //get user id from auth
            $admin_id = Auth::user()->id;

            //check login status of user
            $login_token = AdminLoginToken::where(array('admin_id'=>$admin_id,'login_token'=>$value))->first();        
            if(isset($login_token->token_status) && $login_token->token_status == 0){ 
                Auth::guard('admin')->logout();           
                return redirect('/admin/login');
            }
            if(!Auth::check()){            
                return redirect('/admin/login');
            }
            //LGA
            $getSpeciality = Speciality::where('facility_id',$facilityId)->get();
            if(count($getSpeciality)>0)
            {
                $facilityHtmlSpeciality='<option value="0" data-id="0">Select Speciality</option>';
                foreach($getSpeciality as $speciality)
                {
                    $facilityHtmlSpeciality.="<option data-id='".$speciality['id']."' value='".$speciality['name']."'>" . $speciality['name'] . "</option>";
                }
            }
            else
            {
                $facilityHtmlSpeciality='<option value="0" data-id="0">Select Speciality</option>';
            }
           

            return response()->json(['success'=>1,"dataspeciality"=>$facilityHtmlSpeciality],200);
        }
        catch(Exception $e)
        {
            return response()->json(['error'=>1,"message"=>$e->getMessage()],200);   
        }
    }
     // Get Employee Information
     public function viewemployee(Request $request){
        $employee = Admin::where('employee_id',$request->id)->first();
        $date = $employee->employee_dob;
        $month = date('F',strtotime($date));
        $day = date('j',strtotime($date));
        $year = date('Y',strtotime($date));
        $employee['select_day']= $day;
        $employee['select_month']=$month; 
        $employee['select_year']= $year;
        // dd($employee);
        return response()->json($employee);
    }
    //Add new hospital
    public function EditNewEmployee(Request $request)
    {
        
        try
        {
            //get token from session
            $value = Session::get('admin_token');

            //get user id from auth
            $admin_id = Auth::user()->id;

            //check login status of user
            $login_token = AdminLoginToken::where(array('admin_id'=>$admin_id,'login_token'=>$value))->first();        
            if(isset($login_token->token_status) && $login_token->token_status == 0){ 
                Auth::guard('admin')->logout();           
                return redirect('/admin/login');
            }
            if(!Auth::check()){            
                return redirect('/admin/login');
            }

            $employee_title = isset($request->employee_title) ? $request->employee_title:'';
            $first_name = isset($request->first_name) ? $request->first_name:'';
            $middle_name = isset($request->middle_name) ? $request->middle_name:'';
            $surname = isset($request->surname) ? $request->surname:'';
            $emp_ph = isset($request->employee_phone) ? $request->employee_phone:'';
            $password = isset($request->password) ? $request->password:'';
            $alternative_phone = isset($request->employee_alternative_phone) ? $request->employee_alternative_phone:'';
            $emp_id = isset($request->emp_id) ? $request->emp_id:'';
            $employee_email = isset($request->employee_email) ? $request->employee_email:'';
            $emp_address = isset($request->emp_address) ? $request->emp_address:'';
            $employee_country = isset($request->employee_country) ? $request->employee_country:'';
            $employee_state = isset($request->employee_state) ? $request->employee_state:'';
            $employee_city = isset($request->employee_city) ? $request->employee_city:'';
            $date = $request->day;
            $month =$request->month;
            $month = date('m',strtotime($month));
            $year = $request->years;
            //  $date.$month.$year;
            $emp_dob = $year.'-'.$month.'-'.$date;
            $state_of_origin = isset($request->state_of_origin) ? $request->state_of_origin:'';
            $position = isset($request->position) ? $request->position:'';
            $nextofkin_first_name = isset($request->nextofkin_first_name) ? $request->nextofkin_first_name:'';
            $nextofkin_surname = isset($request->nextofkin_surname) ? $request->nextofkin_surname:'';
            $nextofkin_phone = isset($request->nextofkin_phone) ? $request->nextofkin_phone:'';
            $reference_first_name = isset($request->reference_first_name) ? $request->reference_first_name:'';
            $reference_surname = isset($request->reference_surname) ? $request->reference_surname:'';
            $reference_phone = isset($request->reference_phone) ? $request->reference_phone:'';
            $reference2_first_name = isset($request->reference2_first_name) ? $request->reference2_first_name:'';
            $reference2_surname = isset($request->reference2_surname) ? $request->reference2_surname:'';
            $reference2_phone = isset($request->reference2_phone) ? $request->reference2_phone:'';
            $emp_role = isset($request->emp_role) ? $request->emp_role:'';
            $emp_status = isset($request->emp_status) ? $request->emp_status:'';
            $emp_gender = isset($request->emp_gender) ? $request->emp_gender:'';
            $emp_marital_status = isset($request->emp_marital_status) ? $request->emp_marital_status:'';
            $access_for_hospital = isset($request->access_for_hospital) ? $request->access_for_hospital:'';
            $entry_patient_record = isset($request->entry_patient_record) ? $request->entry_patient_record:'';
            $username = isset($request->username) ? $request->username:'';
            $employee_languages = isset($request->languages) ? $request->languages:'';
            $employee_education_school = isset($request->employee_education_school) ? $request->employee_education_school:'';
            #validations
            if($first_name=='')
            {
                return response()->json(['error'=>1,"message"=>"Please provide employee first name."],200);   
            }
            if($surname=='')
            {
                return response()->json(['error'=>1,"message"=>"Please provide employee surname."],200);   
            }
            else if($employee_email=='')
            {
                return response()->json(['error'=>1,"message"=>"Please provide employee email address."],200);
            }
            else if($emp_ph=='')
            {
                return response()->json(['error'=>1,"message"=>"Please provide employee phone number."],200);
            }
            else if(!is_numeric($emp_ph))
            {
                return response()->json(['error'=>1,"message"=>"Please provide numeric employee phone number."],200);
            }
            else if($emp_address=='')
            {
                return response()->json(['error'=>1,"message"=>"Please provide employee address."],200);
            }
            else if($emp_id=='')
            {
                return response()->json(['error'=>1,"message"=>"Please provide employee ID."],200);
            }
            // else if($employee_country=='')
            // {
            //     return response()->json(['error'=>1,"message"=>"Please provide employee country."],200);
            // }
            else if($employee_state=='')
            {
                return response()->json(['error'=>1,"message"=>"Please provide employee state."],200);
            }
            else if($emp_status=='')
            {
                return response()->json(['error'=>1,"message"=>"Please provide employee address."],200);
            }
            else if($emp_role=='')
            {
                return response()->json(['error'=>1,"message"=>"Please provide employee address."],200);
            }
            else if(count($access_for_hospital)<=0)
            {
                return response()->json(['error'=>1,"message"=>"Please choose access for hospital."],200);
            }
            else if($entry_patient_record=='')
            {
                return response()->json(['error'=>1,"message"=>"Please choose access for patient record ."],200);
            }
          

            
           
            if($access_for_hospital!='')
            {
                if(count($access_for_hospital)==2)
                {
                    $access_for_hospital_val = 3; //access for both 
                }
                elseif(count($access_for_hospital)==1)
                {
                    $access_for_hospital_val = $access_for_hospital[0];
                }
            }
            else
            {
                $access_for_hospital_val=0;
            }

            if($entry_patient_record!='')
            {
                $entry_patient_record_val = $entry_patient_record;
            }
            else
            {
                $entry_patient_record_val = 0;
            }
           
            
            //check for existing hospital 
            $exist_employee = Admin::where('employee_id',$request->employee_id)->count();
            if($exist_employee > 0)
            {
                $employee = Admin::where(array('employee_id' => $request->employee_id))->first();
                if(request()->image!='undefined'){
                    //upload image
                    $imageName = time().'.'.request()->image->getClientOriginalExtension();
                    request()->image->move(public_path('employeeimages'), $imageName);
                }else{
                    $imageName = $employee->employee_picture;
                }
                // dd($emp_dob);
                $employee->employee_id  = $emp_id;
                $employee->employee_title  = $employee_title;
                $employee->first_name =  $first_name;
                $employee->employee_middle_name =  $middle_name;
                $employee->last_name =  $surname;
                $employee->email =  $employee_email;
                $employee->employee_phone =  $emp_ph;
                $employee->employee_alternative_phone =  $alternative_phone;
                $employee->employee_address =  $emp_address;
                $employee->employee_country =  $employee_country;
                $employee->employee_state =  $employee_state;
                $employee->employee_city = $employee_city;
                $employee->employee_dob =  $emp_dob;
                $employee->employee_gender =  $emp_gender;
                $employee->employee_marital_status =  $emp_marital_status;
                $employee->state_of_origin =  $state_of_origin;
                $employee->position =  $position;
                $employee->nextofkin_first_name =  $nextofkin_first_name;
                $employee->nextofkin_surname =  $nextofkin_surname;
                $employee->nextofkin_phone =  $nextofkin_phone;
                $employee->reference_first_name =  $reference_first_name;
                $employee->reference_surname =  $reference_surname;
                $employee->reference_phone =  $reference_phone;
                $employee->reference2_first_name =  $reference2_first_name;
                $employee->reference2_surname =  $reference2_surname;
                $employee->reference2_phone =  $reference2_phone;
                $employee->employee_role =  $emp_role;
                $employee->employee_picture =  $imageName;
                $employee->active_status =  $emp_status;
                $employee->access_to_hospital = $access_for_hospital_val;
                $employee->access_to_patient_record = $entry_patient_record_val;
                $employee->username = $username; 
                $employee->employee_education_school = $employee_education_school;
                $employee->employee_languages = $employee_languages;              
                $employee->save();

                return response()->json(['success'=>1,'message'=>'Employee edited successfully.'],200);
            }
            else
            {
                return response()->json(['error'=>1,"message"=>"Employee not exists."],200); 
            }   
        }
        catch(Exception $e)
        {
            return response()->json(['error'=>1,"message"=>$e->getMessage()],200);   
        }
    }
    public function AllAppointment(Request $request)
    {  

        //get token from session
        $value = Session::get('admin_token');
        $admin_id = Auth::user()->id;
        $login_token = AdminLoginToken::where(array('admin_id'=>$admin_id,'login_token'=>$value))->first();        
        if(isset($login_token->token_status) && $login_token->token_status == 0){ 
            Auth::guard('admin')->logout();           
            return redirect('/admin/login');
        }
        if(!Auth::check()){            
            return redirect('/admin/login');
        }

        //get pagination params
        if(isset($_GET['type']))
        {        
            if($_GET['type'] == "doc_page")
            {
                $doc_page = $_GET['page'];
                $limit = 10;            
            }
            else
            {
                $doc_page = $_GET['doc_page'];
                $limit = 10;            
            } 
        }
        else
        {
        $doc_page = 1;
        $nurse_page =1;
        $ad_page =1;
        $limit = 10;          
        }

        $user = $request->user();
        $admin_id = $user->id;

        //get details of logged in user
        $admin_details = Admin::where('id',$admin_id)->first();  
        $time_zone = $admin_details->admin_timezone;                 
        $dtz = new DateTimeZone($time_zone);
        $time_in_sofia = new DateTime('now', $dtz);        
        $date_offset = $time_in_sofia->format('Z');
        $start_time = strtotime(date("Y-m-d"))-$date_offset;
        $end_time = strtotime(date("Y-m-d",strtotime("+1 day")))-$date_offset; 

        $query=SaveTelemedicalBookingDetail::select('save_telemedical_booking_detail.*','appointment_details.*','patients.*','save_telemedical_booking_detail.id as st_id','save_telemedical_booking_detail.status as st_status')->leftJoin('appointment_details', 'appointment_details.appointment_id','=', 'save_telemedical_booking_detail.appointment_id')->leftJoin('patients', 'save_telemedical_booking_detail.patient_id','=', 'patients.patient_unique_id')->with('specialityFacility');

        $query->where('save_telemedical_booking_detail.approved_status','!=',2);

        $appointments = $query;
        
        if(isset($_GET['filter']))
        {
            if($_GET['filter'] == 'Booking Name') $appointments->orderBy('save_telemedical_booking_detail.booking_name');
            if($_GET['filter'] == 'Specialist') $appointments->orderBy('save_telemedical_booking_detail.specialist_id');
            if($_GET['filter'] == 'Doctor') $appointments->orderBy('save_telemedical_booking_detail.doctor_id');
            if($_GET['filter'] == 'Patient') $appointments->orderBy('save_telemedical_booking_detail.patient_id');
            if($_GET['filter'] == 'Date') $appointments->orderBy('save_telemedical_booking_detail.created_at');
        }
                
        $appointments = $appointments->paginate(20);
        foreach($appointments as $app)
        {
        SaveTelemedicalBookingDetail::where('id', $app->st_id)->update(['status' => 0]);
        }
        $today_appointment=SaveTelemedicalBookingDetail::where('save_telemedical_booking_detail.approved_status','!=',2)->where('appointment_time','>=',$start_time)->where('appointment_time','<',$end_time)->get();            

        $disputed_billing = BillingDetail::where('disputed',1)->orderBy('billing_date','DESC');    
        $disabled = 0;
        if($request->ajax())
        {
            return view('admin.appointment.list_ajax')->with(array('controller'=> 'admin','today_appointments_count'=>$today_appointment->count(),'page'=>'inner','page_type'=>'appointments','timezone'=>$time_zone,"appointments"=>$appointments,"disputed_billing_count"=>$disputed_billing->count(),'disabled'=>$disabled));
            
        }else{
            return view('admin.appointment.list')->with(array('controller'=> 'admin','today_appointments_count'=>$today_appointment->count(),'page'=>'inner','page_type'=>'appointments','timezone'=>$time_zone,"appointments"=>$appointments,"disputed_billing_count"=>$disputed_billing->count(),'disabled'=>$disabled));
            
        }
    } //Ends My schedule function


     /******
    Reschedule Appointment
    *******/
    public function resheduleDetailForAdmin(Request $request){
        //get token from session
        $value = Session::get('admin_token');
        $admin_id = Auth::user()->id;
        $login_token = AdminLoginToken::where(array('admin_id'=>$admin_id,'login_token'=>$value))->first();        
        if(isset($login_token->token_status) && $login_token->token_status == 0){ 
            Auth::guard('admin')->logout();           
            return redirect('/admin/login');
        }
        if(!Auth::check()){            
            return redirect('/admin/login');
        }           
        $doctor_details = Doctor::where('doctor_id',$request->doctor_id)->first();
        $time_zone = $doctor_details->doctor_timezone;
        $dtz = new DateTimeZone($time_zone);     
        $date = date('Y-m-d',strtotime($_POST['appoint_date']));   
        $next_date = date('Y-m-d', strtotime('+1 day', strtotime($date)));
        $time_in_sofia = new DateTime($date, $dtz);        
        $date_offset = $time_in_sofia->format('Z');       
        $start_time = strtotime($date)-$date_offset;
        
        $end_time = strtotime($next_date)-$date_offset;

        $appoint_detail=SaveTelemedicalBookingDetail::with(array("patient_detail","doctor.specialist_categories","patient_appoint"))->where("save_telemedical_booking_detail.booking_id",$_POST['book_id'])->first();
        $doctor_avail_time = ''; 
        if(isset($appoint_detail->patient_appoint) && $appoint_detail->patient_appoint->appointment_type == 2){
            $doctor_avail_time=Doctor::with(array('doctor_availability'=>function($q) use($start_time,$end_time) {$q->where('availability_date','>=',$start_time); $q->where('availability_date','<',$end_time); $q->where('type',2);}))->with('specialist_categories')->whereHas('doctor_availability', function($q) use($start_time,$end_time) {$q->where('availability_date','>=',$start_time); $q->where('availability_date','<',$end_time); $q->where('type',2);})->where('doctor_id',$appoint_detail->doctor_id)->select("*")->first();
            if(isset($doctor_avail_time->doctor_id)){
                $doctor_avail_time = $doctor_avail_time->toArray();
            }
        }elseif(isset($appoint_detail->patient_appoint) && $appoint_detail->patient_appoint->appointment_type == 1){
            $doctor_avail_time=Doctor::with(array('doctor_availability'=>function($q) use($start_time,$end_time) {$q->where('availability_date','>=',$start_time); $q->where('availability_date','<',$end_time);$q->where('type',1);}))->with('specialist_categories')->whereHas('doctor_availability', function($q) use($start_time,$end_time) {$q->where('availability_date','>=',$start_time); $q->where('availability_date','<',$end_time);$q->where('type',1);})->where('doctor_id',$appoint_detail->doctor_id)->select("*")->first();
            if(isset($doctor_avail_time->doctor_id)){
                $doctor_avail_time = $doctor_avail_time->toArray();
            }
        }
         $disputed_billing = BillingDetail::where('doctor_id',$request->doctor_id)->where('disputed',1)->orderBy('billing_date','DESC'); 
        $doc_appoint_listing=SaveTelemedicalBookingDetail::where('save_telemedical_booking_detail.approved_status','!=',2)->where('save_telemedical_booking_detail.appointment_time','>=',$start_time)->where('save_telemedical_booking_detail.appointment_time','<',$end_time)->orderBy('save_telemedical_booking_detail.appointment_time','ASC')->get();
       
        return view('doctor.reshedule')->with(array('controller'=> 'doctor','appointment'=>$appoint_detail,'doctor_avail_time'=>$doctor_avail_time,'doctor_details'=>$doctor_details,'doc_appoint_listing'=>$doc_appoint_listing,'timezone'=>$time_zone,'appoint_date'=>$_POST['appoint_date'],'disputed_billing_count'=>$disputed_billing->count()));
    
    }

    /******
    Cancel Booking
    *******/    
    public function cancelBookingForAdmin(Request $request){
       //get token from session
       $value = Session::get('admin_token');
       $admin_id = Auth::user()->id;
       $login_token = AdminLoginToken::where(array('admin_id'=>$admin_id,'login_token'=>$value))->first();        
       if(isset($login_token->token_status) && $login_token->token_status == 0){ 
           Auth::guard('admin')->logout();           
           return redirect('/admin/login');
       }
       if(!Auth::check()){            
           return redirect('/admin/login');
       }  
        
        $update_status = SaveTelemedicalBookingDetail::where('booking_id',$_POST['book_id'])->update(['approved_status'=>2]);
        $UserNotification = new UserNotification([                
            'notification_id'   => $this->generateNUniqueNumber(),
            'doctor_id'         => $request->doctor_id, 
            'assignee_type'     => 1,                    
            'patient_id'        => $_POST['patient_id'], 
            'event_id'          => $_POST['book_id'],
            'notification_type' => "appt",
            'change_type'       => "cancelled",
            'created_date'      => strtotime('now'),
            'status'            => 0                                          
        ]);
        $UserNotification->save(); 

        $login_token = PatientLoginToken::where('patient_id',$_POST['patient_id'])->where('token_status',1)->get();

        
        $msg = "Dr.".Auth::user()->doctor_first_name." ".Auth::user()->doctor_last_name." cancelled your appointment";
        
        $patients_notification = PatientNotificationSetting::where('patient_id', $_POST['patient_id'])->first();
        if(isset($patients_notification->patient_id)){
            if($patients_notification->appointment_cancel_push == 1){
                if(count($login_token) > 0 && $login_token[0]->device_type != 2){            
                    $device_token = $login_token[0]->device_token;
                    $path = base_path()."/ios_notifcation/all_notifications.php";
                    
                    $nid = $_POST['book_id'];
                    $type= 'appt';
                    exec ('php '.$path.' "'.$msg.'" '.$nid.' '.$type.' '.$device_token.' > /dev/null &');
                }
            }

            if($patients_notification->appointment_cancel_email == 1){
                $url = url('/doctor/send_mail/'.str_replace(" ", "_", $msg).'/'.$_POST['patient_id'].'');   
                $cmd  = "curl --max-time 60 ";   
                $cmd .= "'" . $url . "'";   
                $cmd .= " > /dev/null 2>&1 &";    
                exec($cmd, $output, $exit); 
            }
        } 
        if($update_status > 0){
            return response()->json(['success'=>1], 200);
        }else{
            return response()->json(['success'=>0,'message'=>'Something went wrong'], 200);
        }        
    }
    public function AllHealthRecord(Request $request)
    {  

        $value = Session::get('admin_token');

        //get user id from auth
        $admin_id = Auth::user()->id;

        //check login status of user
        $login_token = AdminLoginToken::where(array('admin_id'=>$admin_id,'login_token'=>$value))->first();        
        if(isset($login_token->token_status) && $login_token->token_status == 0){ 
            Auth::guard('admin')->logout();           
            return redirect('/admin/login');
        }
        if(!Auth::check()){            
            return redirect('/admin/login');
        }
        $user = $request->user();
       $admin_details = Admin::where('id',$admin_id)->first(); 
        /*$doctor_details = Doctor::where('doctor_id',$doctor_id)->first();  
        $hospital_id = $doctor_details->hospital_id;
        $time_zone = $doctor_details->doctor_timezone;                 
        $dtz = new DateTimeZone($time_zone);
        $time_in_sofia = new DateTime('now', $dtz);        
        $date_offset = $time_in_sofia->format('Z');
        $start_time = strtotime(date("Y-m-d"))-$date_offset;
        $end_time = strtotime(date("Y-m-d",strtotime("+1 day")))-$date_offset;*/

        $health_history=HealthHistory::with(array('patient','doctor','history_attachments','doctor.doctor_hospital_details','nurse.nurse_hospital_details','employee.employee_hospital_details'));
        if(isset($_GET['filter']))
        {
            if($_GET['filter'] == 'Employee') $health_history->orderBy('health_history.employee_id');
            if($_GET['filter'] == 'Hospital') $health_history->orderBy('health_history.hospital_id');
            if($_GET['filter'] == 'Doctor') $health_history->orderBy('health_history.doctor_id');
            if($_GET['filter'] == 'Patient') $health_history->orderBy('health_history.patient_id');
            if($_GET['filter'] == 'Nurse') $health_history->orderBy('health_history.nurse_id');
            if($_GET['filter'] == 'Date') $health_history->orderBy('health_history.created_date');
        }
        $health_history = $health_history->orderBy('created_date','DESC')->paginate(20); 
       // echo "<pre>"; print_R($health_history); exit;
        $doctor_details=array();
        if($request->ajax()){
            return view('admin.healthrecord.list_ajax')->with(array('controller'=> 'admin','health_history'=>$health_history,'page'=>'inner','doctor_details'=>$doctor_details,'page_type'=>'health_history')); 
        }else{        
            return view('admin.healthrecord.list')->with(array('controller'=> 'admin','health_history'=>$health_history,'page'=>'inner','doctor_details'=>$doctor_details,'page_type'=>'health_history',"admin_details"=>$admin_details)); 
        }     
    } //Ends My schedule function
}
