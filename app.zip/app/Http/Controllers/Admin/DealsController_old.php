<?php
namespace App\Http\Controllers\Admin;


use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Auth;
use DB;
use Validator;
use Redirect;
use DateTime;
use DateTimeZone;
use Session;
use Hash;
use Mail;
use App\Models\PatientLoginToken;
use App\Models\Patient;
use App\Models\Hospital;
use App\Models\SaveTelemedicalBookingDetail;
use App\Models\HospitalHour;
use App\Models\DoctorAvailability;
use App\Models\PatientAppointment;
use App\Models\CallSession;
use App\Models\HealthHistory;
use App\Models\Doctor;
use App\Models\Nurse;
use App\Models\Admin;
use App\Models\AdminLoginToken;
use App\Models\Country;
use App\Models\ServiceOffered;
use App\Models\State;
use App\Models\StatesNigeria;
use App\Models\LocalGovernment;
use App\Models\CityNigeria;
use App\Models\Facility;
use App\Models\Speciality;
use App\Models\DoctorHospitalDetail;
use App\Models\PatientsDependent;
use App\Models\Employee;
use App\Models\BillingDetail;

use App\Models\SpecialistCategories;
use App\Models\Administrator;

use App\Models\BillingService;
use App\Models\HealthHistoryMedication;
use App\Models\UserNotification;
use App\Models\PatientNotificationSetting;
use App\Models\HealthHistoryAttachments;
use App\Models\PatientHealthDiary;
use Twilio\Rest\Client;
//use Edujugon\PushNotification\PushNotification;

use App\Models\Deals;
use App\Models\DealCategories;
class DealsController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth:admin',['except' => ['SendMailTest']]);
    }
    
    //Get all deals and display
    public function index(Request $request)
    {
        //get token from session
        $value = Session::get('admin_token');
        $admin_id = Auth::user()->id;
        $login_token = AdminLoginToken::where(array('admin_id'=>$admin_id,'login_token'=>$value))->first();        
        if(isset($login_token->token_status) && $login_token->token_status == 0){ 
            Auth::guard('admin')->logout();           
            return redirect('/admin/login');
        }
        if(!Auth::check()){            
            return redirect('/admin/login');
        }

        //get pagination params
        if(isset($_GET['type']))
        {        
           if($_GET['type'] == "doc_page")
           {
               $doc_page = $_GET['page'];
               $limit = 10;            
           }
           else
           {
               $doc_page = $_GET['doc_page'];
               $limit = 10;            
           } 
       }
       else
       {
         $doc_page = 1;
         $nurse_page =1;
         $ad_page =1;
         $limit = 10;          
       }

        $facilities = Hospital::all();
        $deal_category = DealCategories::where(['is_deleted' => 0])->get();
        $deals = Deals::with('facility_details')->where(['is_deleted' => 0]);
        if(isset($_GET['filter']))
        {
            if($_GET['filter'] == 'Active') $deals->where('status','Active');
            if($_GET['filter'] == 'Expired') $deals->where('status','Expired');
        }
        $deals = $deals->orderBy('created_at', 'desc')->paginate($limit, ['*'],'page',$doc_page);
        if($request->ajax())
        {
            return view('admin.deals.list_ajax')->with(array('controller'=> 'admin','deals'=>$deals,'facilities'=>$facilities,'deal_category'=>$deal_category));
        }else{
            return view('admin.deals.list')->with(array('controller'=> 'admin','deals'=>$deals,'facilities'=>$facilities,'deal_category'=>$deal_category));
        }
    }

    // get all categories dynamically
    public function getCategories(Request $request)
    {
        $deal_categories = DB::table("deal_categories")
                    ->where(["facility_id" => $request->facility_id,'is_deleted' => 0])
                    ->pluck("name","id");
        return response()->json($deal_categories);
    }

    // Create New
    public function create(Request $request){
        try
        {
            //get token from session
            $value = Session::get('admin_token');

            //get user id from auth
            $admin_id = Auth::user()->id;

            //check login status of user
            $login_token = AdminLoginToken::where(array('admin_id'=>$admin_id,'login_token'=>$value))->first();        
            if(isset($login_token->token_status) && $login_token->token_status == 0){ 
                Auth::guard('admin')->logout();           
                return redirect('/admin/login');
            }
            if(!Auth::check()){            
                return redirect('/admin/login');
            }

            $facility_id = isset($request->facility_id) ? $request->facility_id:'';
            $category_id = isset($request->category_id) ? $request->category_id:'';
            $date1 = $request->day1;
            $month1 =$request->month1;
            $month1 = date('m',strtotime($month1));
            $year1 = $request->years1;
            $start_date = $year1.'-'.$month1.'-'.$date1;
            $date2 = $request->day2;
            $month2 =$request->month2;
            $month2 = date('m',strtotime($month2));
            $year2 = $request->years2;
            $end_date = $year2.'-'.$month2.'-'.$date2;
            $title = isset($request->title) ? $request->title:'';
            $previous_price	 = isset($request->previous_price) ? $request->previous_price	:'';
            $current_price = isset($request->current_price) ? $request->current_price:'';
            $details = isset($request->details) ? $request->details:'';
            $restriction = isset($request->restriction) ? $request->restriction:'';
            $about_us = isset($request->about_us) ? $request->about_us:'';

             #validations
             if($facility_id=='')
             {
                 return response()->json(['error'=>1,"message"=>"Please provide facility."],200);   
             }else if($category_id=='')
             {
                 return response()->json(['error'=>1,"message"=>"Please provide category."],200);
             }else if($start_date=='')
             {
                 return response()->json(['error'=>1,"message"=>"Please provide start date."],200);
             }else if($end_date=='')
             {
                 return response()->json(['error'=>1,"message"=>"Please provide end date."],200);
             }else if($previous_price == '')
             {
                 return response()->json(['error'=>1,"message"=>"Please provide previous price."],200);
             }else if($current_price == '')
             {
                 return response()->json(['error'=>1,"message"=>"Please provide current price."],200);
             }else if(!is_numeric($previous_price))
             {
                 return response()->json(['error'=>1,"message"=>"Please provide numeric value of previous price."],200);
             }else if(!is_numeric($current_price)){
                 return response()->json(['error'=>1,"message"=>"Please provide numeric value of current price."],200);
             }
             //upload image
             if(request()->image){
                 $imageName = time().'.'.request()->image->getClientOriginalExtension();
                 request()->image->move(public_path('dealsimages'), $imageName);
                }

            $Deals = new Deals([
            'facility_id'  => $facility_id,
            'category_id'  => $category_id,
            'start_date'=>$start_date,
            'end_date'=>$end_date,
            'title'=>$title,
            'previous_price' => $previous_price,
            'current_price' => $current_price,
            'details' => $details,
            'restriction' => $restriction,
            'about_us'=>$about_us,
            'status' =>'Active',
            'image' => $imageName                    
            ]);

            $Deals->save();
            return response()->json(['success'=>1,'message'=>'Deals has been added successfully.'],200);
        }
        catch(Exception $e)
        {
            return response()->json(['error'=>1,"message"=>$e->getMessage()],200);   
        }
    }

    // Get Deal Information
    public function show(Request $request){
        $deals = Deals::with('facility_details','categories_details')->where('id',$request->id)->first();
        $DealCategories = DealCategories::where('is_deleted',0)->get();
        $deals['DealCategories'] = $DealCategories;
        return response()->json($deals);
    }

    // Edit Deal Information
    public function edit(Request $request){
        try
        {
            //get token from session
            $value = Session::get('admin_token');
            //get user id from auth
            $admin_id = Auth::user()->id;
            //check login status of user
            $login_token = AdminLoginToken::where(array('admin_id'=>$admin_id,'login_token'=>$value))->first();        
            if(isset($login_token->token_status) && $login_token->token_status == 0){ 
                Auth::guard('admin')->logout();           
                return redirect('/admin/login');
            }
            if(!Auth::check()){            
                return redirect('/admin/login');
            }

             //upload image
            if(request()->image){
                $imageName = time().'.'.request()->image->getClientOriginalExtension();
                request()->image->move(public_path('dealsimages'), $imageName);
            }
            $facility_id = isset($request->facility_id) ? $request->facility_id:'';
            $category_id = isset($request->category_id) ? $request->category_id:'';
            $date1 = $request->day1;
            $month1 =$request->month1;
            $month1 = date('m',strtotime($month1));
            $year1 = $request->years1;
            $start_date = $year1.'-'.$month1.'-'.$date1;
            $date2 = $request->day2;
            $month2 =$request->month2;
            $month2 = date('m',strtotime($month2));
            $year2 = $request->years2;
            $end_date = $year2.'-'.$month2.'-'.$date2;
            $title = isset($request->title) ? $request->title:'';
            $previous_price	 = isset($request->previous_price) ? $request->previous_price	:'';
            $current_price = isset($request->current_price) ? $request->current_price:'';
            $details = isset($request->details) ? $request->details:'';
            $restriction = isset($request->restriction) ? $request->restriction:'';
            $about_us = isset($request->about_us) ? $request->about_us:'';

             #validations
             if($facility_id=='')
             {
                 return response()->json(['error'=>1,"message"=>"Please provide facility."],200);   
             }else if($category_id=='')
             {
                 return response()->json(['error'=>1,"message"=>"Please provide category."],200);
             }else if($start_date=='')
             {
                 return response()->json(['error'=>1,"message"=>"Please provide start date."],200);
             }else if($end_date=='')
             {
                 return response()->json(['error'=>1,"message"=>"Please provide end date."],200);
             }else if($previous_price == '')
             {
                 return response()->json(['error'=>1,"message"=>"Please provide previous price."],200);
             }else if($current_price == '')
             {
                 return response()->json(['error'=>1,"message"=>"Please provide current price."],200);
             }else if(!is_numeric($previous_price))
             {
                 return response()->json(['error'=>1,"message"=>"Please provide numeric value of previous price."],200);
             }else if(!is_numeric($current_price)){
                 return response()->json(['error'=>1,"message"=>"Please provide numeric value of current price."],200);
             }

            $Deals = Deals::where(array('id' => $request->deal_id))->first();
            $Deals->facility_id = $facility_id;
            $Deals->category_id = $category_id;
            $Deals->start_date = $start_date;
            $Deals->end_date = $end_date;
            $Deals->title = $title;
            $Deals->previous_price = $previous_price;
            $Deals->current_price = $current_price;
            $Deals->details = $details;
            $Deals->restriction = $restriction;
            $Deals->about_us = $about_us;
            if(isset($imageName)){
                $Deals->image = $imageName;
            }
            $Deals->save();
            return response()->json(['success'=>1,'message'=>'Deals has been updated successfully.'],200);
        }
        catch(Exception $e)
        {
            return response()->json(['error'=>1,"message"=>$e->getMessage()],200);   
        }
    }

    // Use for remove
    public function remove(Request $request){
        try
        {
            //get token from session
            $value = Session::get('admin_token');
            //get user id from auth
            $admin_id = Auth::user()->id;

            //check login status of user
            $login_token = AdminLoginToken::where(array('admin_id'=>$admin_id,'login_token'=>$value))->first();        
            if(isset($login_token->token_status) && $login_token->token_status == 0){ 
                Auth::guard('admin')->logout();           
                return redirect('/admin/login');
            }
            if(!Auth::check()){            
                return redirect('/admin/login');
            }
            $id = isset($request->id) ? $request->id:'';
            $Deals = Deals::where(array('id' => $id))->first();
            $Deals->is_deleted = 1;
            $Deals->save();
            return response()->json(['success'=>1,'message'=>'Deals has been deleted successfully.'],200);
        }
        catch(Exception $e)
        {
            return response()->json(['error'=>1,"message"=>$e->getMessage()],200);   
        }
    }
}
