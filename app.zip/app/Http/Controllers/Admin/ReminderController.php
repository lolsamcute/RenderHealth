<?php
namespace App\Http\Controllers\Admin;


use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Auth;
use DB;
use Validator;
use Redirect;
use DateTime;
use DateTimeZone;
use Session;
use Hash;
use Mail;
use App\Models\PatientLoginToken;
use App\Models\Patient;
use App\Models\Hospital;
use App\Models\SaveTelemedicalBookingDetail;
use App\Models\DoctorAvailability;
use App\Models\PatientAppointment;
use App\Models\CallSession;
use App\Models\HealthHistory;
use App\Models\Doctor;
use App\Models\Admin;
use App\Models\AdminLoginToken;
use App\Models\Country;
use App\Models\State;
use App\Models\DoctorHospitalDetail;
use App\Models\Employee;
use App\Models\UserNotification;



//use Edujugon\PushNotification\PushNotification;

class ReminderController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    /*public function __construct()
    {
       
        $this->middleware('auth:admin');  
    }*/
    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */

    //health diary reminder
    public function ReminderHealthDiary(Request $request,$id)
    {       
        $patient_id = $id;

         //get patient detail
        $getPatientDetail = Patient::where('patient_unique_id',$patient_id)->get();

        if(!empty($getPatientDetail))
        {
            //check login token
           $check_token = PatientLoginToken::where(['patient_id'=>$patient_id,'token_status'=>1,'device_type'=>1])->get();           

            if(count($check_token) > 0){
                
                //insert into user notification table
                $UserNotification = new UserNotification([                
                'notification_id'   => $this->generateNUniqueNumber(),                                
                'assignee_type'     => 4,                    
                'patient_id'        => $patient_id, 
                'notification_type' => "health_diary",
                'change_type'       => "cron_health",
                'created_date'      => strtotime('now'),
                'status'            => 0                                          
                ]);

                $UserNotification->save();
               // file_put_contents('demo.txt',$check_token[0]->device_token);
                
                //send notification
                $device_token = $check_token[0]->device_token;
                $path = base_path()."/ios_notifcation/health_reminder_notifications.php";
                $msg = "Please add a new health diary";
                //$nid = $appt['booking_id'];
                $type = 'health_diary';
                exec ('php '.$path.' '.base64_encode($msg).' '.$type.' '.$device_token.' > /dev/null &');

                echo json_encode(array("success"=>1,"message"=>"Notification send successfully"));
                
            }
            else
            {
                echo json_encode(array("success"=>0,"message"=>"Please login first."));
            }
        }
        else
        {
            echo json_encode(array("success"=>0,"message"=>"Patient does not exist"));
        }
           
    }
    public function ReminderHealthDiaryCron(Request $request)
    {
        $allPatientIds = array();
        $patients = DB::select("select patient_unique_id,patient_email from patients where patient_unique_id!='' and patient_unique_id not in (SELECT distinct(patient_id) as p_id FROM patient_health_diary WHERE patient_health_diary.patient_id = patient_health_diary.patient_id AND YEARWEEK(from_unixtime(created_date,'%Y-%m-%d'), 0) = YEARWEEK(NOW(), 0))");

        if(!empty($patients))
        {
            foreach($patients as $patient)
            {
                $patient_id = $patient->patient_unique_id;
              
                $getPatientDetail = Patient::where('patient_unique_id',$patient_id)->get();

                if(!empty($getPatientDetail))
                {
                   $check_token = PatientLoginToken::where(['patient_id'=>$patient_id,'token_status'=>1,'device_type'=>1])->get();

                   //check if notifcation has already been sent
                   $already_send = DB::select("SELECT patient_id FROM `user_notifications` WHERE user_notifications.patient_id = user_notifications.patient_id AND YEARWEEK(from_unixtime(created_date,'%Y-%m-%d'), 0) = YEARWEEK(NOW(), 0) AND notification_type='health_diary' AND patient_id=".$patient_id."");

                   

                    if(empty($already_send) && count($check_token) > 0)
                    {
                        //save notification for listing
                        $UserNotification = new UserNotification([                
                        'notification_id'   => $this->generateNUniqueNumber(),                                
                        'assignee_type'     => 4,                    
                        'patient_id'        => $patient_id, 
                        'notification_type' => "health_diary",
                        'change_type'       => "cron_health",
                        'created_date'      => strtotime('now'),
                        'status'            => 0                                          
                        ]);

                        $UserNotification->save();
                       
                        //send push notification
                        $device_token = $check_token[0]->device_token;
                        $path = base_path()."/ios_notifcation/health_reminder_notifications.php";
                        $msg = "Please add a new health diary";                        
                        $type = 'health_diary';
                        exec ('php '.$path.' '.base64_encode($msg).' '.$type.' '.$device_token.' > /dev/null &');                  
                    }                    
                }           
            }       
        }    
    }
   
     protected function generateNUniqueNumber() {
        $number = mt_rand(1000000000, 9999999999); // better than rand()
        // call the same function if the uniwue id exists already
        if ($this->uniqueNNumberExists($number)) {
            return $this->generateNUniqueNumber();
        }
        // otherwise, it's valid and can be used
        return strval($number);
    }

    protected function uniqueNNumberExists($number) {
        // query the database and return a boolean         
        return UserNotification::wherenotification_id($number)->exists();
    }

   

}
