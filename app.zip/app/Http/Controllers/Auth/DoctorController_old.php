<?php
namespace App\Http\Controllers\Auth;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Auth;
use Route;
use Cookie;
use Redirect;
use Session;
use GuzzleHttp\Client;
use App\User;
use Illuminate\Support\Facades\Validator;
use Illuminate\Foundation\Auth\RegistersUsers;
use App\Models\Doctor;
use App\Models\DoctorLoginToken;
use App\Models\SaveTelemedicalBookingDetail;


class DoctorController extends Controller
{
    public $successStatus = 200;

    public function __construct()
    {
      $this->middleware('guest:doctor', ['except' => ['logout']]);
    }

    //show doctor login form
    public function showDoctorLoginForm()
    {
        $user_login_email = "";
        $user_login_password = "";
        // check if details are there in cookies
        if (Cookie::get('email') !== false) {            
            $user_login_email = Cookie::get('email');        
        }
     
        if (Cookie::get('password') !== false) {            
            $user_login_password = Cookie::get('password');        
        }

        return view('doctor.login')->with(array('controller'=> 'doctor','email'=> $user_login_email,'password'=> $user_login_password));
    }
        
    protected function validator(array $data)
    {
        return Validator::make($data, [
            'p_first_name' => 'required|max:255',
            'p_last_name' => 'required|max:255',
            'email' => 'required|email|max:255|unique:patients',
            'p_phone' => 'required|max:10',
            'password' => 'required|min:6|confirmed',
        ]);
    }  

    //doctor login  
    public function login(Request $request)
    {
        $validator = Validator::make($_POST, [             
            'doctor_email' => 'required|email',                 
            'doctor_password' => 'required',               
        ]);
        if($validator->fails()){
            return response()->json(['success'=>0, 'message'=>$validator->messages()->first()], 200);
        }
        else{
            // set the remember me cookie if the user check the box
            $remember = false;
            if(isset($_POST['remember']) && $_POST['remember']==1)
            {
                $remember = ($_POST['remember'] == 1) ? true : false; 
                Cookie::queue('email',$_POST['doctor_email'], 5000);
                
                Cookie::queue('password',$_POST['doctor_password'], 5000);
            }
            if(isset($_POST['remember']) && $_POST['remember']==0)
            {
                Cookie::queue(  Cookie::forget('email'));
                Cookie::queue(  Cookie::forget('password'));
            }

            //attempt doctor login
            if(Auth::guard('doctor')->attempt(['doctor_email' => $_POST['doctor_email'], 'password' => $_POST['doctor_password']],$remember)){ 

                $user = Auth::guard('doctor')->user();  
                //if doctor is active
                if($user->active_status == 1){
                    $success['id'] =  $user->id; 
                    //creating token
                    $token = $user->createToken('MyApp')->accessToken;
                    $success['token'] =  $token;  
                    Session::put('doctor_token', $token);
                    //adding token in doctor login
                    DoctorLoginToken::where(array('doctor_id'=>$user->doctor_id))->update(array('token_status'=>0));
                    $DoctorLoginToken = new DoctorLoginToken([                
                        'doctor_id'    => $user->doctor_id,
                        'login_token'   => $token,                     
                        'token_status'  => "1",
                        'device_type'   => "2",                                           
                    ]);
                    $DoctorLoginToken->save();
                                    
                   return response()->json(['success'=>1,"redirect_url"=>route('doctor.dashboard')],200); 
                }else{
                    // logout if doctor is not active
                    Auth::guard('doctor')->logout();
                    return response()->json(['success'=>0,"message"=>"Your account has been suspended"],200); 
                }
            } 
            else{ 
                return response()->json(['success'=>0, 'message'=>'Please enter a valid email and password'], 200); 
            } 
        }    
    }

    //doctor forgot password
    public function forgotpassword(Request $request)
    {         
        $data=$_POST;
    
        $post_data = json_encode($data);  

         //using api function for forgot password   
        $curl = url('/')."/api/forgot_password";
        $response = $this->commoncurl($curl,$post_data);      
        
        //Authenticates patient
        if($response['success'] == 1){    
           return response()->json(['success'=>$response['success'],"message"=>$response['message']],200);
        }else{
            return response()->json(['success'=>$response['success'],"message"=>$response['message']],200);
        }
        
    }

    //recover password after user clicks on link in email
    public function recoverpassword($user_id,$fptoken)
    {        
        
        $user = Patient::where('patient_unique_id',$user_id)->where('fp_token',$fptoken)->first();
        if($user)
        {
            return view('patient/resetpassword')->with(array('controller'=> 'patient','FPtoken'=> $fptoken,'user_id'=> $user_id));
        }
        else
        {
            echo "This Link is not valid";
        }
    }

    //reset doctor password
    public function resetpasswordform()
    {
        $user = Patient::where('patient_unique_id',$_POST['user_id'])->where('fp_token',$_POST['fptoken'])->first();
        if($user)
        {           
            Patient::where('patient_unique_id',$_POST['user_id'])->update(['fp_token'=>'','patient_password'=>bcrypt($_POST['new_password'])]);
            return response()->json(['success'=>1,"message"=>"Password reset successfully.",'redirect'=>url('patient/login')],200);              
        }
        else
        {
            return response()->json(['success'=>0,"message"=>"This link has been expired."],200); 
        }
        
    }

    //doctor logout
    public function logout()
    {
        $user = Auth::guard('doctor')->user();
        DoctorLoginToken::where(array('doctor_id'=> $user['doctor_id'],'device_type'=>2))->update(array('token_status'=>0)); 
        SaveTelemedicalBookingDetail::where('doctor_id',$user['doctor_id'])->update(['call_status'=>0]);
        Auth::guard('doctor')->logout();
        return redirect('/doctor/login');
    } 

    //curl for different functions
    private function commoncurl($url,$post_data){
        $ch1 = curl_init();       
        curl_setopt($ch1, CURLOPT_URL,$url);
        curl_setopt($ch1, CURLOPT_HEADER, 0);
        curl_setopt($ch1, CURLOPT_POST, 1);
        curl_setopt($ch1, CURLOPT_POSTFIELDS, $post_data);  
        curl_setopt($ch1, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch1, CURLOPT_SSL_VERIFYPEER, 0);
        $output = curl_exec($ch1);     
        
        curl_close ($ch1);
        $output= json_decode($output,true);
        return $output;
    }   

    protected function guard()
    {
        return Auth::guard('doctor');
    }
}