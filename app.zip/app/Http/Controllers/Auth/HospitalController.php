<?php
namespace App\Http\Controllers\Auth;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Auth;
use Route;
use Cookie;
use Redirect;
use Session;
use GuzzleHttp\Client;
use App\User;
use Illuminate\Support\Facades\Validator;
use Illuminate\Foundation\Auth\RegistersUsers;
use App\Models\Hospital;
use App\Models\HospitalLoginToken;
use App\Models\Administrator;

class HospitalController extends Controller
{
    public $successStatus = 200;

    public function __construct()
    {
      $this->middleware('guest:administrator', ['except' => ['logout']]);
    }
    public function showHospitalLoginForm()
    {
        $user_login_email = "";
        $user_login_password = "";

        if (Cookie::get('hospital_email') !== false) {
            
            $user_login_email = Cookie::get('hospital_email');
        
        }
     
        if (Cookie::get('hospital_password') !== false) {
            
            $user_login_password = Cookie::get('hospital_password');
        
        }
        return view('hospital.login')->with(array('controller'=> 'hospital','email'=> $user_login_email,'password'=> $user_login_password));
    }        
        
    public function login(Request $request)
    {
        $validator = Validator::make($_POST, [             
            'hospital_email' => 'required|email',                 
            'hospital_password' => 'required',               
        ]);
        if($validator->fails()){
            return response()->json(['success'=>0, 'message'=>$validator->messages()->first()], 200);
        }
        else{
            // set the remember me cookie if the user check the box
            $remember = false;
            if(isset($_POST['remember']) && $_POST['remember']==1)
            {
                $remember = ($_POST['remember'] == 1) ? true : false; 
                Cookie::queue('hospital_email',$_POST['hospital_email'], 5000);
                
                Cookie::queue('hospital_password',$_POST['hospital_password'], 5000);
            }
            if(isset($_POST['remember']) && $_POST['remember']==0)
            {
                Cookie::queue(  Cookie::forget('hospital_email'));
                Cookie::queue(  Cookie::forget('hospital_password'));
            }

            if(Auth::guard('hospital')->attempt(['hosp_email' => $_POST['hospital_email'], 'password' => $_POST['hospital_password']],$remember)){
                $user = Auth::guard('hospital')->user();

               // echo "1";  
                //dd($user); die;

                $success['id'] =  $user->id; 
                $token = $user->createToken('MyApp')->accessToken;
                $success['token'] =  $token;  
                Session::put('hospital_token', $token);
                HospitalLoginToken::where(array('hosp_id'=>$user->hospital_id))->update(array('token_status'=>0));
                $hospital_id = new HospitalLoginToken([                
                    'hosp_id'    => $user->hosp_id,
                    'login_token'   => $token,                     
                    'token_status'  => "1",
                    'device_type'   => "2",                                           
                ]);
                $hospital_id->save(); 
                                
               return response()->json(['success'=>1,"redirect_url"=>route('hospital.dashboard')],200); 
            } else if(Auth::guard('administrator')->attempt(['administrator_email' => $_POST['hospital_email'], 'password' => $_POST['hospital_password']],$remember)){ 
                //echo '2';   

                $user = Auth::guard('administrator')->user();  

                $success['id'] =  $user->id; 
                $token = $user->createToken('MyApp')->accessToken;
                $success['token'] =  $token;  
                Session::put('hospital_token', $token);
               /* HospitalLoginToken::where(array('hosp_id'=>$user->hospital_id))->update(array('token_status'=>0));
                $hospital_id = new HospitalLoginToken([                
                    'hosp_id'    => $user->hosp_id,
                    'login_token'   => $token,                     
                    'token_status'  => "1",
                    'device_type'   => "2",                                           
                ]);
                $hospital_id->save(); */
                                
               return response()->json(['success'=>1,"redirect_url"=>route('hospital.dashboard')],200); 
            }
            else{ 
                //echo '3s'; 
                return response()->json(['success'=>0, 'message'=>'Please enter a valid emails and password'], 200); 
            } 
        } 

    }

    public function forgotpassword(Request $request)
    {
     
      /* $validate= $this->validator($request->all())->validate();*/
         $data=$_POST;
        //echo "<pre>"; print_r($data); exit;
         $post_data = json_encode($data);     
         $curl = url('/')."/api/forgot_password";    

         $response = $this->commoncurl($curl,$post_data);      
        
        //Authenticates patient

        if($response['success'] == 1){    
           return response()->json(['success'=>$response['success'],"message"=>$response['message']],200);
        }else{
            return response()->json(['success'=>$response['success'],"message"=>$response['message']],200);
        }
        
    }

    public function recoverpassword($user_id,$fptoken)
    {        
        
        $user = Patient::where('patient_unique_id',$user_id)->where('fp_token',$fptoken)->first();
        if($user)
        {
            return view('patient/resetpassword')->with(array('controller'=> 'patient','FPtoken'=> $fptoken,'user_id'=> $user_id));
        }
        else
        {
            echo "This Link is not valid";
        }
    }

    public function resetpasswordform()
    {
        $user = Patient::where('patient_unique_id',$_POST['user_id'])->where('fp_token',$_POST['fptoken'])->first();
        if($user)
        {
           
            Patient::where('patient_unique_id',$_POST['user_id'])->update(['fp_token'=>'','patient_password'=>bcrypt($_POST['new_password'])]);

            return response()->json(['success'=>1,"message"=>"Password reset successfully.",'redirect'=>url('patient/login')],200);           
            
        }
        else
        {
            return response()->json(['success'=>0,"message"=>"This link has been expired."],200); 
        }
        
    }

    public function logout()
    {
        $user = Auth::guard('administrator')->user();
        HospitalLoginToken::where(array('hosp_id'=> $user['hospital_id'],'device_type'=>2))->update(array('token_status'=>0)); 
        Auth::guard('administrator')->logout();
        return redirect('/hospital/login');
    } 

    private function commoncurl($url,$post_data){
    $ch1 = curl_init();       
    curl_setopt($ch1, CURLOPT_URL,$url);
    curl_setopt($ch1, CURLOPT_HEADER, 0);
    curl_setopt($ch1, CURLOPT_POST, 1);
    curl_setopt($ch1, CURLOPT_POSTFIELDS, $post_data);  
    curl_setopt($ch1, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch1, CURLOPT_SSL_VERIFYPEER, 0);
    $output = curl_exec($ch1);     
    
    curl_close ($ch1);
    $output= json_decode($output,true);
    return $output;
  }   

    protected function guard()
    {
        return Auth::guard('administrator');
    }

    
}