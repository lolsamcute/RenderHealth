<?php
namespace App\Http\Controllers\Auth;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Auth;
use Route;
use Cookie;
use Redirect;
use Session;
use GuzzleHttp\Client;
use App\User;
use Illuminate\Support\Facades\Validator;
use Illuminate\Foundation\Auth\RegistersUsers;
use App\Models\Admin;
use App\Models\AdminLoginToken;


class AdminLoginController extends Controller
{
    public $successStatus = 200;

    public function __construct()
    {
      $this->middleware('guest:admin', ['except' => ['logout']]);
    }

    //show admin login form
    public function showAdminLoginForm()
    {

        $user_login_email = "";
        $user_login_password = "";
        //check if login details are saved in cookies
        if (Cookie::get('email') !== false) {            
            $user_login_email = Cookie::get('email');        
        }
     
        if (Cookie::get('password') !== false) {            
            $user_login_password = Cookie::get('password');        
        }   

        return view('admin.login')->with(array('controller'=> 'admin','email'=> $user_login_email,'password'=> $user_login_password));
    }
    
    //admin login
    public function login(Request $request)
    {
        $validator = Validator::make($_POST, [             
            'email' => 'required|email',                 
            'password' => 'required',               
        ]);
        if($validator->fails()){
            return response()->json(['success'=>0, 'message'=>$validator->messages()->first()], 200);
        }
        else{
            // set the remember me cookie if the user check the box
            $remember = false;
            if(isset($_POST['remember']) && $_POST['remember']==1)
            {
                $remember = ($_POST['remember'] == 1) ? true : false; 
                Cookie::queue('email',$_POST['email'], 5000);
                
                Cookie::queue('password',$_POST['email'], 5000);
            }
            if(isset($_POST['remember']) && $_POST['remember']==0)
            {
                Cookie::queue(  Cookie::forget('email'));
                Cookie::queue(  Cookie::forget('password'));
            }
            // attempting login
            if(Auth::guard('admin')->attempt(['email' => $_POST['email'], 'password' => $_POST['password']],$remember)){
                $user = Auth::guard('admin')->user();  
                $success['id'] =  $user->id; 
                $token = $user->createToken('MyApp')->accessToken;
                $success['token'] =  $token;  
                Session::put('admin_token', $token);
               // AdminLoginToken::where(array('admin_id'=>$user->id))->update(array('token_status'=>0));

                //insert token in admin login token table
                $AdminLoginToken = new AdminLoginToken([                
                    'admin_id'    => $user->id,
                    'login_token'   => $token,                     
                    'token_status'  => "1",
                    'device_type'   => "2",                                           
                ]);
                $AdminLoginToken->save(); 
                                
               return response()->json(['success'=>1,"redirect_url"=>route('admin.dashboard')],200); 
            } 
            else{ 
                return response()->json(['success'=>0, 'message'=>'Please enter a valid email and password'], 200); 
            } 
        }    
    }

  
    //admin logout
    public function logout()
    {
        $user = Auth::guard('admin')->user();
        Auth::guard('admin')->logout();
        return redirect('/admin/login');
    } 

      

    protected function guard()
    {
        return Auth::guard('admin');
    }
}