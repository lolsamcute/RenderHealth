<?php
namespace App\Http\Controllers\Auth;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Auth;
use Route;
use Cookie;
use Redirect;
use Session;
use GuzzleHttp\Client;
use App\User;
use Illuminate\Support\Facades\Validator;
use Illuminate\Foundation\Auth\RegistersUsers;
use App\Models\Employee;
use App\Models\EmployeeLoginToken;

class EmployeeController extends Controller
{
    public $successStatus = 200;

    public function __construct()
    {
      $this->middleware('guest:employee', ['except' => ['logout']]);
    }
    public function showEmployeeLoginForm()
    {
        $user_login_email = "";
        $user_login_password = "";

        if (Cookie::get('employee_email') !== false) {
            
            $user_login_email = Cookie::get('employee_email');
        
        }
     
        if (Cookie::get('employee_password') !== false) {
            
            $user_login_password = Cookie::get('employee_password');
        
        }
        return view('employee.login')->with(array('controller'=> 'employee','email'=> $user_login_email,'password'=> $user_login_password));
    }        
        
    public function login(Request $request)
    {
        $validator = Validator::make($_POST, [             
            'employee_email' => 'required|email',                 
            'employee_password' => 'required',               
        ]);
        if($validator->fails()){
            return response()->json(['success'=>0, 'message'=>$validator->messages()->first()], 200);
        }
        else{
            // set the remember me cookie if the user check the box
            $remember = false;
            if(isset($_POST['remember']) && $_POST['remember']==1)
            {
                $remember = ($_POST['remember'] == 1) ? true : false; 
                Cookie::queue('employee_email',$_POST['employee_email'], 5000);
                
                Cookie::queue('employee_password',$_POST['employee_password'], 5000);
            }
            if(isset($_POST['remember']) && $_POST['remember']==0)
            {
                Cookie::queue(  Cookie::forget('employee_email'));
                Cookie::queue(  Cookie::forget('employee_password'));
            }
            if(Auth::guard('employee')->attempt(['employee_email' => $_POST['employee_email'], 'password' => $_POST['employee_password']],$remember)){ 

                $user = Auth::guard('employee')->user();  

                $success['id'] =  $user->id; 
                $token = $user->createToken('MyApp')->accessToken;
                $success['token'] =  $token;  
                Session::put('employee_token', $token);
                EmployeeLoginToken::where(array('employee_id'=>$user->employee_id))->update(array('token_status'=>0));
                $EmployeeLoginToken = new EmployeeLoginToken([                
                    'doctor_id'    => $user->employee_id,
                    'login_token'   => $token,                     
                    'token_status'  => "1",
                    'device_type'   => "2",                                           
                ]);
                $EmployeeLoginToken->save(); 
                                
               return response()->json(['success'=>1,"redirect_url"=>route('employee.dashboard')],200); 
            } 
            else{ 
                return response()->json(['success'=>0, 'message'=>'Please enter a valid email and password'], 200); 
            } 
        }    
    }

    public function forgotpassword(Request $request)
    {
     
      /* $validate= $this->validator($request->all())->validate();*/
         $data=$_POST;
        //echo "<pre>"; print_r($data); exit;
         $post_data = json_encode($data);     
         $curl = url('/')."/api/forgot_password";    

         $response = $this->commoncurl($curl,$post_data);      
        
        //Authenticates patient

        if($response['success'] == 1){    
           return response()->json(['success'=>$response['success'],"message"=>$response['message']],200);
        }else{
            return response()->json(['success'=>$response['success'],"message"=>$response['message']],200);
        }
        
    }

    public function recoverpassword($user_id,$fptoken)
    {        
        
        $user = Patient::where('patient_unique_id',$user_id)->where('fp_token',$fptoken)->first();
        if($user)
        {
            return view('patient/resetpassword')->with(array('controller'=> 'patient','FPtoken'=> $fptoken,'user_id'=> $user_id));
        }
        else
        {
            echo "This Link is not valid";
        }
    }

    public function resetpasswordform()
    {
        $user = Patient::where('patient_unique_id',$_POST['user_id'])->where('fp_token',$_POST['fptoken'])->first();
        if($user)
        {
           
            Patient::where('patient_unique_id',$_POST['user_id'])->update(['fp_token'=>'','patient_password'=>bcrypt($_POST['new_password'])]);

            return response()->json(['success'=>1,"message"=>"Password reset successfully.",'redirect'=>url('patient/login')],200);           
            
        }
        else
        {
            return response()->json(['success'=>0,"message"=>"This link has been expired."],200); 
        }
        
    }

    public function logout()
    {
        $user = Auth::guard('employee')->user();
        EmployeeLoginToken::where(array('employee_id'=> $user['employee_id'],'device_type'=>2))->update(array('token_status'=>0)); 
        Auth::guard('employee')->logout();
        return redirect('/employee/login');
    } 

    private function commoncurl($url,$post_data){
    $ch1 = curl_init();       
    curl_setopt($ch1, CURLOPT_URL,$url);
    curl_setopt($ch1, CURLOPT_HEADER, 0);
    curl_setopt($ch1, CURLOPT_POST, 1);
    curl_setopt($ch1, CURLOPT_POSTFIELDS, $post_data);  
    curl_setopt($ch1, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch1, CURLOPT_SSL_VERIFYPEER, 0);
    $output = curl_exec($ch1);     
    
    curl_close ($ch1);
    $output= json_decode($output,true);
    return $output;
  }   

    protected function guard()
    {
        return Auth::guard('employee');
    }
}