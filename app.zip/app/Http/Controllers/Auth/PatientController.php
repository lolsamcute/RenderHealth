<?php
namespace App\Http\Controllers\Auth;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use DB;
use Auth;
use Route;
use Cookie;
use Session;
use DateTime;
use DateTimeZone;
/*use GuzzleHttp\Client;*/
use App\User;
use Illuminate\Support\Facades\Validator;
use Illuminate\Foundation\Auth\RegistersUsers;
use App\Models\Patient;
use App\Models\PatientLoginToken;
use App\Models\PaidBillingDetail;
use App\Models\PaymentErrorLog;
use App\Models\BillingDetail;
use App\Models\UserNotification;
use App\Models\SaveTelemedicalBookingDetail;
use App\Models\DoctorAvailability;
use Mail;
use Twilio\Rest\Client;

class PatientController extends Controller
{
    public $successStatus = 200;

    public function __construct()
    {
      $this->middleware('guest:patient', ['except' => ['logout','saveTranDetails','freeDoctorAppt']]);
    }

    //show patient login form
    public function showLoginForm()
    {
        $user_login_email = "";
        $user_login_password = "";

        //check cookies
        if (Cookie::get('email') !== false) {            
            $user_login_email = Cookie::get('email');        
        }
     
        if (Cookie::get('password') !== false) {            
            $user_login_password = Cookie::get('password');        
        }

        return view('patient.login')->with(array('controller'=> 'patient','email'=> $user_login_email,'password'=> $user_login_password));
    }

    //show register form
    public function showRegisterForm()
    {
      return view('patient.signup')->with(array('controller'=> 'patient'));   
    }

    //register patient
    public function register(Request $request)
    {
     
      /* $validate= $this->validator($request->all())->validate();*/
         $data=$_POST;
         $timezone_name = timezone_name_from_abbr("", $data['timezone']*60, false);    
         $data['timezone'] = $timezone_name;    
         $data['device_type'] = 2;
         $date = $data['day'];
        $month =$data['month'];
        $month = date('m',strtotime($month));
        $year = $data['years'];
        $patient_dob = $year.'-'.$month.'-'.$date;
        $data['patient_date_of_birth']= strtotime($patient_dob); 
      // echo "<pre>"; print_r($data); exit;
         $post_data = json_encode($data);     
         $curl = url('/')."/api/patient_signup";    

         $response = $this->commoncurl($curl,$post_data);      
         
        //Authenticates patient
        if($response['success'] == 1){                  
            if (Auth::guard('patient')->attempt(['patient_email' => $_POST['patient_email'], 'password' => $_POST['patient_password']])) { 
                Session::put('token', $response['data']['token']);  
                 $send_email_from = $_ENV['send_email_from'];
                $get_email = Patient::select('patient_first_name','patient_middle_name','patient_last_name','patient_email')->where('patient_unique_id',$response['data']['patient_unique_id'])->get();
                $data = array('name'=>$get_email[0]->patient_first_name,'email'=>$get_email[0]->patient_email,'password'=>$_POST['patient_password'],"type"=>"patient");    
                $email =$get_email[0]->patient_email;
                $res = Mail::send('patient.signupemail', $data, function ($message) use ($email,$send_email_from)  {
                $message->to($email)->subject('Account Registration');
                $message->from($send_email_from,'Render Health');              
                });

                // Send message on phone               
                $message=$this->registrationmessage($response['data']['patient_unique_id']);
           
                $this->sendMessage($message,'+918699499852');

                                         
                return response()->json(['success'=>1,"redirect_url"=>route('patient.dashboard')],200);
            }
        }else{
            return response()->json(['success'=>0,"message"=>$response['message']],200);
        }
        
    }
    protected function validator(array $data)
    {
        return Validator::make($data, [
            'p_first_name' => 'required|max:255',
            'p_last_name' => 'required|max:255',
            'email' => 'required|email|max:255|unique:patients',
            'p_phone' => 'required|max:15',
            'password' => 'required|min:6|confirmed',
        ]);
    }

    //Create a new patient instance after a validation.
    protected function create(array $data)
    {
        return Patient::create([
            'patient_first_name' => $data['p_first_name'],
            'patient_last_name' => $data['p_last_name'],
            'patient_email' => $data['email'],
            'patient_phone' => $data['p_phone'],
            'patient_password' => bcrypt($data['password']),
        ]);
    }    

    //patient login
    public function login(Request $request)
    {
        $validator = Validator::make($_POST, [             
            'patient_email' => 'required|email',                 
            'patient_password' => 'required',               
        ]);
        if($validator->fails()){
            return response()->json(['success'=>0, 'message'=>$validator->messages()->first()], 200);
        }
        else{

            // set the remember me cookie if the user check the box
            $remember = ($_POST['remember'] == 1) ? true : false;
            if(isset($_POST['remember']) && $_POST['remember']==1)
            {                 
                Cookie::queue('email',$_POST['patient_email'], 5000);                
                Cookie::queue('password',$_POST['patient_password'], 5000);
            }

            if(isset($_POST['remember']) && $_POST['remember']==0)
            {
                Cookie::queue(Cookie::forget('email'));
                Cookie::queue(Cookie::forget('password'));
            }

            //attempting patient login
            if(Auth::guard('patient')->attempt(['patient_email' => $_POST['patient_email'], 'password' => $_POST['patient_password']],$remember)){ 
                $user = Auth::guard('patient')->user();                 
                $success['id'] =  $user->id; 
                //creating token
                $token = $user->createToken('MyApp')->accessToken;
                $success['token'] =  $token; 
                Session::put('token', $token);

                //patient login token 
                PatientLoginToken::where(array('patient_id'=>$user->patient_unique_id))->update(array('token_status'=>0));
                $PatientLoginToken = new PatientLoginToken([                
                    'patient_id'    => $user->patient_unique_id,
                    'login_token'   => $token,                     
                    'token_status'  => "1",
                    'device_type'   => "2",                                           
                ]);
                $PatientLoginToken->save();           
                $success['patient_email'] =  $user->patient_email; 
                $success['patient_first_name'] =  $user->patient_first_name; 
                $success['patient_phone'] =  $user->patient_phone; 
                $success['patient_unique_id'] =  (string)$user->patient_unique_id;                 
                return response()->json(['success'=>1,"redirect_url"=>route('patient.dashboard')],200); 
            } 
            else{ 
                return response()->json(['success'=>0, 'message'=>'Please enter a valid email and password'], 200); 
            } 
        }    
    }

    //forgot password
    public function forgotpassword(Request $request)
    {         
         $data=$_POST;

         //sending curl request        
         $post_data = json_encode($data);     
         $curl = url('/')."/api/forgot_password";    

         $response = $this->commoncurl($curl,$post_data);      
        
        //Authenticates patient

        if($response['success'] == 1){    
           return response()->json(['success'=>$response['success'],"message"=>$response['message']],200);
        }else{
            return response()->json(['success'=>$response['success'],"message"=>$response['message']],200);
        }
        
    }

    //recover password
    public function recoverpassword($user_id,$fptoken)
    {        
        
        $user = Patient::where('patient_unique_id',$user_id)->where('fp_token',$fptoken)->first();
        if($user)
        {
            return view('patient/resetpassword')->with(array('controller'=> 'patient','FPtoken'=> $fptoken,'user_id'=> $user_id));
        }
        else
        {
            echo "This Link is not valid";
        }
    }

    //reset password
    public function resetpasswordform()
    {
        $user = Patient::where('patient_unique_id',$_POST['user_id'])->where('fp_token',$_POST['fptoken'])->first();
        if($user)
        {           
            Patient::where('patient_unique_id',$_POST['user_id'])->update(['fp_token'=>'','patient_password'=>bcrypt($_POST['new_password'])]);
            return response()->json(['success'=>1,"message"=>"Password reset successfully.",'redirect'=>url('patient/login')],200);             
        }
        else
        {
            return response()->json(['success'=>0,"message"=>"This link has been expired."],200); 
        }
        
    }

    //patient logout
    public function logout()
    {
        $user = Auth::guard('patient')->user();
        PatientLoginToken::where(array('patient_id'=> $user['patient_unique_id'],'device_type'=>2))->update(array('token_status'=>0)); 
        //disconnect call if it is going on
        SaveTelemedicalBookingDetail::where('patient_id',$user['patient_unique_id'])->update(['call_status'=>0]);
        Auth::guard('patient')->logout();
        return redirect('/patient/login');
    } 

    //save payment details
    public function saveTranDetails(Request $header_request){
        try{
            
            $result = array();
            //Set other parameters as keys in the $postdata array
            $url = "https://api.paystack.co/transaction/verify/".$_GET['reference'];

            $ch = curl_init();
            curl_setopt($ch, CURLOPT_URL, $url);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
            curl_setopt(
              $ch, CURLOPT_HTTPHEADER, [
                'Authorization: Bearer sk_test_858ee66cc3ec342738a20e52d4f1842942cee9a3']
            );
            $request = curl_exec($ch);
            $err = curl_error($ch);
            
            if($err){                   
                $err_res = json_decode($err,true);

                //payment error log
                $PaymentErrorLog = new PaymentErrorLog([
                    'transaction_id'    => $_GET['reference'],
                    'billing_id'        => NULL,
                    'patient_id'        => NULL,
                    'doctor_id'         => NULL,
                    'error_msg'         => $err,                        
                    'created_date'      => strtotime("now")                                     
                ]); 

                $PaymentErrorLog->save();  

                return view('patient.payment_msg')->with(array('controller'=> 'patient','message'=> $err_res['message']));             
            }
            curl_close($ch);

            if ($request){
                $result = json_decode($request,true);
                if(isset($result['data'])){      
                    //update timezone               
                    $dtz = new DateTimeZone($result['data']['metadata']['time_zone']);     
                    $date = date('Y-m-d H:i:s',strtotime("now"));                           
                    $time_in_sofia = new DateTime($date, $dtz);        
                    $date_offset = $time_in_sofia->format('Z');       
                    $billing_time = strtotime($date);
                    $result = json_decode($request, true);

                    //adding payment detail in billing table
                    $PayBilling = new PaidBillingDetail([
                        'transaction_id'    => $result['data']['reference'],
                        'billing_id'        => $result['data']['metadata']['billing_id'],
                        'patient_id'        => $result['data']['metadata']['patient_id'],
                        'doctor_id'         => NULL,                        
                        'created_date'      => $billing_time                                        
                    ]); 

                    $PayBilling->save();

                    //updating amount
                    $amt = $result['data']['amount']/100;
                    $update_amt = BillingDetail::where('billing_id',$result['data']['metadata']['billing_id'])->update(['paid_amount'=> DB::raw('paid_amount + '.$amt),'paid_date'=>$billing_time]);

                    //user notification
                    $UserNotification = new UserNotification([                
                      'notification_id'   => $this->generateNUniqueNumber(),              
                      'assignee_type'     => 4,                    
                      'patient_id'        => $result['data']['metadata']['patient_id'], 
                      'event_id'          => $result['data']['metadata']['billing_id'],
                      'notification_type' => "bill",
                      'change_type'       => "paid",
                      'created_date'      => $billing_time,
                      'status'            => 0                                          
                    ]);
                    $UserNotification->save();                 

                  
                    $login_token = PatientLoginToken::where('patient_id',$result['data']['metadata']['patient_id'])->where('token_status',1)->get();
                    //echo "<pre>"; print_R($login_token); exit;
                    
                    //sending push notifications
                    if(count($login_token) > 0 && $login_token[0]->device_type != 2){            
                        $device_token = $login_token[0]->device_token;
                        $path = "/var/www/html/projects/renderhealth/ios_notifcation/payment_notifications.php";     
                        exec ('php '.$path.' '.$device_token.' > /dev/null &');
                    }

                    if(count($login_token) > 0 && $login_token[0]->device_type != 2){            
                        $device_token = $login_token[0]->device_token;
                        $path = "/var/www/html/projects/renderhealth/ios_notifcation/all_notifications.php";
                        $msg = "You paid a bill";                
                        $nid = $result['data']['metadata']['billing_id'];
                        $type= 'bill';
                        exec ('php '.$path.' "'.$msg.'" '.$nid.' '.$type.' '.$device_token.' > /dev/null &');
                    }

                    
                    return view('patient.payment_msg')->with(array('controller'=> 'patient','message'=> 'Bill paid successfully'));  
                   
                }else{
                    $PaymentErrorLog = new PaymentErrorLog([
                        'transaction_id'    => $_GET['reference'],
                        'billing_id'        => NULL,
                        'patient_id'        => NULL,
                        'doctor_id'         => NULL,
                        'error_msg'         => $request,                        
                        'created_date'      => strtotime("now")                                     
                    ]); 

                    $PaymentErrorLog->save();                       

                    return view('patient.payment_msg')->with(array('controller'=> 'patient','message'=> $err_res['message']));
                }
            }
        }catch(\Exception $e){
            return view('patient.payment_msg')->with(array('controller'=> 'patient','message'=> $e->getMessage()));            
        }

    }

    //updating doctor availability after 30 mins
    public function freeDoctorAppt(){
        date_default_timezone_set('UTC');           
        $fromDate = strtotime("-01 minutes", strtotime('now'));
        $toDate = strtotime("+01 minutes", strtotime('now'));  
        $fromThiryDate = strtotime("-31 minutes", strtotime('now'));
        $toThiryDate = strtotime("-29 minutes", strtotime('now'));  
        //SaveTelemedicalBookingDetail::where('appointment_time','<',$fromDate)->update(['approved_status'=> 2]); 
       
        DoctorAvailability::whereNotIn('doctor_id',function($query) use($fromDate,$toDate,$fromThiryDate,$toThiryDate) { $query->select('doctor_id')->from('save_telemedical_booking_detail')->where(function ($q) use($fromDate,$toDate) {$q->where('appointment_time', '>=', $fromDate)->where('appointment_time', '<=', $toDate);})->orWhere(function ($q1) use($fromThiryDate,$toThiryDate) {$q1->where('appointment_time', '>=', $fromThiryDate)->where('appointment_time', '<=', $toThiryDate);});})->update(['booking_status'=> 0]);

        DoctorAvailability::whereIn('doctor_id',function($query) use($fromDate,$toDate,$fromThiryDate,$toThiryDate) { $query->select('doctor_id')->from('save_telemedical_booking_detail')->where(function ($q) use($fromDate,$toDate) {$q->where('appointment_time', '>=', $fromDate)->where('appointment_time', '<=', $toDate);})->orWhere(function ($q1) use($fromThiryDate,$toThiryDate) {$q1->where('appointment_time', '>=', $fromThiryDate)->where('appointment_time', '<=', $toThiryDate);});})->update(['booking_status'=> 1]);
        
   }
    

    private function commoncurl($url,$post_data){
    $ch1 = curl_init();       
    curl_setopt($ch1, CURLOPT_URL,$url);
    curl_setopt($ch1, CURLOPT_HEADER, 0);
    curl_setopt($ch1, CURLOPT_POST, 1);
    curl_setopt($ch1, CURLOPT_POSTFIELDS, $post_data);  
    curl_setopt($ch1, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch1, CURLOPT_SSL_VERIFYPEER, 0);
    $output = curl_exec($ch1);     
    //echo "<pre>"; print_R($output); exit;
    curl_close ($ch1);
    $output= json_decode($output,true);
    return $output;
  }   

    protected function generateNUniqueNumber() {
        $number = mt_rand(1000000000, 9999999999); // better than rand()
        // call the same function if the uniwue id exists already
        if ($this->uniqueNNumberExists($number)) {
            return $this->generateNUniqueNumber();
        }
        // otherwise, it's valid and can be used
        return strval($number);
    }

    protected function uniqueNNumberExists($number) {
        // query the database and return a boolean         
        return UserNotification::wherenotification_id($number)->exists();
    }
    protected function guard()
    {
        return Auth::guard('patient');
    }

     // Send messsage to user
      private function sendMessage($message, $recipients)
        {
        $account_sid = getenv("TWILIO_SID");
        $auth_token = getenv("TWILIO_AUTH_TOKEN");
        $twilio_number = getenv("TWILIO_NUMBER");
        $client = new Client($account_sid, $auth_token);

       /* $validation_request = $client->validationRequests
        ->create($recipients, // phoneNumber
        array(
        "friendlyName" => "Newuser"
        )
        );
        print($validation_request);
        if(!empty($validation_request->friendlyName)){*/
        $client->messages->create($recipients, ['from' => $twilio_number, 'body' => $message]);
  // }
       return 1;
    }
    protected function registrationmessage($patient_id){
        $message="";
        $get_email = Patient::select('patient_first_name','patient_middle_name','patient_last_name','patient_email')->where('patient_unique_id',$patient_id)->get();

        if(!empty($get_email)){
        $message="Thank you for registering with Render Health \n";
        $message.= "Here are your details:\n";
        $message.= "Email: ".$get_email[0]->patient_email."\n";
        $message.= "Password: as chosen by you at the time of registration \n";
        $message.= "For any queries you can contact us at: contact@renderhealth.com \n";
        return $message;
    }
    }
}