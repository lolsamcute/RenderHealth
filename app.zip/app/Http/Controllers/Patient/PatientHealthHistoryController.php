<?php
namespace App\Http\Controllers\Patient;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Auth;
use DB;
use Validator;
use DateTime;
use DateTimeZone;
use Session;
use File;
use App\Models\PatientLoginToken;
use App\Models\Patient;
use App\Models\Hospital;
use App\Models\Doctor;
use App\Models\SaveTelemedicalBookingDetail;
use App\Models\PatientAppointment;
use App\Models\SpecialistCategories;
use App\Models\PatientHealthDiary;
use App\Models\PatientDiaryAttachment;
use App\Models\HealthHistory;

class PatientHealthHistoryController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth:patient');
        //date_default_timezone_set("Asia/Kolkata");
    }
    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */

    /******
    Health history listing
    *******/
    public function index(Request $request,$month = null,$spe = null,$hosp=null)
    {
        try{
            $value = Session::get('token');
            $patient_id = Auth::user()->patient_unique_id;
            $login_token =PatientLoginToken::where(array('patient_id'=>$patient_id,'login_token'=>$value))->first();        
            if(isset($login_token->token_status) && $login_token->token_status == 0){ 
                Auth::guard('patient')->logout();  
                 if($request->ajax()){         
                    return response()->json(['redirect'=>1,"redirect_url"=>asset('/patient/login')],200);
                }else{         
                    return redirect('/patient/login');
                }
            }
            if(!Auth::check()){   
                 if($request->ajax()){         
                    return response()->json(['redirect'=>1,"redirect_url"=>asset('/patient/login')],200);
                }else{         
                    return redirect('/patient/login');
                }
            }
            $user = $request->user();
            $time_zone = $user->timezone;
            $dtz = new DateTimeZone($user->timezone);
            if(!empty($month)){
                $date = date('Y-m-d',strtotime($month));  
            }else{
                $month = date("Y-m-01 00:00:00",strtotime('now'));
            }
            $date = date('Y-m-d',strtotime($month));   
            $next_date = date('Y-m-t', strtotime($date));
            $time_in_sofia = new DateTime($date, $dtz);        
            $date_offset = $time_in_sofia->format('Z');       
            $start_time = strtotime($date)-$date_offset;                        
            $end_time = strtotime($next_date)-$date_offset;
            if($spe != ""){    
                $spe = json_decode($spe,true);
            }  
            if(($spe != "" && count($spe) > 0) && $hosp != 0){ 
                $health_history=HealthHistory::with(array('patient','doctor','history_attachments','doctor.specialist_categories','doctor.doctor_hospital_details'))->where('patient_id',$patient_id)->where('created_date','>=',$start_time)->where('created_date','<=',$end_time)->whereHas('doctor', function($q) use($spe) {$q->whereIn('doctor_speciality',$spe);})->where('hospital_id','=',$hosp)->orderBy('created_date','DESC')->paginate(20);
            }else if(($spe != "" && count($spe) > 0) && $hosp == 0){  
                $health_history=HealthHistory::with(array('patient','doctor','history_attachments','doctor.specialist_categories','doctor.doctor_hospital_details'))->where('patient_id',$patient_id)->where('created_date','>=',$start_time)->where('created_date','<=',$end_time)->whereHas('doctor', function($q) use($spe) {$q->whereIn('doctor_speciality',$spe);})->orderBy('created_date','DESC')->paginate(20);                                
            }else if(($spe != "" && count($spe) == 0) && $hosp != 0){   
                $health_history=HealthHistory::with(array('patient','doctor','history_attachments','doctor.specialist_categories','doctor.doctor_hospital_details'))->where('patient_id',$patient_id)->where('created_date','>=',$start_time)->where('created_date','<=',$end_time)->where('hospital_id','=',$hosp)->orderBy('created_date','DESC')->paginate(20);                
            }else{        
               $health_history=HealthHistory::with(array('patient','doctor','history_attachments','doctor.specialist_categories','doctor.doctor_hospital_details'))->where('patient_id',$patient_id)->where('created_date','>=',$start_time)->where('created_date','<=',$end_time)->orderBy('created_date','DESC')->paginate(20);                
            }            

            $start_date = HealthHistory::select('created_date')->where('patient_id',$patient_id)->orderBy('created_date','ASC')->first();
            $speciality_detail = SpecialistCategories::select('*')->where('type_of_user', '=' ,1)->get();
            $hospitals = Hospital::get();

             if($request->ajax()){
                return view('patient.health_history_inner')->with(array('controller'=> 'pages','user'=>$user,'page'=>'dashboard','page_type'=>'health_history','health_history'=>$health_history,'start_date'=>$start_date,'time_zone'=>$time_zone,'speciality_detail'=>$speciality_detail));
            }else{
                return view('patient.health_history_list')->with(array('controller'=> 'pages','user'=>$user,'page'=>'dashboard','page_type'=>'health_history','health_history'=>$health_history,'start_date'=>$start_date,'time_zone'=>$time_zone,'hospitals'=>$hospitals,'speciality_detail'=>$speciality_detail));
            }

        }catch(Exception $e) {
            if($request->ajax()){
                return response()->json(['error'=>1,"message"=>$e->getMessage()],200);
            }else{
                echo 'Message: ' .$e->getMessage(); 
            }
        }
    }

    /******
    Health history detail
    *******/
    public function historyDetail(Request $request,$id)
    {
        try{
            $value = Session::get('token');
            $patient_id = Auth::user()->patient_unique_id;
            $login_token =PatientLoginToken::where(array('patient_id'=>$patient_id,'login_token'=>$value))->first();        
            if(isset($login_token->token_status) && $login_token->token_status == 0){ 
                Auth::guard('patient')->logout();  
                return redirect('/patient/login');
            }
            if(!Auth::check()){   
                return redirect('/patient/login');
            }
            $user = $request->user();
            $time_zone = $user->timezone;
            $health_history=HealthHistory::with(array('patient','doctor','history_attachments','doctor.specialist_categories','doctor.doctor_hospital_details'))->where('history_id',$id)->first();             

             return view('patient.health_history_detail')->with(array('controller'=> 'pages','user'=>$user,'page'=>'history','page_type'=>'health_history','health_history'=>$health_history,'time_zone'=>$time_zone));

        }catch(Exception $e) {
            echo 'Message: ' .$e->getMessage(); 
        }
    }

    /******
    Monthly Health history listing
    *******/

     public function monthlyHealthHistory(Request $request,$month){
        try{
            $value = Session::get('token');
            $patient_id = Auth::user()->patient_unique_id;
            $login_token =PatientLoginToken::where(array('patient_id'=>$patient_id,'login_token'=>$value))->first();        
            if(isset($login_token->token_status) && $login_token->token_status == 0){ 
                Auth::guard('patient')->logout();           
                return redirect('/patient/login');
            }
            if(!Auth::check()){            
               return redirect('/patient/login');
            }  
            $user = $request->user();
            $time_zone = $user->timezone;
            $patient_id = Auth::user()->patient_unique_id;         
            $login_token = PatientLoginToken::where('patient_id',$patient_id)->where('token_status',1)->where('device_token',NULL)->first();   
            if(isset($login_token->login_token)){                
                $dtz = new DateTimeZone($user->timezone);     
                $date = date('Y-m-d',strtotime($month));   
                $next_date = date('Y-m-t', strtotime($date));
                $time_in_sofia = new DateTime($date, $dtz);        
                $date_offset = $time_in_sofia->format('Z');       
                $start_time = strtotime($date)-$date_offset;                        
                $end_time = strtotime($next_date)-$date_offset;
                $base_url = asset('/');
                $patient_history = HealthHistory::with(array('patient','doctor','history_attachments','doctor.specialist_categories','doctor.doctor_hospital_details'))->where('created_date','>=',$start_time)->where('created_date','<=',$end_time)->orderBy('created_date','DESC')->paginate(5);              
                
                $start_date = HealthHistory::select('created_date')->where('patient_id',$patient_id)->orderBy('created_date','ASC')->first();            
                return view('patient.health_history_inner')->with(array('controller'=> 'pages','page'=>'dashboard','page_type'=>'health_history','start_date'=>$start_date,'health_history'=>$patient_history,'timezone'=>$time_zone));
            
            }else{
                return redirect('/patient/login');
            }      
        }catch(Exception $e) {
            echo 'Message: ' .$e->getMessage(); 
        }

    }
}