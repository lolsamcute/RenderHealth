<?php
namespace App\Http\Controllers\Patient;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Auth;
use DB;
use Validator;
use DateTime;
use DateTimeZone;
use Session;
use File;
use App\Models\PatientLoginToken;
use App\Models\Patient;
use App\Models\Hospital;
use App\Models\Doctor;
use App\Models\SaveTelemedicalBookingDetail;
use App\Models\PatientAppointment;
use App\Models\SpecialistCategories;
use App\Models\PatientHealthDiary;
use App\Models\PatientDiaryAttachment;

class PatientHealthDiaryController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth:patient');
        //date_default_timezone_set("Asia/Kolkata");
    }
    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */
    
    /******
    Health Diary View
    *******/
    public function healthDiary(Request $request)
    {
        try{
            $value = Session::get('token');
            $patient_id = Auth::user()->patient_unique_id;
            $login_token =PatientLoginToken::where(array('patient_id'=>$patient_id,'login_token'=>$value))->first();        
            if(isset($login_token->token_status) && $login_token->token_status == 0){ 
                Auth::guard('patient')->logout();           
                return redirect('/patient/login');
            }
            if(!Auth::check()){            
                return redirect('/patient/login');
            }
            $user = $request->user();

            $user_id = Auth::user()->patient_unique_id;               
                 
            $time_zone = $user->timezone;           
            $path = public_path('uploads/diary');
            $dtz = new DateTimeZone($time_zone);     
            $format_date = date('Y-m-d',strtotime('now'));                           
            $time_in_sofia = new DateTime($format_date, $dtz);        
            $date_offset = $time_in_sofia->format('Z');       
            $start_time = strtotime('last sunday')-$date_offset;
            $end_time = strtotime('next saturday , 11:59pm')-$date_offset;

            $previous_week = strtotime("-1 week +1 day");

            $start_week = strtotime("last sunday midnight",$previous_week)-$date_offset;
            $end_week = strtotime("next saturday, 11:59pm",$start_week)-$date_offset; 
            $base_url = asset('/');

            $current_diary = PatientHealthDiary::with(array('diary_attachment'=>function($q) use($base_url){$q->select('*',DB::Raw('CONCAT("'.$base_url.'",health_diary_attachments.attachment_path) as attachments'));}))->where('created_date','>=',$start_time)->where('created_date','<=',$end_time)->orderBy('created_date','DESC')->where('patient_id',$user_id)->get();

            $prev_diary = PatientHealthDiary::with(array('diary_attachment'=>function($q) use($base_url){$q->select('*',DB::Raw('CONCAT("'.$base_url.'",health_diary_attachments.attachment_path) as attachments'));}))->where('created_date','>=',$start_week)->where('created_date','<=',$end_week)->orderBy('created_date')->where('patient_id',$user_id)->get();

            $start_date = PatientHealthDiary::select('created_date')->where('patient_id',$user_id)->orderBy('created_date','ASC')->first();

            return view('patient.health_diary')->with(array('controller'=> 'pages','user'=>$user,'page'=>'dashboard','page_type'=>'health_diary','current_diary'=>$current_diary,'prev_diary'=>$prev_diary,'start_date'=>$start_date,'time_zone'=>$time_zone));
        }catch(Exception $e) {
            echo 'Message: ' .$e->getMessage(); 
        }
    }

    /******
    Add new diary
    *******/
    public function addNewDiary(Request $request)
    {
        try{
            $value = Session::get('token');
            $patient_id = Auth::user()->patient_unique_id;
            $login_token =PatientLoginToken::where(array('patient_id'=>$patient_id,'login_token'=>$value))->first();        
            if(isset($login_token->token_status) && $login_token->token_status == 0){ 
                Auth::guard('patient')->logout();           
                return redirect('/patient/login');
            }
            if(!Auth::check()){            
                return redirect('/patient/login');
            }
            DB::enableQueryLog();
            $user = $request->user();
           
           $patient_diary= PatientHealthDiary::select('feeling_details')->where('patient_id',$patient_id)->where('feeling_details','!=',6)->where(DB::raw('DATE_FORMAT(FROM_UNIXTIME(created_date), "%Y-%m-%d") '),'=', DB::raw('curdate()'))->get();
          // print_r(DB::connection('mysql')->getQueryLog());
          return view('patient.add_new_diary')->with(array('controller'=> 'pages','user'=>$user,'page'=>'dashboard','page_type'=>'health_diary','patient_diary'=>$patient_diary));
        }catch(Exception $e) {
            echo 'Message: ' .$e->getMessage(); 
        }
    }

    /******
    Edit health diary
    *******/
    public function editHealthDiary(Request $request,$diary_id)
    {
        try{
            $value = Session::get('token');
            $patient_id = Auth::user()->patient_unique_id;
            $login_token =PatientLoginToken::where(array('patient_id'=>$patient_id,'login_token'=>$value))->first();        
            if(isset($login_token->token_status) && $login_token->token_status == 0){ 
                Auth::guard('patient')->logout();           
                return redirect('/patient/login');
            }
            if(!Auth::check()){            
                return redirect('/patient/login');
            }
            $user = $request->user();
            $time_zone = $user->timezone;
            $base_url = asset('/');
            $patient_diary = PatientHealthDiary::with(array('diary_attachment'=>function($q) use($base_url){$q->select('*',DB::Raw('CONCAT("'.$base_url.'",health_diary_attachments.attachment_path) as attachments'));}))->where('diary_id',$diary_id)->get();
             $patient_diary2= PatientHealthDiary::select('feeling_details')->where('patient_id',$patient_id)->where('feeling_details','!=',6)->get();
            return view('patient.edit_diary')->with(array('controller'=> 'pages','user'=>$user,'page'=>'dashboard','page_type'=>'health_diary','patient_diary'=>$patient_diary,'time_zone'=>$time_zone,"patient_diary2"=>$patient_diary2));
        }catch(Exception $e) {
            echo 'Message: ' .$e->getMessage(); 
        }
    }

    /******
    Save Diary Details
    *******/
    public function saveDiaryDetails(Request $request)
    {   
        try{
           // print_r($_POST); die;
            $value = Session::get('token');
            $patient_id = Auth::user()->patient_unique_id;
            $login_token =PatientLoginToken::where(array('patient_id'=>$patient_id,'login_token'=>$value))->first();        
            if(isset($login_token->token_status) && $login_token->token_status == 0){ 
                Auth::guard('patient')->logout();           
                return response()->json(['redirect'=>1,"redirect_url"=>asset('/patient/login')],200);
            }
            if(!Auth::check()){            
                return response()->json(['redirect'=>1,"redirect_url"=>asset('/patient/login')],200);
            }   
            $user = $request->user();     
          /* $validate= $this->validator($request->all())->validate();*/
            $data=$_POST; 
            $validator = Validator::make($_POST, [ 
                'feeling_details'=>'required', 
                'symptom_details' =>'required'                           
            ]); 

            if ($validator->fails()) { 
                $errorMsg=$validator->messages();               
                return response()->json(['success'=>0, 'message'=>$validator->messages()->first()], 200);            
            }

            $patient_id = Auth::user()->patient_unique_id;         
            $login_token = PatientLoginToken::where('patient_id',$patient_id)->where('token_status',1)->where('device_token',NULL)->first();   
            if(isset($login_token->login_token)){
                $data['patient_id'] = $patient_id;          
                $data['login_token'] = $login_token->login_token;   
                $data['time_zone'] = $user->timezone;  
                $data['web'] =1;
                $post_data = json_encode($data); 
                //print_r($post_data); die;
                if(isset($_POST['edit']) && isset($_POST['diary_id'])){ 
                    $curl = url('/')."/api/edit_health_diary";
                }else{
                    $curl = url('/')."/api/add_health_diary";
                }

                $response = $this->commoncurl($curl,$post_data); 

                //print_r($post_data); die;
                if($response['success'] == 1){  
                   return response()->json(['success'=>$response['success'],"message"=>$response['message'],"redirect_url"=>asset('/patient/health_diary')],200);
                }else{
                    return response()->json(['success'=>$response['success'],"message"=>$response['message']],200);
                }
            }else{
                return response()->json(['redirect'=>1,"redirect_url"=>asset('/patient/login')],200);
            }
        }catch(Exception $e) {
            return response()->json(['error'=>1,"message"=>$e->getMessage()],200);       
        }      
        
    }

    /******
    View Diary Details
    *******/
    public function viewHealthDiary(Request $request,$diary_id){
        try{
            $value = Session::get('token');
            $patient_id = Auth::user()->patient_unique_id;
            $login_token =PatientLoginToken::where(array('patient_id'=>$patient_id,'login_token'=>$value))->first();        
            if(isset($login_token->token_status) && $login_token->token_status == 0){ 
                Auth::guard('patient')->logout();           
                return response()->json(['redirect'=>1,"redirect_url"=>asset('/patient/login')],200);
            }
            if(!Auth::check()){            
                return response()->json(['redirect'=>1,"redirect_url"=>asset('/patient/login')],200);
            }   
            $user = $request->user();
            $time_zone = $user->timezone;
            $base_url = asset('/');
            $patient_diary = PatientHealthDiary::with(array('diary_attachment'=>function($q) use($base_url){$q->select('*',DB::Raw('CONCAT("'.$base_url.'",health_diary_attachments.attachment_path) as attachments'));}))->where('diary_id',$diary_id)->get();
            return view('patient.view_diary')->with(array('controller'=> 'pages','page'=>'dashboard','page_type'=>'health_diary','diary_detail'=>$patient_diary,'timezone'=>$time_zone));
        }catch(Exception $e) {
            echo 'Message: ' .$e->getMessage(); 
        }
    }

    /******
    Upload Diary Attachments on select
    *******/
    public function uploadDiaryAttachments(Request $request){
        try{
            $value = Session::get('token');
            $patient_id = Auth::user()->patient_unique_id;
            $login_token =PatientLoginToken::where(array('patient_id'=>$patient_id,'login_token'=>$value))->first();        
            if(isset($login_token->token_status) && $login_token->token_status == 0){ 
                Auth::guard('patient')->logout();           
                return response()->json(['redirect'=>1,"redirect_url"=>asset('/patient/login')],200);
            }
            if(!Auth::check()){            
                return response()->json(['redirect'=>1,"redirect_url"=>asset('/patient/login')],200);
            }   
            $filename_arr = array();
            $attach_path =array();
            $folder_name = array();
            if($_POST['imagesLength']){
                for($i=0;$i< $_POST['imagesLength'];$i++)
                {
                    if(isset($_FILES['attachments'.$i.''])){  
                        $user = $request->user();
                        $user_id = Auth::user()->patient_unique_id;               
                         
                        $time_zone = $user->timezone;           
                        $path = public_path('uploads/diary');
                        $dtz = new DateTimeZone($time_zone);     
                        $format_date = date('Y-m-d',strtotime('now'));                           
                        $time_in_sofia = new DateTime($format_date, $dtz);        
                        $date_offset = $time_in_sofia->format('Z');       
                        $date = strtotime($format_date)-$date_offset; 
                       
                        
                        if(!is_dir($path."/".$user_id))
                        {
                            mkdir($path."/".$user_id);
                            chmod($path."/".$user_id, 0777);
                        }
                        
                        if(!is_dir($path."/".$user_id."/".$date))
                        {
                            mkdir($path."/".$user_id."/".$date);
                            chmod($path."/".$user_id."/".$date, 0777);
                        }

                        $extension = $request->file('attachments'.$i.'')->getClientOriginalExtension();// getting image extension
                        $dir = $path."/".$user_id."/".$date;               
                        $count = $this->generateUniqueNumber($user_id);
                        
                        $filename = $user_id."_".$count.'.'.$extension;    
                        $request->file('attachments'.$i.'')->move($dir, $filename);    
                        
                        array_push($filename_arr,$filename);                  
                        array_push($attach_path,"uploads/diary/".$user_id."/".$date."/".$filename);                     
                        array_push($folder_name,$date);
                    }     
                }              
                return response()->json(['attach_name'=>$filename_arr,"attach_path"=>$attach_path,"folder_name"=>$folder_name],200);  
            }          
        }catch(Exception $e) {
            return response()->json(['error'=>1,"message"=>$e->getMessage()],200);       
        } 
    }

    /******
    Monthly diary View
    *******/
    public function monthlyHealthDiary(Request $request,$month){
        try{
            $value = Session::get('token');
            $patient_id = Auth::user()->patient_unique_id;
            $login_token =PatientLoginToken::where(array('patient_id'=>$patient_id,'login_token'=>$value))->first();        
            if(isset($login_token->token_status) && $login_token->token_status == 0){ 
                Auth::guard('patient')->logout();           
                return redirect('/patient/login');
            }
            if(!Auth::check()){            
               return redirect('/patient/login');
            }  
            $user = $request->user();
            $time_zone = $user->timezone;
            $patient_id = Auth::user()->patient_unique_id;         
            $login_token = PatientLoginToken::where('patient_id',$patient_id)->where('token_status',1)->where('device_token',NULL)->first();   
            if(isset($login_token->login_token)){                
                $dtz = new DateTimeZone($user->timezone);     
                $date = date('Y-m-d',strtotime($month));   
                $next_date = date('Y-m-d', strtotime($date));
                $time_in_sofia = new DateTime($date, $dtz);        
                $date_offset = $time_in_sofia->format('Z');       
                $start_time = strtotime($date)-$date_offset;                        
                $end_time = strtotime($next_date)-$date_offset;
                $base_url = asset('/');
                $patient_diary = PatientHealthDiary::with(array('diary_attachment'=>function($q) use($base_url){$q->select('*',DB::Raw('CONCAT("'.$base_url.'",health_diary_attachments.attachment_path) as attachments'));}))->where(DB::raw('EXTRACT(MONTH FROM DATE_FORMAT(FROM_UNIXTIME(created_date), "%Y-%m-%d"))'),DB::raw('EXTRACT(MONTH FROM ("'.$month.'"))'))->orderBy('created_date')->where('patient_id',$patient_id)->paginate(6);
                $total = $patient_diary->lastPage();
                
                $diary_start = PatientHealthDiary::select('created_date')->where('patient_id',$patient_id)->orderBy('created_date','ASC')->first();            
               if(isset($diary_start->created_date)){
                    if(count($patient_diary) > 0){   
                                                                 
                        return view('patient.monthly_diary')->with(array('controller'=> 'pages','page'=>'dashboard','page_type'=>'health_diary','total'=>$total,'diary_details'=>$patient_diary,'timezone'=>$time_zone));
                    }else{
                        
                        return view('patient.monthly_diary')->with(array('controller'=> 'pages','page'=>'dashboard','page_type'=>'health_diary','diary_details'=>array()));
                    }
                }else{
                   
                    return view('patient.monthly_diary')->with(array('controller'=> 'pages','page'=>'dashboard','page_type'=>'health_diary','diary_details'=>array()));
                }
            
            }else{
                return redirect('/patient/login');
            }      
        }catch(Exception $e) {
            echo 'Message: ' .$e->getMessage(); 
        }

    }

    /******
    Delete health diary
    *******/
     public function deleteHealthDiary(Request $request,$diary_id){
        try{
            $value = Session::get('token');
            $patient_id = Auth::user()->patient_unique_id;
            $login_token =PatientLoginToken::where(array('patient_id'=>$patient_id,'login_token'=>$value))->first();        
            if(isset($login_token->token_status) && $login_token->token_status == 0){ 
                Auth::guard('patient')->logout();           
                return response()->json(['redirect'=>1,"redirect_url"=>asset('/patient/login')],200);
            }
            if(!Auth::check()){            
               return response()->json(['redirect'=>1,"redirect_url"=>asset('/patient/login')],200);
            }  
            $user = $request->user();
            $data=$_POST; 
            $time_zone = $user->timezone;
            $patient_id = Auth::user()->patient_unique_id;         
            $login_token = PatientLoginToken::where('patient_id',$patient_id)->where('token_status',1)->where('device_token',NULL)->first();   
            if(isset($login_token->login_token)){
                $data['patient_id'] = $patient_id;          
                $data['login_token'] = $login_token->login_token;   
                $data['time_zone'] = $user->timezone;  
                $data['diary_id'] = $diary_id;
                $data['web'] =1;
                $post_data = json_encode($data);  
                $curl = url('/')."/api/delete_health_diary"; 
                $response = $this->commoncurl($curl,$post_data); 
                if($response['success'] == 1){  
                   return response()->json(['success'=>$response['success'],"message"=>$response['message']],200);
                }else{
                    return response()->json(['success'=>$response['success'],"message"=>$response['message']],200);
                }
            
            }else{
                return response()->json(['redirect'=>1,"redirect_url"=>asset('/patient/login')],200);
            }      
        }catch(Exception $e) {
             return response()->json(['error'=>1,"message"=>$e->getMessage()],200);  
        }

    }

    /******
    Delete add diary images
    *******/
    public function deleteAddDiaryImage(Request $request){
        try{
            $value = Session::get('token');
            $patient_id = Auth::user()->patient_unique_id;
            $login_token =PatientLoginToken::where(array('patient_id'=>$patient_id,'login_token'=>$value))->first();        
            if(isset($login_token->token_status) && $login_token->token_status == 0){ 
                Auth::guard('patient')->logout();           
                return response()->json(['redirect'=>1,"redirect_url"=>asset('/patient/login')],200);
            }
            if(!Auth::check()){            
               return response()->json(['redirect'=>1,"redirect_url"=>asset('/patient/login')],200);
            }  
            $user = $request->user();
            $data=$_POST; 
            $time_zone = $user->timezone;
            $patient_id = Auth::user()->patient_unique_id;            
            $path = public_path('/');
            if(file_exists($path."/".$_POST['val'])){
                //unlink($path."/".$_POST['val']);
                return response()->json(['success'=>1],200);
            }else{
                return response()->json(['success'=>0,'message'=>"Image not found"],200);
            }                
        }catch(Exception $e) {
             return response()->json(['error'=>1,"message"=>$e->getMessage()],200);  
        }

    }
     /******
   View diary detail
    *******/
    public function ViewDiary(Request $request,$diary_id){
        try{
        $value = Session::get('token');
        $patient_id = Auth::user()->patient_unique_id;
        $login_token =PatientLoginToken::where(array('patient_id'=>$patient_id,'login_token'=>$value))->first();        
        if(isset($login_token->token_status) && $login_token->token_status == 0){ 
        Auth::guard('patient')->logout();           
        return response()->json(['redirect'=>1,"redirect_url"=>asset('/patient/login')],200);
        }
        if(!Auth::check()){            
        return response()->json(['redirect'=>1,"redirect_url"=>asset('/patient/login')],200);
        }  
        $user = $request->user();
        $time_zone = $user->timezone;
        $base_url = asset('/');
        $patient_diary = PatientHealthDiary::with(array('diary_attachment'=>function($q) use($base_url){$q->select('*',DB::Raw('CONCAT("'.$base_url.'",health_diary_attachments.attachment_path) as attachments'));}))->where('diary_id',$diary_id)->get();
        $feeling_pic = ['admin/doctor/images/smilies/no_pain@2x.png','admin/doctor/images/smilies/mild@2x.png','admin/doctor/images/smilies/moderate@2x.png','admin/doctor/images/smilies/severe@2x.png','admin/doctor/images/smilies/very_severe@2x.png','admin/doctor/images/smilies/worst_pain@2x.png','admin/doctor/images/smilies/moderate@2x.png'];
        $feeling_pic=$feeling_pic[$patient_diary[0]->feeling_details];
        $feeling = ['Feeling No Pain','Feeling Mild Pain','Feeling Moderate Pain','Feeling Severe Pain','Feeling Very Severe Pain','Feeling Worst Pain',"Other"];
        if($patient_diary[0]->feeling_details==6){
        $feeling_name=$patient_diary[0]->describe_feeling_other;
        }else{
        $feeling_name=$feeling[$patient_diary[0]->feeling_details];
        }
        $symptom_details= $patient_diary[0]->symptom_details;   
        $created_date= date("d F Y",$patient_diary[0]->created_date);       

        if( $patient_diary){
        return response()->json(['success'=>1,"feeling_pic"=>$feeling_pic,"feeling_name"=>$feeling_name,"symptom_details"=>$symptom_details,"created_date"=>$created_date,"diary_id"=>$diary_id],200);

        }else{
        return response()->json(['success'=>0,'message'=>"Image not found"],200);
        }                
        }catch(Exception $e) {
             return response()->json(['error'=>1,"message"=>$e->getMessage()],200);  
        }

    }

    /******
    Delete edit diary images
    *******/
    public function deleteDiaryImages(Request $request,$attach_id){
        try{
            $value = Session::get('token');
            $patient_id = Auth::user()->patient_unique_id;
            $login_token =PatientLoginToken::where(array('patient_id'=>$patient_id,'login_token'=>$value))->first();        
            if(isset($login_token->token_status) && $login_token->token_status == 0){ 
                Auth::guard('patient')->logout();           
                return response()->json(['redirect'=>1,"redirect_url"=>asset('/patient/login')],200);
            }
            if(!Auth::check()){            
               return response()->json(['redirect'=>1,"redirect_url"=>asset('/patient/login')],200);
            }  
            $user = $request->user();
            $data=$_POST; 
            $time_zone = $user->timezone;
            $patient_id = Auth::user()->patient_unique_id; 
            $image_det = PatientDiaryAttachment::where('attachment_id',$attach_id)->get();        
            if(count($image_det) > 0){                                              
                $path = public_path('/');
                if(file_exists($path."/".$image_det[0]->attachment_path)){
                    unlink($path."/".$image_det[0]->attachment_path);
                }
                PatientDiaryAttachment::where('attachment_id',$attach_id)->delete();                                         

                return response()->json(['success'=>1,'message'=>"Image deleted successfully"],200);
            }else{
                return response()->json(['success'=>0,'message'=>"Image not found"],200);
            }     
        }catch(Exception $e) {
             return response()->json(['error'=>1,"message"=>$e->getMessage()],200);  
        }

    }
    private function commoncurl($url,$post_data){
        $ch1 = curl_init();       
        curl_setopt($ch1, CURLOPT_URL,$url);
        curl_setopt($ch1, CURLOPT_HEADER, 0);
        curl_setopt($ch1, CURLOPT_POST, 1);
        curl_setopt($ch1, CURLOPT_POSTFIELDS, $post_data);  
        curl_setopt($ch1, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch1, CURLOPT_SSL_VERIFYPEER, 0);
        $output = curl_exec($ch1);  
        //echo "<pre>"; print_R($output); exit;    
        curl_close ($ch1);
        $output= json_decode($output,true);
        
        return $output;
    } 

    protected function generateUniqueNumber($user_id) {
        $number = mt_rand(1000000000, 9999999999); // better than rand()
        // call the same function if the uniwue id exists already
        if ($this->uniqueNumberExists($number,$user_id)) {
            return $this->generateUniqueNumber();
        }
        // otherwise, it's valid and can be used
        return strval($number);
    }

    protected function uniqueNumberExists($number,$user_id) {
        // query the database and return a boolean         
        return PatientDiaryAttachment::whereattachment_name($user_id."_".$number.".jpeg")->exists();
    }

}
