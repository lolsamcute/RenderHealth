<?php
namespace App\Http\Controllers\Patient;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Auth;
use Validator;
use DateTime;
use DateTimeZone;
use Session;
use Mail;
use App\Models\PatientLoginToken;
use App\Models\Patient;
use App\Models\Hospital;
use App\Models\Doctor;
use App\Models\SaveTelemedicalBookingDetail;
use App\Models\PatientAppointment;
use App\Models\SpecialistCategories;
use App\Models\HealthHistory;
use App\Models\HealthHistoryAttachments;
use App\Models\CallSession;
use App\Models\UserNotification;
use App\Models\PatientNotificationSetting;
use App\Models\PatientHealthDiary;
use App\Models\PaidBillingDetail;
use Twilio\Rest\Client;
class PatientDashboardController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth:patient',['except' => ['sendMail','sendMailTemplate','doctorAvailabilityListing']]);       
        
        //date_default_timezone_set("Asia/Kolkata");
    }
    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */

    /******
    Patient Dashboard
    *******/
    public function index(Request $request,$return=null)
    {   
        $value = Session::get('token');
        $patient_id = Auth::user()->patient_unique_id;
        $login_token =PatientLoginToken::where(array('patient_id'=>$patient_id,'login_token'=>$value))->first();

        if(isset($login_token->token_status) && $login_token->token_status == 0){ 
            Auth::guard('patient')->logout();           
            return redirect('/patient/login');
        }
        if(!Auth::check()){            
            return redirect('/patient/login');
        }
        $user = $request->user();
        $patient_detail = Patient::where('patient_unique_id',$patient_id)->first();

        $appoint_listing=SaveTelemedicalBookingDetail::with("doctor","patient_appoint","doctor.specialist_categories","hospital_detail")->select("*")->where('save_telemedical_booking_detail.approved_status','!=',2)->where('save_telemedical_booking_detail.patient_id',$patient_id)->orderBy('save_telemedical_booking_detail.appointment_time','DESC')->limit(5)->get();

        $health_history=HealthHistory::with(array('patient','doctor','history_attachments','doctor.specialist_categories','doctor.doctor_hospital_details'))->where('patient_id',$patient_id)->orderBy('created_date','DESC')->limit(5)->get();

        $dtz = $user->timezone ? new DateTimeZone($user->timezone) : '';     
        $date = date('Y-m-d',strtotime('now'));                  
        $time_in_sofia = $dtz ? new DateTime($date, $dtz) : new DateTime($date);        
        $date_offset = $time_in_sofia->format('Z');       
        $start_time = strtotime($date)-$date_offset;
        
        $appoint_count=SaveTelemedicalBookingDetail::with("doctor","patient_appoint","doctor.specialist_categories","hospital_detail")->select("*")->where('save_telemedical_booking_detail.approved_status','!=',2)->where('save_telemedical_booking_detail.patient_id',$patient_id)->where('save_telemedical_booking_detail.appointment_time','>=',$start_time)->count();
      //  echo "<pre>";
        //print_r($health_history);die;

        return view('patient.dashboard')->with(array('controller'=> 'patient','user'=>$user,'page'=>'dashboard','page_type'=>'extra_links','patient_detail'=>$patient_detail,'appoint_listing'=>$appoint_listing,'timezone'=>$user->timezone,'health_history'=>$health_history,'appoint_count'=>$appoint_count));
    }   

    /******
    Immediate telemedical Appoitnment View
    *******/
    public function immediateTelemedical(Request $request,$id,$speciality=null)
    {

        $value = Session::get('token');
        $patient_id = Auth::user()->patient_unique_id;
        $login_token =PatientLoginToken::where(array('patient_id'=>$patient_id,'login_token'=>$value))->first();        
        if(isset($login_token->token_status) && $login_token->token_status == 0){ 
            Auth::guard('patient')->logout();           
            return redirect('/patient/login');
        }
        if(!Auth::check()){            
            return redirect('/patient/login');
        }
       
        $user = $request->user();
        $book_details = SaveTelemedicalBookingDetail::with('doctor','doctor.specialist_categories')->where('appointment_id',$id)->where('patient_id',$patient_id)->orderBy('created_at','DESC')->get();
        $hospitals = Hospital::get();
        $BillingInfo = PaidBillingDetail::where('appointment_id',$id)->where('patient_id',$patient_id)->get(); 
          $health_diaries=PatientHealthDiary::where(array('patient_id'=>$patient_id,))->orderBy('id','DESC')->get();
        //print_r($BillingInfo); die;        
        return view('patient.immediate_tele')->with(array('controller'=> 'patient','user'=>$user,'hospitals'=>$hospitals,'appointment_id'=>$id,'book_details'=>$book_details,'BillingInfo'=>$BillingInfo,'page'=>'inner','speciality'=>$speciality,'timezone'=>$user->timezone,"health_diaries"=>$health_diaries));
    }

    /******
    Future telemedical Appoitnment View
    *******/
    public function futureTelemedical(Request $request,$id,$doctor_id,$date,$time,$speciality=null)
    {       
        $value = Session::get('token');
        $patient_id = Auth::user()->patient_unique_id;
        $login_token =PatientLoginToken::where(array('patient_id'=>$patient_id,'login_token'=>$value))->first();        
        if(isset($login_token->token_status) && $login_token->token_status == 0){ 
            Auth::guard('patient')->logout();           
            return redirect('/patient/login');
        }
        if(!Auth::check()){            
            return redirect('/patient/login');
        }
        
        $user = $request->user(); 
        $doctor_detail = Doctor::where('doctor_id',$doctor_id)->first();         
        $book_details = SaveTelemedicalBookingDetail::where('appointment_id',$id)->orderBy('created_at','DESC')->get();
         $health_diaries=PatientHealthDiary::where(array('patient_id'=>$patient_id,))->orderBy('id','DESC')->get();
        return view('patient.future_tele')->with(array('controller'=> 'patient','user'=>$user,'doctor_id'=>$doctor_id,'appointment_id'=>$id,'doctor_apponitment_date'=>$date,'doctor_apponitment_time'=>$time,'doctor_detail'=>$doctor_detail,'book_details'=>$book_details,'page_type'=>'extra_links','page'=>'inner','speciality'=>$speciality,'timezone'=>$user->timezone,"health_diaries"=>$health_diaries));
    }

    /******
    Appointment Detail View
    *******/
    public function appointmentDetail(Request $request,$id)
    {       
        $value = Session::get('token');
        $patient_id = Auth::user()->patient_unique_id;
        $login_token =PatientLoginToken::where(array('patient_id'=>$patient_id,'login_token'=>$value))->first();        
        if(isset($login_token->token_status) && $login_token->token_status == 0){ 
            Auth::guard('patient')->logout();           
            return redirect('/patient/login');
        }
        if(!Auth::check()){            
            return redirect('/patient/login');
        }
        
        $user = $request->user();   
        $patient_id = Auth::user()->patient_unique_id;         
        $login_token = PatientLoginToken::where('patient_id',$patient_id)->where('token_status',1)->where('device_token',NULL)->first();
        if(isset($login_token->login_token)){              
             $data['patient_id'] = $patient_id;          
             $data['login_token'] = $login_token->login_token; 
             $data['booking_id'] = $id;      
             $post_data = json_encode($data);  
             $curl = url('/')."/api/single_appointment_detail";                
             $response = $this->commoncurl($curl,$post_data); 
             if($response['success'] == 0){
                $response['data'] = array();
              }     
            if(isset($response['data'][0])){
            $health_diary_array=explode(',', $response['data'][0]['health_diary']);
            $diary_details=PatientHealthDiary::whereIn('patient_health_diary.diary_id', $health_diary_array)->leftJoin('health_diary_attachments', 'patient_health_diary.diary_id','=', 'health_diary_attachments.diary_id')->groupBy('patient_health_diary.diary_id')->get();
            }else{
            $diary_details="";
            }


               
            return view('patient.appointment_detail')->with(array('controller'=> 'patient','user'=>$user,'page_type'=>'extra_links','page'=>'inner','appointment'=>$response['data'],'timezone'=>$user->timezone,"diary_details"=>$diary_details));
        }else{
          return redirect('/patient/login');
        }
    }

    /******
    Speciality Telemedical View
    *******/
    public function specialityTelemedical(Request $request,$id)
    {       
        $value = Session::get('token');
        $patient_id = Auth::user()->patient_unique_id;
        $login_token =PatientLoginToken::where(array('patient_id'=>$patient_id,'login_token'=>$value))->first();        
        if(isset($login_token->token_status) && $login_token->token_status == 0){ 
            Auth::guard('patient')->logout();           
            return redirect('/patient/login');
        }
        if(!Auth::check()){            
            return redirect('/patient/login');
        }
        
        $user = $request->user(); 
        $speciality_detail = SpecialistCategories::select('*')->where('type_of_user', '=' ,1)->get();
        if(count($speciality_detail) > 0){
            $speciality_detail = $speciality_detail->toArray();
        }                
        return view('patient.speciality_listing')->with(array('controller'=> 'patient','user'=>$user,'appointment_id'=>$id,'speciality_detail'=>$speciality_detail,'page'=>'inner','timezone'=>$user->timezone));
    }

    /******
    Doctor Listing View
    *******/
    public function doctorListing(Request $request,$id,$date,$type,$speciality=null)
    {
        $value = Session::get('token');
        $patient_id = Auth::user()->patient_unique_id;
        $login_token =PatientLoginToken::where(array('patient_id'=>$patient_id,'login_token'=>$value))->first();        
        if(isset($login_token->token_status) && $login_token->token_status == 0){ 
            Auth::guard('patient')->logout();           
            return redirect('/patient/login');
        }
        if(!Auth::check()){            
            return redirect('/patient/login');
        }
        
        $user = $request->user();
        $patient_id = Auth::user()->patient_unique_id;         
        $login_token = PatientLoginToken::where('patient_id',$patient_id)->where('token_status',1)->where('device_token',NULL)->first();   
        if(isset($login_token->login_token)){  
             $data['appoint_date'] = $date; 
             if(!empty($speciality)){
                $data['speciality_id'] = $speciality;
            }             

            $dtz = new DateTimeZone($user->timezone);     
            $date = date('Y-m-d',strtotime($date));               
            $next_date = date('Y-m-d', strtotime('+1 day', strtotime($date)));
            $time_in_sofia = new DateTime($date, $dtz);        
            $date_offset = $time_in_sofia->format('Z');       
            $start_time = strtotime($date)-$date_offset;            
            $end_time = strtotime($next_date)-$date_offset;
            $data['patient_id'] = $patient_id;          
            $data['login_token'] = $login_token->login_token;
            $data['time_zone'] = $user->timezone; 
            $data['web'] = 1;      
            $post_data = json_encode($data);  

            $curl = url('/')."/api/doctor_listing";
            $speciality_detail = SpecialistCategories::select('*')->where('type_of_user', '=' ,1)->get();
            $response = $this->commoncurl($curl,$post_data); 
            
            if($response['success'] == 0){
                $response['data'] = array();
            }     
            
            $doc_appoint_listing=SaveTelemedicalBookingDetail::where('save_telemedical_booking_detail.approved_status','!=',2)->where('save_telemedical_booking_detail.appointment_time','>=',$start_time)->where('save_telemedical_booking_detail.appointment_time','<',$end_time)->orderBy('save_telemedical_booking_detail.appointment_time','ASC')->get();

            //echo "<pre>"; print_r($doc_appoint_listing); exit;
            if($request->ajax()){               
              return view('patient.ajax_doctor_listing')->with(array('controller'=> 'patient','user'=>$user,'date'=>$date,'doctors'=>$response['data'],'id'=>$id,'type'=>$type,'speciality_detail'=>$speciality_detail,'timezone'=>$user->timezone,'doc_appoint_listing'=>$doc_appoint_listing,'pid'=>$patient_id));      
            }else{
              return view('patient.doctors_listing')->with(array('controller'=> 'patient','user'=>$user,'date'=>$date,'doctors'=>$response['data'],'page'=>'inner','page_type'=>'extra_links','id'=>$id,'type'=>$type,'speciality_detail'=>$speciality_detail,'timezone'=>$user->timezone,'doc_appoint_listing'=>$doc_appoint_listing,'pid'=>$patient_id));
            }
        }else{
            return redirect('/patient/login');
        }
    }


    /******
    My Appointment Listing View
    *******/
    public function myAppointments(Request $request,$type=null,$spe=null,$hosp=null)
    {

        $value = Session::get('token');
        $patient_id = Auth::user()->patient_unique_id;
        $login_token =PatientLoginToken::where(array('patient_id'=>$patient_id,'login_token'=>$value))->first();        
        if(isset($login_token->token_status) && $login_token->token_status == 0){ 
            Auth::guard('patient')->logout();   
            if($request->ajax()){         
                return response()->json(['redirect'=>1,"redirect_url"=>asset('/patient/login')],200);
            }else{
                return redirect('/patient/login');
            }
        }
        if(!Auth::check()){  
            if($request->ajax()){ 
                return response()->json(['redirect'=>1,"redirect_url"=>asset('/patient/login')],200);        
            }else{          
                return redirect('/patient/login');
            }
        }
        
        $user = $request->user();
        $patient_id = Auth::user()->patient_unique_id;  
        if($spe != ""){    
            $spe = json_decode($spe,true);
        }    

        if($type != 0){
            $time_zone = $user->timezone;
            $dtz = new DateTimeZone($time_zone);
            $time_in_sofia = new DateTime('now', $dtz);        
            $date_offset = $time_in_sofia->format('Z');
            $start_time = strtotime(date("Y-m-d"))-$date_offset;
            $end_time = strtotime(date("Y-m-d",strtotime("+1 day")))-$date_offset;

            $query=SaveTelemedicalBookingDetail::with("doctor","patient_appoint","doctor.specialist_categories","hospital_detail")->select("*");            
            if($type === '1'){                 
                if(count($spe) > 0 && $hosp != 0){                   
                    $query->where('save_telemedical_booking_detail.appointment_time', '>=', $start_time)->where('save_telemedical_booking_detail.appointment_time', '<', $end_time)->where('save_telemedical_booking_detail.approved_status','!=',2)->where('save_telemedical_booking_detail.patient_id',$patient_id)->whereHas('doctor', function($q) use($spe) {$q->whereIn('doctor_speciality',$spe);})->where('hospital_id','=',$hosp);
                }elseif(count($spe) > 0 && $hosp == 0){                   
                    $query->where('save_telemedical_booking_detail.appointment_time', '>=', $start_time)->where('save_telemedical_booking_detail.appointment_time', '<', $end_time)->where('save_telemedical_booking_detail.approved_status','!=',2)->where('save_telemedical_booking_detail.patient_id',$patient_id)->whereHas('doctor', function($q) use($spe) {$q->whereIn('doctor_speciality',$spe);});
                }elseif(count($spe) == 0 && $hosp != 0){                    
                    $query->where('save_telemedical_booking_detail.appointment_time', '>=', $start_time)->where('save_telemedical_booking_detail.appointment_time', '<', $end_time)->where('save_telemedical_booking_detail.approved_status','!=',2)->where('save_telemedical_booking_detail.patient_id',$patient_id)->where('hospital_id','=',$hosp);
                }elseif(count($spe) == 0 && $hosp == 0){                    
                    $query->where('save_telemedical_booking_detail.appointment_time', '>=', $start_time)->where('save_telemedical_booking_detail.appointment_time', '<', $end_time)->where('save_telemedical_booking_detail.approved_status','!=',2)->where('save_telemedical_booking_detail.patient_id',$patient_id);
                }                
            }else if($type === '2'){                
                if(count($spe) > 0 && $hosp != 0){                   
                    $query->where('save_telemedical_booking_detail.appointment_time', '>', $end_time)->where('save_telemedical_booking_detail.approved_status','!=',2)->where('save_telemedical_booking_detail.patient_id',$patient_id)->whereHas('doctor', function($q) use($spe) {$q->whereIn('doctor_speciality',$spe);})->where('hospital_id','=',$hosp);
                }elseif(count($spe) > 0 && $hosp == 0){                    
                    $query->where('save_telemedical_booking_detail.appointment_time', '>', $end_time)->where('save_telemedical_booking_detail.approved_status','!=',2)->where('save_telemedical_booking_detail.patient_id',$patient_id)->whereHas('doctor', function($q) use($spe) {$q->whereIn('doctor_speciality',$spe);});
                }elseif(count($spe) == 0 && $hosp != 0){                    
                    $query->where('save_telemedical_booking_detail.appointment_time', '>', $end_time)->where('save_telemedical_booking_detail.approved_status','!=',2)->where('save_telemedical_booking_detail.patient_id',$patient_id)->where('hospital_id','=',$hosp);
                }elseif(count($spe) == 0 && $hosp == 0){                     
                    $query->where('save_telemedical_booking_detail.appointment_time', '>', $end_time)->where('save_telemedical_booking_detail.approved_status','!=',2)->where('save_telemedical_booking_detail.patient_id',$patient_id);
                }               
            }else if($type === '3'){ 
                if(count($spe) > 0 && $hosp != 0){                   
                    $query->where('save_telemedical_booking_detail.appointment_time', '<', $start_time)->where('save_telemedical_booking_detail.approved_status','!=',2)->where('save_telemedical_booking_detail.patient_id',$patient_id)->whereHas('doctor', function($q) use($spe) {$q->whereIn('doctor_speciality',$spe);})->where('hospital_id','=',$hosp);
                }elseif(count($spe) > 0 && $hosp == 0){                    
                    $query->where('save_telemedical_booking_detail.appointment_time', '<', $start_time)->where('save_telemedical_booking_detail.approved_status','!=',2)->where('save_telemedical_booking_detail.patient_id',$patient_id)->whereHas('doctor', function($q) use($spe) {$q->whereIn('doctor_speciality',$spe);});
                }elseif(count($spe) == 0 && $hosp != 0){                   
                   $query->where('save_telemedical_booking_detail.appointment_time', '<', $start_time)->where('save_telemedical_booking_detail.approved_status','!=',2)->where('save_telemedical_booking_detail.patient_id',$patient_id)->where('hospital_id','=',$hosp);
                }elseif(count($spe) == 0 && $hosp == 0){                                    
                    $query->where('save_telemedical_booking_detail.appointment_time', '<', $start_time)->where('save_telemedical_booking_detail.approved_status','!=',2)->where('save_telemedical_booking_detail.patient_id',$patient_id);
                }
            }
            $appoint_listing = $query->orderBy('save_telemedical_booking_detail.appointment_time','DESC')->paginate(20);            
            $total = $appoint_listing->lastPage();
        }else if(($spe != "" && count($spe) > 0) && $hosp != 0){ 
            $query=SaveTelemedicalBookingDetail::with("doctor","patient_appoint","doctor.specialist_categories","hospital_detail")->select("*");                         
            $query->where('save_telemedical_booking_detail.approved_status','!=',2)->where('save_telemedical_booking_detail.patient_id',$patient_id)->whereHas('doctor', function($q) use($spe) {$q->whereIn('doctor_speciality',$spe);})->where('hospital_id','=',$hosp);
            $appoint_listing = $query->orderBy('save_telemedical_booking_detail.appointment_time','DESC')->paginate(20);            
            $total = $appoint_listing->lastPage();
        }else if(($spe != "" && count($spe) > 0) && $hosp == 0){  
            $query=SaveTelemedicalBookingDetail::with("doctor","patient_appoint","doctor.specialist_categories","hospital_detail")->select("*");                         
            $query->where('save_telemedical_booking_detail.approved_status','!=',2)->where('save_telemedical_booking_detail.patient_id',$patient_id)->whereHas('doctor', function($q) use($spe) {$q->whereIn('doctor_speciality',$spe);});
            $appoint_listing = $query->orderBy('save_telemedical_booking_detail.appointment_time','DESC')->paginate(20);            
            $total = $appoint_listing->lastPage();
        }else if(($spe != "" && count($spe) == 0) && $hosp != 0){   
            $query=SaveTelemedicalBookingDetail::with("doctor","patient_appoint","doctor.specialist_categories","hospital_detail")->select("*");             
            $query->where('save_telemedical_booking_detail.approved_status','!=',2)->where('save_telemedical_booking_detail.patient_id',$patient_id)->where('hospital_id','=',$hosp);
            $appoint_listing = $query->orderBy('save_telemedical_booking_detail.appointment_time','DESC')->paginate(20);            
            $total = $appoint_listing->lastPage();
        }else{        
            $appoint_listing=SaveTelemedicalBookingDetail::with("doctor","patient_appoint","doctor.specialist_categories","hospital_detail")->select("*")->where('save_telemedical_booking_detail.approved_status','!=',2)->where('save_telemedical_booking_detail.patient_id',$patient_id)->orderBy('save_telemedical_booking_detail.id','DESC')->paginate(20);
            $total = $appoint_listing->lastPage();

        }
        $speciality_detail = SpecialistCategories::select('*')->where('type_of_user', '=' ,1)->get();
        // Get hospital that are linked with patient
            $hospitals = Hospital::whereIn('hosp_id', function($query) use($patient_id){
            $query->select('hospital_id')
            ->from(with(new SaveTelemedicalBookingDetail)->getTable())
            ->where('patient_id', $patient_id);})->get();
        if($request->ajax()){
            return view('patient.appointment_inner')->with(array('controller'=> 'patient','user'=>$user,'appointments'=>$appoint_listing,'page_type'=>'extra_links','total'=>$total,'back_btn'=>'immediate','timezone'=>$user->timezone,'hospitals'=>$hospitals,'speciality_detail' => $speciality_detail));
        }else{        
            return view('patient.my_appointments')->with(array('controller'=> 'patient','user'=>$user,'appointments'=>$appoint_listing,'page_type'=>'extra_links','total'=>$total,'back_btn'=>'immediate','timezone'=>$user->timezone,'hospitals'=>$hospitals,'speciality_detail' => $speciality_detail));
        }
        
    }

    /******
    Appointment Detail Save
    *******/
    public function appointmentDetails(Request $request)
    {   

        $value = Session::get('token');
        $patient_id = Auth::user()->patient_unique_id;
        $login_token =PatientLoginToken::where(array('patient_id'=>$patient_id,'login_token'=>$value))->first();        
        if(isset($login_token->token_status) && $login_token->token_status == 0){ 
            Auth::guard('patient')->logout();           
            return response()->json(['redirect'=>1,"redirect_url"=>asset('/patient/login')],200);
        }
        if(!Auth::check()){            
            return response()->json(['redirect'=>1,"redirect_url"=>asset('/patient/login')],200);
        }        
        
        $user = $request->user();
      /* $validate= $this->validator($request->all())->validate();*/
         $data=$_POST; 
         $patient_id = Auth::user()->patient_unique_id;         
         $login_token = PatientLoginToken::where('patient_id',$patient_id)->where('token_status',1)->where('device_token',NULL)->first();   
         if(isset($login_token->login_token)){      
             $data['patient_id'] = $patient_id;          
             $data['login_token'] = $login_token->login_token;      
             $post_data = json_encode($data);  
             $curl = url('/')."/api/appointment_detail";  
             $response = $this->commoncurl($curl,$post_data);   
            
            //Authenticates patient
            if($response['success'] == 1){  
                if($data['appointment_type'] == 1){
                    if($data['appointment_type'] == 1 && $data['telemedical_consult_type'] == 1 && $data['telemedical_consult_time'] == 1) {
                        return response()->json(['success'=>$response['success'],"id"=>$response['data']['appoint_id'], "redirect_url"=>asset('/patient/immediate_tele_details/'.$response['data']['appoint_id'])],200);
                    }else if(($data['appointment_type'] == 1 && $data['telemedical_consult_type'] == 1 && $data['telemedical_consult_time'] == 2) || ($data['appointment_type'] == 1 && $data['telemedical_consult_type'] == 2 && $data['telemedical_consult_time'] == 2)) {
                        return response()->json(['success'=>$response['success'],"id"=>$response['data']['appoint_id']],200);
                    }
                    if($data['appointment_type'] == 1 && $data['telemedical_consult_type'] == 2 && $data['telemedical_consult_time'] == 1) {
                        return response()->json(['success'=>$response['success'],"id"=>$response['data']['appoint_id'], "redirect_url"=>asset('/patient/immediate_speciality_details/'.$response['data']['appoint_id'])],200);
                    }
                }else{
                    return response()->json(['success'=>$response['success'],"id"=>$response['data']['appoint_id'], "redirect_url"=>asset('/patient/hospital_appointment/'.$response['data']['appoint_id'])],200);
                }
            }else{
                return response()->json(['success'=>$response['success'],"message"=>$response['message']],200);
            }
        }else{
            return response()->json(['redirect'=>1,"redirect_url"=>asset('/patient/login')],200);
        }
        
    }

    /******
    Save Booking Detail
    *******/
    public function saveBookDetails(Request $request)
    {   
        $value = Session::get('token');
        $patient_id = Auth::user()->patient_unique_id;
        $login_token =PatientLoginToken::where(array('patient_id'=>$patient_id,'login_token'=>$value))->first();        
        if(isset($login_token->token_status) && $login_token->token_status == 0){ 
            Auth::guard('patient')->logout();           
            return response()->json(['redirect'=>1,"redirect_url"=>asset('/patient/login')],200);
        }
        if(!Auth::check()){            
            return response()->json(['redirect'=>1,"redirect_url"=>asset('/patient/login')],200);
        }   
        $user = $request->user();     
      /* $validate= $this->validator($request->all())->validate();*/
         $data=$_POST; 
         //print_r($data); die;
        if(isset($data['appointment_type']) && $data['appointment_type'] == 2){
            $validator = Validator::make($_POST, [ 
                'doctor_id'=>'required',                   
                'doctor_appoint_date' => 'required',
                'appoint_time' => 'required'                       
            ]); 

            if ($validator->fails()) { 
                $errorMsg=$validator->messages();               
                return response()->json(['success'=>0, 'message'=>$validator->messages()->first()], 200);            
            }

            $patient_id = Auth::user()->patient_unique_id;  

            $login_token = PatientLoginToken::where('patient_id',$patient_id)->where('token_status',1)->where('device_token',NULL)->first();   
            if(isset($login_token->login_token)){
                $data['patient_id'] = $patient_id;          
                $data['login_token'] = $login_token->login_token;   
                $data['time_zone'] = $user->timezone;
                $data['appointment_type'] = $_POST['appointment_type'];
                $post_data = json_encode($data);  
               // print_r($post_data); die; 
                $curl = url('/')."/api/appointment_detail";  
                $app_response = $this->commoncurl($curl,$post_data);
              
                if($app_response['success'] == 1){         
                    $data['appointment_id'] = $app_response['data']['appoint_id'];  
                    $appointment_date = $_POST['doctor_appoint_date']." ".$_POST['appoint_time'];   
                    $data['appointment_time'] = date('d-m-Y H:i:s',strtotime($appointment_date));   
                    $data['web'] = 1; 
                    
                    $post_data = json_encode($data);  
                    $curl = url('/')."/api/save_booking";  
                  // echo "<pre>";print_r($post_data);exit;
                    $response = $this->commoncurl($curl,$post_data);                    
                    //Authenticates patient   
                   
                    if($response['success'] == 1){            
                  $get_email = Patient::select('patient_email','patient_first_name','patient_last_name')->where('patient_unique_id',$patient_id)->get();
                                   //Notification                
                        $msg = "You scheduled a new appointment ";  
                        $url = url('/patient/send_mail/'.str_replace(" ", "_", $msg).'/'.$patient_id.'');   
                        $cmd  = "curl --max-time 60 ";   
                        $cmd .= "'" . $url . "'";   
                        $cmd .= " > /dev/null 2>&1 &";    
                        exec($cmd, $output, $exit);  
                        // Appoitment
                    $login_token = PatientLoginToken::where('patient_id',$patient_id)->where('token_status',0)->get();

                    $msg = "You scheduled a new appointment "; 

                    $patients_notification = PatientNotificationSetting::where('patient_id', $patient_id)->first();
                    if(isset($patients_notification->patient_id)){
                    if($patients_notification->appointment_activity_push == 1){
                    if($login_token[0]['device_type'] != 2){            
                    $device_token = $login_token[0]['device_token'];
                    $path = base_path()."/ios_notifcation/all_notifications.php";
                    $nid = $response['id'];
                    $type= 'appt';
                    exec ('php '.$path.' "'.$msg.'" '.$nid.' '.$type.' '.$device_token.' > /dev/null &');
                    }
                    }
                    // Send message on phone

                  $message= $this->appointment_message($response['id'],$_POST['doctor_id'],2);
                   /* $doc_det = SaveTelemedicalBookingDetail::with('doctor','doctor.specialist_categories')->where('booking_id', $response['id'])->get();           
                    date_default_timezone_set($user->timezone);          
                    $date1=date("F d, Y",$doc_det[0]['appointment_time']);
                    $time_of= date("g:i A",$doc_det[0]['appointment_time']);
                    $doctor_details = Doctor::where('doctor_id',$_POST['doctor_id'])->first();
                    $message="Hello ".$user->patient_first_name.", \n ";
                    $message.="Your new hospital appointment is scheduled.\n ";
                    $message.="Here are the details:\n ";
                    if(!empty($doctor_details)){
                    $message.="Doctor: Dr.".$doctor_details->doctor_first_name." ".$doctor_details->doctor_last_name." \n ";
                    }
                    $message.="Date: ".$date1." \n ";
                    $message.="Time: ". $time_of." \n ";
                    $message.="For any queries, you can contact us at: contact@renderhealth.com \n "; */                         

                    $this->sendMessage($message,'+919781705177');    
                        }
                                 
                       return response()->json(['success'=>$response['success'],"message"=>$response['message'],"id"=>$response['id']],200);
                    }else{
                        return response()->json(['success'=>$response['success'],"message"=>$response['message']],200);
                    }
                }else{
                    return response()->json(['success'=>$response['success'],"message"=>$response['message']],200);
                }
            }else{
                return response()->json(['redirect'=>1,"redirect_url"=>asset('/patient/login')],200);
            }
        }else{
             $fetch_appointment=PatientAppointment::where('appointment_id',$_POST['appointment_id'])->get()->first();                     
             if($fetch_appointment->telemedical_consult_time==2)
            {
                $validator = Validator::make($_POST, [ 
                    'appointment_id'=>'required',                   
                    'doctor_id' => 'required'                       
                ]); 
            }else{
                 $validator = Validator::make($_POST, [              
                    'booking_name' => 'required',                       
                    'hospital_name' => 'required',                       
                    'mobile_number' => 'required',
                    'terms_conditions' => 'required',   
                    'symptoms' => 'required',                       
                ]);
            }
            if ($validator->fails()) { 
                $errorMsg=$validator->messages();               
                return response()->json(['success'=>0, 'message'=>$validator->messages()->first()], 200);            
            }

            $patient_id = Auth::user()->patient_unique_id;         
             $login_token = PatientLoginToken::where('patient_id',$patient_id)->where('token_status',1)->where('device_token',NULL)->first();   
             if(isset($login_token->login_token)){               
                $data['patient_id'] = $patient_id;          
                $data['login_token'] = $login_token->login_token;   
                $data['time_zone'] = $user->timezone;
                 if(isset($_POST['doctor_appoint_date'])){ 
                    $data['appointment_time'] = date('d-m-Y H:i:s',strtotime($_POST['doctor_appoint_date']));  
                }else{
                    $data['appointment_time'] = date('d-m-Y H:i:s'); 
                }   
                $data['web'] = 1;     
                if(!empty($_POST['health_diary'])){
                $health_diary = $_POST['health_diary'];
                }else{
                $health_diary = NULL;
                }
                 $post_data = json_encode($data); 
                 $curl = url('/')."/api/save_booking";  
                 $response = $this->commoncurl($curl,$post_data);   

                 
                //print_r($response); die; 
                //Authenticates patient
                if($response['success'] == 1){  
                   if($fetch_appointment->telemedical_consult_time != 2){
                       $doctors = $this->fetch_doctors($response['id']);
                      //print_r($doctors); die; 
                       if($doctors['success'] == 1){                            
                            $UserNotification = new UserNotification([                
                                'notification_id'   => $this->generateNUniqueNumber(),                                
                                'assignee_type'     => 4,                    
                                'patient_id'        => $patient_id, 
                                'event_id'          => $response['id'],
                                'notification_type' => "appt",
                                'change_type'       => "created",
                                'created_date'      => strtotime('now'),
                                'status'            => 0                                          
                            ]);
                            $UserNotification->save(); 

                            $login_token = PatientLoginToken::where('patient_id',$patient_id)->where('token_status',0)->get();

                            $msg = "You scheduled a new appointment "; 

                            $patients_notification = PatientNotificationSetting::where('patient_id', $patient_id)->first();
                            if(isset($patients_notification->patient_id)){
                                if($patients_notification->appointment_activity_push == 1){
                                    if( $login_token[0]['device_type'] != 2){            
                                        $device_token =$login_token[0]['device_token'];
                                        $path = base_path()."/ios_notifcation/all_notifications.php";
                                        $nid = $response['id'];
                                        $type= 'appt';
                                        exec ('php '.$path.' "'.$msg.'" '.$nid.' '.$type.' '.$device_token.' > /dev/null &');
                                    }
                                }

                                if($patients_notification->appointment_activity_email == 1){
                                    //send email notification
                                    $url = url('/patient/send_mail/'.str_replace(" ", "_", $msg).'/'.$patient_id.'');   
                                    $cmd  = "curl --max-time 60 ";   
                                    $cmd .= "'" . $url . "'";   
                                    $cmd .= " > /dev/null 2>&1 &";    
                                    exec($cmd, $output, $exit); 
                                }
                          // exit;
                            }
                      
                              // Send message on phone
                           $message= $this->appointment_message($response['id'],$_POST['doctor_id'],1);
                            //$message='You scheduled a new telemedical appointment'; 
                            $this->sendMessage($message,'+919781705177'); 
                            $doc_det = SaveTelemedicalBookingDetail::with('doctor','doctor.specialist_categories')->where('booking_id', $response['id'])->get();
                            $doc_name = "Dr. ".$doc_det[0]->doctor->doctor_first_name." ".$doc_det[0]->doctor->doctor_last_name.", ".$doc_det[0]->doctor->doctor_degree; 
                            $doc_spe = $doc_det[0]->doctor->specialist_categories->speciality_name;
                            return response()->json(['success'=>$doctors['success'],"message"=>$response['message'],"id"=>$response['id'],'doc_name'=>$doc_name,'doc_pic'=>$doc_det[0]->doctor->doctor_picture,'doc_spe'=>$doc_spe],200);
                        }else{ 

                            return response()->json(['success'=>$doctors['success'],"message"=>$doctors['message'],"id"=>$response['id']],200); 
                        }
                    }else{
                        $UserNotification = new UserNotification([                
                            'notification_id'   => $this->generateNUniqueNumber(),                                
                            'assignee_type'     => 4,                    
                            'patient_id'        => $patient_id, 
                            'event_id'          => $response['id'],
                            'notification_type' => "appt",
                            'change_type'       => "created",
                            'created_date'      => strtotime('now'),
                            'status'            => 0
                         

                        ]);
                        $UserNotification->save(); 

                        $login_token = PatientLoginToken::where('patient_id',$patient_id)->where('token_status',0)->get();

                         if($fetch_appointment->appointment_type == 2){
                            $msg = "You scheduled a new hospital appointment"; 
                        }else{
                            $msg = "You scheduled a new telemedical appointment";
                        }

                        $patients_notification = PatientNotificationSetting::where('patient_id', $patient_id)->first();
                        if(isset($patients_notification->patient_id)){
                            if($patients_notification->appointment_activity_push == 1){
                                if( $login_token[0]['device_type'] != 2){            
                                    $device_token =$login_token[0]['device_token'];
                                    $path = base_path()."/ios_notifcation/all_notifications.php";
                                    $nid = $response['id'];
                                    $type= 'appt';
                                    exec ('php '.$path.' "'.$msg.'" '.$nid.' '.$type.' '.$device_token.' > /dev/null &');
                                }
                            }

                            if($patients_notification->appointment_activity_email == 1)
                                //send email notification
                                $url = url('/patient/send_mail/'.str_replace(" ", "_", $msg).'/'.$patient_id.'');   
                                $cmd  = "curl --max-time 60 ";   
                                $cmd .= "'" . $url . "'";   
                                //$cmd .= " > /dev/null 2>&1 &";    
                                exec($cmd, $output, $exit); 
                            }
                              // Send message on phone
                              $message= $this->appointment_message($response['id'],$_POST['doctor_id'],1);
                            $this->sendMessage($message,'+919781705177'); 

                        return response()->json(['success'=>$response['success'],"message"=>$response['message'],"id"=>$response['id']],200);
                    }
                }else{
                    return response()->json(['success'=>$response['success'],"message"=>$response['message']],200);
                }
            }else{
                return response()->json(['redirect'=>1,"redirect_url"=>asset('/patient/login')],200);
            }
        }        
        
    }

     /******
    Check if any call is going on or not
    *******/
    public function checkAppointConnection(Request $request){
        $value = Session::get('token');
        $patient_id = Auth::user()->patient_unique_id;
        $login_token =PatientLoginToken::where(array('patient_id'=>$patient_id,'login_token'=>$value))->first();        
        if(isset($login_token->token_status) && $login_token->token_status == 0){ 
            Auth::guard('patient')->logout();           
            return response()->json(['redirect'=>1,"redirect_url"=>asset('/patient/login')],200);
        }
        if(!Auth::check()){            
            return response()->json(['redirect'=>1,"redirect_url"=>asset('/patient/login')],200);
        }
        $user = $request->user();      

        $status = SaveTelemedicalBookingDetail::where('patient_id',$patient_id)->where('call_status','=',1)->count();

        $doc_det = SaveTelemedicalBookingDetail::with(array('doctor','patient_appoint','call_det'=>function($q) {$q->where('patient_call_status',1)->orderBy('id','DESC')->limit(1);}))->where('call_status','=',1)->where('patient_id',$patient_id)->where('allowed_status','>',0)->get();  

        //echo "<prE>"; print_R($doc_det); exit;    
        $call_status = 0;
        if($status > 0){
            $call_status = 1;        
            $doc_name = "Dr. ".$doc_det[0]->doctor->doctor_first_name." ".$doc_det[0]->doctor->doctor_last_name;  
            
            return response()->json(['success'=>1,'status'=>$call_status,'doc_name'=>$doc_name,'doc_pic'=>$doc_det[0]->doctor->doctor_picture,'appoint_det'=>$doc_det[0]],200);  
        }else{
            return response()->json(['success'=>1,'status'=>$call_status],200);  
        }       
        
        
    }//Ends of call connection function

    /******
    Check if call is going on or not for particular appointment
    *******/
    public function checkConnection(Request $request){
        $value = Session::get('token');
        $patient_id = Auth::user()->patient_unique_id;
        $login_token =PatientLoginToken::where(array('patient_id'=>$patient_id,'login_token'=>$value))->first();        
        if(isset($login_token->token_status) && $login_token->token_status == 0){ 
            Auth::guard('patient')->logout();           
            return response()->json(['redirect'=>1,"redirect_url"=>asset('/patient/login')],200);
        }
        if(!Auth::check()){            
            return response()->json(['redirect'=>1,"redirect_url"=>asset('/patient/login')],200);
        }
        

        $patient_appoint = SaveTelemedicalBookingDetail::where('appointment_id',$_POST['appoint_id'])->get(); 
        if(count($patient_appoint) > 0){
         return response()->json(['success'=>1,"appoint"=>$patient_appoint[0]->call_status],200);
        }else{
            return response()->json(['success'=>0],200);
        }
    }//Ends of specific call connection function

    /******
    Update status on call diconnect
    *******/
    public function disconnectConnectStatus(Request $request){
        $value = Session::get('token');
        $patient_id = Auth::user()->patient_unique_id;
        $login_token =PatientLoginToken::where(array('patient_id'=>$patient_id,'login_token'=>$value))->first();        
        if(isset($login_token->token_status) && $login_token->token_status == 0){ 
            Auth::guard('patient')->logout();           
            return response()->json(['redirect'=>1,"redirect_url"=>asset('/patient/login')],200);
        }
        if(!Auth::check()){            
            return response()->json(['redirect'=>1,"redirect_url"=>asset('/patient/login')],200);
        }
        $user = $request->user();      

        SaveTelemedicalBookingDetail::where('appointment_id',$_POST['appoint_id'])->update(['call_status'=>0,'allowed_status'=>0]);

        return response()->json(['success'=>1], 200);        
    }//Ends of diconnect function

     /******
    Calling Patient view screen
    *******/
    public function callingPatient(Request $request,$call_id,$a_id,$id,$p_id,$type){          
        $value = Session::get('token');
        $patient_id = Auth::user()->patient_unique_id;
        $login_token =PatientLoginToken::where(array('patient_id'=>$patient_id,'login_token'=>$value))->first();

        if(isset($login_token->token_status) && $login_token->token_status == 0){ 
            Auth::guard('patient')->logout();           
            return redirect('/patient/login');
        }
        if(!Auth::check()){            
            return redirect('/patient/login');
        }         
        $user = $request->user();        
       
        $doctor_details = Doctor::where('doctor_id',$id)->first();
        $data = Doctor::where('doctor_id', $id)->first();
        $call_status = CallSession::where('call_id',$call_id)->first();

        CallSession::where('call_id',$call_id)->where('appoint_id',$a_id)->where('patient_id',$p_id)->update(['patient_call_status'=>0]);
        
        $patient_details = Patient::where('patient_unique_id',$p_id)->first();
        if(isset($call_status->call_id) && $call_status->patient_call_status == 0){          
            SaveTelemedicalBookingDetail::where('appointment_id',$a_id)->update(['call_status'=>0,'allowed_status'=>0]); 
            // $device_token = '86C6E590D8839FE6A8584AD8546CC94561FBF21E9DBE92F82784E85A5F2B0823';    
            // $path = "/var/www/html/projects/renderhealth/ios_notifcation/silent_notify.php";    
            //exec ('php '.$path.' '.$a_id.' '.$device_token.' > /dev/null &');  
            return view('patient.tokbox')->with(array('expire'=>1,'controller'=> 'doctor','sessionId'=>$data->doctor_tokbox_id,'token'=>$data->doctor_tokbox_token,'page'=>'inner','type'=>$type,'a_id'=>$a_id,'d_id'=>$id,'call_id'=>$call_id,'patient_details'=>$patient_details));
        }
        SaveTelemedicalBookingDetail::where('appointment_id',$a_id)->update(['call_status'=>4]);
        return view('patient.tokbox')->with(array('controller'=> 'doctor','sessionId'=>$data->doctor_tokbox_id,'token'=>$data->doctor_tokbox_token,'page'=>'inner','type'=>$type,'a_id'=>$a_id,'d_id'=>$id,'call_id'=>$call_id,'doctor_details'=>$doctor_details,'patient_details'=>$patient_details));
    }//Ends calling patient functio   

    /******
    Update Tiemzone
    *******/ 
    public function updateTimeZone(Request $request,$time_zone,$dst){
        $value = Session::get('token');
        $patient_id = Auth::user()->patient_unique_id;
        $login_token =PatientLoginToken::where(array('patient_id'=>$patient_id,'login_token'=>$value))->first();        
        if(isset($login_token->token_status) && $login_token->token_status == 0){ 
            Auth::guard('patient')->logout();           
            return response()->json(['redirect'=>1,"redirect_url"=>asset('/patient/login')],200);
        }
        if(!Auth::check()){            
            return response()->json(['redirect'=>1,"redirect_url"=>asset('/patient/login')],200);
        } 
        $user = $request->user();
        $patient_id = Auth::user()->patient_unique_id;
        if($dst == 1){
             $time_zone_name = timezone_name_from_abbr("", $time_zone*60,1); 
             if(empty($time_zone_name)){
                $time_zone_name = timezone_name_from_abbr("", $time_zone*60,0); 
             }
        }else{
            $time_zone_name = timezone_name_from_abbr("", $time_zone*60,1); 

             if(empty($time_zone_name)){
                $time_zone_name = timezone_name_from_abbr("", $time_zone*60,0); 

             }
        }            
        
        if(!empty($time_zone_name)){            
            $update_time = Patient::where('patient_unique_id',$patient_id)->update(['timezone'=>$time_zone_name]);
        }
        return response()->json(['success'=>1,"redirect_url"=>route('patient.dashboard')], 200);      
    }

    /******
    Hospital Appointment
    *******/ 
    public function hospitalAppointment(Request $request,$id){
        $value = Session::get('token');
        $patient_id = Auth::user()->patient_unique_id;
        $login_token =PatientLoginToken::where(array('patient_id'=>$patient_id,'login_token'=>$value))->first();        
        if(isset($login_token->token_status) && $login_token->token_status == 0){ 
            Auth::guard('patient')->logout();           
            return redirect('/patient/login');
        }
        if(!Auth::check()){            
            return redirect('/patient/login');
        } 
        $user = $request->user();
        $patient_id = Auth::user()->patient_unique_id;
        $hospitals = Hospital::orderBy('hosp_name','ASC')->get();
        $health_diaries=PatientHealthDiary::where(array('patient_id'=>$patient_id,))->orderBy('id','DESC')->get();
        return view('patient.hospital_appointment')->with(array('controller'=> 'patient','user'=>$user,'page'=>'inner','page_type'=>'extra_links','hospitals'=>$hospitals,'hosp_id'=>$id,"health_diaries"=>$health_diaries));

    }

    /******
    Hospital Doctor Listing
    *******/ 
    public function hospitalDoctorListing(Request $request,$id){
        // dd($id);
    	$value = Session::get('token');
        $patient_id = Auth::user()->patient_unique_id;
        $login_token =PatientLoginToken::where(array('patient_id'=>$patient_id,'login_token'=>$value))->first();        
        if(isset($login_token->token_status) && $login_token->token_status == 0){ 
            Auth::guard('patient')->logout();           
            return response()->json(['redirect'=>1,"redirect_url"=>asset('/patient/login')],200);
        }
        if(!Auth::check()){            
            return response()->json(['redirect'=>1,"redirect_url"=>asset('/patient/login')],200);
        } 

         $user = $request->user();     
      /* $validate= $this->validator($request->all())->validate();*/
         $data=$_POST;                  
         $login_token = PatientLoginToken::where('patient_id',$patient_id)->where('token_status',1)->where('device_token',NULL)->first();   
         if(isset($login_token->login_token)){
            $data['patient_id'] = $patient_id;          
            $data['login_token'] = $login_token->login_token;   
            $data['time_zone'] = $user->timezone;
            $data['hosp_id']= $id; 
            $data['web'] = 1;     
            $data['date'] = date('Y-m-d',strtotime('now'));
            $post_data = json_encode($data);  
            $curl = url('/')."/api/hospital_doctors";  
            $response = $this->commoncurl($curl,$post_data);               

            $dtz = new DateTimeZone($user->timezone);     
            $date = date('Y-m-d',strtotime($data['date']));               
            $next_date = date('Y-m-d', strtotime('+1 day', strtotime($date)));
            $time_in_sofia = new DateTime($date, $dtz);        
            $date_offset = $time_in_sofia->format('Z');       
            $start_time = strtotime($date)-$date_offset;            
            $end_time = strtotime($next_date)-$date_offset;
            
            $doc_appoint_listing=SaveTelemedicalBookingDetail::where('save_telemedical_booking_detail.approved_status','!=',2)->where('save_telemedical_booking_detail.appointment_time','>=',$start_time)->where('save_telemedical_booking_detail.appointment_time','<',$end_time)->orderBy('save_telemedical_booking_detail.appointment_time','ASC')->get();
            //Authenticates patient
           // print_r($doc_appoint_listing); 
            /*oreach($doc_appoint_listing as $doc_appoint){ 
                echo date('H:i',$doc_appoint['appointment_time']);
            }
            die;*/
            $hospital_doctors = array();
            if(isset($response['data'])){
                $hospital_doctors = $response['data'];
            }
            if($response['success'] == 1 || $response['success'] == 0){  
                return view('patient.hospital_doctors')->with(array('controller'=> 'patient','user'=>$user,'page'=>'inner','page_type'=>'extra_links','hospital_doctors'=>$hospital_doctors,'timezone'=>$user->timezone,'doc_appoint_listing'=>$doc_appoint_listing,'hosp_id'=>$id,'hosp_date'=>$data['date']));
            }
        }else{
            return response()->json(['redirect'=>1,"redirect_url"=>asset('/patient/login')],200);
        }

    }

    /******
    Doctor Availability Listing
    *******/ 
    public function doctorAvailabilityListing(Request $request,$id,$date,$key){
        
        $value = Session::get('token');
        $patient_id = Auth::user()['patient_unique_id']?Auth::user()['patient_unique_id']:'';
        
        $user = $request->user();     
      /* $validate= $this->validator($request->all())->validate();*/
         $data=$_POST;                  
        //  $login_token = PatientLoginToken::where('patient_id',$patient_id)->where('token_status',1)->where('device_token',NULL)->first();   
        //  if(isset($login_token->login_token)){
            $data['patient_id'] = $patient_id;          
            $data['login_token'] = time()."123";   
            $data['time_zone'] = isset($user)?$user->timezone:date_default_timezone_get();
            $data['doctor_id']= $id; 
            $data['type']= 2; 
            $data['web'] = 1;     
            if(!isset($date) || empty($date)){
               $data['appoint_date'] = date('Y-m-d',strtotime('now'));
            }else{
                $data['appoint_date'] = date('Y-m-d',strtotime($date));
            }
            $post_data = json_encode($data);  
            $curl = url('/')."/api/availability_listing_new";  
            $response = $this->commoncurl($curl,$post_data);
            // dd($response);
            $dtz = new DateTimeZone(isset($user)?$user->timezone:date_default_timezone_get());     
            $date = date('Y-m-d',strtotime($data['appoint_date']));               
            $next_date = date('Y-m-d', strtotime('+1 day', strtotime($date)));
            $time_in_sofia = new DateTime($date, $dtz);        
            $date_offset = $time_in_sofia->format('Z');       
            $start_time = strtotime($date)-$date_offset;            
            $end_time = strtotime($next_date)-$date_offset;
            $doctors_availability = array();
            if(isset($response['data'])){
                $doctors_availability = $response['data'];
            }
            ////


            



            ////
            $dtz = new DateTimeZone(isset($user)?$user->timezone:date_default_timezone_get());     
            $date = date('Y-m-d H:i:s',strtotime($data['appoint_date']));                  
            $time_in_sofia = new DateTime($date, $dtz);        
            $date_offset = $time_in_sofia->format('Z');       
            $appointment_time = strtotime($date)-$date_offset;
            $booking_exists=SaveTelemedicalBookingDetail::where('save_telemedical_booking_detail.approved_status','!=',2)->where('save_telemedical_booking_detail.appointment_time','>=',$start_time)->where('save_telemedical_booking_detail.appointment_time','<',$end_time)->where('save_telemedical_booking_detail.patient_id',$patient_id)->where('approved_status','!=',2)->get();
            $main_time = [];
            foreach($doctors_availability as $avaKey => $Doctorvalue){
                foreach($booking_exists as $key =>$value){
                    if($Doctorvalue['availability_time']===date("H:i A",$value['appointment_time'])){
                        $doctors_availability[$avaKey]['time_status'] = 1;  
                    }
                }
            }
            //Authenticates patient
            $doc_appoint_listing=SaveTelemedicalBookingDetail::where('save_telemedical_booking_detail.approved_status','!=',2)->where('save_telemedical_booking_detail.appointment_time','>=',$start_time)->where('save_telemedical_booking_detail.appointment_time','<',$end_time)->orderBy('save_telemedical_booking_detail.appointment_time','ASC')->get();
            if($response['success'] == 1 || $response['success'] == 0){  
                return view('patient.doctors_availability')->with(array('controller'=> 'patient','user'=>isset($user)?$user:'','page'=>'inner','page_type'=>'extra_links','doctors_availability'=>$doctors_availability,'timezone'=>isset($user)?$user->timezone:date_default_timezone_get(),'doc_appoint_listing'=>$doc_appoint_listing,'doct_id'=>$id,'hosp_date'=>$data['appoint_date'], 'key'=>$key));
            }
        // }else{
        //     return response()->json(['redirect'=>1,"redirect_url"=>asset('/patient/login')],200);
        // }

    }

    /******
    Doctor Availability Listing Login
    *******/ 
    public function doctorAvailabilityListingLogin(Request $request,$id,$date,$key,$patient_id){
        $value = Session::get('token');
        // $patient_id = Auth::user()['patient_unique_id']?Auth::user()['patient_unique_id']:'';
        
        $user = $request->user();     
      /* $validate= $this->validator($request->all())->validate();*/
         $data=$_POST;                  
        //  $login_token = PatientLoginToken::where('patient_id',$patient_id)->where('token_status',1)->where('device_token',NULL)->first();   
        //  if(isset($login_token->login_token)){
            $data['patient_id'] = $patient_id;          
            $data['login_token'] = time()."123";   
            $data['time_zone'] = isset($user)?$user->timezone:date_default_timezone_get();
            $data['doctor_id']= $id; 
            $data['type']= 2; 
            $data['web'] = 1;     
            if(!isset($date) || empty($date)){
               $data['appoint_date'] = date('Y-m-d',strtotime('now'));
            }else{
                $data['appoint_date'] = date('Y-m-d',strtotime($date));
            }
            $post_data = json_encode($data);  
            $curl = url('/')."/api/availability_listing_new";  
            $response = $this->commoncurl($curl,$post_data);
            // dd($response);
            $dtz = new DateTimeZone(isset($user)?$user->timezone:date_default_timezone_get());     
            $date = date('Y-m-d',strtotime($data['appoint_date']));               
            $next_date = date('Y-m-d', strtotime('+1 day', strtotime($date)));
            $time_in_sofia = new DateTime($date, $dtz);        
            $date_offset = $time_in_sofia->format('Z');       
            $start_time = strtotime($date)-$date_offset;            
            $end_time = strtotime($next_date)-$date_offset;
            $doctors_availability = array();
            if(isset($response['data'])){
                $doctors_availability = $response['data'];
            }
            ////


            



            ////

            $dtz = new DateTimeZone(isset($user)?$user->timezone:date_default_timezone_get());     
            $date = date('Y-m-d H:i:s',strtotime($data['appoint_date']));                  
            $time_in_sofia = new DateTime($date, $dtz);        
            $date_offset = $time_in_sofia->format('Z');       
            $appointment_time = strtotime($date)-$date_offset;

            $appoint_det = PatientAppointment::where('patient_id',$patient_id)->get();
            // foreach($doctors_availability as $avaKey => $Doctorvalue){
                foreach($appoint_det as $keyappoint => $valueappoint){
                    $booking_exists=SaveTelemedicalBookingDetail::where('save_telemedical_booking_detail.patient_id',$patient_id)->where('appointment_id','!=',$valueappoint['appointment_id'])->where('approved_status','!=',2)->get();
                    foreach($booking_exists as $key =>$value){
                        // dd(date("H:i a",$valueappoint['appointment_time']));
                        // echo "Doctorvalue:".$Doctorvalue['availability_time']."<br>";
                        // echo "appointment_time:".date("H:i a",$value['appointment_time'])."<br>";
                        // if($Doctorvalue['availability_time']===date("H:i a",$value['appointment_time'])){
                           
                        //     $doctors_availability[$avaKey]['time_status'] = 1;  
                        // }
                    }
                }
            // }
           
            
            $main_time = [];
            
            $doctor_details = Doctor::where('doctor_id',$id)->first();
            $time_zone = $doctor_details->doctor_timezone;
            $dtz = new DateTimeZone($time_zone);     
            $date = date('Y-m-d',strtotime($data['appoint_date']));   
            $next_date = date('Y-m-d', strtotime('+1 day', strtotime($date)));
            $time_in_sofia = new DateTime($date, $dtz);        
            $date_offset = $time_in_sofia->format('Z');       
            $start_time = strtotime($date)-$date_offset;
            $end_time = strtotime($next_date)-$date_offset;
            //Authenticates patient
            $doc_appoint_listing=SaveTelemedicalBookingDetail::where('save_telemedical_booking_detail.approved_status','!=',2)->where('save_telemedical_booking_detail.appointment_time','>=',$start_time)->where('save_telemedical_booking_detail.appointment_time','<',$end_time)->orderBy('save_telemedical_booking_detail.appointment_time','ASC')->get();
            // dd($doc_appoint_listing);
           
            if($response['success'] == 1 || $response['success'] == 0){  
                return view('patient.doctors_availability')->with(array('controller'=> 'patient','user'=>isset($user)?$user:'','page'=>'inner','page_type'=>'extra_links','doctors_availability'=>$doctors_availability,'timezone'=>isset($user)?$user->timezone:date_default_timezone_get(),'doc_appoint_listing'=>$doc_appoint_listing,'doct_id'=>$id,'hosp_date'=>$data['appoint_date'], 'key'=>$key));
            }
        // }else{
        //     return response()->json(['redirect'=>1,"redirect_url"=>asset('/patient/login')],200);
        // }

    }

    /******
    send Mail
    *******/
    public function sendMail($msg,$p_id){        
        $msg = str_replace("_", " ", $msg);       
        //send email notification        
        $get_email = Patient::select('patient_email')->where('patient_unique_id',$p_id)->get();

        if($get_email[0]->patient_email!='')
        {
            $email = $get_email[0]->patient_email;
            $send_email_from = $_ENV['send_email_from'];
            $res = Mail::send([], [], function ($message) use($email,$send_email_from,$msg){
                $message->to($email)->from($send_email_from)->subject('Render Health')->setBody($msg); 
            });
        }
    }
     /******
    send  Template Mail
    *******/
    public function sendMailTemplate($p_id,$history_id){        
       $msg="You scheduled Hospital appointment";
        //send email notification        
        $get_email = Patient::select('patient_email')->where('patient_unique_id',$p_id)->get();

        if($get_email[0]->patient_email!='')
        {
            $email = "harpreet.k1@iapptechnologies.com";
            $send_email_from = $_ENV['send_email_from'];
             //$appoint_listing=SaveTelemedicalBookingDetail::with("doctor","patient_appoint","doctor.specialist_categories","hospital_detail")->select("*")->where('save_telemedical_booking_detail.appointment_id',$appointment_id)->get();
            $res = Mail::send([],[], function ($message) use($email,$send_email_from,$msg){
                $message->to($email)->from($send_email_from)->subject('Render Health')->setBody($msg); 
            });
           // print_r( $res);
        }
    }

    /******
    Fetch doctor
    *******/
    protected function fetch_doctors($id){
        $value = Session::get('token');
        $patient_id = Auth::user()->patient_unique_id;
        $login_token =PatientLoginToken::where(array('patient_id'=>$patient_id,'login_token'=>$value))->first();        
        if(isset($login_token->token_status) && $login_token->token_status == 0){ 
            Auth::guard('patient')->logout();           
            return response()->json(['redirect'=>1,"redirect_url"=>asset('/patient/login')],200);
        }
        if(!Auth::check()){            
            return response()->json(['redirect'=>1,"redirect_url"=>asset('/patient/login')],200);
        } 
        
        $data = array();
        $patient_id = Auth::user()->patient_unique_id;               
        $login_token = PatientLoginToken::where('patient_id',$patient_id)->where('token_status',1)->where('device_token',NULL)->first();

        if(isset($login_token->login_token)){ 
            $data['time'] = date("H:i",strtotime('09:00'));    
            $data['patient_id'] = $patient_id;
            $data['booking_id'] = $id;          
            $data['login_token'] = $login_token->login_token;                     
            $post_data = json_encode($data);  
             
            $curl = url('/')."/api/fetch_doctor";  
            $response = $this->commoncurl($curl,$post_data);            
            return $response;
        }else{
            return response()->json(['redirect'=>1,"redirect_url"=>asset('/patient/login')],200);
        }
    }



    private function commoncurl($url,$post_data){
        $ch1 = curl_init();       
        curl_setopt($ch1, CURLOPT_URL,$url);
        curl_setopt($ch1, CURLOPT_HEADER, 0);
        curl_setopt($ch1, CURLOPT_POST, 1);
        curl_setopt($ch1, CURLOPT_POSTFIELDS, $post_data);  
        curl_setopt($ch1, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch1, CURLOPT_SSL_VERIFYPEER, 0);
        $output = curl_exec($ch1);  
        //echo "<pre>"; print_R($output);
        curl_close ($ch1);
        $output= json_decode($output,true);
        
        return $output;
    } 

    protected function generateNUniqueNumber() {
        $number = mt_rand(1000000000, 9999999999); // better than rand()
        // call the same function if the uniwue id exists already
        if ($this->uniqueNNumberExists($number)) {
            return $this->generateNUniqueNumber();
        }
        // otherwise, it's valid and can be used
        return strval($number);
    }

    protected function uniqueNNumberExists($number) {
        // query the database and return a boolean         
        return UserNotification::wherenotification_id($number)->exists();
    }
     // Send messsage to user
      private function sendMessage($message, $recipients)
        {
        $account_sid = getenv("TWILIO_SID");
        $auth_token = getenv("TWILIO_AUTH_TOKEN");
        $twilio_number = getenv("TWILIO_NUMBER");
        $client = new Client($account_sid, $auth_token);

       /* $validation_request = $client->validationRequests
        ->create($recipients, // phoneNumber
        array(
        "friendlyName" => "Newuser"
        )
        );
        print($validation_request);
        if(!empty($validation_request->friendlyName)){*/
        $client->messages->create($recipients, ['from' => $twilio_number, 'body' => $message]);
  // }
       return 1;
    }
protected function appointment_message($booking_id,$doctor_id,$type){
$message="";
if($type==2){
$app="hospital";
}else{
  $app="telemedical";
}
$patient_first_name = Auth::user()->patient_first_name;
$patient_timezone = Auth::user()->timezone;
$doc_det = SaveTelemedicalBookingDetail::with('doctor','doctor.specialist_categories')->where('booking_id', $booking_id)->get();
date_default_timezone_set($patient_timezone);          
$date1=date("F d, Y",$doc_det[0]['appointment_time']);
$time_of= date("g:i A",$doc_det[0]['appointment_time']);
$doctor_details = Doctor::where('doctor_id',$doctor_id)->first();
$message="Hello ".$patient_first_name.", \n ";
$message.="Your new ".$app." appointment is scheduled.\n ";
$message.="Here are the details:\n ";
if(!empty($doctor_details)){
$message.="Doctor: Dr.".$doctor_details->doctor_first_name." ".$doctor_details->doctor_last_name." \n ";
}
$message.="Date: ".$date1." \n ";
$message.="Time: ". $time_of." \n ";
$message.="For any queries, you can contact us at: contact@renderhealth.com \n ";  
return $message;
}
   
 
// Get information of Users (Nurse, Doctor & Administrator)
public function ViewDoctor(Request $request)
{

    try
    {
        $doctor_id = isset($request->doctor_id) ? $request->doctor_id:'';
        $getData = array();
        if($request->doctor_id){
            $getData = Doctor::where(['doctor_id' => $doctor_id])->first(); 
        }else
        {
            $getData = NULl;
        }

        if(!empty($getData))
        {
            return response()->json(['error'=>0,"message"=>'Data has been find successfully!','data' => $getData],200); 
        }else
        {
            return response()->json(['error'=>1,"message"=>'Data not found!','data' => []],200); 
        }
    }
    catch(Exception $e)
    {
        return response()->json(['error'=>1,"message"=>'Invalid Request. Please try again!','data' => []],200);   
    }
}
}