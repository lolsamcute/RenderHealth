<?php
namespace App\Http\Controllers\Patient;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Auth;
use DB;
use Hash;
use Validator;
use DateTime;
use DateTimeZone;
use Session;
use App\Models\PatientLoginToken;
use App\Models\Patient;
use App\Models\Hospital;
use App\Models\PatientsDependent;
use App\Models\Doctor;
use App\Models\SaveTelemedicalBookingDetail;
use App\Models\PatientAppointment;
use App\Models\SpecialistCategories;
use App\Models\PatientNotificationSetting;
use App\Models\HealthHistory;
use App\Models\BillingDetail;
use App\Models\UserNotification;
use App\Models\StatesNigeria;
use App\Models\LocalGovernment;
use PDF;
use Mail;
use Swift_Attachment;
use ZipArchive;
class PatientPagesController extends Controller
{
  /**
  * Create a new controller instance.
  *
  * @return void
  */
  public function __construct()
  {
      $this->middleware('auth:patient');
      //date_default_timezone_set("Asia/Kolkata");
  }
  /**
  * Show the application dashboard.
  *
  * @return \Illuminate\Http\Response
  */

  /******
  Patient profile view
  *******/
  public function myProfile(Request $request){
    try
    {
      $value = Session::get('token');
      $patient_id = Auth::user()->patient_unique_id;
      $login_token =PatientLoginToken::where(array('patient_id'=>$patient_id,'login_token'=>$value))->first();        
      if(isset($login_token->token_status) && $login_token->token_status == 0){ 
        Auth::guard('patient')->logout();           
        return redirect('/patient/login');
      }
      if(!Auth::check()){            
        return redirect('/patient/login');
      }
      $user = $request->user();      
      $myprofile = Patient::where('patient_unique_id', $patient_id)->get();
      $appointment_count = SaveTelemedicalBookingDetail::where('patient_id',$patient_id)->count();
      $history_count = HealthHistory::where('patient_id',$patient_id)->count();
      return view('patient.my_profile')->with(array('controller'=> 'pages','user'=>$user,'page'=>'dashboard','page_type'=>'settings','myprofile'=>$myprofile,'apt_cnt'=>$appointment_count,'hstry_cnt'=>$history_count));
    }catch(Exception $e) {
            echo 'Message: ' .$e->getMessage(); 
    }  
  }

  /******
  Patient notification view
  *******/
  public function notifications(Request $request){
    try
    {  
      $value = Session::get('token');
      $patient_id = Auth::user()->patient_unique_id;
      $login_token =PatientLoginToken::where(array('patient_id'=>$patient_id,'login_token'=>$value))->first();        
      if(isset($login_token->token_status) && $login_token->token_status == 0){ 
        Auth::guard('patient')->logout();           
        return redirect('/patient/login');
      }
      if(!Auth::check()){            
        return redirect('/patient/login');
      }
      $user = $request->user();
      $notifications=UserNotification::with('doctor','nurse','employee','hospital','patient')->where('patient_id',$patient_id)->orderBy('created_date','DESC')->paginate(10);

      foreach($notifications as $notify)
      {
          UserNotification::where('notification_id', $notify['notification_id'])->update(['status' => 1]);
      } 

      if($request->ajax()){        
        return view('patient.notifications_inner')->with(array('controller'=> 'pages','user'=>$user,'page'=>'dashboard','page_type'=>'settings','notifications'=>$notifications));
      }else{        
        return view('patient.notifications')->with(array('controller'=> 'pages','user'=>$user,'page'=>'dashboard','page_type'=>'settings','notifications'=>$notifications));
      }
    }catch(Exception $e) {
      echo 'Message: ' .$e->getMessage(); 
    }    
  } 

  /******
  Patient settings view
  *******/
  public function settings(Request $request){
    $value = Session::get('token');
    $patient_id = Auth::user()->patient_unique_id;
    $login_token =PatientLoginToken::where(array('patient_id'=>$patient_id,'login_token'=>$value))->first();       
    if(isset($login_token->token_status) && $login_token->token_status == 0){ 
      Auth::guard('patient')->logout();           
      return redirect('/patient/login');
    }
    if(!Auth::check()){            
      return redirect('/patient/login');
    }
    $user = $request->user();
    $current_user_id = Auth::user()->id;
    $patient = Patient::where('id', $current_user_id)->get();
    $patients_notification = PatientNotificationSetting::where('patient_id', $current_user_id)->get();
    $hospitals = Hospital::get();
    $hospitals_dependent = PatientsDependent::where('patients_id', $current_user_id)->get();
    $statesNigeria = StatesNigeria::all();
    $state = StatesNigeria::where('name',$patient[0]->patient_state)->first();
    $LocalGovernment = LocalGovernment::where('state_id',isset($state->id)?$state->id:'')->get();
    $patient[0]['localGovernment'] = $LocalGovernment;
    return view('patient.settings')->with(array('controller'=> 'pages','user'=>$user,'page'=>'dashboard','page_type'=>'settings','patient'=>$patient,'patients_notification'=>$patients_notification,'hospitals'=>$hospitals,'hospitals_dependent'=>$hospitals_dependent,'statesNigeria'=>$statesNigeria));
  } 

  /******
  Patient update profile
  *******/
  public function profile(Request $request){
    try{
      
      $value = Session::get('token');
      $patient_id = Auth::user()->patient_unique_id;
      $login_token =PatientLoginToken::where(array('patient_id'=>$patient_id,'login_token'=>$value))->first();        
      if(isset($login_token->token_status) && $login_token->token_status == 0){ 
        Auth::guard('patient')->logout();           
        return response()->json(['redirect'=>1,"redirect_url"=>asset('/patient/login')],200);
      }
      if(!Auth::check()){            
        return response()->json(['redirect'=>1,"redirect_url"=>asset('/patient/login')],200);
      }
      $image = $request->file('images');
      $date = $request->input('day');
      $month = $request->input('month');
      $month = date('m',strtotime($month));
      $year = $request->input('years');
      $patient_dob = $year.'/'.$month.'/'.$date;
      $patient_dob= strtotime($patient_dob); 
      $validator = Validator::make($request->all(),[
        'patient_first_name'=>'required',
        'patient_middle_name'=>'required',
        'patient_last_name'=>'required',
        'patient_email'=>'required',
        'patient_phone'=>'required',
        'emergency_phone'=>'required',
        'gender'  => 'required',
        'patient_address'=>'required',
        'languages'=>'required',
        'patient_origin_state'=>'required',
        'religion'=>'required',
        'patient_insurance'=>'required',
        'patient_visited_hospital'=>'required',
        'images'=>'image|max:2000'
        ], [
          'images.max' => 'Image size should be as less then 2 Mb',
        ]);

      if($validator->fails()){
          return response()->json(['success'=>0, 'message'=>$validator->messages()->first()], 200);
      }else{
        if(isset($image)){
          $image = time().'.'.$image->getClientOriginalExtension();
          $destinationPath = public_path().'/uploads/patient';
          $request->file('images')->move($destinationPath, $image);
          Patient::where('id', $request->input('profile_id'))->update([        
          'patient_first_name'      => $request->input('patient_first_name'),
          'patient_middle_name'      => $request->input('patient_middle_name'),
          'patient_last_name'       => $request->input('patient_last_name'),
          'patient_email'           => $request->input('patient_email'),
          'patient_phone'           => $request->input('patient_phone'),
          'emergency_phone'           => $request->input('emergency_phone'),
          'patient_martial_status'  => $request->input('patient_martial_status'),
          'patient_address'         => $request->input('patient_address'),
          'patient_date_of_birth'   => $patient_dob,
          'patient_gender'          => $request->input('gender'),
          'religion'          => $request->input('religion'),
          'patient_origin_state'    => $request->input('patient_origin_state'),
          'patient_languages'       => $request->input('languages'),
          'patient_insurance'       => $request->input('patient_insurance'),
          'next_first_name'          => $request->input('next_first_name'),
          'next_surname'          => $request->input('next_surname'),
          'next_phone'          => $request->input('next_phone'),
          'patient_visited_hospital' => $request->input('patient_visited_hospital'),
          'patient_state'       => $request->input('patient_state'),
          'lga'       => $request->input('lga'),
          'patient_city'          => $request->input('patient_city'),
          'patient_profile_img'     =>$image
          ]);
        }else{
          Patient::where('id', $request->input('profile_id'))->update([        
            'patient_first_name'      => $request->input('patient_first_name'),
            'patient_middle_name'      => $request->input('patient_middle_name'),
            'patient_last_name'       => $request->input('patient_last_name'),
            'patient_email'           => $request->input('patient_email'),
            'patient_phone'           => $request->input('patient_phone'),
            'emergency_phone'           => $request->input('emergency_phone'),
            'patient_martial_status'  => $request->input('patient_martial_status'),
            'patient_address'         => $request->input('patient_address'),
            'patient_date_of_birth'   => $patient_dob,
            'patient_gender'          => $request->input('gender'),
            'religion'          => $request->input('religion'),
            'patient_origin_state'    => $request->input('patient_origin_state'),
            'patient_languages'       => $request->input('languages'),
            'patient_insurance'       => $request->input('patient_insurance'),
            'next_first_name'          => $request->input('next_first_name'),
            'next_surname'          => $request->input('next_surname'),
            'next_phone'          => $request->input('next_phone'),
            'patient_state'       => $request->input('patient_state'),
            'lga'       => $request->input('lga'),
            'patient_city'          => $request->input('patient_city'),
            'patient_visited_hospital' => $request->input('patient_visited_hospital')
          ]);
        }

        PatientsDependent::where('patients_id', $request->input('profile_id'))->delete();
        //dependent table
        if(count($request->dependentname) > 0){
         foreach($request->dependentname as $name => $valname){
              $array[$name]['name'] = $valname;
          }
        }

        if(count($request->dependentday) > 0){
          foreach($request->dependentday as $day => $valday){
              $array[$day]['day'] = $valday;
          }
        }

        if(count($request->dependentmonth) > 0){
          foreach($request->dependentmonth as $month => $valmonth){
              $array[$month]['month'] = $valmonth;
          }
        }

        if(count($request->dependentyears) > 0){
          foreach($request->dependentyears as $years => $valyears){
              $array[$years]['years'] = $valyears;
          }
        }

        if(count($request->dependentrelationship) > 0){
          foreach($request->dependentrelationship as $relationship => $valrelationship){
              $array[$relationship]['relationship'] = $valrelationship;
          }
        }
        // $array['patients_id'] = 123;
        if(count($array) > 0)
        {
          foreach($array as $key => $value){
            if($value['name'] && $value['day'] && $value['month'] && $value['years'] && $value['relationship'])
            {
              $value['patients_id'] = $request->input('profile_id') ? $request->input('profile_id') : '';
              $PatientsDependent = new PatientsDependent($value); 
              $PatientsDependent->save();
            }
          }
        }
        //return response()->json(['success'=>'your data submited']);
         return response()->json(['success'=>1,'message'=>'Your information has been updated successfully!']);
        }
    }catch(Exception $e){
      return response()->json(['error'=>1,"message"=>$e->getMessage()],200);       
    }      
  }

  /******
  Patient update notifcation
  *******/
  public function profileNotification(Request $request){
    try{
      $value = Session::get('token');
      $patient_id = Auth::user()->patient_unique_id;
      $login_token =PatientLoginToken::where(array('patient_id'=>$patient_id,'login_token'=>$value))->first();        
      if(isset($login_token->token_status) && $login_token->token_status == 0){ 
          Auth::guard('patient')->logout();           
          return response()->json(['redirect'=>1,"redirect_url"=>asset('/patient/login')],200);
      }
      if(!Auth::check()){            
          return response()->json(['redirect'=>1,"redirect_url"=>asset('/patient/login')],200);
      }
    	if(PatientNotificationSetting::where('patient_id', '=',$patient_id)->count() > 0) {
  	  	PatientNotificationSetting::where('patient_id', $patient_id)->update([           
          'appointment_activity_email'    => $request->input('patient_activty'),
          'newsletter_subscription'       => $request->input('patient_newsletter'),
          'patient_history_notification'  => $request->input('patient_history_email'),
          'appointment_activity_push'     => $request->input('patient_activty_push'),
          'appointment_activity_sms'      => $request->input('patient_activty_sms'),
          'appointment_cancel_email'      => $request->input('appt_cancel_email'),
          'appointment_cancel_push'       => $request->input('appt_cancel_push'),
          'appointment_cancel_sms'        => $request->input('appt_cancel_sms'),
          'appointment_reschedule_email'  => $request->input('appt_reschedule_email'),
          'appointment_reschedule_push'   => $request->input('appt_reschedule_device'),
          'appointment_reschedule_sms'    => $request->input('appt_reschedule_sms'),
          'patient_history_push'          => $request->input('patient_history_push'),
          'patient_appt_reminder_push'    => $request->input('appt_reminder_push'),
          'patient_appt_reminder_sms'     => $request->input('appt_reminder_sms'),
          'patient_bill_push'             => $request->input('bill_email'),
          'patient_bill_sms'              => $request->input('bill_push'),
          'heath_diary_push'              => $request->input('health_diary_push'),
          'outstanding_bill_push'         => $request->input('outstanding_bill_push'),
          'outstanding_bill_email'        => $request->input('outstanding_bill_email')
        ]);
  			return response()->json(['success'=>1,'message'=>'Notification settings updated successfully']);	
  		}else{
  			$addParameters =  new PatientNotificationSetting();
    		$addParameters->patient_id                  = $patient_id;
        $addParameters->Notification_unique_id      = $this->generateUniqueNumber();
        $addParameters->appointment_activity_email  = $request->input('patient_activty');
        $addParameters->patient_history_notification  = $request->input('patient_history_email');
        $addParameters->appointment_activity_push  = $request->input('patient_activty_push');
        $addParameters->appointment_activity_sms  = $request->input('patient_activty_sms');
        $addParameters->appointment_cancel_email  = $request->input('appt_cancel_email');
        $addParameters->appointment_cancel_push  = $request->input('appt_cancel_push');
        $addParameters->appointment_cancel_sms  = $request->input('appt_cancel_sms');
        $addParameters->appointment_reschedule_email  = $request->input('appt_reschedule_email');
        $addParameters->appointment_reschedule_push  = $request->input('appt_reschedule_device');
        $addParameters->appointment_reschedule_sms  = $request->input('appt_reschedule_sms');
        $addParameters->patient_history_push  = $request->input('patient_history_push');
        $addParameters->patient_appt_reminder_push  = $request->input('appt_reminder_push');
        $addParameters->patient_appt_reminder_sms  = $request->input('appt_reminder_sms');
        $addParameters->patient_bill_push  = $request->input('bill_email');
        $addParameters->patient_bill_sms  = $request->input('bill_push');
        $addParameters->heath_diary_push  = $request->input('health_diary_push');
        $addParameters->outstanding_bill_push  = $request->input('outstanding_bill_push');
        $addParameters->outstanding_bill_email  = $request->input('outstanding_bill_email');
        $addParameters->newsletter_subscription     = $request->input('patient_newsletter');
          if($addParameters->save()){
            return response()->json(['success'=>1,'message'=>'Notification settings saved successfully']);
          }else{
          return response()->json(['success'=>0,'message'=>"Notification settings couldn't be saved"]);
          }
  			}
    }catch(Exception $e){
      return response()->json(['error'=>1,"message"=>$e->getMessage()],200);       
    }       	
  }

	/******
  Patient update password
  *******/
  public function accountSetting(Request $request){
    try{
      $value = Session::get('token');
      $patient_id = Auth::user()->patient_unique_id;
      $login_token =PatientLoginToken::where(array('patient_id'=>$patient_id,'login_token'=>$value))->first();        
      if(isset($login_token->token_status) && $login_token->token_status == 0){ 
        Auth::guard('patient')->logout();           
        return response()->json(['redirect'=>1,"redirect_url"=>asset('/patient/login')],200);
      }
      if(!Auth::check()){            
        return response()->json(['redirect'=>1,"redirect_url"=>asset('/patient/login')],200);
      }
      $current_user_id = Auth::user()->patient_unique_id;
      $account_setting = Patient::where('patient_unique_id', $current_user_id)->first();
      $patientEmail = $account_setting->patient_email;
      $patientPassword = $account_setting->patient_password;
      $FormEmail = $request->input('account_email');
      $FormPassword = $request->input('account_password');
      //$FormPassword = bcrypt($FormPassword);

      if($FormEmail !=  $patientEmail){
        return response()->json(['success'=>0, 'message'=>"Email doesn't match with existsing email"]);
      }else{
        $validatorAccount = Validator::make($request->all(),[
          'account_email'=>'required|email',
          'account_password'=>'required',
          'account_new_password'=>'required',
          'account_conf_password'=>'required|same:account_new_password'
        ]);
        if ($validatorAccount->fails()) {    
          return response()->json(['success'=>0, 'message'=>$validatorAccount->messages()->first()], 200);
        }
      }

      if(Hash::check($FormPassword, $patientPassword))
      {
        Patient::where('patient_unique_id', $current_user_id)->update(['patient_password' => bcrypt($request->input('account_new_password'))]);
        return response()->json(['success'=>1,'message'=>'Password successfully updated']);
      }else{
        return response()->json(['success'=>0,'message'=>'Your current password does not match']);
      } 
    }catch(Exception $e){
      return response()->json(['error'=>1,"message"=>$e->getMessage()],200);       
    }     
  }

  /******
  Patient billing List
  *******/
  public function billing(Request $request){
    try{
      $value = Session::get('token');
      $patient_id = Auth::user()->patient_unique_id;
      $login_token =PatientLoginToken::where(array('patient_id'=>$patient_id,'login_token'=>$value))->first();       
      if(isset($login_token->token_status) && $login_token->token_status == 0){ 
        Auth::guard('patient')->logout();           
        return redirect('/patient/login');
      }
      if(!Auth::check()){            
        return redirect('/patient/login');
      }
      $user = $request->user();
      $time_zone = $user->timezone;
      $billing_detail = BillingDetail::with(array('doctor','doctor.doctor_hospital_details'))->where('patient_id',$patient_id)->whereRaw('payable_amount-paid_amount >= 0')->orderBy('billing_date','DESC')->paginate(20);
      if($request->ajax()){
         return view('patient.billing_inner')->with(array('controller'=> 'pages','user'=>$user,'page'=>'dashboard','page_type'=>'billing','billing_detail'=>$billing_detail,'time_zone'=>$time_zone));
      }else{
        $start_date = BillingDetail::select('billing_date')->where('patient_id',$patient_id)->orderBy('billing_date','ASC')->first();
        return view('patient.billing')->with(array('controller'=> 'pages','user'=>$user,'page'=>'dashboard','page_type'=>'billing','billing_detail'=>$billing_detail,'start_date'=>$start_date,'time_zone'=>$time_zone));
      }
    }catch(Exception $e){
      echo 'Message: ' .$e->getMessage(); 
    }  
  }
  
  /******
  Patient pay bill view
  *******/
   public function paybill(Request $request,$id){
    try{
      $value = Session::get('token');
      $patient_id = Auth::user()->patient_unique_id;
      $login_token =PatientLoginToken::where(array('patient_id'=>$patient_id,'login_token'=>$value))->first();       
      if(isset($login_token->token_status) && $login_token->token_status == 0){ 
        Auth::guard('patient')->logout();           
        return redirect('/patient/login');
      }
      if(!Auth::check()){            
        return redirect('/patient/login');
      }
      $user = $request->user();
      $billing_detail = BillingDetail::with(array('doctor','billing_service','doctor.doctor_hospital_details','doctor.specialist_categories'))->where('patient_id',$patient_id)->where('billing_id',$id)->first();  
      return view('patient.paybill')->with(array('controller'=> 'pages','user'=>$user,'page'=>'billing','page_type'=>'billing','billing_detail'=>$billing_detail));
    }catch(Exception $e){
      echo 'Message: ' .$e->getMessage(); 
    }    
  }
   // Pay billing by cash
       public function payBillingCash(Request $request){ 
            try{             
          $value = Session::get('token');
          $patient_id = Auth::user()->patient_unique_id;
          $login_token =PatientLoginToken::where(array('patient_id'=>$patient_id,'login_token'=>$value))->first();       
          if(isset($login_token->token_status) && $login_token->token_status == 0){ 
              Auth::guard('patient')->logout();           
              return response()->json(['redirect'=>1,"redirect_url"=>asset('/doctor/login')],200);
          }
          if(!Auth::check()){            
              return response()->json(['redirect'=>1,"redirect_url"=>asset('/doctor/login')],200);
          }

          $user = $request->user();
         
          $data=$_POST;
          $time_zone = $user->timezone;
          $data['patient_id'] = $patient_id;          
          $data['login_token'] = $login_token->login_token;   
          $data['time_zone'] = $user->timezone; 
          $data['web'] = 1;       
          $dtz = new DateTimeZone($time_zone);     
          $date = date('Y-m-d H:i:s',strtotime("now"));                   
          $time_in_sofia = new DateTime($date, $dtz);        
          $date_offset = $time_in_sofia->format('Z');       
          $billing_time = strtotime($date)-$date_offset;  
          //DB::enableQueryLog();
          $update_amt = BillingDetail::where('billing_id',$_POST['billing_id'])->update(['paid_amount'=> DB::raw('paid_amount + '.$_POST['amt']),'paid_date'=>$billing_time,'cash_card'=>"cash"]);
         //print_r(DB::connection('mysql')->getQueryLog());
          $UserNotification = new UserNotification([                
              'notification_id'   => $this->generateNUniqueNumber(),              
              'assignee_type'     => 4,                    
              'patient_id'        => $_POST['patient_id'], 
              'event_id'          => $_POST['billing_id'],
              'notification_type' => "bill",
              'change_type'       => "paid",
              'created_date'      => strtotime('now'),
              'status'            => 0                                          
          ]);
          $UserNotification->save();

          $login_token = PatientLoginToken::where('patient_id',$_POST['patient_id'])->where('token_status',1)->get();
          $msg = "You paid a bill"; 
          
          if(count($login_token) > 0 && $login_token[0]->device_type != 2){            
              $device_token = $login_token[0]->device_token;
              $path = base_path()."/ios_notifcation/all_notifications.php";                            
              $nid = $_POST['billing_id'];
              $type= 'bill';
              exec ('php '.$path.' "'.$msg.'" '.$nid.' '.$type.' '.$device_token.' > /dev/null &');
          }

          $url = url('/patient/send_mail/'.str_replace(" ", "_", $msg).'/'.$_POST['patient_id'].'');   
          $cmd  = "curl --max-time 60 ";   
          $cmd .= "'" . $url . "'";   
          $cmd .= " > /dev/null 2>&1 &";    
          exec($cmd, $output, $exit); 

          return response()->json(['success'=>1,"message"=>"Bill paid successfully"],200);

        }catch(Exception $e) {
            return response()->json(['error'=>1,"message"=>$e->getMessage()],200);       
        }

       }

  /******
  Patient montly bill view
  *******/
  public function monthlyBillingList(Request $request,$month){
        try{
            $value = Session::get('token');
            $patient_id = Auth::user()->patient_unique_id;
            $login_token =PatientLoginToken::where(array('patient_id'=>$patient_id,'login_token'=>$value))->first();        
            if(isset($login_token->token_status) && $login_token->token_status == 0){ 
                Auth::guard('patient')->logout();           
                return redirect('/patient/login');
            }
            if(!Auth::check()){            
               return redirect('/patient/login');
            }  
            $user = $request->user();
            $time_zone = $user->timezone;
            $patient_id = Auth::user()->patient_unique_id;         
            $login_token = PatientLoginToken::where('patient_id',$patient_id)->where('token_status',1)->where('device_token',NULL)->first();   
            if(isset($login_token->login_token)){                
                $dtz = new DateTimeZone($user->timezone);     
                $date = date('Y-m-d',strtotime($month));   
                $next_date = date('Y-m-t', strtotime($date));
                $time_in_sofia = new DateTime($date, $dtz);        
                $date_offset = $time_in_sofia->format('Z');       
                $start_time = strtotime($date)-$date_offset;                        
                $end_time = strtotime($next_date)-$date_offset;
                $base_url = asset('/');
                $billing_detail = BillingDetail::with(array('doctor','doctor.doctor_hospital_details'))->where('patient_id',$patient_id)->where('billing_date','>=',$start_time)->where('billing_date','<=',$end_time)->orderBy('billing_date','DESC')->paginate(5);               
                $start_date = BillingDetail::select('billing_date')->where('patient_id',$patient_id)->orderBy('billing_date','ASC')->first();           
                return view('patient.billing_inner')->with(array('controller'=> 'pages','page'=>'dashboard','page_type'=>'billing','start_date'=>$start_date,'billing_detail'=>$billing_detail,'timezone'=>$time_zone));
            
            }else{
                return redirect('/patient/login');
            }      
        }catch(Exception $e) {
            echo 'Message: ' .$e->getMessage(); 
        }

    }

    /******
    Patient pay bill save
    *******/
    public function payBilling(Request $request){
      try{  

          $value = Session::get('token');
          $patient_id = Auth::user()->patient_unique_id;
          $login_token =PatientLoginToken::where(array('patient_id'=>$patient_id,'login_token'=>$value))->first();       
          if(isset($login_token->token_status) && $login_token->token_status == 0){ 
              Auth::guard('patient')->logout();           
              return response()->json(['redirect'=>1,"redirect_url"=>asset('/doctor/login')],200);
          }
          if(!Auth::check()){            
              return response()->json(['redirect'=>1,"redirect_url"=>asset('/doctor/login')],200);
          }
          $user = $request->user();
          $data=$_POST;
          $time_zone = $user->timezone;
          $data['patient_id'] = $patient_id;          
          $data['login_token'] = $login_token->login_token;   
          $data['time_zone'] = $user->timezone; 
          $data['web'] = 1;         
          
          $post_data = json_encode($data);  

          $curl = url('/')."/api/pay_billing";  
          $response = $this->commoncurl($curl,$post_data); 
          $UserNotification = new UserNotification([                
              'notification_id'   => $this->generateNUniqueNumber(),              
              'assignee_type'     => 4,                    
              'patient_id'        => $_POST['patient_id'], 
              'event_id'          => $_POST['billing_id'],
              'notification_type' => "bill",
              'change_type'       => "paid",
              'created_date'      => strtotime('now'),
              'status'            => 0                                          
          ]);
          $UserNotification->save();

          $login_token = PatientLoginToken::where('patient_id',$_POST['patient_id'])->where('token_status',1)->get();
          $msg = "You paid a bill"; 
          
          if(count($login_token) > 0 && $login_token[0]->device_type != 2){            
              $device_token = $login_token[0]->device_token;
              $path = base_path()."/ios_notifcation/all_notifications.php";                            
              $nid = $_POST['billing_id'];
              $type= 'bill';
              exec ('php '.$path.' "'.$msg.'" '.$nid.' '.$type.' '.$device_token.' > /dev/null &');
          }

          $url = url('/patient/send_mail/'.str_replace(" ", "_", $msg).'/'.$_POST['patient_id'].'');   
          $cmd  = "curl --max-time 60 ";   
          $cmd .= "'" . $url . "'";   
          $cmd .= " > /dev/null 2>&1 &";    
          exec($cmd, $output, $exit); 

          return response()->json(['success'=>$response['success'],"message"=>$response['message']],200);

      }catch(Exception $e) {
            return response()->json(['error'=>1,"message"=>$e->getMessage()],200);       
      } 
  }

  /******
  Patient download bill
  *******/
  public function downloadBillingPdf(Request $request,$id){
    try{
      $value = Session::get('token');
      $patient_id = Auth::user()->patient_unique_id;
      $login_token =PatientLoginToken::where(array('patient_id'=>$patient_id,'login_token'=>$value))->first();       
      if(isset($login_token->token_status) && $login_token->token_status == 0){ 
        Auth::guard('patient')->logout();           
        return redirect('/patient/login');
      }
      if(!Auth::check()){            
        return redirect('/patient/login');
      }
      $user = $request->user();
      
      $billing_detail = BillingDetail::with(array('doctor','billing_service','doctor.doctor_hospital_details','doctor.specialist_categories'))->where('patient_id',$patient_id)->where('billing_id',$id)->first(); 
      $pdf = PDF::loadView('pdf/billing_report',compact('billing_detail'));       
      return $pdf->download('billing'.$id.'.pdf'); //to automatically delete it       
    }catch(Exception $e) {
        echo 'Message: ' .$e->getMessage(); 
    }
  }

  protected function generateUniqueNumber(){
    $number = mt_rand(1000000000, 9999999999); // better than rand()
    // call the same function if the uniwue id exists already
    if ($this->uniqueNumberExists($number)) {
      return $this->generateUniqueNumber();
    }
      // otherwise, it's valid and can be used
    return strval($number);
  }

 protected function uniqueNumberExists($number){
    // query the database and return a boolean       
    return Patient::wherepatient_unique_id($number)->exists();
  }

  private function commoncurl($url,$post_data){
      $ch1 = curl_init();       
      curl_setopt($ch1, CURLOPT_URL,$url);
      curl_setopt($ch1, CURLOPT_HEADER, 0);
      curl_setopt($ch1, CURLOPT_POST, 1);
      curl_setopt($ch1, CURLOPT_POSTFIELDS, $post_data);  
      curl_setopt($ch1, CURLOPT_RETURNTRANSFER, 1);
      curl_setopt($ch1, CURLOPT_SSL_VERIFYPEER, 0);
      $output = curl_exec($ch1);  
      //echo "<pre>"; print_R($output); exit;    
      curl_close ($ch1);
      $output= json_decode($output,true);
      
      return $output;
  }

  protected function generateNUniqueNumber() {
        $number = mt_rand(1000000000, 9999999999); // better than rand()
        // call the same function if the uniwue id exists already
        if ($this->uniqueNNumberExists($number)) {
            return $this->generateNUniqueNumber();
        }
        // otherwise, it's valid and can be used
        return strval($number);
    }

    protected function uniqueNNumberExists($number) {
        // query the database and return a boolean         
        return UserNotification::wherenotification_id($number)->exists();
    }
     /******
    Reschedule Appointment
    *******/
    public function resheduleDetail(Request $request){
       $value = Session::get('token');
      $patient_id = Auth::user()->patient_unique_id;
      $login_token =PatientLoginToken::where(array('patient_id'=>$patient_id,'login_token'=>$value))->first();       
      if(isset($login_token->token_status) && $login_token->token_status == 0){ 
        Auth::guard('patient')->logout();           
        return redirect('/patient/login');
      }
      if(!Auth::check()){            
        return redirect('/patient/login');
      }          
        $user = $request->user();
        $time_zone = $user->timezone;        
        $dtz = new DateTimeZone($time_zone);     
        $date = date('Y-m-d',strtotime($_POST['appoint_date']));   
        $next_date = date('Y-m-d', strtotime('+1 day', strtotime($date)));
        $time_in_sofia = new DateTime($date, $dtz);        
        $date_offset = $time_in_sofia->format('Z');       
        $start_time = strtotime($date)-$date_offset;        
        $end_time = strtotime($next_date)-$date_offset;
        $appoint_detail=SaveTelemedicalBookingDetail::with(array("patient_detail","doctor.specialist_categories","patient_appoint"))->where("save_telemedical_booking_detail.booking_id",$_POST['book_id'])->first();
        
        if($appoint_detail->patient_appoint->appointment_type == 2){
            $doctor_avail_time=Doctor::with(array('doctor_availability'=>function($q) use($start_time,$end_time) {$q->where('availability_date','>=',$start_time); $q->where('availability_date','<',$end_time); $q->where('type',2);}))->with('specialist_categories')->whereHas('doctor_availability', function($q) use($start_time,$end_time) {$q->where('availability_date','>=',$start_time); $q->where('availability_date','<',$end_time); $q->where('type',2);})->where('doctor_id',$appoint_detail->doctor_id)->select("*")->first();
            if(isset($doctor_avail_time->doctor_id)){
                $doctor_avail_time = $doctor_avail_time->toArray();
            }
        }elseif($appoint_detail->patient_appoint->appointment_type == 1){
            $doctor_avail_time=Doctor::with(array('doctor_availability'=>function($q) use($start_time,$end_time) {$q->where('availability_date','>=',$start_time); $q->where('availability_date','<',$end_time);$q->where('type',1);}))->with('specialist_categories')->whereHas('doctor_availability', function($q) use($start_time,$end_time) {$q->where('availability_date','>=',$start_time); $q->where('availability_date','<',$end_time);$q->where('type',1);})->where('doctor_id',$appoint_detail->doctor_id)->select("*")->first();
            if(isset($doctor_avail_time->doctor_id)){
                $doctor_avail_time = $doctor_avail_time->toArray();
            }
        }
       // echo "<pre>";print_r( $doctor_avail_time);die;
         //$disputed_billing = BillingDetail::where('doctor_id',$doctor_id)->where('disputed',1)->orderBy('billing_date','DESC'); 
        $doc_appoint_listing=SaveTelemedicalBookingDetail::where('save_telemedical_booking_detail.approved_status','!=',2)->where('save_telemedical_booking_detail.appointment_time','>=',$start_time)->where('save_telemedical_booking_detail.appointment_time','<',$end_time)->orderBy('save_telemedical_booking_detail.appointment_time','ASC')->get();
       
        return view('patient.reshedule')->with(array('controller'=> 'patient','appointment'=>$appoint_detail,'doctor_avail_time'=>$doctor_avail_time,'doc_appoint_listing'=>$doc_appoint_listing,'timezone'=>$time_zone,'appoint_date'=>$_POST['appoint_date']));
    
    }
      /******
    Cancel Booking
    *******/    
    public function cancelBooking(Request $request){
        $value = Session::get('token');
      $patient_id = Auth::user()->patient_unique_id;
      $login_token =PatientLoginToken::where(array('patient_id'=>$patient_id,'login_token'=>$value))->first();       
      if(isset($login_token->token_status) && $login_token->token_status == 0){ 
        Auth::guard('patient')->logout();           
        return redirect('/patient/login');
      }
      if(!Auth::check()){            
        return redirect('/patient/login');
      }          
        $user = $request->user();
        $time_zone = $user->timezone; 
        $doctor_details = Doctor::where('doctor_id',$_POST['doctor_id'])->first();
        $update_status = SaveTelemedicalBookingDetail::where('booking_id',$_POST['book_id'])->update(['approved_status'=>2]);
        $UserNotification = new UserNotification([                
            'notification_id'   => $this->generateNUniqueNumber(),
            'doctor_id'         => $_POST['doctor_id'], 
            'assignee_type'     => 1,                    
            'patient_id'        => $_POST['patient_id'], 
            'event_id'          => $_POST['book_id'],
            'notification_type' => "appt",
            'change_type'       => "cancelled",
            'created_date'      => strtotime('now'),
            'status'            => 0                                          
        ]);
        $UserNotification->save(); 

        $login_token = PatientLoginToken::where('patient_id',$_POST['patient_id'])->where('token_status',1)->get();

        
        $msg = "Dr.".$doctor_details->doctor_first_name." ".$doctor_details->doctor_last_name." cancelled your appointment";
        
        $patients_notification = PatientNotificationSetting::where('patient_id', $_POST['patient_id'])->first();
        if(isset($patients_notification->patient_id)){
            if($patients_notification->appointment_cancel_push == 1){
                if(count($login_token) > 0 && $login_token[0]->device_type != 2){            
                    $device_token = $login_token[0]->device_token;
                    $path = base_path()."/ios_notifcation/all_notifications.php";
                    
                    $nid = $_POST['book_id'];
                    $type= 'appt';
                    exec ('php '.$path.' "'.$msg.'" '.$nid.' '.$type.' '.$device_token.' > /dev/null &');
                }
            }
           

            if($patients_notification->appointment_cancel_email == 1){
                $url = url('/patient/send_mail/'.str_replace(" ", "_", $msg).'/'.$_POST['patient_id'].'');   
                $cmd  = "curl --max-time 60 ";   
                $cmd .= "'" . $url . "'";   
                $cmd .= " > /dev/null 2>&1 &";    
                exec($cmd, $output, $exit); 
            }
        } 
        if($update_status > 0){
            return response()->json(['success'=>1], 200);
        }else{
            return response()->json(['success'=>0,'message'=>'Something went wrong'], 200);
        }        
    }

    /******
    Update appointment
    *******/
    public function updateAppointments(Request $request){
        try{

      $value = Session::get('token');
      $patient_id = Auth::user()->patient_unique_id;
      $login_token =PatientLoginToken::where(array('patient_id'=>$patient_id,'login_token'=>$value))->first();       
      if(isset($login_token->token_status) && $login_token->token_status == 0){ 
      Auth::guard('patient')->logout();           
      return redirect('/patient/login');
      }
      if(!Auth::check()){            
      return redirect('/patient/login');
      }          
            $user = $request->user();
            $time_zone = $user->timezone;         
         $doctor_details = Doctor::where('doctor_id',$_POST['doctor_id'])->first();
            $appoint_time = $_POST['appoint_date']." ".$_POST['appoint_time'];          
            $dtz = new DateTimeZone($time_zone);     
            $date = date('Y-m-d H:i',strtotime($appoint_time));                   
            $time_in_sofia = new DateTime($date, $dtz);        
            $date_offset = $time_in_sofia->format('Z');       
            $appointment_time = strtotime($date)-$date_offset;         
            $update_time = SaveTelemedicalBookingDetail::where('booking_id',$_POST['book_id'])->update(['appointment_time'=>$appointment_time]);
            $UserNotification = new UserNotification([                
                'notification_id'   => $this->generateNUniqueNumber(),
                'doctor_id'         => $_POST['doctor_id'], 
                'assignee_type'     => 1,                    
                'patient_id'        => $_POST['patient_id'], 
                'event_id'          => $_POST['book_id'],
                'notification_type' => "appt",
                'change_type'       => "rescheduled",
                'created_date'      => strtotime('now'),
                'status'            => 0                                          
            ]);
            $UserNotification->save(); 

            $login_token = PatientLoginToken::where('patient_id',$_POST['patient_id'])->where('token_status',1)->get();

            $msg = "Dr.".$doctor_details->doctor_first_name." ".$doctor_details->doctor_last_name." rescheduled your appointment"; 

            $patients_notification = PatientNotificationSetting::where('patient_id', $_POST['patient_id'])->first();
            if(isset($patients_notification->patient_id)){
                if($patients_notification->appointment_reschedule_push == 1){
                    if(count($login_token) > 0 && $login_token[0]->device_type != 2){            
                        $device_token = $login_token[0]->device_token;
                        $path = base_path()."/ios_notifcation/all_notifications.php";
                                       
                        $nid = $_POST['book_id'];
                        $type= 'appt';
                        exec ('php '.$path.' "'.$msg.'" '.$nid.' '.$type.' '.$device_token.' > /dev/null &');
                    }
                }
                if($patients_notification->appointment_reschedule_email == 1){
                    $url = url('/patient/send_mail/'.str_replace(" ", "_", $msg).'/'.$_POST['patient_id'].'');   
                    $cmd  = "curl --max-time 60 ";   
                    $cmd .= "'" . $url . "'";   
                    $cmd .= " > /dev/null 2>&1 &";    
                    exec($cmd, $output, $exit);  
                }
            }
            return response()->json(['success'=>1], 200);
        }catch(Exception $e) {
            return response()->json(['error'=>1,"message"=>$e->getMessage()],200);       
        } 
    }
            // Send records
            public function SendRecords(Request $request){
            try{
            $value = Session::get('token');
            $patient_id = Auth::user()->patient_unique_id;
             $user = $request->user();
            $login_token =PatientLoginToken::where(array('patient_id'=>$patient_id,'login_token'=>$value))->first();       
            if(isset($login_token->token_status) && $login_token->token_status == 0){ 
            Auth::guard('patient')->logout();           
            return redirect('/patient/login');
            }
            if(!Auth::check()){            
            return redirect('/patient/login');
            }  
            $history_id=$request->history_id;
             $email=$request->email;
             $health_history=HealthHistory::with(array('patient','doctor','history_attachments','doctor.specialist_categories','doctor.doctor_hospital_details'))->where('history_id',$history_id)->first();
            if(count($health_history['history_attachments']) > 0){
                   $send_email_from = $_ENV['send_email_from'];
             $res= Mail::send('patient.welcome',array('patient_name' => $user->patient_first_name.' '.$user->patient_last_name), function ($message) use($send_email_from,$health_history,$email)  {

            $message->to($email);
            $message->from($send_email_from);
            $message->subject('Original Records');
           //$message->setBody("Hello");
            // $message->attach("/var/www/html/renderhealth/public/admin/doctor/uploads/hhistory/5749212886/original_record/2019-07-17-170223_1366x768_scrot.png");

            foreach($health_history['history_attachments'] as $history_attachments)    {
            if($history_attachments->type == 2){      

            if(!empty($health_history->doctor_id)){       
            
            $message->attach(public_path()."/admin/doctor/uploads/hhistory/".$history_attachments['patient_history_id']."/original_record/".$history_attachments['patient_attachment_name']);
            }
            elseif(!empty($health_history->nurse_id)){
           
            $message->attach(public_path().'/admin/nurse/uploads/hhistory/'.$history_attachments['patient_history_id'].'/original_record/'.$history_attachments['patient_attachment_name']);
            }
            elseif(!empty($health_history->hospital_id)) {
       
            $message->attach(public_path().'/admin/hospital/uploads/hhistory/'.$history_attachments['patient_history_id'].'/original_record/'.$history_attachments['patient_attachment_name']);
            }
            elseif(!empty($health_history->employee_id)){
          
            $message->attach(public_path().'/admin/employee/uploads/hhistory/'.$history_attachments['patient_history_id'].'/original_record/'.$history_attachments['patient_attachment_name']);
            }

            //  });
            }
            }
            });
            }
           // echo  $res;
            return response()->json(['success'=>1], 200);
            }catch(Exception $e) {
            return response()->json(['error'=>1,"message"=>$e->getMessage()],200);       
            } 

            }
            public function Downloadrecords(Request $request,$id=''){
                  try{
                  $value = Session::get('token');
                  $patient_id = Auth::user()->patient_unique_id;
                  $user = $request->user();
                  $login_token =PatientLoginToken::where(array('patient_id'=>$patient_id,'login_token'=>$value))->first();       
                  if(isset($login_token->token_status) && $login_token->token_status == 0){ 
                  Auth::guard('patient')->logout();           
                  return redirect('/patient/login');
                  }
                  if(!Auth::check()){            
                  return redirect('/patient/login');
                  }  
                  $zipper = new \Chumper\Zipper\Zipper;
                  $filename=strtotime("now");
                  $zipper->make(public_path($filename.'zip'));       
                $health_history=HealthHistory::with(array('patient','doctor','history_attachments','doctor.specialist_categories','doctor.doctor_hospital_details'))->where('history_id',$id)->first();
                if(count($health_history['history_attachments']) > 0){
                foreach($health_history['history_attachments'] as $history_attachments)    {
                if($history_attachments->type == 2){     
                if(!empty($health_history->doctor_id)){ 
                if(file_exists(public_path().'/admin/doctor/uploads/hhistory/'.$history_attachments['patient_history_id'].'/original_record/'.$history_attachments['patient_attachment_name'])){
                $zipper->zip($filename.'.zip')->folder('pdf')->add(public_path().'/admin/doctor/uploads/hhistory/'.$history_attachments['patient_history_id'].'/original_record/'.$history_attachments['patient_attachment_name'],$history_attachments['patient_attachment_name']);
                }
                }
                elseif(!empty($health_history->nurse_id)){
                if(file_exists(public_path().'/admin/nurse/uploads/hhistory/'.$history_attachments['patient_history_id'].'/original_record/'.$history_attachments['patient_attachment_name'])){
                $zipper->zip($filename.'.zip')->folder('pdf')->add(public_path().'/admin/nurse/uploads/hhistory/'.$history_attachments['patient_history_id'].'/original_record/'.$history_attachments['patient_attachment_name'],$history_attachments['patient_attachment_name']);
                }
                }
                elseif(!empty($health_history->hospital_id)) {
                if(file_exists(public_path().'/admin/hospitals/uploads/hhistory/'.$history_attachments['patient_history_id'].'/original_record/'.$history_attachments['patient_attachment_name'])){
                $zipper->zip($filename.'.zip')->folder('pdf')->add(public_path().'/admin/hospitals/uploads/hhistory/'.$history_attachments['patient_history_id'].'/original_record/'.$history_attachments['patient_attachment_name'],$history_attachments['patient_attachment_name']);
                }
                }
                elseif(!empty($health_history->employee_id)){
                if(file_exists(public_path().'/admin/employee/uploads/hhistory/'.$history_attachments['patient_history_id'].'/original_record/'.$history_attachments['patient_attachment_name'])){
                $zipper->zip($filename.'.zip')->folder('pdf')->add(public_path().'/admin/employee/uploads/hhistory/'.$history_attachments['patient_history_id'].'/original_record/'.$history_attachments['patient_attachment_name'],$history_attachments['patient_attachment_name']);
                }
                }
                }
                }
                }
                  $zipper->close();
                   return response()->download(public_path($filename.'.zip'));
                  }
                  catch(Exception $e) {
                  return response()->json(['error'=>1,"message"=>$e->getMessage()],200);
                  }
            }
    }

