<?php
namespace App\Http\Controllers\Patient;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Carbon\Carbon;
use Auth;
use Validator;
use DateTime;
use DateTimeZone;
use Session;
use Mail;
use App\Models\PatientLoginToken;
use App\Models\Patient;
use App\Models\Hospital;
use App\Models\Doctor;
use App\Models\SaveTelemedicalBookingDetail;
use App\Models\PatientAppointment;
use App\Models\ServiceOffered;
use App\Models\Speciality;
use App\Models\Hmolist;
use App\Models\SpecialistCategories;
use App\Models\HealthHistory;
use App\Models\HealthHistoryAttachments;
use App\Models\CallSession;
use App\Models\UserNotification;
use App\Models\PatientNotificationSetting;
use App\Models\PatientHealthDiary;
use App\Models\PaidBillingDetail;
use Twilio\Rest\Client;
class AppointmentController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        // if(strpos(request()->route()->uri, '/appointment') !== false || strpos(request()->route()->uri, 'get_paitint_by_doctor') !== false || strpos(request()->route()->uri, 'save_appointment_details') !== false){
            $this->middleware('auth:patient',['except' => ['sendMail','sendMailTemplate','patient_appointment']]);      
        // }
    }
    
    public function index(Request $request){
        
    // dd(Auth::user());
        $value = Session::get('token');
        if(Auth::user()){
            $user = $request->user();
            $patient_id = Auth::user()->patient_unique_id;
            $login_token =PatientLoginToken::where(array('patient_id'=>$patient_id,'login_token'=>$value))->first();        
            if(isset($login_token->token_status) && $login_token->token_status == 0){ 
                Auth::guard('patient')->logout();           
                return redirect('/patient/login');
            }
            if(!Auth::check()){            
                return redirect('/patient/login');
            } 
            $patient_id = Auth::user()->patient_unique_id;
        }
        $user = $request->user();
        $hospitals = Hospital::orderBy('hosp_name','ASC')->with('doctor_hospital_details');
        // dd($hospitals);
        $search_hospital_name = '';
        if(isset($_GET['hospital_name'])){
            $search_hospital_name = $_GET['hospital_name'];
            $hospitals = $hospitals->where('hosp_name', 'like', '%'.$_GET['hospital_name'].'%');
        }
        if(isset($_GET['offered'])){
            $hospitals = $hospitals->where('serviceofferd', 'like', '%'.$_GET['offered'].'%');
        }
        if(isset($_GET['hosp_speciality'])){
            $hospitals = $hospitals->where('hosp_speciality', 'like', '%'.$_GET['hosp_speciality'].'%');
        }
        if(isset($_GET['type_of_speciality'])){
            $hospitals = $hospitals->where('hosp_speciality', 'like', '%'.$_GET['type_of_speciality'].'%');
        }
        
        if(isset($_GET['state'])){
            $hospitals = $hospitals->where('hosp_state', 'like', '%'.$_GET['state'].'%');
        }
        if(isset($_GET['lga'])){
            $hospitals = $hospitals->where('lga', 'like', '%'.$_GET['lga'].'%');
        }
        if(isset($_GET['HMO'])){
            $hospitals = $hospitals->where('hmo', 'like', '%'.$_GET['HMO'].'%');
        }
        $search_doctor_id = '';
        if(isset($_GET['doctor_id']) && $_GET['doctor_id']!=''){
            $search_doctor_id = $_GET['doctor_id'];
        }
        if(isset($_GET['type_of_speciality'])){
            $hospitals = $hospitals->with('doctor_hospital_details')->orWhereHas('doctor_hospital_details', function($q){
                $q->where('doctor_speciality', $_GET['type_of_speciality']);
            });
        }
        $hospitals = $hospitals->get();
        
        $Hospitals = array();
        // array('A' => array(),
        // 'B' => array(),'C' => array(), 'D' => array(), 'E' => array(),'F' => array(), 'G' => array(), 'H' => array(), 'I' => array(), 'J' => array(),'K' => array(), 'L' => array(), 'M' => array(), 'N' => array(), 'O' => array(), 'P' => array(), 'Q' => array(), 'R' => array(), 'S' => array()); 
        foreach ($hospitals as $key => $value) {
            if(isset($value->hosp_name)){
                $Hospitals[substr(ucfirst($value->hosp_name),0,1)][$key] = $value;//$value->name ;
            }   
        }
        $doctors = [];
        if(isset($_GET['hosp_id']) && $_GET['hosp_id']!=''){
            $doctors = Doctor::with('doctor_availability')->where('hospital_id',$_GET['hosp_id'])->get();
        }
        $Doctors = array();
        // array('A' => array(),
        // 'B' => array(),'C' => array(), 'D' => array(), 'E' => array(),'F' => array(), 'G' => array(), 'H' => array(), 'I' => array(), 'J' => array(),'K' => array(), 'L' => array(), 'M' => array(), 'N' => array(), 'O' => array(), 'P' => array(), 'Q' => array(), 'R' => array(), 'S' => array()); 
        foreach ($doctors as $key => $value) {
            if(isset($value->doctor_first_name)){
                $Doctors[substr(ucfirst($value->doctor_first_name),0,1)][$key] = $value;//$value->name ;
            }   
        }
        //speciality
        $speciality = Speciality::all();
        //Service Offered
        $serviceOffered = ServiceOffered::all();
        //hmo
        $Hmolist = Hmolist::all();
     
        $health_diaries=PatientHealthDiary::where(array('patient_id'=>isset($patient_id)?$patient_id:'',))->orderBy('id','DESC')->get();
       if(Auth::guard('patient')->check()){
            return view('patient.appointment.index')->with(array('controller'=> 'patient','user'=>$user,'page'=>'inner','page_type'=>'extra_links','hospitals'=>$Hospitals,"health_diaries"=>$health_diaries,'doctors'=>$Doctors,'search_hospital_name'=>$search_hospital_name,'search_doctor_id'=>$search_doctor_id,'serviceOffered'=>$serviceOffered,'speciality'=>$speciality,'Hmolist'=>$Hmolist));
       }else{
            return view('patient.appointment.index')->with(array('controller'=> 'patient','user'=>'','page'=>'inner','page_type'=>'extra_links','hospitals'=>$Hospitals,"health_diaries"=>$health_diaries,'doctors'=>$Doctors,'search_hospital_name'=>$search_hospital_name,'search_doctor_id'=>$search_doctor_id,'serviceOffered'=>$serviceOffered,'speciality'=>$speciality,'Hmolist'=>$Hmolist));
       }
    }

    public function patient_appointment(Request $request){
        
        // dd(Auth::user());
            $value = Session::get('token');
            if(Auth::user()){
                $user = $request->user();
                $patient_id = Auth::user()->patient_unique_id;
                $login_token =PatientLoginToken::where(array('patient_id'=>$patient_id,'login_token'=>$value))->first();        
                if(isset($login_token->token_status) && $login_token->token_status == 0){ 
                    Auth::guard('patient')->logout();           
                    return redirect('/patient/login');
                }
                if(!Auth::check()){            
                    return redirect('/patient/login');
                } 
                $patient_id = Auth::user()->patient_unique_id;
            }
            $user = $request->user();
            $hospitals = Hospital::orderBy('hosp_name','ASC')->with('doctor_hospital_details');
            // dd($hospitals);
            $search_hospital_name = '';
            if(isset($_GET['hospital_name'])){
                $search_hospital_name = $_GET['hospital_name'];
                $hospitals = $hospitals->where('hosp_name', 'like', '%'.$_GET['hospital_name'].'%');
            }
            if(isset($_GET['offered'])){
                $hospitals = $hospitals->where('type_of_facility', 'like', '%'.$_GET['offered'].'%');
            }
            if(isset($_GET['hosp_speciality'])){
                $hospitals = $hospitals->where('hosp_speciality', 'like', '%'.$_GET['hosp_speciality'].'%');
            }
            if(isset($_GET['type_of_speciality'])){
                $hospitals = $hospitals->where('hosp_speciality', 'like', '%'.$_GET['type_of_speciality'].'%');
            }
            
            if(isset($_GET['state'])){
                $hospitals = $hospitals->where('hosp_state', 'like', '%'.$_GET['state'].'%');
            }
            if(isset($_GET['lga'])){
                $hospitals = $hospitals->where('lga', 'like', '%'.$_GET['lga'].'%');
            }
            if(isset($_GET['HMO'])){
                $hospitals = $hospitals->where('hmo', 'like', '%'.$_GET['HMO'].'%');
            }
            $search_doctor_id = '';
            if(isset($_GET['doctor_id']) && $_GET['doctor_id']!=''){
                $search_doctor_id = $_GET['doctor_id'];
            }
            if(isset($_GET['type_of_speciality'])){
                $hospitals = $hospitals->with('doctor_hospital_details')->orWhereHas('doctor_hospital_details', function($q){
                    $q->where('doctor_speciality', $_GET['type_of_speciality']);
                });
            }
            $hospitals = $hospitals->get();
            
            $Hospitals = array();
            // array('A' => array(),
            // 'B' => array(),'C' => array(), 'D' => array(), 'E' => array(),'F' => array(), 'G' => array(), 'H' => array(), 'I' => array(), 'J' => array(),'K' => array(), 'L' => array(), 'M' => array(), 'N' => array(), 'O' => array(), 'P' => array(), 'Q' => array(), 'R' => array(), 'S' => array()); 
            foreach ($hospitals as $key => $value) {
                if(isset($value->hosp_name)){
                    $Hospitals[substr(ucfirst($value->hosp_name),0,1)][$key] = $value;//$value->name ;
                }   
            }
            $doctors = [];
            if(isset($_GET['hosp_id']) && $_GET['hosp_id']!=''){
                $doctors = Doctor::with('doctor_availability')->where('hospital_id',$_GET['hosp_id'])->get();
            }
            $Doctors = array();
            // array('A' => array(),
            // 'B' => array(),'C' => array(), 'D' => array(), 'E' => array(),'F' => array(), 'G' => array(), 'H' => array(), 'I' => array(), 'J' => array(),'K' => array(), 'L' => array(), 'M' => array(), 'N' => array(), 'O' => array(), 'P' => array(), 'Q' => array(), 'R' => array(), 'S' => array()); 
            foreach ($doctors as $key => $value) {
                if(isset($value->doctor_first_name)){
                    $Doctors[substr(ucfirst($value->doctor_first_name),0,1)][$key] = $value;//$value->name ;
                }   
            }
            //speciality
            $speciality = Speciality::all();
            //Service Offered
            $serviceOffered = ServiceOffered::all();
            //hmo
            $Hmolist = Hmolist::all();
         
            $health_diaries=PatientHealthDiary::where(array('patient_id'=>isset($patient_id)?$patient_id:'',))->orderBy('id','DESC')->get();
           if(Auth::guard('patient')->check()){
                return view('patient.appointment.index')->with(array('controller'=> 'patient','user'=>$user,'page'=>'inner','page_type'=>'extra_links','hospitals'=>$Hospitals,"health_diaries"=>$health_diaries,'doctors'=>$Doctors,'search_hospital_name'=>$search_hospital_name,'search_doctor_id'=>$search_doctor_id,'serviceOffered'=>$serviceOffered,'speciality'=>$speciality,'Hmolist'=>$Hmolist));
           }else{
                return view('patient.appointment.index')->with(array('controller'=> 'patient','user'=>'','page'=>'inner','page_type'=>'extra_links','hospitals'=>$Hospitals,"health_diaries"=>$health_diaries,'doctors'=>$Doctors,'search_hospital_name'=>$search_hospital_name,'search_doctor_id'=>$search_doctor_id,'serviceOffered'=>$serviceOffered,'speciality'=>$speciality,'Hmolist'=>$Hmolist));
           }
        }
    // Get Patient and doctor
    public function getPaitintByDoctor(Request $request){
        $admin = Auth::user();
        $doctors_details = Doctor::where('doctor_id',$request->id)->first();
        $doctors_details['patient_name'] = $admin->patient_first_name." ".$admin->patient_last_name;
        $doctors_details['patient_gender'] = $admin->patient_gender;
        $doctors_details['patient_address'] = $admin->patient_address;
        $now = time(); 
        $patient_date_of_birth = $now - $admin->patient_date_of_birth;
        //There are 31556926 seconds in a year.
        $age = floor($patient_date_of_birth / 31556926);
        $doctors_details['patient_age']=$age;
        // dd($admin->created_at);
        $doctors_details['patient_date_of_birth'] = date('d F Y',$admin->patient_date_of_birth);   
        $doctors_details['patient_month_year'] = Carbon::parse($admin->created_at)->format('m Y');
        $doctors_details['patient_date'] = Carbon::parse($admin->created_at)->format('d');
        $doctors_details['patient_time'] = Carbon::parse($admin->created_at)->format('h:i:A');
        $doctors_details['patient_image'] = $admin->patient_profile_img;
        return response()->json($doctors_details);
    }
    
     // Get Patient and doctor
     public function saveAppointmentDetails(Request $request){
        $admin_id = Auth::user()->id;
        $PatientAppointment = new PatientAppointment([
            'appointment_id'		=> $this->generateUniqueNumber(),
            'patient_id'			=> $admin_id,
            'appointment_type'		=> $request->hosps_id ? $request->hosps_id : '',
            'telemedical_type'		=> '',	
            'telemedical_consult_type' => '',	
            'telemedical_consult_time' => '',	
            'appointment_time'		=> $request->time,	
            'reanson_for_visit'		=> $request->reanson_for_visit,	
            'appoint_booking_status'	=> 0,
            'appoint_created_date'	=> strtotime("now"),		
            'status'				=> 1			     			
        ]);	
        $PatientAppointment->save();
        return response()->json(['redirect'=>1,"redirect_url"=>asset('/patient/appointment')],200);
     }
     protected function generateUniqueNumber() {
        $number = mt_rand(1000000000, 9999999999); // better than rand()
        // call the same function if the uniwue id exists already
        if ($this->uniqueNumberExists($number)) {
            return $this->generateUniqueNumber();
        }
        // otherwise, it's valid and can be used
        return strval($number);
    }
    protected function uniqueNumberExists($number) {
        // query the database and return a boolean		   
        return Patient::wherepatient_unique_id($number)->exists();
    }
}