<?php
namespace App\Http\Controllers\Patient;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Carbon\Carbon;
use Auth;
use Validator;
use DateTime;
use DateTimeZone;
use Session;
use Mail;
use App\Models\PatientLoginToken;
use App\Models\Patient;
use App\Models\Hospital;
use App\Models\Doctor;
use App\Models\SaveTelemedicalBookingDetail;
use App\Models\PatientAppointment;
use App\Models\ServiceOffered;
use App\Models\Speciality;
use App\Models\Hmolist;
use App\Models\SpecialistCategories;
use App\Models\HealthHistory;
use App\Models\HealthHistoryAttachments;
use App\Models\CallSession;
use App\Models\UserNotification;
use App\Models\PatientNotificationSetting;
use App\Models\PatientHealthDiary;
use App\Models\PaidBillingDetail;
use App\Models\StatesNigeria;
use Twilio\Rest\Client;
class AppointmentController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        // if(strpos(request()->route()->uri, '/appointment') !== false || strpos(request()->route()->uri, 'get_paitint_by_doctor') !== false || strpos(request()->route()->uri, 'save_appointment_details') !== false){
            $this->middleware('auth:patient',['except' => ['sendMail','sendMailTemplate','patient_appointment']]);      
        // }
    }
    
    public function index(Request $request){
        
    // dd(Auth::user());
        $value = Session::get('token');
        if(Auth::user()){
            $user = $request->user();
            $patient_id = Auth::user()->patient_unique_id;
            $login_token =PatientLoginToken::where(array('patient_id'=>$patient_id,'login_token'=>$value))->first();        
            if(isset($login_token->token_status) && $login_token->token_status == 0){ 
                Auth::guard('patient')->logout();           
                return redirect('/patient/login');
            }
            if(!Auth::check()){            
                return redirect('/patient/login');
            } 
            $patient_id = Auth::user()->patient_unique_id;
        }
        $user = $request->user();
        $hospitals = Hospital::orderBy('hosp_name','ASC')->with('doctor_hospital_details');
        // dd($hospitals);
        $search_hospital_name = '';
        if(isset($_GET['hospital_name'])){
            $search_hospital_name = $_GET['hospital_name'];
            $hospitals = $hospitals->where('hosp_name', 'like', '%'.$_GET['hospital_name'].'%');
        }
        if(isset($_GET['offered'])){
            $hospitals = $hospitals->where(function($query) use ($request) {
                foreach ($_GET['offered'] as $key => $connectivity) {
                    if ($key == 0) {
                        $query->whereRaw('find_in_set("'.$connectivity.'",serviceofferd)');
                    } else {
                        $query->orWhereRaw('find_in_set("'.$connectivity.'",serviceofferd)');
                    }
                }
            });
        }
        if(isset($_GET['hosp_speciality'])){
            $hospitals = $hospitals->where('hosp_speciality', 'like', '%'.$_GET['hosp_speciality'].'%');
        }
        if(isset($_GET['type_of_speciality'])){
            $hospitals = $hospitals->where('hosp_speciality', 'like', '%'.$_GET['type_of_speciality'].'%');
        }
        
        if(isset($_GET['state'])){
            $hospitals = $hospitals->where('hosp_state', 'like', '%'.$_GET['state'].'%');
        }
        if(isset($_GET['lga'])){
            $hospitals = $hospitals->where('lga', 'like', '%'.$_GET['lga'].'%');
        }
        if(isset($_GET['HMO'])){
            $hospitals = $hospitals->whereRaw('find_in_set("'.$_GET['HMO'].'",hmo)');
        }
        $search_doctor_id = '';
        if(isset($_GET['doctor_id']) && $_GET['doctor_id']!=''){
            $search_doctor_id = $_GET['doctor_id'];
        }
        if(isset($_GET['type_of_speciality'])){
            $hospitals = $hospitals->with('doctor_hospital_details')->orWhereHas('doctor_hospital_details', function($q){
                $q->where('doctor_speciality', $_GET['type_of_speciality']);
            });
        }
        $hospitals = $hospitals->get();
        
        $Hospitals = array();
        // array('A' => array(),
        // 'B' => array(),'C' => array(), 'D' => array(), 'E' => array(),'F' => array(), 'G' => array(), 'H' => array(), 'I' => array(), 'J' => array(),'K' => array(), 'L' => array(), 'M' => array(), 'N' => array(), 'O' => array(), 'P' => array(), 'Q' => array(), 'R' => array(), 'S' => array()); 
        foreach ($hospitals as $key => $value) {
            if(isset($value->hosp_name)){
                $Hospitals[substr(ucfirst($value->hosp_name),0,1)][$key] = $value;//$value->name ;
            }   
        }
        $doctors = [];
        if(isset($_GET['hosp_id']) && $_GET['hosp_id']!=''){
            $doctors = Doctor::with('doctor_availability')->where('hospital_id',$_GET['hosp_id'])->get();
        }
        $Doctors = array();
        // array('A' => array(),
        // 'B' => array(),'C' => array(), 'D' => array(), 'E' => array(),'F' => array(), 'G' => array(), 'H' => array(), 'I' => array(), 'J' => array(),'K' => array(), 'L' => array(), 'M' => array(), 'N' => array(), 'O' => array(), 'P' => array(), 'Q' => array(), 'R' => array(), 'S' => array()); 
        foreach ($doctors as $key => $value) {
            if(isset($value->doctor_first_name)){
                $Doctors[substr(ucfirst($value->doctor_first_name),0,1)][$key] = $value;//$value->name ;
            }   
        }
        //speciality
        $speciality = Speciality::all();
        //Service Offered
        $serviceOffered = ServiceOffered::all();
        //hmo
        $Hmolist = Hmolist::all();
        //state
        $states = StatesNigeria::orderBy('name')->get();
        $health_diaries=PatientHealthDiary::where(array('patient_id'=>isset($patient_id)?$patient_id:'',))->orderBy('id','DESC')->get();
       if(Auth::guard('patient')->check()){
            return view('patient.appointment.index')->with(array('controller'=> 'patient','user'=>$user,'page'=>'inner','page_type'=>'extra_links','hospitals'=>$Hospitals,"health_diaries"=>$health_diaries,'doctors'=>$Doctors,'search_hospital_name'=>$search_hospital_name,'search_doctor_id'=>$search_doctor_id,'serviceOffered'=>$serviceOffered,'speciality'=>$speciality,'Hmolist'=>$Hmolist,'states'=>$states));
       }else{
            return view('patient.appointment.index')->with(array('controller'=> 'patient','user'=>'','page'=>'inner','page_type'=>'extra_links','hospitals'=>$Hospitals,"health_diaries"=>$health_diaries,'doctors'=>$Doctors,'search_hospital_name'=>$search_hospital_name,'search_doctor_id'=>$search_doctor_id,'serviceOffered'=>$serviceOffered,'speciality'=>$speciality,'Hmolist'=>$Hmolist,'states'=>$states));
       }
    }

    public function patient_appointment(Request $request){
        
        // dd(Auth::user());
            $value = Session::get('token');
            if(Auth::user()){
                $user = $request->user();
                $patient_id = Auth::user()->patient_unique_id;
                $login_token =PatientLoginToken::where(array('patient_id'=>$patient_id,'login_token'=>$value))->first();        
                if(isset($login_token->token_status) && $login_token->token_status == 0){ 
                    Auth::guard('patient')->logout();           
                    return redirect('/patient/login');
                }
                if(!Auth::check()){            
                    return redirect('/patient/login');
                } 
                $patient_id = Auth::user()->patient_unique_id;
            }
            $user = $request->user();
            $hospitals = Hospital::orderBy('hosp_name','ASC')->with('doctor_hospital_details');
            // dd($hospitals);
            $search_hospital_name = '';
            if(isset($_GET['hospital_name'])){
                $search_hospital_name = $_GET['hospital_name'];
                $hospitals = $hospitals->where('hosp_name', 'like', '%'.$_GET['hospital_name'].'%');
            }
            if(isset($_GET['offered'])){
                $hospitals = $hospitals->where(function($query) use ($request) {
                    foreach ($_GET['offered'] as $key => $connectivity) {
                        if ($key == 0) {
                            $query->whereRaw('find_in_set("'.$connectivity.'",serviceofferd)');
                        } else {
                            $query->orWhereRaw('find_in_set("'.$connectivity.'",serviceofferd)');
                        }
                    }
                });
            }
            if(isset($_GET['hosp_speciality'])){
                $hospitals = $hospitals->where('hosp_speciality', 'like', '%'.$_GET['hosp_speciality'].'%');
            }
            if(isset($_GET['type_of_speciality'])){
                $hospitals = $hospitals->where('hosp_speciality', 'like', '%'.$_GET['type_of_speciality'].'%');
            }
            
            if(isset($_GET['state'])){
                $hospitals = $hospitals->where('hosp_state', 'like', '%'.$_GET['state'].'%');
            }
            if(isset($_GET['lga'])){
                $hospitals = $hospitals->where('lga', 'like', '%'.$_GET['lga'].'%');
            }
            if(isset($_GET['HMO'])){
                $hospitals = $hospitals->whereRaw('find_in_set("'.$_GET['HMO'].'",hmo)');
            }
            $search_doctor_id = '';
            if(isset($_GET['doctor_id']) && $_GET['doctor_id']!=''){
                $search_doctor_id = $_GET['doctor_id'];
            }
            
            $hospitals = $hospitals->get();
            
            $Hospitals = array();
            // array('A' => array(),
            // 'B' => array(),'C' => array(), 'D' => array(), 'E' => array(),'F' => array(), 'G' => array(), 'H' => array(), 'I' => array(), 'J' => array(),'K' => array(), 'L' => array(), 'M' => array(), 'N' => array(), 'O' => array(), 'P' => array(), 'Q' => array(), 'R' => array(), 'S' => array()); 
            foreach ($hospitals as $key => $value) {
                if(isset($value->hosp_name)){
                    $Hospitals[substr(ucfirst($value->hosp_name),0,1)][$key] = $value;//$value->name ;
                }   
            }
            $doctors = [];
            if(isset($_GET['hosp_id']) && $_GET['hosp_id']!=''){
                $doctors = Doctor::with('doctor_availability')->where('hospital_id',$_GET['hosp_id'])->get();
            }
            $Doctors = array();
            // array('A' => array(),
            // 'B' => array(),'C' => array(), 'D' => array(), 'E' => array(),'F' => array(), 'G' => array(), 'H' => array(), 'I' => array(), 'J' => array(),'K' => array(), 'L' => array(), 'M' => array(), 'N' => array(), 'O' => array(), 'P' => array(), 'Q' => array(), 'R' => array(), 'S' => array()); 
            foreach ($doctors as $key => $value) {
                if(isset($value->doctor_first_name)){
                    $Doctors[substr(ucfirst($value->doctor_first_name),0,1)][$key] = $value;//$value->name ;
                }   
            }
            //speciality
            $speciality = Speciality::all();
            //Service Offered
            $serviceOffered = ServiceOffered::all();
            //hmo
            $Hmolist = Hmolist::all();
            //state
            $states = StatesNigeria::orderBy('name')->get();

            $health_diaries=PatientHealthDiary::where(array('patient_id'=>isset($patient_id)?$patient_id:'',))->orderBy('id','DESC')->get();
           if(Auth::guard('patient')->check()){
                return view('patient.appointment.index')->with(array('controller'=> 'patient','user'=>$user,'page'=>'inner','page_type'=>'extra_links','hospitals'=>$Hospitals,"health_diaries"=>$health_diaries,'doctors'=>$Doctors,'search_hospital_name'=>$search_hospital_name,'search_doctor_id'=>$search_doctor_id,'serviceOffered'=>$serviceOffered,'speciality'=>$speciality,'Hmolist'=>$Hmolist,'states'=>$states));
           }else{
                return view('patient.appointment.index')->with(array('controller'=> 'patient','user'=>'','page'=>'inner','page_type'=>'extra_links','hospitals'=>$Hospitals,"health_diaries"=>$health_diaries,'doctors'=>$Doctors,'search_hospital_name'=>$search_hospital_name,'search_doctor_id'=>$search_doctor_id,'serviceOffered'=>$serviceOffered,'speciality'=>$speciality,'Hmolist'=>$Hmolist,'states'=>$states));
           }
        }
    // Get Patient and doctor
    public function getPaitintByDoctor(Request $request){
        $admin = Auth::user();
        $doctors_details = Doctor::where('doctor_id',$request->id)->first();
        $doctors_details['patient_name'] = $admin->patient_first_name." ".$admin->patient_last_name;
        $doctors_details['patient_gender'] = $admin->patient_gender;
        $doctors_details['patient_address'] = $admin->patient_address;
        $now = time(); 
        $patient_date_of_birth = $now - $admin->patient_date_of_birth;
        //There are 31556926 seconds in a year.
        $age = floor($patient_date_of_birth / 31556926);
        $doctors_details['patient_age']=$age;
        // dd($admin->created_at);
        $doctors_details['patient_date_of_birth'] = date('d F Y',$admin->patient_date_of_birth);   
        $doctors_details['patient_month_year'] = Carbon::parse($admin->created_at)->format('m Y');
        $doctors_details['patient_date'] = Carbon::parse($admin->created_at)->format('d');
        $doctors_details['patient_time'] = Carbon::parse($admin->created_at)->format('h:i:A');
        $doctors_details['patient_image'] = $admin->patient_profile_img;
        return response()->json($doctors_details);
    }
    
     // Get Patient and doctor
     public function saveAppointmentDetails(Request $request){
        $value = Session::get('token');
        $patient_id = Auth::user()->patient_unique_id;
        $login_token =PatientLoginToken::where(array('patient_id'=>$patient_id,'login_token'=>$value))->first();        
        if(isset($login_token->token_status) && $login_token->token_status == 0){ 
            Auth::guard('patient')->logout();           
            return redirect('/patient/login');
        }
        if(!Auth::check()){            
            return redirect('/patient/login');
        } 
        $patient_id = Auth::user()->patient_unique_id;
        $patient_details = $request->user();               
        $time_zone = $patient_details->timezone;
        $hospital_id = $request->hosp_id ? $request->hosp_id : '';
        $hospital_data =Hospital::where('hosp_id',$hospital_id)->first(); 
        $doctor_id = $request->doctor_id ? $request->doctor_id : '';
        $doctor_data =Doctor::where('doctor_id',$doctor_id)->first(); 
        
        $appointment_date = $request->appoint_date." ".$request->time; 
        $appointment_date = date('d-m-Y H:i:s',strtotime($appointment_date));  
        if($request->appointment_type == 1){            
            $telemedical=NULL;
            $telemedical_consult_type = NULL;
            $telemedical_consult_time = NULL;
           
            if(!empty($appointment_date)){  
                          
                $dtz = new DateTimeZone($time_zone);     
                $date = date('Y-m-d H:i:s',strtotime($appointment_date));                  
                $time_in_sofia = new DateTime($date, $dtz);        
                $date_offset = $time_in_sofia->format('Z');       
                $appointment_time = strtotime($date)-$date_offset;             
            }else{
                $appointment_time = NULL;
            }
            $PatientAppointment = new PatientAppointment([
                'appointment_id'              => $this->generateAUniqueNumber(),
                'patient_id'                  => $patient_id,
                'appointment_type'            => 1,
                'telemedical_type'            => $telemedical,  
                'telemedical_consult_type'    => $telemedical_consult_type, 
                'telemedical_consult_time'    => $telemedical_consult_time, 
                'appoint_booking_status'      => 0,
                'appoint_created_date'        => strtotime("now"),  
                'appointment_time'            => $appointment_time,
                'status'                      => 1                
            ]); 

            $PatientAppointment->save();
            $status = 0;
            
            if(isset($PatientAppointment->appointment_id)){
                $booking_count = SaveTelemedicalBookingDetail::where('appointment_id',$PatientAppointment->appointment_id)->get();
                if(count($booking_count) > 0){
                  $status = 1;
                  $_POST['submit_id'] = $booking_count[0]['booking_id'];
                }
            }
            $booking_exists=SaveTelemedicalBookingDetail::where('save_telemedical_booking_detail.patient_id',$patient_id)->where('save_telemedical_booking_detail.appointment_time',$appointment_time)->where('appointment_id','!=',$PatientAppointment->appointment_id)->where('approved_status','!=',2)->count();
            $booking_name = NULL;
            if($booking_exists == 0){
                             
                  $save_telemedical_booking_detail = new SaveTelemedicalBookingDetail([                
                    'booking_id'    => $this->generateBUniqueNumber(),
                    'appointment_id'  => $PatientAppointment->appointment_id,
                    'booking_name'    => trim($booking_name),
                    'patient_id'    => $patient_id,
                    'hospital_id'   => $hospital_id,
                    'doctor_id'     => $doctor_id,
                    'specialist_id'   => 0,
                    'hospital_name'   => trim(isset($hospital_data)?$hospital_data->hospital_name:''), 
                    'mobile_number'   => trim(isset($patient_details)?$patient_details->patient_phone:''),
                    'symptoms'      => isset($request->reanson_for_visit)?$request->reanson_for_visit:'',
                    'terms_conditions'  => '', 
                    'appointment_time'  => $appointment_time,
                    'sharing_status'  => 0, 
                    'approved_status' => 0,
                    'status'      => 1,
                    'created_at'    => strtotime("now")                             
                  ]); 

                  $save_telemedical_booking_detail->save();
                  if(isset($PatientAppointment->appointment_id)){
                    PatientAppointment::where('appointment_id', $PatientAppointment->appointment_id)->update(['appoint_booking_status' => 1]);
                  }
                  $UserNotification = new UserNotification([                
                    'notification_id'   => $this->generateNUniqueNumber(),
                    'doctor_id'         => $doctor_id, 
                    'assignee_type'     => 1,                    
                    'patient_id'        => $patient_id, 
                    'event_id'          => $save_telemedical_booking_detail->booking_id,
                    'notification_type' => "appt",
                    'change_type'       => "created",
                    'created_date'      => strtotime('now'),
                    'status'            => 0                                          
                  ]);
                  $UserNotification->save(); 

                    $login_token = PatientLoginToken::where('patient_id',$patient_id)->where('token_status',1)->get();

                    $msg = "Dr.".Auth::user()->doctor_first_name." ".Auth::user()->doctor_last_name." scheduled a new hospital appointment with you";

                    $patients_notification = PatientNotificationSetting::where('patient_id', $patient_id)->first();
                    if(isset($patients_notification->patient_id)){
                        if($patients_notification->appointment_activity_push == 1){
                            if(count($login_token) > 0 && $login_token[0]->device_type != 2){            
                                $device_token = $login_token[0]->device_token;
                                $path = base_path()."/ios_notifcation/all_notifications.php";
                                $nid = $save_telemedical_booking_detail->booking_id;
                                $type= 'appt';
                                exec ('php '.$path.' "'.$msg.'" '.$nid.' '.$type.' '.$device_token.' > /dev/null &');
                            }
                        }

                        if($patients_notification->appointment_activity_email == 1){
                            $url = url('/doctor/send_mail/'.str_replace(" ", "_", $msg).'/'.$_POST['patient_id'].'');   
                            $cmd  = "curl --max-time 60 ";   
                            $cmd .= "'" . $url . "'";   
                            $cmd .= " > /dev/null 2>&1 &";    
                            exec($cmd, $output, $exit); 
                        }
                    }

                         // Send message on phone
                          $message= $this->appointment_message($save_telemedical_booking_detail->booking_id,$patient_id,$doctor_id,2);
                            $this->sendMessage($message,'+919800186999');   

                      return response()->json(['redirect'=>1,'success'=>1,'message'=>'Booking added successfully.','id'=>$save_telemedical_booking_detail->booking_id,'telemedical_type'=>$request->appointment_type,"redirect_url"=>asset('/patient/appointment')],200);
                    

            }else{
                return response()->json(['redirect'=>0,'success'=>0,'message'=>'You already have booking with another doctor.'],200);
            }
        }






        // $admin_id = Auth::user()->id;
        // $PatientAppointment = new PatientAppointment([
        //     'appointment_id'		=> $this->generateUniqueNumber(),
        //     'patient_id'			=> $admin_id,
        //     'appointment_type'		=> $request->hosps_id ? $request->hosps_id : '',
        //     'telemedical_type'		=> '',	
        //     'telemedical_consult_type' => '',	
        //     'telemedical_consult_time' => '',	
        //     'appointment_time'		=> $request->time,	
        //     'reanson_for_visit'		=> $request->reanson_for_visit,	
        //     'appoint_booking_status'	=> 0,
        //     'appoint_created_date'	=> strtotime("now"),		
        //     'status'				=> 1			     			
        // ]);	
        // $PatientAppointment->save();
        // return response()->json(['redirect'=>1,"redirect_url"=>asset('/patient/appointment')],200);
     }
     protected function generateUniqueNumber() {
        $number = mt_rand(1000000000, 9999999999); // better than rand()
        // call the same function if the uniwue id exists already
        if ($this->uniqueNumberExists($number)) {
            return $this->generateUniqueNumber();
        }
        // otherwise, it's valid and can be used
        return strval($number);
    }
    protected function uniqueNumberExists($number) {
        // query the database and return a boolean		   
        return Patient::wherepatient_unique_id($number)->exists();
    }
    protected function generateAUniqueNumber() {
        $number = mt_rand(1000000000, 9999999999); // better than rand()
        // call the same function if the uniwue id exists already
        if ($this->uniqueANumberExists($number)) {
            return $this->generateAUniqueNumber();
        }
        // otherwise, it's valid and can be used
        return strval($number);
    }
    protected function uniqueANumberExists($number) {
        // query the database and return a boolean       
        return PatientAppointment::whereappointment_id($number)->exists();
    }
    protected function generateBUniqueNumber() {
        $number = mt_rand(1000000000, 9999999999); // better than rand()
        // call the same function if the uniwue id exists already
        if ($this->uniqueBNumberExists($number)) {
            return $this->generateBUniqueNumber();
        }
        // otherwise, it's valid and can be used
        return strval($number);
    }

    protected function uniqueBNumberExists($number) {
        // query the database and return a boolean       
        return SaveTelemedicalBookingDetail::wherebooking_id($number)->exists();
    }
    protected function generateNUniqueNumber() {
        $number = mt_rand(1000000000, 9999999999); // better than rand()
        // call the same function if the uniwue id exists already
        if ($this->uniqueNNumberExists($number)) {
            return $this->generateNUniqueNumber();
        }
        // otherwise, it's valid and can be used
        return strval($number);
    }

    protected function uniqueNNumberExists($number) {
        // query the database and return a boolean         
        return UserNotification::wherenotification_id($number)->exists();
    }
    protected function appointment_message($booking_id,$patient_id,$doctor_id,$type){
        $message="";
        if($type==2){
        $app="hospital";
        }else{
        $app="telemedical";
        }
          $patient_detail = Patient::where('patient_unique_id',$patient_id)->first();
        $patient_first_name = $patient_detail->patient_first_name;
        $patient_timezone = Auth::user()->timezone;
        $doc_det = SaveTelemedicalBookingDetail::with('doctor','doctor.specialist_categories')->where('booking_id', $booking_id)->get();
        date_default_timezone_set($patient_timezone);          
        $date1=date("F d, Y",$doc_det[0]['appointment_time']);
        $time_of= date("g:i A",$doc_det[0]['appointment_time']);
        $doctor_details = Doctor::where('doctor_id',$doctor_id)->first();
        $message="Hello ".$patient_first_name.", \n ";
        $message.="Your new ".$app." appointment is scheduled.\n ";
        $message.="Here are the details:\n ";
        if(!empty($doctor_details)){
        $message.="Doctor: Dr.".$doctor_details->doctor_first_name." ".$doctor_details->doctor_last_name." \n ";
        }
        $message.="Date: ".$date1." \n ";
        $message.="Time: ". $time_of." \n ";
        $message.="For any queries, you can contact us at: contact@renderhealth.com \n ";  
        return $message;
        }
        // Send messsage to user
      private function sendMessage($message, $recipients)
      {
      $account_sid = getenv("TWILIO_SID");
      $auth_token = getenv("TWILIO_AUTH_TOKEN");
      $twilio_number = getenv("TWILIO_NUMBER");
      $client = new Client($account_sid, $auth_token);

     /* $validation_request = $client->validationRequests
      ->create($recipients, // phoneNumber
      array(
      "friendlyName" => "Newuser"
      )
      );
      print($validation_request);
      if(!empty($validation_request->friendlyName)){*/
      $client->messages->create($recipients, ['from' => $twilio_number, 'body' => $message]);
// }
     return 1;
  }

}