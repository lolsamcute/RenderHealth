<?php
namespace App\Http\Controllers\Api;


use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Auth;
use DB;
use Validator;
use App\Models\Doctor;

class DoctorsController extends Controller
{
    public function __construct()
    {
    }
    
    //Get all Doctor and display
    public function index(Request $request)
    {
        try {
            if(isset($_GET['type'])){        
            if($_GET['type'] == "doc_page")
            {
                $doc_page = $_GET['page'];
                $limit = 10;            
            }
            else
            {
                $doc_page = $_GET['doc_page'];
                $limit = 10;            
                } 
            }else{
                $doc_page = 1;
                $nurse_page =1;
                $ad_page =1;
                $limit = 10;          
            }
            
            $doctor = Doctor::orderBy('created_at', 'desc')->paginate($limit, ['*'],'page',$doc_page);
            return response()->json(['doctor' => $doctor], 200);
        } catch (\Throwable $th) {
            return response()->json(['error' => 'Invalid Request'], 400);
        }
    }

    // Get Doctor Information
    public function show(Request $request){
        try {
            if ($request->id) {
                $doctor = Doctor::where('id',$request->id)->first();
                return response()->json(['doctor' => $doctor], 200);
            } else {
                return response()->json(['error' => 'Invalid Request'], 400);
            }
        } catch (\Throwable $th) {
            return response()->json(['error' => 'Invalid Request'], 400);
        }
    }
}
