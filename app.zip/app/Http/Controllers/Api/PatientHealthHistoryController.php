<?php
	
	namespace App\Http\Controllers\Api;
	
	use App\Http\Requests;
	use Illuminate\Http\Request;
	use Illuminate\Support\Facades\Input;
	use GuzzleHttp\Client;
	use Auth;
	use Validator;
	use Redirect;
	use Session;
	use Response;
	use DB;
	use Hash;
	use View;
	use Mail;
	use Cookie;
	use DateTime;	
	use App\Http\Controllers\Controller;
	use Illuminate\Routing\UrlGenerator;
	use App\Models\Patient;	
	use App\Models\PatientLoginToken;
	use App\Models\HealthHistory;
	
	class PatientHealthHistoryController extends Controller
	{
		public function __construct()
		{
			
		}

		/******
		Patient Health History Api
	 	*******/
		public function healthHistoryListing(Request $header_request){	
			try{ 		
				$decodedArray = json_decode( file_get_contents('php://input'));			
				$decodedArray =  (array) $decodedArray;
				$_POST = $decodedArray;		

				$this->app_version      = $header_request->header('app-version');
		        $this->device_type      = strtoupper($header_request->header('device-type'));
		        $this->device_token     = $header_request->header('device-token');
		        $this->time_zone        = $header_request->header('time-zone');	        
				
				 if($this->app_version=='' || $this->device_type =='' || $this->device_token=='' || $this->time_zone ==''){        	 
		            return response()->json(['success' => 0,'message'=>'Insufficient data in headers'],200);
		            exit;
		        }  
		        $_POST['login_token'] = $this->device_token;
		        $time_zone = $this->time_zone;
				
				$result = $this->check_basic_parameters($_POST);
				//echo "<pre>"; print_R($result); exit;
				if($result ==1)
				{	
					$check_user_by_ID = $this->check_user_by_ID($_POST['patient_id']);

					if($check_user_by_ID ==0)
					{
						return response()->json(['success'=>0,'message'=>'Please enter correct user id.'],200);					
					}
					
					$token_status = $this->check_token_status($_POST['patient_id'],$_POST['login_token']);
					
					if($token_status ==1)
					{		
						if($_POST['page'] == ""){	
							$base_url = asset('/');									
							$health_history = HealthHistory::with(array('patient','doctor.specialist_categories','doctor.doctor_hospital_details','history_medication'))->with(array('patient'=>function($q) use($base_url){$q->select('*',DB::Raw('CONCAT("'.$base_url.'uploads/patient/",patient_profile_img) as patient_profile_img'));}))->with(array('doctor'=>function($q) use($base_url){$q->select('*',DB::Raw('CONCAT("'.$base_url.'admin/doctor/uploads/profile/",doctor_picture) as doctor_picture'));}))->with(array('history_attachments'=>function($q) use($base_url){$q->select('*',DB::Raw('CONCAT("'.$base_url.'admin/doctor/uploads/hhistory/",patient_history_id,"/",patient_attachment_name) as patient_attachment_name'));}))->where('patient_id',$_POST['patient_id'])->orderBy('created_date','DESC')->get();	          				
							if(count($health_history) > 0){								
								return response()->json(['success'=>1,'data'=>$health_history],200);
							}else{
								return response()->json(['success'=>0,'message'=>"No Data Found"],200);
							}
						}else{
							$limit = 5;
							$page = $_POST['page'];
							$base_url = asset('/');								
							$health_history=HealthHistory::with(array('patient','doctor.specialist_categories','doctor.doctor_hospital_details','history_medication'))->with(array('patient'=>function($q) use($base_url){$q->select('*',DB::Raw('CONCAT("'.$base_url.'uploads/patient/",patient_profile_img) as patient_profile_img'));}))->with(array('doctor'=>function($q) use($base_url){$q->select('*',DB::Raw('CONCAT("'.$base_url.'admin/doctor/uploads/profile/",doctor_picture) as doctor_picture'));}))->with(array('history_attachments'=>function($q) use($base_url){$q->select('*',DB::Raw('CONCAT("'.$base_url.'admin/doctor/uploads/hhistory/",patient_history_id,"/",patient_attachment_name) as patient_attachment_name'));}))->where('patient_id',$_POST['patient_id'])->orderBy('created_date','DESC')->paginate($limit, ['*'],'page',$page); 
							if(count($health_history) > 0){
								$total = $health_history->lastPage(); 
								$health_history = $health_history->toArray()['data'];
								return response()->json(['success'=>1,'data'=>$health_history,'total'=>$total],200);
							}else{
								return response()->json(['success'=>0,'message'=>"No Data Found"],200);
							}
						}
					}

					if($token_status == 0)
					{
						return response()->json(['success'=>2,'message'=>'Expired login token.'],200);						
					}
					if($token_status == 2)
					{
						return response()->json(['success'=>2,'message'=>'Invalid login token.'],200);					
					}
				}
			}catch(\Exception $e){
				return response()->json(['success' => 0,'message'=>$e->getMessage()]);
			}  
		}

		/******
		Patient Health History Detail Api
	 	*******/

		public function healthHistoryView(Request $header_request){	
			try{ 		
				$decodedArray = json_decode( file_get_contents('php://input'));			
				$decodedArray =  (array) $decodedArray;
				$_POST = $decodedArray;		

				$this->app_version      = $header_request->header('app-version');
		        $this->device_type      = strtoupper($header_request->header('device-type'));
		        $this->device_token     = $header_request->header('device-token');
		        $this->time_zone        = $header_request->header('time-zone');	        
				
				 if($this->app_version=='' || $this->device_type =='' || $this->device_token=='' || $this->time_zone ==''){        	 
		            return response()->json(['success' => 0,'message'=>'Insufficient data in headers'],200);
		            exit;
		        }  
		        $_POST['login_token'] = $this->device_token;
		        $time_zone = $this->time_zone;
				
				$result = $this->check_basic_parameters($_POST);
				//echo "<pre>"; print_R($result); exit;
				if($result ==1)
				{	
					$check_user_by_ID = $this->check_user_by_ID($_POST['patient_id']);

					if($check_user_by_ID ==0)
					{
						return response()->json(['success'=>0,'message'=>'Please enter correct user id.'],200);					
					}
					
					$token_status = $this->check_token_status($_POST['patient_id'],$_POST['login_token']);
					
					if($token_status ==1)
					{										
						$health_history=HealthHistory::with(array('patient','doctor','history_attachments','doctor.specialist_categories','doctor.doctor_hospital_details'))->where('health_history.history_id',$_POST['history_id'])->get();
						if(count($health_history) > 0){
							return response()->json(['success'=>1,'data'=>$health_history],200);
						}else{
							return response()->json(['success'=>0,'message'=>"No Data Found"],200);
						}
					}

					if($token_status == 0)
					{
						return response()->json(['success'=>2,'message'=>'Expired login token.'],200);						
					}
					if($token_status == 2)
					{
						return response()->json(['success'=>2,'message'=>'Invalid login token.'],200);					
					}
				}
			}catch(\Exception $e){
				return response()->json(['success' => 0,'message'=>$e->getMessage()]);
			}
		}

		protected function check_basic_parameters($data)
		{
			
			if(!isset($data['login_token']) || empty($data['login_token']))
			{
				echo json_encode(array('success'=>0,'message'=>'Please provide Login token'));
				exit;
			}
			if(!isset($data['patient_id']) || empty($data['patient_id']))
			{
				echo json_encode(array('success'=>0,'message'=>'Please provide user id'));
				exit;
			}
			return 1;
		}

		protected function check_user_by_ID($user_id)
		{
			$check_user_by_ID = Patient::where('patient_unique_id', '=', $user_id)->get();

			if(!empty($check_user_by_ID) && count($check_user_by_ID)==1)
			{
				if($check_user_by_ID[0]->patient_unique_id == $user_id)
				{
					return 1;
				}
				if($check_user_by_ID[0]->patient_unique_id != $user_id)
				{
					return 0;
				}
			}
			if(empty($check_user_by_ID))
			{
				return 0;
			}
		}

		private function check_token_status($user_id,$login_token)
		{
			$where_condition_user = array('patient_id'=>$user_id,'login_token'=>$login_token);

			$token_status= PatientLoginToken::where($where_condition_user)->get();
			//echo "<pre>"; print_R($token_status); exit;
			if(count($token_status)<=0)
			{
				return 2;
			}
			if(count($token_status)>0)
			{
				return $token_status[0]->token_status;
			}
		}
		
		protected function generateUniqueNumber() {
		    $number = mt_rand(1000000000, 9999999999); // better than rand()
		    // call the same function if the uniwue id exists already
		    if ($this->uniqueNumberExists($number)) {
		        return $this->generateUniqueNumber();
		    }
		    // otherwise, it's valid and can be used
		    return strval($number);
		}

		protected function uniqueNumberExists($number) {
		    // query the database and return a boolean		   
		    return Patient::wherepatient_unique_id($number)->exists();
		}
	}