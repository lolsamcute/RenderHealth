<?php
namespace App\Http\Controllers\Api;


use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Auth;
use DB;
use Validator;
use Redirect;
use DateTime;
use DateTimeZone;
use Session;
use Hash;
use Mail;
use App\Models\PatientLoginToken;
use App\Models\Patient;
use App\Models\Hospital;
use App\Models\Facility;
use App\Models\Deals;
use App\Models\DealCategories;
class DealsController extends Controller
{
    public function __construct()
    {
    }
    
    //Get all deals and display
    public function index(Request $request)
    {
        //get pagination params
        if(isset($_GET['type']))
        {        
           if($_GET['type'] == "doc_page")
           {
               $doc_page = $_GET['page'];
               $limit = 10;            
           }
           else
           {
               $doc_page = $_GET['doc_page'];
               $limit = 10;            
           } 
       }
       else
       {
         $doc_page = 1;
         $nurse_page =1;
         $ad_page =1;
         $limit = 10;          
       }

        $facilities = Facility::all();
        $deals = Deals::with('facility_details')->where(['is_deleted' => 0]);
        if(isset($_GET['filter']))
        {
            if($_GET['filter'] == 'Active') $deals->where('status','Active');
            if($_GET['filter'] == 'Expired') $deals->where('status','Expired');
        }
        $deals = $deals->orderBy('created_at', 'desc')->paginate($limit, ['*'],'page',$doc_page);
        return response()->json(['deals'=>$deals,'facilities'=>$facilities]);
    }

    // get all categories dynamically
    public function getCategories(Request $request)
    {
        $deal_categories = DB::table("deal_categories")
                    ->where(["facility_id" => $request->facility_id,'is_deleted' => 0])
                    ->pluck("name","id",'image');
        return response()->json($deal_categories);
    }

    // Get Deal Information
    public function show(Request $request){
        $deals = Deals::with('facility_details','categories_details')->where('id',$request->id)->where('category_id',$request->category_id)->first();
        return response()->json($deals);
    }
    //Get all deals and display
    public function dealsCategory(Request $request)
    {
        $dealCategories = DealCategories::with('facility_details')->where(['is_deleted' => 0])->orderBy('created_at', 'desc')->get();
        return response()->json(['dealCategories'=>$dealCategories]);
    }
    // Get Deal List
    public function showDealsList($id=null,$sort_val=null){
        $deals = Deals::with('facility_details','categories_details')->where('start_date', '<=', date('Y-m-d'))->where('end_date', '>=', date('Y-m-d'))->where('category_id',$id)->where('is_deleted','0');
        if($sort_val){
            $deals = $deals->orderBy($sort_val);
        }
        $deals = $deals->get();
        return response()->json($deals);
    }
}
