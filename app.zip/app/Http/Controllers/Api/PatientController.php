<?php
	
	namespace App\Http\Controllers\Api;
	
	use App\Http\Requests;
	use Illuminate\Http\Request;
	use Illuminate\Support\Facades\Input;
	use GuzzleHttp\Client;
	use Auth;
	use Validator;
	use Redirect;
	use Session;
	use Response;
	use DB;
	use Hash;
	use View;
	use Mail;
	use Illuminate\Support\Facades\URL;
	use Cookie;
	use DateTime;	
	use App\Http\Controllers\Controller;
	use Illuminate\Routing\UrlGenerator;
	use App\Models\Patient;
	use App\Models\PatientLoginToken;
	use App\Models\SaveTelemedicalBookingDetail;
	use App\Models\HealthHistory;
	use App\Models\PatientNotificationSetting;
	use App\Models\UserNotification;
	use App\Models\RequestInformation;
	use App\Models\ScheduleDemo;
	use App\Models\GetListedOnRender;
	
	class PatientController extends Controller
	{

		/**
			* Create a new controller instance.
			*
			* @return void
		*/
		public $successStatus = 200;
		

		public function __construct()
		{
			// $this->middleware('auth');
		}

		public function create(){			
			header('Content-Type: application/x-www-form-urlencoded');
			header('Content-Type: application/json');
			$decodedArray = json_decode( file_get_contents('php://input'));
			$decodedArray =  (array) $decodedArray;
			$_POST = $decodedArray;	

			return Response::json(array(
			'success' => 1,
			'message' => $_POST
			));	
		}

		/* Login api */
		public function login(Request $request){ 
			try{
				header('Content-Type: application/x-www-form-urlencoded');
				header('Content-Type: application/json');
				$decodedArray = json_decode( file_get_contents('php://input'));
				$decodedArray =  (array) $decodedArray;
				$_POST = $decodedArray;
				if(isset($_POST) && !empty($_POST))
				{
					if(!isset($_POST['device_token']) || empty($_POST['device_token']))
					{
						return response()->json(['success' => '0','message'=>'Device token is Missing.'],200);
					}				
					
					$validator = Validator::make($_POST, [ 	           
			            'patient_email' => 'required|email',	             
			            'patient_password' => 'required', 	            
			        ]);
			        if($validator->fails()){
			        	return response()->json(['success'=>0, 'message'=>$validator->messages()->first()], 401);
			        }
			        else{
				        if(Auth::guard('patient')->attempt(['patient_email' => $_POST['patient_email'], 'password' => $_POST['patient_password']])){ 
				            $user = Auth::guard('patient')->user();		            
				            $success['id'] =  (string)$user->id; 
				            $token = $user->createToken('MyApp')->accessToken;
					        $success['token'] =  $token;	 
					        PatientLoginToken::where(array('patient_id'=>$user->patient_unique_id))->update(array('token_status'=>0));
			                $PatientLoginToken = new PatientLoginToken([                
			                    'patient_id'    => $user->patient_unique_id,
			                    'login_token'   => $token, 
			                    'device_token'	=> $_POST['device_token'],
			                    'token_status'  => "1",
			                    'device_type'   => "1",                                           
			                ]);
			                $PatientLoginToken->save();	       
					        $success['patient_email'] =  $user->patient_email; 
					        $success['patient_first_name'] =  $user->patient_first_name; 
					        $success['patient_phone'] =  $user->patient_phone; 
					        $success['patient_unique_id'] =  (string)$user->patient_unique_id; 
				            return response()->json(['success'=>1, 'data' => $success], $this->successStatus); 
				        } 
				        else{ 
				            return response()->json(['success'=>0, 'message'=>'Please enter a valid email and password'], 401); 
				        } 
			        }
			     	
			    }else{
					echo json_encode(array('success'=>0,'message'=>'Some thing going wrong'));
					exit;
				}
			}catch(Exception $e) {
				return response()->json(['error'=>1,"message"=>$e->getMessage()],200);		 
			}
	    }
	    /** 
     * Register api 
     * 
     * @return \Illuminate\Http\Response 
     */ 
	    public function register(Request $request){ 
	    	try{
		    	header('Content-Type: application/x-www-form-urlencoded');
				header('Content-Type: application/json');			
				$decodedArray = json_decode( file_get_contents('php://input'));
				$decodedArray =  (array) $decodedArray;
				$_POST = $decodedArray;

		  		if(isset($_POST) && !empty($_POST))
				{		

					if(!isset($_POST['device_type']) || empty($_POST['device_type']))
					{
						return response()->json(['success' => '0','message'=>'Device type is Missing.'],200);
					}	
					if($_POST['device_type'] == 1){						
						if(!isset($_POST['device_token']) || empty($_POST['device_token']))
						{
							return response()->json(['success' => '0','message'=>'Device token is Missing.'],200);
						}	
					}	

			        $validator = Validator::make($_POST, [ 
			            'patient_first_name' => 'required', 
			            'patient_last_name' => 'required', 
			            /*'patient_username' => 'required|unique:patients',*/
			            'patient_email' => 'required|email|unique:patients',			             
			            'patient_phone' => 'required|max:15', 
			            'patient_password' => 'required' 
			            
			        ]);
					if ($validator->fails()) { 
						$errorMsg=$validator->messages();				
					    return response()->json(['success'=>0, 'message'=>$validator->messages()->first()], 401);            
					}

					$input = $_POST; 
			        $input['patient_password'] = bcrypt($input['patient_password']); 			     				  
				    $input['patient_unique_id'] = $this->generateUniqueNumber();  
			        $user = Patient::create($input); 			
			        $success['id'] =  (string)$user->id; 
			        $token = $user->createToken('MyApp')->accessToken;
			        $success['token'] = $token;	   
			        $success['patient_email'] =  $user->patient_email; 
			        $success['patient_first_name'] =  $user->patient_first_name; 
			        $success['patient_phone'] = $user->patient_phone; 
			        $success['patient_unique_id'] =  $user->patient_unique_id;
			        if(isset($_POST['device_token'])){
			        	$device_token = $_POST['device_token'];
			        	PatientLoginToken::where(array('patient_id'=>$user->patient_unique_id,'device_type'=>$_POST['device_type'],'device_token'=>$device_token))->update(array('token_status'=>0)); 
			        }else{
			        	$device_token = NULL;
			        	PatientLoginToken::where(array('patient_id'=>$user->patient_unique_id,'device_type'=>$_POST['device_type']))->update(array('token_status'=>0)); 
			        }	        
			        
			        $PatientLoginToken = new PatientLoginToken([				
					    'patient_id'	=> $user->patient_unique_id,
					    'login_token'	=> $token, 
					    'device_token'	=> $device_token,
					    'token_status'	=> "1",
					    'device_type'	=> $_POST['device_type']			    			     			
					]);
					$PatientLoginToken->save();	
					 
					return response()->json(['success'=>1, 'data'=>$success], $this->successStatus); 
					
				}else{
					echo json_encode(array('success'=>0,'message'=>'Some thing going wrong'));
					exit;
				}
			}catch(Exception $e) {
				return response()->json(['error'=>1,"message"=>$e->getMessage()],200);		 
			}
	    }

	    /******
		Forgot Password Api
	 	*******/
	    public function forgotpassword(){
			try{
				header('Content-Type: application/x-www-form-urlencoded');
				header('Content-Type: application/json');			
				$decodedArray = json_decode( file_get_contents('php://input'));
				$decodedArray =  (array) $decodedArray;
				$_POST = $decodedArray;
				//echo "<pre>"; print_R($_POST); exit;
				$user = Patient::where('patient_email',$_POST['patient_email'])->first();
				if(!$user)
				{
						return response()->json(['success'=>0,"message"=>"This email does not exists."],200);	
				}
				else
				{
					$FPtoken = str_random(16);
					Patient::where('patient_email',$user->patient_email)->update(['fp_token'=>$FPtoken]);
					
					$send_email_from = $_ENV['send_email_from'];
					
					$data['recoverurl'] = asset('/patient/recoverpassword')."/".$user->patient_unique_id."/".$FPtoken;
					
					$data['name'] = $user->patient_first_name;
					
					$sent_to_email = $user->patient_email ;
					
					Mail::send('emails.recoverpassword', $data, function ($message) use ($sent_to_email,$send_email_from) {

					        $message->from($send_email_from, 'Render Health'); 

					        $message->to($sent_to_email)->subject('Recover password Render Health');

					});
					return response()->json(['success'=>1,"message"=>"Reset Password link sent to ".$sent_to_email.""],200);
				}
			}catch(Exception $e) {
				return response()->json(['error'=>1,"message"=>$e->getMessage()],200);		 
			}
		}	

		/******
		Patient Logout Api
	 	*******/
		public function logout(){
			try{
				header('Content-Type: application/x-www-form-urlencoded');
				header('Content-Type: application/json');
				$decodedArray = json_decode( file_get_contents('php://input'));
				$decodedArray =  (array) $decodedArray;
				$_POST = $decodedArray; 
	        	

				$result = $this->check_basic_parameters($_POST);

				if($result ==1)
				{	
					$check_user_by_ID = $this->check_user_by_ID($_POST['user_id']);

					if($check_user_by_ID ==0)
					{
						return response()->json(['success'=>0,'message'=>'Please enter correct user id.'],200);					
					}
					
					$token_status = $this->check_token_status($_POST['user_id'],$_POST['login_token']);
					
					if($token_status ==1)
					{				   
					    PatientLoginToken::where(array('patient_id'=> $_POST['user_id']))->update(array('token_status'=>0)); 
					    return response()->json(['success'=>1,'message'=>'Logout successfully'],200);
					}

					if($token_status == 0)
					{
						return response()->json(['success'=>0,'message'=>'Expired login token.'],200);						
					}
					if($token_status == 2)
					{
						return response()->json(['success'=>0,'message'=>'Invalid login token.'],200);					
					}

				}
			}catch(Exception $e) {
				return response()->json(['error'=>1,"message"=>$e->getMessage()],200);		 
			}
		    
		}

		/* Patient profile update api */
		public function profileUpdate(Request $header_request){ 
			try{
				$this->app_version      = $header_request->header('app-version');
		        $this->device_type      = strtoupper($header_request->header('device-type'));
		        $this->device_token     = $header_request->header('device-token');
		        $this->time_zone        = $header_request->header('time-zone');	        
		        //$this->server           = $header_request->server('HTTP_HOST');		       

		        if($this->app_version=='' || $this->device_type =='' || $this->device_token=='' || $this->time_zone ==''){        	 
		            return response()->json(['success' => 0,'message'=>'Insufficient data in headers'],200);
		            exit;
	        	}  
	        	$_POST['login_token'] = $this->device_token; 
	        	$_POST['user_id'] = $_POST['patient_id'];      	
	        	$time_zone = $this->time_zone;
				//echo "<pre>"; print_R($_FILES['profile_img']); exit;
				if(isset($_POST) && !empty($_POST))
				{

					$result = $this->check_basic_parameters($_POST);

					if($result ==1)
					{	
						$check_user_by_ID = $this->check_user_by_ID($_POST['user_id']);

						if($check_user_by_ID ==0)
						{
							return response()->json(['success'=>0,'message'=>'Please enter correct user id.'],200);					
						}
						
						$token_status = $this->check_token_status($_POST['user_id'],$_POST['login_token']);
						
						if($token_status ==1)
						{				   				
					
							$validator = Validator::make($_POST, [ 	                
					            'patient_id' => 'required',	             
					            'patient_first_name' => 'required',	             
					            'patient_last_name' => 'required',	             
					            'patient_phone' => 'required',	             
					            'patient_martial_status' => 'required',	             
					            'patient_address' => 'required',	             
					            'patient_dob' => 'required',	
					            'patient_gender' => 'required',            	             
					            'patient_origin_state' => 'required',	             	             
					            'blood' => 'required',	             	             
					            'patient_languages' => 'required',
					            'patient_insurance' => 'required',
					            'profile_img'=>'image|max:2000'	            	            
					        ], [
						        'profile_img.max' => 'Image size should be as less then 2 Mb',
						    ]);
					        if($validator->fails()){
					        	return response()->json(['success'=>0, 'message'=>$validator->messages()], 401);
					        }else{
				        		$check_user_by_ID = Patient::where('patient_unique_id', '=', $_POST['user_id'])->get();							
								$patient_dob= strtotime($_POST['patient_dob']);

						        if(isset($_FILES['profile_img'])){
						        	$image=$header_request->file('profile_img');
							        $image = time().'.'.$image->getClientOriginalExtension();
							        $destinationPath = public_path().'/uploads/patient';
							        if(!empty($check_user_by_ID[0]->patient_profile_img)){
							          	if(file_exists($destinationPath."/".$check_user_by_ID[0]->patient_profile_img)){
							          		unlink($destinationPath."/".$check_user_by_ID[0]->patient_profile_img);
							          	}
							        }
							        $header_request->file('profile_img')->move($destinationPath, $image);
							        Patient::where('patient_unique_id', $_POST['user_id'])->update([        
							          'patient_first_name'      => $_POST['patient_first_name'],
							          'patient_last_name'       => $_POST['patient_last_name'],
							          'patient_phone'           => $_POST['patient_phone'],
							          'patient_martial_status'  => $_POST['patient_martial_status'],
							          'patient_address'         => $_POST['patient_address'],
							          'patient_date_of_birth'   => $patient_dob,
							          'patient_gender'          => $_POST['patient_gender'],
							          'patient_origin_state'    => $_POST['patient_origin_state'],
							          'patient_blood_type'      => $_POST['blood'],
							          'patient_languages'       => $_POST['patient_languages'],
							          'patient_insurance'       => $_POST['patient_insurance'],
							          'patient_profile_img'     =>$image
							        ]);
							    }
							    else{
								    Patient::where('patient_unique_id', $_POST['user_id'])->update([        
							          'patient_first_name'      => $_POST['patient_first_name'],
							          'patient_last_name'       => $_POST['patient_last_name'],
							          'patient_phone'           => $_POST['patient_phone'],
							          'patient_martial_status'  => $_POST['patient_martial_status'],
							          'patient_address'         => $_POST['patient_address'],
							          'patient_date_of_birth'   => $patient_dob,
							          'patient_gender'          => $_POST['patient_gender'],
							          'patient_origin_state'    => $_POST['patient_origin_state'],
							          'patient_blood_type'      => $_POST['blood'],
							          'patient_languages'       => $_POST['patient_languages'],
							          'patient_insurance'       => $_POST['patient_insurance']
								    ]);
							    }

							    $patient_detail = Patient::where('patient_unique_id', '=', $_POST['user_id'])->get();

							    return response()->json(['success'=>1,'message'=>'Profile Updated successfully','data'=>$patient_detail],200);
												        	
				        	}
					    }

						if($token_status == 0)
						{
							return response()->json(['success'=>0,'message'=>'Expired login token.'],200);						
						}
						if($token_status == 2)
						{
							return response()->json(['success'=>0,'message'=>'Invalid login token.'],200);					
						}

					}
			     	
			    }else{
					echo json_encode(array('success'=>0,'message'=>'Some thing going wrong'));
					exit;
				}
			}catch(Exception $e) {
				return response()->json(['error'=>1,"message"=>$e->getMessage()],200);		 
			}
	    }

	    /* Patient get profile api */
		public function getProfile(Request $header_request){ 
			try{
				$decodedArray = json_decode( file_get_contents('php://input'));			
				$decodedArray =  (array) $decodedArray;
				$_POST = $decodedArray;	

				$this->app_version      = $header_request->header('app-version');
		        $this->device_type      = strtoupper($header_request->header('device-type'));
		        $this->device_token     = $header_request->header('device-token');
		        $this->time_zone        = $header_request->header('time-zone');	        
		        //$this->server           = $header_request->server('HTTP_HOST');		       

		        if($this->app_version=='' || $this->device_type =='' || $this->device_token=='' || $this->time_zone ==''){        	 
		            return response()->json(['success' => 0,'message'=>'Insufficient data in headers'],200);
		            exit;
	        	}  
	        	$_POST['login_token'] = $this->device_token;       
	        	$_POST['user_id'] = $_POST['patient_id']; 	
	        	$time_zone = $this->time_zone;
				//echo "<pre>"; print_R($_FILES['profile_img']); exit;
				if(isset($_POST) && !empty($_POST))
				{

					$result = $this->check_basic_parameters($_POST);

					if($result ==1)
					{	
						$check_user_by_ID = $this->check_user_by_ID($_POST['user_id']);

						if($check_user_by_ID ==0)
						{
							return response()->json(['success'=>0,'message'=>'Please enter correct user id.'],200);					
						}
						
						$token_status = $this->check_token_status($_POST['user_id'],$_POST['login_token']);
						
						if($token_status ==1)
						{
							$base_url = asset('/');
							$myprofile = Patient::where('patient_unique_id', $_POST['user_id'])->select('*',DB::Raw('CONCAT("'.$base_url.'uploads/patient/",patients.patient_profile_img) as patient_profile_img'))->get();
							$appointment_count = SaveTelemedicalBookingDetail::where('patient_id',$_POST['user_id'])->count();
							$history_count = HealthHistory::where('patient_id',$_POST['user_id'])->count();
							$notfy_data = PatientNotificationSetting::where('patient_id', '=', $_POST['user_id'])->get();							
							return response()->json(['success'=>1,'data'=>$myprofile,'notfy_data'=>$notfy_data,'apt_cnt'=>$appointment_count,'hstry_cnt'=>$history_count],200);

					    }

						if($token_status == 0)
						{
							return response()->json(['success'=>2,'message'=>'Expired login token.'],200);						
						}
						if($token_status == 2)
						{
							return response()->json(['success'=>2,'message'=>'Invalid login token.'],200);					
						}

					}
			     	
			    }else{
					echo json_encode(array('success'=>2,'message'=>'Some thing going wrong'));
					exit;
				}
			}catch(Exception $e) {
				return response()->json(['error'=>1,"message"=>$e->getMessage()],200);		 
			}
	    }

	    /* Patient notification api */
		public function notificationUpdate(Request $header_request){ 
			try{
				$decodedArray = json_decode( file_get_contents('php://input'));			
				$decodedArray =  (array) $decodedArray;
				$_POST = $decodedArray;	

				$this->app_version      = $header_request->header('app-version');
		        $this->device_type      = strtoupper($header_request->header('device-type'));
		        $this->device_token     = $header_request->header('device-token');
		        $this->time_zone        = $header_request->header('time-zone');	        
		        //$this->server           = $header_request->server('HTTP_HOST');		       

		        if($this->app_version=='' || $this->device_type =='' || $this->device_token=='' || $this->time_zone ==''){        	 
		            return response()->json(['success' => 0,'message'=>'Insufficient data in headers'],200);
		            exit;
	        	}  
	        	$_POST['login_token'] = $this->device_token;   
	        	$_POST['user_id'] = $_POST['patient_id'];     	
	        	$time_zone = $this->time_zone;
				//echo "<pre>"; print_R($_FILES['profile_img']); exit;
				if(isset($_POST) && !empty($_POST))
				{

					$result = $this->check_basic_parameters($_POST);

					if($result ==1)
					{	
						$check_user_by_ID = $this->check_user_by_ID($_POST['user_id']);

						if($check_user_by_ID ==0)
						{
							return response()->json(['success'=>0,'message'=>'Please enter correct user id.'],200);					
						}
						
						$token_status = $this->check_token_status($_POST['user_id'],$_POST['login_token']);
						
						if($token_status ==1)
						{
							$notfy_status = PatientNotificationSetting::where('patient_id', '=', $_POST['user_id'])->count();
							if(isset($_POST['patient_activty']) && $_POST['patient_activty'] != ""){
								$patient_activity = $_POST['patient_activty'];
							}else{
								$patient_activity = 0;
							}
							if(isset($_POST['patient_newsletter']) && $_POST['patient_newsletter'] != ""){
								$patient_newsletter = $_POST['patient_newsletter'];
							}else{
								$patient_newsletter = 0;
							}
							if(isset($_POST['patient_activty_push']) && $_POST['patient_activty_push'] != ""){
								$patient_activty_push = $_POST['patient_activty_push'];
							}else{
								$patient_activty_push = 0;
							}
							if(isset($_POST['patient_activty_sms']) && $_POST['patient_activty_sms'] != ""){
								$patient_activty_sms = $_POST['patient_activty_sms'];
							}else{
								$patient_activty_sms = 0;
							}
							if(isset($_POST['appt_cancel_email']) && $_POST['appt_cancel_email'] != ""){
								$appt_cancel_email = $_POST['appt_cancel_email'];
							}else{
								$appt_cancel_email = 0;
							}
							if(isset($_POST['appt_cancel_push']) && $_POST['appt_cancel_push'] != ""){
								$appt_cancel_push = $_POST['appt_cancel_push'];
							}else{
								$appt_cancel_push = 0;
							}
							if(isset($_POST['appt_cancel_sms']) && $_POST['appt_cancel_sms'] != ""){
								$appt_cancel_sms = $_POST['appt_cancel_sms'];
							}else{
								$appt_cancel_sms = 0;
							}
							if(isset($_POST['appt_reschedule_email']) && $_POST['appt_reschedule_email'] != ""){
								$appt_reschedule_email = $_POST['appt_reschedule_email'];
							}else{
								$appt_reschedule_email = 0;
							}
							if(isset($_POST['appt_reschedule_device']) && $_POST['appt_reschedule_device'] != ""){
								$appt_reschedule_device = $_POST['appt_reschedule_device'];
							}else{
								$appt_reschedule_device = 0;
							}
							if(isset($_POST['appt_reschedule_sms']) && $_POST['appt_reschedule_sms'] != ""){
								$appt_reschedule_sms = $_POST['appt_reschedule_sms'];
							}else{
								$appt_reschedule_sms = 0;
							}
							if(isset($_POST['patient_history_push']) && $_POST['patient_history_push'] != ""){
								$patient_history_push = $_POST['patient_history_push'];
							}else{
								$patient_history_push = 0;
							}
							if(isset($_POST['patient_history']) && $_POST['patient_history'] != ""){
								$patient_history = $_POST['patient_history'];
							}else{
								$patient_history = 0;
							}
							if(isset($_POST['outstanding_bill_email']) && $_POST['outstanding_bill_email'] != ""){
								$outstanding_bill_email = $_POST['outstanding_bill_email'];
							}else{
								$outstanding_bill_email = 0;
							}
							if(isset($_POST['appt_reminder_push']) && $_POST['appt_reminder_push'] != ""){
								$appt_reminder_push = $_POST['appt_reminder_push'];
							}else{
								$appt_reminder_push = 0;
							}
							if(isset($_POST['appt_reminder_sms']) && $_POST['appt_reminder_sms'] != ""){
								$appt_reminder_sms = $_POST['appt_reminder_sms'];
							}else{
								$appt_reminder_sms = 0;
							}
							if(isset($_POST['bill_email']) && $_POST['bill_email'] != ""){
								$bill_email = $_POST['bill_email'];
							}else{
								$bill_email = 0;
							}
							if(isset($_POST['bill_push']) && $_POST['bill_push'] != ""){
								$bill_push = $_POST['bill_push'];
							}else{
								$bill_push = 0;
							}
							if(isset($_POST['health_diary_push']) && $_POST['health_diary_push'] != ""){
								$health_diary_push = $_POST['health_diary_push'];
							}else{
								$health_diary_push = 0;
							}
							if(isset($_POST['outstanding_bill_push']) && $_POST['outstanding_bill_push'] != ""){
								$outstanding_bill_push = $_POST['outstanding_bill_push'];
							}else{
								$outstanding_bill_push = 0;
							}
							if($notfy_status > 0) {
							  	  	PatientNotificationSetting::where('patient_id', $_POST['user_id'])->update([           
							          'appointment_activity_email'   => $patient_activity,
							          'newsletter_subscription'      => $patient_newsletter,
							          'patient_history_notification' => $patient_history,
							          'appointment_activity_push'    => $patient_activty_push,
							          'appointment_activity_sms'     => $patient_activty_sms,
							          'appointment_cancel_email'     => $appt_cancel_email,
							          'appointment_cancel_push'      => $appt_cancel_push,
							          'appointment_cancel_sms'       => $appt_cancel_sms,
							          'appointment_reschedule_email' => $appt_reschedule_email,
							          'appointment_reschedule_push'  => $appt_reschedule_device,
							          'appointment_reschedule_sms'   => $appt_reschedule_sms,
							          'patient_history_push'         => $patient_history_push,
							          'patient_appt_reminder_push'   => $appt_reminder_push,
							          'patient_appt_reminder_sms'    => $appt_reminder_sms,
							          'patient_bill_push'            => $bill_email,
							          'patient_bill_sms'             => $bill_push,
							          'heath_diary_push'             => $health_diary_push,
							          'outstanding_bill_push'        => $outstanding_bill_push,
							          'outstanding_bill_email'       => $outstanding_bill_email
							        ]);
							        $notfy_data = PatientNotificationSetting::where('patient_id', '=', $_POST['user_id'])->get();
						  			return response()->json(['success'=>1,'data'=>$notfy_data,'message'=>'Notification settings updated successfully']);	
						  		}else{
						  			$addParameters 									=  new PatientNotificationSetting();
						    		$addParameters->patient_id         				=	$_POST['user_id'];
							        $addParameters->Notification_unique_id     	 	= 	$this->generateUniqueNumber();
							        $addParameters->appointment_activity_email 		=	$patient_activity;
							        $addParameters->newsletter_subscription    		= 	$patient_newsletter;
							        $addParameters->patient_history_notification  	= 	$patient_history;
							        $addParameters->appointment_activity_push  		= 	$patient_activty_push;
							        $addParameters->appointment_activity_sms  		= 	$patient_activty_sms;
							        $addParameters->appointment_cancel_email  		= 	$appt_cancel_email;
							        $addParameters->appointment_cancel_push  		= 	$appt_cancel_push;
							        $addParameters->appointment_cancel_sms  		= 	$appt_cancel_sms;
							        $addParameters->appointment_reschedule_email  	= 	$appt_reschedule_email;
							        $addParameters->appointment_reschedule_push  	= 	$appt_reschedule_device;
							        $addParameters->appointment_reschedule_sms  	= 	$appt_reschedule_sms;
							        $addParameters->patient_history_push  			= 	$patient_history_push;
							        $addParameters->patient_appt_reminder_push  	= 	$appt_reminder_push;
							        $addParameters->patient_appt_reminder_sms  		= 	$appt_reminder_sms;
							        $addParameters->patient_bill_push  				= 	$bill_email;
							        $addParameters->patient_bill_sms  				= 	$bill_push;
							        $addParameters->heath_diary_push  				= 	$health_diary_push;
							        $addParameters->outstanding_bill_push  			= 	$outstanding_bill_push;
							        $addParameters->outstanding_bill_email  		= 	$outstanding_bill_email;
							        $addParameters->newsletter_subscription     	= 	$patient_newsletter;
						          if($addParameters->save()){
						          	$notfy_data = PatientNotificationSetting::where('patient_id', '=', $_POST['user_id'])->get();
						            return response()->json(['success'=>1,'data'=>$notfy_data, 'message'=>'Notification settings saved successfully']);
						          }else{
						          	return response()->json(['success'=>0,'message'=>"Notification settings couldn't be saved"]);
						          }
  							}

					    }

						if($token_status == 0)
						{
							return response()->json(['success'=>0,'message'=>'Expired login token.'],200);						
						}
						if($token_status == 2)
						{
							return response()->json(['success'=>0,'message'=>'Invalid login token.'],200);					
						}

					}
			     	
			    }else{
					echo json_encode(array('success'=>0,'message'=>'Some thing going wrong'));
					exit;
				}
			}catch(Exception $e) {
				return response()->json(['error'=>1,"message"=>$e->getMessage()],200);		 
			}
	    }

	    /* Patient get notification api */
		public function getNotificationSettings(Request $header_request){ 
			try{
				$decodedArray = json_decode( file_get_contents('php://input'));			
				$decodedArray =  (array) $decodedArray;
				$_POST = $decodedArray;	

				$this->app_version      = $header_request->header('app-version');
		        $this->device_type      = strtoupper($header_request->header('device-type'));
		        $this->device_token     = $header_request->header('device-token');
		        $this->time_zone        = $header_request->header('time-zone');	        
		        //$this->server           = $header_request->server('HTTP_HOST');		       

		        if($this->app_version=='' || $this->device_type =='' || $this->device_token=='' || $this->time_zone ==''){        	 
		            return response()->json(['success' => 0,'message'=>'Insufficient data in headers'],200);
		            exit;
	        	}  
	        	$_POST['login_token'] = $this->device_token;  
	        	$_POST['user_id'] = $_POST['patient_id'];      	
	        	$time_zone = $this->time_zone;
				//echo "<pre>"; print_R($_FILES['profile_img']); exit;
				if(isset($_POST) && !empty($_POST))
				{

					$result = $this->check_basic_parameters($_POST);

					if($result ==1)
					{	
						$check_user_by_ID = $this->check_user_by_ID($_POST['user_id']);

						if($check_user_by_ID ==0)
						{
							return response()->json(['success'=>0,'message'=>'Please enter correct user id.'],200);					
						}
						
						$token_status = $this->check_token_status($_POST['user_id'],$_POST['login_token']);
						
						if($token_status ==1)
						{
							$notfy_data = PatientNotificationSetting::where('patient_id', '=', $_POST['user_id'])->get();
							return response()->json(['success'=>1,'data'=>$notfy_data],200);

					    }

						if($token_status == 0)
						{
							return response()->json(['success'=>0,'message'=>'Expired login token.'],200);						
						}
						if($token_status == 2)
						{
							return response()->json(['success'=>0,'message'=>'Invalid login token.'],200);					
						}

					}
			     	
			    }else{
					echo json_encode(array('success'=>0,'message'=>'Some thing going wrong'));
					exit;
				}
			}catch(Exception $e) {
				return response()->json(['error'=>1,"message"=>$e->getMessage()],200);		 
			}
	    }

	    /* Update Patient account settings api */
		public function updateAccountSettings(Request $header_request){ 
			try{
				$decodedArray = json_decode( file_get_contents('php://input'));			
				$decodedArray =  (array) $decodedArray;
				$_POST = $decodedArray;	

				$this->app_version      = $header_request->header('app-version');
		        $this->device_type      = strtoupper($header_request->header('device-type'));
		        $this->device_token     = $header_request->header('device-token');
		        $this->time_zone        = $header_request->header('time-zone');	        
		        //$this->server           = $header_request->server('HTTP_HOST');		       

		        if($this->app_version=='' || $this->device_type =='' || $this->device_token=='' || $this->time_zone ==''){        	 
		            return response()->json(['success' => 0,'message'=>'Insufficient data in headers'],200);
		            exit;
	        	}  
	        	$_POST['login_token'] = $this->device_token;  
	        	$_POST['user_id'] = $_POST['patient_id'];      	
	        	$time_zone = $this->time_zone;
				//echo "<pre>"; print_R($_FILES['profile_img']); exit;
				if(isset($_POST) && !empty($_POST))
				{

					$result = $this->check_basic_parameters($_POST);

					if($result ==1)
					{	
						$check_user_by_ID = $this->check_user_by_ID($_POST['user_id']);

						if($check_user_by_ID ==0)
						{
							return response()->json(['success'=>0,'message'=>'Please enter correct user id.'],200);					
						}
						
						$token_status = $this->check_token_status($_POST['user_id'],$_POST['login_token']);
						
						if($token_status ==1)
						{							
					      	$account_setting = Patient::where('patient_unique_id', $_POST['user_id'])->first();
					      	$patientEmail = $account_setting->patient_email;
					      	$patientPassword = $account_setting->patient_password;
					      	$FormEmail = $_POST['account_email'];
					      	$FormPassword = $_POST['account_password'];					      

					      	if($FormEmail !=  $patientEmail){
					      		return response()->json(['success'=>0, 'message'=>"Email doesn't match with existing email"]);
					      	}else{
					        	$validatorAccount = Validator::make($_POST,[
					          		'account_email'=>'required|email',
					          		'account_password'=>'required',
					          		'account_new_password'=>'required',
					          		'account_conf_password'=>'required|same:account_new_password'
					        	]);
					        	if ($validatorAccount->fails()) {    
					        		return response()->json(['success'=>0, 'message'=>$validatorAccount->messages()->first()], 200);
					        	}
					     	}
					      	if(Hash::check($FormPassword, $patientPassword))
					      	{
					        	Patient::where('patient_unique_id', $_POST['user_id'])->update(['patient_password' => bcrypt($_POST['account_new_password'])]);
					         	return response()->json(['success'=>1,'message'=>'Password updated successfully']);
					      	}else{
					        	return response()->json(['success'=>0,'message'=>"Current password doesn't matches the existing password"]);
					        } 

					    }

						if($token_status == 0)
						{
							return response()->json(['success'=>2,'message'=>'Expired login token.'],200);						
						}
						if($token_status == 2)
						{
							return response()->json(['success'=>2,'message'=>'Invalid login token.'],200);					
						}

					}
			     	
			    }else{
					echo json_encode(array('success'=>0,'message'=>'Some thing going wrong'));
					exit;
				}
			}catch(Exception $e) {
				return response()->json(['error'=>1,"message"=>$e->getMessage()],200);		 
			}
	    }

	    /******
		Thirty min before appointment Cron
	 	*******/
	    public function apptThirtyMinNotification(){
			date_default_timezone_set('UTC');			
			$fromDate = strtotime("+59 minutes", strtotime('now'));
			$toDate = strtotime("+1 hour +01 minutes", strtotime('now'));	
			$appts = SaveTelemedicalBookingDetail::where('appointment_time','>=',$fromDate)->where('appointment_time','<',$toDate)->get();			
			
			if(count($appts) > 0){
				foreach($appts as $appt){
					$url = asset('/api/send_thirtyappt_notification/'.$appt->booking_id.'/'.$appt->patient_id.'');	 
				    $cmd  = "curl --max-time 60 ";   
				    $cmd .= "'" . $url . "'";   
				    $cmd .= " > /dev/null 2>&1 &";    
				    exec($cmd, $output, $exit); 		    
				}
			}	
			return 0;   
		}		

		
		public function sendThirtyApptNotification($appt_id,$user_id){
			$check_token = PatientLoginToken::where(['patient_id'=>$user_id,'token_status'=>1,'device_type'=>1])->get();	
			$appt = SaveTelemedicalBookingDetail::with('doctor')->where('booking_id',$appt_id)->first();

			if(isset($appt->booking_id)){
				$UserNotification = new UserNotification([                
                    'notification_id'   => $this->generateNUniqueNumber(),                                
                    'assignee_type'     => 4,                    
                    'patient_id'        => $appt['patient_id'], 
                    'event_id'          => $appt['booking_id'],
                    'notification_type' => "cron",
                    'change_type'       => "executed",
                    'created_date'      => strtotime('now'),
                    'status'            => 0                                          
                ]);
                $UserNotification->save();
            }

			if(count($check_token) > 0){									
				if(isset($appt->booking_id)){		
					$patients_notification = PatientNotificationSetting::where('patient_id', $appt['patient_id'])->first();
		            if(isset($patients_notification->patient_id)){
			           	if($patients_notification->patient_appt_reminder_push == 1){			
							$device_token = $check_token[0]->device_token;
		                    $path = "/var/www/html/projects/renderhealth/ios_notifcation/all_notifications.php";
		                    $msg = "You have an appointment with Dr.".$appt['doctor']['doctor_first_name']." ".$appt['doctor']['doctor_last_name']." in 1 hour";
		                    $nid = $appt['booking_id'];
		                    $type= 'appt';
		                    exec ('php '.$path.' '.$msg.' '.$nid.' '.$type.' '.$device_token.' > /dev/null &');
		                }
		            }
			    }
			}
		}	

		protected function check_basic_parameters($data){
			if(!isset($data['login_token']) || empty($data['login_token']))
			{
				echo json_encode(array('success'=>0,'message'=>'Please provide Login token'));
				exit;
			}
			if(!isset($data['user_id']) || empty($data['user_id']))
			{
				echo json_encode(array('success'=>0,'message'=>'Please provide user id'));
				exit;
			}
			return 1;
		}

		protected function check_user_by_ID($user_id){
			$check_user_by_ID = Patient::where('patient_unique_id', '=', $user_id)->get();

			if(!empty($check_user_by_ID) && count($check_user_by_ID)==1)
			{
				if($check_user_by_ID[0]->patient_unique_id == $user_id)
				{

					return 1;
				}
				if($check_user_by_ID[0]->patient_unique_id != $user_id)
				{
					return 0;
				}
			}
			if(empty($check_user_by_ID))
			{
				return 0;
			}
		}

		private function check_token_status($user_id,$login_token){
			$where_condition_user = array('patient_id'=>$user_id,'login_token'=>$login_token,'device_type'=>1);
			
			$token_status= PatientLoginToken::where($where_condition_user)->get();
			
			if(count($token_status) <= 0)
			{
				return 2;
			}
			if(!empty($token_status))
			{
				return $token_status[0]->token_status;
			}
		}
		
	    protected function generateUniqueNumber(){
		    $number = mt_rand(1000000000, 9999999999); // better than rand()
		    // call the same function if the uniwue id exists already
		    if ($this->uniqueNumberExists($number)) {
		        return $this->generateUniqueNumber();
		    }
		    // otherwise, it's valid and can be used
		    return strval($number);
		}

		protected function uniqueNumberExists($number){
		    // query the database and return a boolean		   
		    return Patient::wherepatient_unique_id($number)->exists();
		}

		protected function generateNUniqueNumber() {
	        $number = mt_rand(1000000000, 9999999999); // better than rand()
	        // call the same function if the uniwue id exists already
	        if ($this->uniqueNNumberExists($number)) {
	            return $this->generateNUniqueNumber();
	        }
	        // otherwise, it's valid and can be used
	        return strval($number);
	    }

	    protected function uniqueNNumberExists($number) {
	        // query the database and return a boolean         
	        return UserNotification::wherenotification_id($number)->exists();
	    }

		protected function guard(){
	        return Auth::guard('patient');
		}	  
		public function saveRequestInformation(Request $request)
		{
			if(RequestInformation::create($request->data)){
				return response()->json(['message'=>"Request information added successfully.","status"=>1,'redirect_url'=>URL::previous()]);
			}else{
				return response()->json(['message'=>"Request information not added successfully.","status"=>0,'redirect_url'=>URL::previous()]);
			}
		} 
		public function saveScheduleDemo(Request $request)
		{
			if(ScheduleDemo::create($request->data)){
				return response()->json(['message'=>"Schedule Demo added successfully.","status"=>1,'redirect_url'=>URL::previous()]);
			}else{
				return response()->json(['message'=>"Schedule Demo not added successfully.","status"=>0,'redirect_url'=>URL::previous()]);
			}
		}
		public function savegetListedOnRender(Request $request)
		{
			if(GetListedOnRender::create($request->data)){
				return response()->json(['message'=>"Get Listed On Render added successfully.","status"=>1,'redirect_url'=>URL::previous()]);
			}else{
				return response()->json(['message'=>"Get Listed On Render not added successfully.","status"=>0,'redirect_url'=>URL::previous()]);
			}
		}
	}