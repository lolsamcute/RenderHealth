<?php
	
	namespace App\Http\Controllers\Api;
	
	use App\Http\Requests;
	use Illuminate\Http\Request;
	use Illuminate\Support\Facades\Input;
	use GuzzleHttp\Client;
	use Auth;
	use Validator;
	use Redirect;
	use Session;
	use Response;
	use DB;
	use Hash;
	use View;
	use Mail;
	use Cookie;
	use DateTime;	
	use DateTimeZone;
	use App\Http\Controllers\Controller;
	use Illuminate\Routing\UrlGenerator;
	use App\Models\Patient;	
	use App\Models\PatientLoginToken;
	use App\Models\BillingDetail;
	use App\Models\PaidBillingDetail;
	use App\Models\BillingService;
	use App\Models\PaymentErrorLog;
	
	class PatientBillingController extends Controller
	{
		public function __construct()
		{
			
		}

		/******
		Billing List Api
	 	*******/
		public function billingList(Request $header_request){
			try{ 		
				$decodedArray = json_decode( file_get_contents('php://input'));			
				$decodedArray =  (array) $decodedArray;
				$_POST = $decodedArray;

				$this->app_version      = $header_request->header('app-version');
		        $this->device_type      = strtoupper($header_request->header('device-type'));
		        $this->device_token     = $header_request->header('device-token');
		        $this->time_zone        = $header_request->header('time-zone');	        
				
				 if($this->app_version=='' || $this->device_type =='' || $this->device_token=='' || $this->time_zone ==''){        	 
		            return response()->json(['success' => 0,'message'=>'Insufficient data in headers'],200);
		            exit;
		        }  
		        $_POST['login_token'] = $this->device_token;
		        $time_zone = $this->time_zone;
				
				$result = $this->check_basic_parameters($_POST);
				//echo "<pre>"; print_R($result); exit;
				if($result ==1)
				{	
					$check_user_by_ID = $this->check_user_by_ID($_POST['patient_id']);
					//echo "<pre>"; print_R($check_user_by_ID); exit;
					if($check_user_by_ID ==0)
					{
						return response()->json(['success'=>0,'message'=>'Please enter correct user id.'],200);					
					}
					
					$token_status = $this->check_token_status($_POST['patient_id'],$_POST['login_token']);
					
					if($token_status ==1)
					{		
						if($_POST['page'] == "" && $_POST['comp_page'] == ""){										
							$outstanding_detail = BillingDetail::with(array('doctor','nurse','hospital','employee','billing_service','doctor.doctor_hospital_details','doctor.specialist_categories','employee.specialist_categories','nurse.specialist_categories','hospital.specialist_categories'))->where('patient_id',$_POST['patient_id'])->whereRaw('payable_amount-paid_amount > 0')->orderBy('billing_date','DESC')->get();							
	          				$paid_detail = BillingDetail::with(array('doctor','nurse','hospital','employee','billing_service','doctor.doctor_hospital_details','doctor.specialist_categories','employee.specialist_categories','nurse.specialist_categories','hospital.specialist_categories'))->where('patient_id',$_POST['patient_id'])->whereRaw('payable_amount-paid_amount = 0')->orderBy('paid_date','DESC')->get();	          				
	          				
							if(count($outstanding_detail) > 0 || count($paid_detail) > 0){								
								return response()->json(['success'=>1,'out_data'=>$outstanding_detail,'comp_data'=>$paid_detail],200);
						}else{
							return response()->json(['success'=>0,'message'=>"No Data Found"],200);
						}
						}else{
							$limit = 5;
							$page = $_POST['page'];
							$comp_page = $_POST['comp_page'];							
							$outstanding_detail = BillingDetail::with(array('doctor','nurse','hospital','employee','billing_service','doctor.doctor_hospital_details','doctor.specialist_categories','employee.specialist_categories','nurse.specialist_categories','hospital.specialist_categories'))->where('patient_id',$_POST['patient_id'])->whereRaw('payable_amount-paid_amount > 0')->orderBy('billing_date','DESC')->paginate($limit, ['*'],'page',$page);
							$total = $outstanding_detail->lastPage();
	          				$paid_detail = BillingDetail::with(array('doctor','nurse','hospital','employee','billing_service','doctor.doctor_hospital_details','doctor.specialist_categories','employee.specialist_categories','nurse.specialist_categories','hospital.specialist_categories'))->where('patient_id',$_POST['patient_id'])->whereRaw('payable_amount-paid_amount = 0')->orderBy('paid_date','DESC')->paginate($limit, ['*'],'page',$comp_page);
	          				
	          				$comp_total = $paid_detail->lastPage();
							if(count($outstanding_detail) > 0 || count($paid_detail) > 0){
								$outstanding_detail = $outstanding_detail->toArray()['data'];
								$paid_detail = $paid_detail->toArray()['data'];
								return response()->json(['success'=>1,'out_data'=>$outstanding_detail,'comp_data'=>$paid_detail,'total'=>$total,'comp_total'=>$comp_total],200);
							}else{
								return response()->json(['success'=>0,'message'=>"No Data Found"],200);
							}
						}
					}

					if($token_status == 0)
					{
						return response()->json(['success'=>2,'message'=>'Expired login token.'],200);						
					}
					if($token_status == 2)
					{
						return response()->json(['success'=>2,'message'=>'Invalid login token.'],200);					
					}
				}
			}catch(\Exception $e){
				return response()->json(['success' => 0,'message'=>$e->getMessage()]);
			}
		}

		/******
		Billing View Api
	 	*******/

		public function billingView(Request $header_request){
			try{ 		
				$decodedArray = json_decode( file_get_contents('php://input'));			
				$decodedArray =  (array) $decodedArray;
				$_POST = $decodedArray;

				$this->app_version      = $header_request->header('app-version');
		        $this->device_type      = strtoupper($header_request->header('device-type'));
		        $this->device_token     = $header_request->header('device-token');
		        $this->time_zone        = $header_request->header('time-zone');	        
				
				 if($this->app_version=='' || $this->device_type =='' || $this->device_token=='' || $this->time_zone ==''){        	 
		            return response()->json(['success' => 0,'message'=>'Insufficient data in headers'],200);
		            exit;
		        }  
		        $_POST['login_token'] = $this->device_token;
		        $time_zone = $this->time_zone;
				
				$result = $this->check_basic_parameters($_POST);
				//echo "<pre>"; print_R($result); exit;
				if($result ==1)
				{	
					$check_user_by_ID = $this->check_user_by_ID($_POST['patient_id']);
					//echo "<pre>"; print_R($check_user_by_ID); exit;
					if($check_user_by_ID ==0)
					{
						return response()->json(['success'=>0,'message'=>'Please enter correct user id.'],200);					
					}
					
					$token_status = $this->check_token_status($_POST['patient_id'],$_POST['login_token']);
					
					if($token_status ==1)
					{		
						$validator = Validator::make($_POST, [ 
				            'billing_id' => 'required'			                    
				        ]);
						if ($validator->fails()) { 
							$errorMsg=$validator->messages();				
						    return response()->json(['success'=>0, 'message'=>$validator->messages()->first()], 401);            
						}												
						$billing_detail = BillingDetail::with(array('doctor','nurse','hospital','employee','billing_service','doctor.doctor_hospital_details','doctor.specialist_categories','employee.specialist_categories','nurse.specialist_categories','hospital.specialist_categories'))->where('patient_id',$_POST['patient_id'])->where('billing_id',$_POST['billing_id'])->get();		

						$billing_sum = BillingService::where('pbilling_id',$_POST['billing_id'])->sum('service_amount');
							
						if(count($billing_detail) > 0){							
							return response()->json(['success'=>1,'comp_data'=>$billing_detail,'sum'=>$billing_sum],200);
						}else{
							return response()->json(['success'=>0,'message'=>"No Data Found"],200);
						}
					}

					if($token_status == 0)
					{
						return response()->json(['success'=>2,'message'=>'Expired login token.'],200);						
					}
					if($token_status == 2)
					{
						return response()->json(['success'=>2,'message'=>'Invalid login token.'],200);					
					}
				}
			}catch(\Exception $e){
				return response()->json(['success' => 0,'message'=>$e->getMessage()]);
			}
		}

		/******
		Pay Bill Api
	 	*******/
		public function PayBilling(Request $header_request){
			try{ 		
				$decodedArray = json_decode( file_get_contents('php://input'));			
				$decodedArray =  (array) $decodedArray;
				$_POST = $decodedArray;
				if(!isset($_POST['web'])){
					$this->app_version      = $header_request->header('app-version');
			        $this->device_type      = strtoupper($header_request->header('device-type'));
			        $this->device_token     = $header_request->header('device-token');
			        $this->time_zone        = $header_request->header('time-zone');	        
					
					 if($this->app_version=='' || $this->device_type =='' || $this->device_token=='' || $this->time_zone ==''){        	 
			            return response()->json(['success' => 0,'message'=>'Insufficient data in headers'],200);
			            exit;
			        }  
			        $_POST['login_token'] = $this->device_token;
			        $time_zone = $this->time_zone;
			    }else if(isset($_POST['time_zone'])){
					$time_zone = $_POST['time_zone'];
				}else{
					$time_zone = 'UTC';
				}
					
				$result = $this->check_basic_parameters($_POST);
				//echo "<pre>"; print_R($result); exit;
				if($result ==1)
				{	
					$check_user_by_ID = $this->check_user_by_ID($_POST['patient_id']);
					//echo "<pre>"; print_R($check_user_by_ID); exit;
					if($check_user_by_ID ==0)
					{
						return response()->json(['success'=>0,'message'=>'Please enter correct user id.'],200);					
					}
					
					$token_status = $this->check_token_status($_POST['patient_id'],$_POST['login_token']);
					
					if($token_status ==1)
					{	
						$dtz = new DateTimeZone($time_zone);     
				        $date = date('Y-m-d H:i:s',strtotime("now"));   				        
				        $time_in_sofia = new DateTime($date, $dtz);        
				        $date_offset = $time_in_sofia->format('Z');       
				        $billing_time = strtotime($date)-$date_offset;

				        $validator = Validator::make($_POST, [ 
				            'transaction_id' => 'required',
				            'billing_id' => 'required',
				            'patient_id' => 'required',				            
				            'amt'		=> 'required'			                    
				        ]);
						if ($validator->fails()) { 
							$errorMsg=$validator->messages();				
						    return response()->json(['success'=>0, 'message'=>$validator->messages()->first()], 401);            
						}

						$PayBilling = new PaidBillingDetail([
							'transaction_id'	=> $_POST['transaction_id'],
						    'billing_id'		=> $_POST['billing_id'],
						    'patient_id'		=> $_POST['patient_id'],
						    'doctor_id'			=> NULL,	
						    'appointment_id'	=> $_POST['appointment_id'],					    
						    'created_date'		=> $billing_time				   		     			
						]);	

						$PayBilling->save();

						$update_amt = BillingDetail::where('billing_id',$_POST['billing_id'])->update(['paid_amount'=> DB::raw('paid_amount + '.$_POST['amt']),'paid_date'=>$billing_time,'cash_card'=>"card"]);

						return response()->json(['success'=>1,'message'=>'Bill paid successfully.','data'=>$_POST['transaction_id']],200);
					}

					if($token_status == 0)
					{
						return response()->json(['success'=>2,'message'=>'Expired login token.'],200);						
					}
					if($token_status == 2)
					{
						return response()->json(['success'=>2,'message'=>'Invalid login token.'],200);					
					}
				}
			}catch(\Exception $e){
				return response()->json(['success' => 0,'message'=>$e->getMessage()]);
			}
		}

		/******
		Sending Pay Bill Url from Paystack Api
	 	*******/
		public function billPayment(Request $header_request){
			try{
				$decodedArray = json_decode( file_get_contents('php://input'));			
				$decodedArray =  (array) $decodedArray;
				$_POST = $decodedArray;
				$this->app_version      = $header_request->header('app-version');
		        $this->device_type      = strtoupper($header_request->header('device-type'));
		        $this->device_token     = $header_request->header('device-token');
		        $this->time_zone        = $header_request->header('time-zone');	        
				
				 if($this->app_version=='' || $this->device_type =='' || $this->device_token=='' || $this->time_zone ==''){        	 
		            return response()->json(['success' => 0,'message'=>'Insufficient data in headers'],200);
		            exit;
		        }  
		        $_POST['login_token'] = $this->device_token;
		        $time_zone = $this->time_zone;

		        $result = $this->check_basic_parameters($_POST);
					//echo "<pre>"; print_R($result); exit;
				if($result ==1)
				{	
					$check_user_by_ID = $this->check_user_by_ID($_POST['patient_id']);
					//echo "<pre>"; print_R($check_user_by_ID); exit;
					if($check_user_by_ID ==0)
					{
						return response()->json(['success'=>0,'message'=>'Please enter correct user id.'],200);					
					}
					
					$token_status = $this->check_token_status($_POST['patient_id'],$_POST['login_token']);
					
					if($token_status ==1)
					{	
						$validator = Validator::make($_POST, [ 
				            'amt' => 'required',	
				            'billing_id' => 'required',

				        ]);
						if ($validator->fails()) { 
							$errorMsg=$validator->messages();				
						    return response()->json(['success'=>0, 'message'=>$validator->messages()->first()], 401);            
						}
						$patient_det = Patient::select('patient_email')->where('patient_unique_id',$_POST['patient_id'])->get();
						$result = array();
						$meta_data = array('billing_id' => $_POST['billing_id'],'patient_id' => $_POST['patient_id'],'time_zone'=>$time_zone);
						//Set other parameters as keys in the $postdata array
						$ref = floor((strtotime('now') + rand()));
						$postdata =  array('email' => $patient_det[0]['patient_email'], 'amount' => $_POST['amt']*100,'reference' => $ref,'callback_url'=>url('patient/save_transac_det'),'metadata'=>json_encode($meta_data));
						
						$url = "https://api.paystack.co/transaction/initialize";
						$ch = curl_init();
						curl_setopt($ch, CURLOPT_URL,$url);
						curl_setopt($ch, CURLOPT_POST, 1);
						curl_setopt($ch, CURLOPT_POSTFIELDS,json_encode($postdata));  //Post Fields
						curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
						$headers = [
						  'Authorization: Bearer sk_test_858ee66cc3ec342738a20e52d4f1842942cee9a3',
						  'Content-Type: application/json',

						];
						curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
						$response = curl_exec($ch);
						
						$err = curl_error($ch);
						curl_close($ch);
						
						if($err){
						  	$result = json_decode($err,true);
						  	$PaymentErrorLog = new PaymentErrorLog([
								'transaction_id'	=> $ref,
							    'billing_id'		=> NULL,
							    'patient_id'		=> NULL,
							    'doctor_id'			=> NULL,
							    'error_msg'			=> $err,					    
							    'created_date'		=> strtotime("now")				   		     			
							]);	

							$PaymentErrorLog->save();
						  	return response()->json(['success'=>0,'message'=>$result['message']],200);
						}else{
						  $result = json_decode($response,true);						  				  
						  return response()->json(['success'=>1,'data' => $result['data']['authorization_url'],'message'=>$result['message']],200);
						 
						}
					}

					if($token_status == 0)
					{
						return response()->json(['success'=>2,'message'=>'Expired login token.'],200);						
					}
					if($token_status == 2)
					{
						return response()->json(['success'=>2,'message'=>'Invalid login token.'],200);					
					}
				}
			}catch(\Exception $e){
				return response()->json(['success' => 0,'message'=>$e->getMessage()]);
			}

		}
		

		protected function check_basic_parameters($data)
		{
			
			if(!isset($data['login_token']) || empty($data['login_token']))
			{
				echo json_encode(array('success'=>0,'message'=>'Please provide Login token'));
				exit;
			}
			if(!isset($data['patient_id']) || empty($data['patient_id']))
			{
				echo json_encode(array('success'=>0,'message'=>'Please provide user id'));
				exit;
			}
			return 1;
		}

		protected function check_user_by_ID($user_id)
		{
			$check_user_by_ID = Patient::where('patient_unique_id', '=', $user_id)->get();

			if(!empty($check_user_by_ID) && count($check_user_by_ID)==1)
			{
				if($check_user_by_ID[0]->patient_unique_id == $user_id)
				{
					return 1;
				}
				if($check_user_by_ID[0]->patient_unique_id != $user_id)
				{
					return 0;
				}
			}
			if(empty($check_user_by_ID))
			{
				return 0;
			}
		}

		private function check_token_status($user_id,$login_token)
		{
			$where_condition_user = array('patient_id'=>$user_id,'login_token'=>$login_token);

			$token_status= PatientLoginToken::where($where_condition_user)->get();
			//echo "<pre>"; print_R($token_status); exit;
			if(count($token_status)<=0)
			{
				return 2;
			}
			if(count($token_status)>0)
			{
				return $token_status[0]->token_status;
			}
		}
		
		protected function generateUniqueNumber() {
		    $number = mt_rand(1000000000, 9999999999); // better than rand()
		    // call the same function if the uniwue id exists already
		    if ($this->uniqueNumberExists($number)) {
		        return $this->generateUniqueNumber();
		    }
		    // otherwise, it's valid and can be used
		    return strval($number);
		}

		protected function uniqueNumberExists($number) {
		    // query the database and return a boolean		   
		    return Patient::wherepatient_unique_id($number)->exists();
		} 
	}

?>