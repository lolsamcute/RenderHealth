<?php
namespace App\Http\Controllers\Api;


use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Auth;
use DB;
use Validator;
use Redirect;
use DateTime;
use DateTimeZone;
use Session;
use Hash;
use Mail;
use App\Models\Hospital;
use App\Models\LocalGovernment;

class HospitalsController extends Controller
{
    public function __construct()
    {
    }
    
    //Get all hospital and display
    public function index(Request $request)
    {
        if(isset($_GET['type'])){        
           if($_GET['type'] == "doc_page")
           {
               $doc_page = $_GET['page'];
               $limit = 10;            
           }
           else
           {
               $doc_page = $_GET['doc_page'];
               $limit = 10;            
            } 
        }else{
            $doc_page = 1;
            $nurse_page =1;
            $ad_page =1;
            $limit = 10;          
        }
        
        $hospital = Hospital::orderBy('created_at', 'desc')->paginate($limit, ['*'],'page',$doc_page);
        return response()->json(['hospitals'=>$hospital]);
    }

    // Get hospital Information
    public function show(Request $request){
        $hospital = Hospital::where('id',$request->id)->first();
        return response()->json($hospital);
    }
    // Get hospital by specialist
    public function getHospitalBySpecialist($specialist=null,$sort_val=null){
        $hospital = Hospital::where('hosp_speciality',$specialist);
        if($sort_val){
            $hospital = $hospital->where('hosp_speciality',$specialist)->orderBy($sort_val);
        }
        $hospital = $hospital->get();
        return response()->json($hospital);
    }
    // Get all hospital by type of speciality/state/city 
    public function searchHospital(Request $request){
        $hospital = Hospital::get();
        if($request->type_of_speciality){
            $hospital = $hospital->where('hosp_speciality',$request->type_of_speciality);
        }
        if($request->state){
            $hospital = $hospital->where('hosp_state',$request->state);
        }
        if($request->city){
            $hospital = $hospital->where('hosp_city',$request->city);
        }
        return response()->json($hospital);
    }
    public function getStateWiseLGA($state_id=null)
    {
        $lga = LocalGovernment::where('state_id',$state_id)->get();
        return response()->json(['lga'=>$lga]);
    }

}
