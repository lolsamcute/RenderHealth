<?php
	
	namespace App\Http\Controllers\Api;
	
	use App\Http\Requests;
	use Illuminate\Http\Request;
	use Illuminate\Support\Facades\Input;
	use GuzzleHttp\Client;
	use Auth;
	use Validator;
	use Redirect;
	use Session;
	use Response;
	use DB;
	use Hash;
	use View;
	use Mail;
	use Cookie;
	use DateTime;	
	use DateTimeZone;
	use App\Http\Controllers\Controller;
	use Illuminate\Routing\UrlGenerator;
	use App\Models\Patient;
	use App\Models\Doctor;
	use App\Models\Hospital;
	use App\Models\PatientAppointment;
	use App\Models\PatientLoginToken;
	use App\Models\DoctorAvailability;
	use App\Models\DoctorLogin;
	use App\Models\SaveTelemedicalBookingDetail;
	use App\Models\SpecialistCategories;
	use App\Models\DoctorHospitalDetail;
use App\Models\Facility;
use App\Models\Speciality;
	use App\Models\StatesNigeria;
	use App\Models\UserNotification;
	use App\Models\PatientNotificationSetting;
	use App\Models\LocalGovernment;
	use App\Models\PatientHealthDiary;
	class PatientAppointmentController extends Controller
	{
		public function __construct()
		{
			
		}

		/******
		Patient Add Appointment Api
	 	*******/
		public function addAppointmentDetails(){
			header('Content-Type: application/x-www-form-urlencoded');
			header('Content-Type: application/json');
			$decodedArray = json_decode( file_get_contents('php://input'));			
			$decodedArray =  (array) $decodedArray;
			$_POST = $decodedArray;		
			//~ echo '<pre>'; print_r($_POST); die('here');
			$result = $this->check_basic_parameters($_POST);			
			if($result ==1)
			{	
				$check_user_by_ID = $this->check_user_by_ID($_POST['patient_id']);

				if($check_user_by_ID ==0)
				{
					return response()->json(['success'=>0,'message'=>'Please enter correct user id.'],200);					
				}
				
				$token_status = $this->check_token_status($_POST['patient_id'],$_POST['login_token']);
				
				if($token_status ==1)
				{		
					if($_POST['appointment_type'] == 1){
						$validator = Validator::make($_POST, [ 
				            //~ 'appointment_time' => 'required', 
				            'appointment_type' => 'required',			            
				            'telemedical_consult_type' => 'required',			            
				            'telemedical_consult_time' => 'required'			            
				        ]);
				    }else{
				    	$validator = Validator::make($_POST, [ 
				            //~ 'appointment_time' => 'required', 
				            'appointment_type' => 'required'        
				        ]);
				    }
					if ($validator->fails()) { 
						$errorMsg=$validator->messages();				
					    return response()->json(['success'=>0, 'message'=>$validator->messages()->first()], 401);            
					}		

					$telemedical=NULL;
					if($_POST['appointment_type'] == 1){
						
						if(!empty($_POST['telemedical_type']))
						{
							$telemedical = $_POST['telemedical_type'];
						}
						
						else
						{
							return response()->json(['success'=>0,'message'=>'telemedical type missing.'],200);	
						}			
						
					}else{
						$telemedical = NULL;
					}

					$telemedical_consult_type = NULL;
					if(isset($_POST['telemedical_consult_type'])){
						$telemedical_consult_type = $_POST['telemedical_consult_type'];
					}

					$telemedical_consult_time = NULL;
					if(isset($_POST['telemedical_consult_time'])){
						$telemedical_consult_time = $_POST['telemedical_consult_time'];
					}
				
					$PatientAppointment = new PatientAppointment([
						'appointment_id'		=> $this->generateUniqueNumber(),
					    'patient_id'			=> $_POST['patient_id'],
					    'appointment_type'		=> $_POST['appointment_type'],
					    'telemedical_type'		=> $telemedical,	
					    'telemedical_consult_type'		=> $telemedical_consult_type,	
					    'telemedical_consult_time'		=> $telemedical_consult_time,	
					    'appoint_booking_status'	=> 0,
					    'appoint_created_date'	=> strtotime("now"),		
					    'status'				=> 1			     			
					]);	

					$PatientAppointment->save();
					$appointment_id = array();
					$appointment_id['appoint_id'] = $PatientAppointment->appointment_id; 
					return response()->json(['success'=>1,'message'=>'Appointment added successfully.','data'=>$appointment_id],200);
				}
				
				
				if($token_status == 0)
				{
					return response()->json(['success'=>2,'message'=>'Expired login token.'],200);						
				}
				if($token_status == 2)
				{
					return response()->json(['success'=>2,'message'=>'Invalid login token.'],200);					
				}
				
			}
			
		}

		/******
		Doctor detail Api
	 	*******/
		public function sendDoctorDetails(Request $request){

			header('Content-Type: application/x-www-form-urlencoded');
			header('Content-Type: application/json');
			$decodedArray = json_decode( file_get_contents('php://input'));			
			$decodedArray =  (array) $decodedArray;
			$_POST = $decodedArray;		
			
			$result = $this->check_basic_parameters($_POST);
			
			if($result ==1)
			{	
				$check_user_by_ID = $this->check_user_by_ID($_POST['patient_id']);

				if($check_user_by_ID ==0)
				{
					return response()->json(['success'=>0,'message'=>'Please enter correct user id.'],200);					
				}
				
				$token_status = $this->check_token_status($_POST['patient_id'],$_POST['login_token']);
				
				if($token_status ==1)
				{
					$doctor_details = Doctor::select("doctor_first_name","doctor_last_name","doctor_email","doctor_picture", "doctor_education_school","doctor_degree","doctor_speciality","doctor_languages","doctor_religion")->get();

					return response()->json(['success'=>1,'data'=>$doctor_details],200);
				}

				if($token_status == 0)
				{
					return response()->json(['success'=>2,'message'=>'Expired login token.'],200);						
				}
				if($token_status == 2)
				{
					return response()->json(['success'=>2,'message'=>'Invalid login token.'],200);					
				}
			}
		}


		/******
		Doctor Search Detail Api
	 	*******/
		public function doctorSearchDetails(Request $request){
			
			header('Content-Type: application/x-www-form-urlencoded');
			header('Content-Type: application/json');
			$decodedArray = json_decode( file_get_contents('php://input'));			
			$decodedArray =  (array) $decodedArray;
			$_POST = $decodedArray;		
			
			$result = $this->check_basic_parameters($_POST);
			
			if($result ==1)
			{	
				$check_user_by_ID = $this->check_user_by_ID($_POST['patient_id']);

				if($check_user_by_ID ==0)
				{
					return response()->json(['success'=>0,'message'=>'Please enter correct user id.'],200);					
				}
				
				$token_status = $this->check_token_status($_POST['patient_id'],$_POST['login_token']);
				
				if($token_status ==1)
				{
					$doctor_details = Doctor::select("doctor_first_name","doctor_last_name","doctor_email","doctor_picture", "doctor_education_school","doctor_degree","doctor_speciality","doctor_languages","doctor_religion")->where('doctor_first_name', 'LIKE', '%' . $_POST['search_text'] . '%')->orWhere('doctor_last_name', 'LIKE', '%' . $_POST['search_text'] . '%')->get();

					return response()->json(['success'=>1,'data'=>$doctor_details],200);
				}

				if($token_status == 0)
				{
					return response()->json(['success'=>2,'message'=>'Expired login token.'],200);						
				}
				if($token_status == 2)
				{
					return response()->json(['success'=>2,'message'=>'Invalid login token.'],200);					
				}
			}
		}

		/******
		Hospital Search Api
	 	*******/
		public function hospitalSearchDetails(Request $header_request){
			header('Content-Type: application/x-www-form-urlencoded');
			header('Content-Type: application/json');
			$decodedArray = json_decode( file_get_contents('php://input'));			
			$decodedArray =  (array) $decodedArray;
			$_POST = $decodedArray;		

			$this->app_version      = $header_request->header('app-version');
	        $this->device_type      = strtoupper($header_request->header('device-type'));
	        $this->device_token     = $header_request->header('device-token');
	        $this->time_zone        = $header_request->header('time-zone');	        
			
			 if($this->app_version=='' || $this->device_type =='' || $this->device_token=='' || $this->time_zone ==''){        	 
	            return response()->json(['success' => 0,'message'=>'Insufficient data in headers'],200);
	            exit;
	        }  
	        $_POST['login_token'] = $this->device_token;
	        $time_zone = $this->time_zone;
			
			$result = $this->check_basic_parameters($_POST);
			//echo "<pre>"; print_R($result); exit;
			if($result ==1)
			{	
				$check_user_by_ID = $this->check_user_by_ID($_POST['patient_id']);

				if($check_user_by_ID ==0)
				{
					return response()->json(['success'=>0,'message'=>'Please enter correct user id.'],200);					
				}
				
				$token_status = $this->check_token_status($_POST['patient_id'],$_POST['login_token']);
				
				if($token_status ==1)
				{										
					$hosp_det = Hospital::select('*')->where('hosp_name', 'LIKE', '%' . $_POST['search_text'] . '%')->orderBy("hosp_name","ASC")->get();
					if(count($hosp_det) > 0){
						return response()->json(['success'=>1,'data'=>$hosp_det],200);
					}else{
						return response()->json(['success'=>0,'message'=>"No Data Found"],200);
					}
				}

				if($token_status == 0)
				{
					return response()->json(['success'=>2,'message'=>'Expired login token.'],200);						
				}
				if($token_status == 2)
				{
					return response()->json(['success'=>2,'message'=>'Invalid login token.'],200);					
				}
			}
		}

		/******
		Doctor Avaialability Api
	 	*******/
		public function doctorsAvailaibility(){
			header('Content-Type: application/x-www-form-urlencoded');
			header('Content-Type: application/json');
			$decodedArray = json_decode( file_get_contents('php://input'));			
			$decodedArray =  (array) $decodedArray;
			$_POST = $decodedArray;		
			
			$result = $this->check_basic_parameters($_POST);
			//echo "<pre>"; print_R($result); exit;
			if($result ==1)
			{	
				$check_user_by_ID = $this->check_user_by_ID($_POST['patient_id']);

				if($check_user_by_ID ==0)
				{
					return response()->json(['success'=>0,'message'=>'Please enter correct user id.'],200);					
				}
				
				$token_status = $this->check_token_status($_POST['patient_id'],$_POST['login_token']);
				
				if($token_status ==1)
				{						
					$doctor_details = Doctor::with('doctor_availability')->where('doctor_id',$_POST['doctor_id'])->get();
					//echo "<pre>"; print_R($doctor_details);
					//$doctor_details = DoctorAvailability::all()->doctor->get();
					
					return response()->json(['success'=>1,'data'=>$doctor_details],200);
				}

				if($token_status == 0)
				{
					return response()->json(['success'=>2,'message'=>'Expired login token.'],200);						
				}
				if($token_status == 2)
				{
					return response()->json(['success'=>2,'message'=>'Invalid login token.'],200);					
				}
			}
		}

		/******
		Doctor Particular Date Avaialability Api
	 	*******/
		public function doctorDateAvailaibility(){
			header('Content-Type: application/x-www-form-urlencoded');
			header('Content-Type: application/json');
			$decodedArray = json_decode( file_get_contents('php://input'));			
			$decodedArray =  (array) $decodedArray;
			$_POST = $decodedArray;		
			
			$result = $this->check_basic_parameters($_POST);
			//echo "<pre>"; print_R($result); exit;
			if($result ==1)
			{	
				$check_user_by_ID = $this->check_user_by_ID($_POST['patient_id']);

				if($check_user_by_ID ==0)
				{
					return response()->json(['success'=>0,'message'=>'Please enter correct user id.'],200);					
				}
				
				$token_status = $this->check_token_status($_POST['patient_id'],$_POST['login_token']);
				
				if($token_status ==1)
				{						
					$doctor_details = Doctor::with('doctor_availability')->where('doctor_id',$_POST['doctor_id'])->get();
					//echo "<pre>"; print_R($doctor_details);
					//$doctor_details = DoctorAvailability::all()->doctor->get();
					
					return response()->json(['success'=>1,'data'=>$doctor_details],200);
				}

				if($token_status == 0)
				{
					return response()->json(['success'=>2,'message'=>'Expired login token.'],200);						
				}
				if($token_status == 2)
				{
					return response()->json(['success'=>2,'message'=>'Invalid login token.'],200);					
				}
			}
		}

		/******
		Fetch available immedicate telemedical doctors Api
	 	*******/
		public function fetchTelemedicalDoctor()
		{
			
			header('Content-Type: application/x-www-form-urlencoded');
			header('Content-Type: application/json');
			$decodedArray = json_decode( file_get_contents('php://input'));			
			$decodedArray =  (array) $decodedArray;
			$_POST = $decodedArray;		
			
			$result = $this->check_basic_parameters($_POST);
			
			if($result ==1)
			{	
				$check_user_by_ID = $this->check_user_by_ID($_POST['patient_id']);

				if($check_user_by_ID ==0)
				{
					return response()->json(['success'=>0,'message'=>'Please enter correct user id.'],200);					
				}
				
				$token_status = $this->check_token_status($_POST['patient_id'],$_POST['login_token']);
				
				if($token_status ==1)
				{
					$patient_detail = Patient::where('patient_unique_id',$_POST['patient_id'])->first();
					date_default_timezone_set($patient_detail->timezone);
					$current_time = strtotime('now');
					$beginOfDay = strtotime("midnight", $current_time);
					$endOfDay   = strtotime("tomorrow", $beginOfDay) - 1;
					
					$doctor_details = DoctorAvailability::select('*')->where('availability_date','>=',$beginOfDay)->where('availability_date','<=',$endOfDay)->where('type','=',1)->where('booking_status',0)->orderBy('id','ASC')->get();		

					$last_booking_row = SaveTelemedicalBookingDetail::select('*')->where('save_telemedical_booking_detail.booking_id',$_POST['booking_id'])->where('patient_id',$_POST['patient_id'])->first();

					if(!empty($doctor_details))
					{	
					 //return response()->json(['success'=>3,'doctor_details'=> $doctor_details],200); die;					
						$count =0;
						foreach($doctor_details as $doctor_detail){
							
							
							$availability_time =  $doctor_detail['availability_time'];
							$selectedTime = date('h:i A');
							$LessTime = strtotime("-15 minutes", strtotime($selectedTime));
							$GraterTime = strtotime("+15 minutes", strtotime($selectedTime));
							// $LTime= date('h:i A', $LessTime);	
							 //$GTime= date('h:i A', $GraterTime);

							
							//return response()->json(['success'=>3,'doctor_details'=> strtotime($availability_time) .'/'. $LessTime . '/' .$GraterTime],200); die;					
							if((strtotime($availability_time) > $LessTime) OR( strtotime($availability_time) < $GraterTime)){
								$doctor_details_arr = array();
								$doctor_details_arr['doctor_id'] = $doctor_detail['doctor_id'];
								$doctor_details_arr = (object) $doctor_details_arr;
								if(!empty($last_booking_row) && $last_booking_row->doctor_id == "")
								{
									$count =1;
									SaveTelemedicalBookingDetail::where('booking_id', $last_booking_row->booking_id)->update(['doctor_id' => $doctor_details_arr->doctor_id]);									
								}
								DoctorAvailability::where('doctor_id', $doctor_details_arr->doctor_id)->update(['booking_status' => 1]);
								return response()->json(['success'=>1,'message'=>'Booking successful'],200);
															
							}
						}	

						if($count == 0)	{
							SaveTelemedicalBookingDetail::where('booking_id', $last_booking_row->booking_id)->update(['approved_status' => 2]);
							return response()->json(['success'=>3,'message'=>'No doctor available just now please schedule again after some time'],200);	
						}		
					}
					else
					{
						SaveTelemedicalBookingDetail::where('booking_id', $last_booking_row->booking_id)->update(['approved_status' => 2]);
						return response()->json(['success'=>3,'message'=>'No doctor available just now again after some time.'],200);	
					}
				}
				
			
			
				if($token_status == 0)
				{
					return response()->json(['success'=>2,'message'=>'Expired login token.'],200);						
				}
				
				if($token_status == 2)
				{
					return response()->json(['success'=>2,'message'=>'Invalid login token.'],200);					
				}
			}
					
		}

		/******
		Fetch available future telemedical doctors Api
	 	*******/
		public function fetchFutureTeleDoctor()
		{
			
			header('Content-Type: application/x-www-form-urlencoded');
			header('Content-Type: application/json');
			$decodedArray = json_decode( file_get_contents('php://input'));			
			$decodedArray =  (array) $decodedArray;
			$_POST = $decodedArray;		
			
			$result = $this->check_basic_parameters($_POST);
			
			if($result ==1)
			{	
				$check_user_by_ID = $this->check_user_by_ID($_POST['patient_id']);

				if($check_user_by_ID ==0)
				{
					return response()->json(['success'=>0,'message'=>'Please enter correct user id.'],200);					
				}
				
				$token_status = $this->check_token_status($_POST['patient_id'],$_POST['login_token']);
				
				if($token_status ==1)
				{
				
					$doctor_details = DoctorLogin::select('*')->where('doctor_login.status','1')->whereDate('doctor_login.login_time', '=', date('Y-m-d'))->whereRaw('json_contains(doctor_availability.availability_time, \'["' . $_POST['time'] . '"]\')')->orderBy(DB::raw('doctor_login.login_time'),'ASC')->join('doctor_availability', 'doctor_login.doctor_id', '=', 'doctor_availability.doctor_id')->get()->first();
					//echo '<pre>'; print_r($doctor_details); die('here');
					if(!empty($doctor_details))
					{
						$last_booking_row = SaveTelemedicalBookingDetail::select('*')->where('save_telemedical_booking_detail.approved_status','!=',2)->orderBy(DB::raw('id'),'DESC')->limit(1)->get()->first();
						// echo '<pre>'; print_r($last_booking_row->booking_id); die('here');
						if(!empty($last_booking_row))
						{
							SaveTelemedicalBookingDetail::where('booking_id', $last_booking_row->booking_id)->update(['doctor_id' => $doctor_details->doctor_id]);
						}
						return response()->json(['success'=>1,'data'=>$doctor_details],200);
					}
					else
					{
						return response()->json(['success'=>0,'message'=>'No doctor available.'],200);	
					}
				}
				
			
			
				if($token_status == 0)
				{
					return response()->json(['success'=>2,'message'=>'Expired login token.'],200);						
				}
				
				if($token_status == 2)
				{
					return response()->json(['success'=>2,'message'=>'Invalid login token.'],200);					
				}
			}
					
		}

		/******
		Save booking details Api
	 	*******/
		public function saveBookingDetails(Request $header_request)
		{
			
			header('Content-Type: application/x-www-form-urlencoded');
			header('Content-Type: application/json');
			$decodedArray = json_decode( file_get_contents('php://input'));			
			$decodedArray =  (array) $decodedArray;
			$_POST = $decodedArray;	
	
			//return response()->json(['success'=>2,'message'=>$aa],200); die('here');
			if(!isset($_POST['web'])){
				$this->app_version      = $header_request->header('app-version');
		        $this->device_type      = strtoupper($header_request->header('device-type'));
		        $this->device_token     = $header_request->header('device-token');
		        $this->time_zone        = $header_request->header('time-zone');	        
				
				 if($this->app_version=='' || $this->device_type =='' || $this->device_token=='' || $this->time_zone ==''){        	 
		            return response()->json(['success' => 0,'message'=>'Insufficient data in headers'],200);
		            exit;
		        }  
		        $_POST['login_token'] = $this->device_token;
		        $time_zone = $this->time_zone;
		    }else if(isset($_POST['time_zone'])){
				$time_zone = $_POST['time_zone'];
			}else{
				$time_zone = 'UTC';
			}
	        $result = $this->check_basic_parameters($_POST);
			
			if($result ==1)
			{	
				$check_user_by_ID = $this->check_user_by_ID($_POST['patient_id']);

				if($check_user_by_ID ==0)
				{
					return response()->json(['success'=>0,'message'=>'Please enter correct user id.'],200);					
				}
				
				$token_status = $this->check_token_status($_POST['patient_id'],$_POST['login_token']);
				
				if($token_status ==1)
				{
					$check_appointment_id=false;
					if(!empty($_POST['appointment_id']))
					{
						$fetch_appointment=DB::table('appointment_details')->where('appointment_id',$_POST['appointment_id'])->first();	
						if($fetch_appointment->appointment_type == 1){					
							if($fetch_appointment->telemedical_consult_time==2)
							{
								$check_appointment_id=true;
							}
						}else{
							$check_appointment_id=true;
						}
						//~ echo '<pre>'; print_r($fetch_appointment->telemedical_consult_time); die('here');
					}
					
					if($check_appointment_id)
					{
						$validator = Validator::make($_POST, [ 
							'appointment_id'=>'required',		            
							'doctor_id' => 'required'			            
						]);						
					}
					else
					{							
						$validator = Validator::make($_POST, [ 
							'appointment_id'=>'required',
							'booking_name' => 'required', 
							'mobile_number' => 'required',			            
							//~ 'symptoms ' => 'required',			            
							'terms_conditions' => 'required',			            
							'appointment_time' => 'required|date',			            
							'hospital_name' => 'required',
							'sharing_status' => 'required'			            
						]);
								
					}

					if ($validator->fails()) { 
							$errorMsg=$validator->messages();				
							return response()->json(['success'=>0, 'message'=>$validator->messages()->first()], 401);            
					}

					if(!empty($_POST['symptoms'])){
						$symptoms = trim($_POST['symptoms']);
					}else{
						$symptoms = NULL;
					}

					if(!empty($_POST['doctor_id'])){
						$doctor_id = $_POST['doctor_id'];
					}else{
						$doctor_id = NULL;
					}
					
					if(!empty($_POST['booking_name'])){
						$booking_name = $_POST['booking_name'];
					}else{
						$booking_name = NULL;
					}
					
					if(!empty($_POST['mobile_number'])){
						$mobile_number = $_POST['mobile_number'];
					}else{
						$mobile_number = NULL;
					}
					if(!empty($_POST['health_diary'])){
						$health_diary = implode(',',$_POST['health_diary']);
						$health_diary= $health_diary;
					}else{
						$health_diary = NULL;
					}
					
					if(!empty($_POST['terms_conditions'])){
						$terms_conditions = $_POST['terms_conditions'];
					}else{
						$terms_conditions = NULL;
					}
					
					if(!empty($_POST['appointment_time'])){		
						
				        $dtz = new DateTimeZone($time_zone);     
				        $date = date('Y-m-d H:i:s',strtotime($_POST['appointment_time']));   				        
				        $time_in_sofia = new DateTime($date, $dtz);        
				        $date_offset = $time_in_sofia->format('Z');       
				        $appointment_time = strtotime($date)-$date_offset;			       
					}else{
						$appointment_time = NULL;
					}
					
					if(!empty($_POST['hospital_name'])){
						$hospital_name = $_POST['hospital_name'];
					}else{
						$hospital_name = NULL;
					}

					if(!empty($_POST['hospital_id'])){
						$hospital_id = $_POST['hospital_id'];
					}else{
						$hospital_id = 0;
					}
					
					if(!empty($_POST['sharing_status'])){
						$sharing_status = $_POST['sharing_status'];
					}else{
						$sharing_status = NULL;
					}

					if(!empty($_POST['speciality_id'])){
						$specialist_id = $_POST['speciality_id'];
					}else{
						$specialist_id = 0;
					}

					$status = 0;

					if(isset($_POST['appointment_id'])){
						$booking_count = SaveTelemedicalBookingDetail::where('appointment_id',$_POST['appointment_id'])->get();
						if(count($booking_count) > 0){
							$status = 1;
							$_POST['submit_id'] = $booking_count[0]['booking_id'];
						}
					}

					$booking_exists=SaveTelemedicalBookingDetail::where('save_telemedical_booking_detail.patient_id',$_POST['patient_id'])->where('save_telemedical_booking_detail.appointment_time',$appointment_time)->where('appointment_id','!=',$_POST['appointment_id'])->where('approved_status','!=',2)->count();
					
					if($booking_exists == 0){						
						if(((isset($_POST['submit_status']) && $_POST['submit_status'] == 1) && (isset($_POST['submit_id']) && !empty($_POST['submit_id']))) || ($status == 1)){							
							
							SaveTelemedicalBookingDetail::where('booking_id', $_POST['submit_id'])->update(['appointment_id'=> $_POST['appointment_id'],'booking_name' => trim($booking_name),'patient_id'=> $_POST['patient_id'],'hospital_id'=>$hospital_id,'specialist_id'=> $specialist_id,'hospital_name'=> trim($hospital_name),'mobile_number'=> trim($mobile_number),'symptoms'	=> trim($symptoms),'terms_conditions'=> $terms_conditions,'sharing_status'=> $sharing_status,'health_diary'=>$health_diary]);							
						    return response()->json(['success'=>1,'message'=>'Booking updated successfully.','id'=>$_POST['submit_id']],200);
						}else{
													
							$save_telemedical_booking_detail = new SaveTelemedicalBookingDetail([								
								'booking_id'		=> $this->generateUniqueNumber(),
								'appointment_id'	=> $_POST['appointment_id'],
							    'booking_name'		=> trim($booking_name),
							    'patient_id'		=> $_POST['patient_id'],
							    'hospital_id'		=> $hospital_id,
							    'doctor_id'			=> $doctor_id,
							    'specialist_id'		=> $specialist_id,
							    'hospital_name'		=> trim($hospital_name), 
							    'mobile_number'		=> trim($mobile_number),
							    'symptoms'			=> $symptoms,
							    'terms_conditions'	=> $terms_conditions,	
							    'appointment_time'	=> $appointment_time,
							    'sharing_status'	=> $sharing_status,	
							    'approved_status'	=> 0,
							    'status'			=> 1,
							    'created_at'		=> strtotime("now"),
							    'health_diary'	    =>$health_diary
							   		     			
							]);	

							$save_telemedical_booking_detail->save();
							// return response()->json(['success'=>2,'message'=>1],200);
							if(isset($_POST['appointment_id'])){
								PatientAppointment::where('appointment_id', $_POST['appointment_id'])->update(['appointment_time'=>$appointment_time,'appoint_booking_status' => 1]);
							}
								
							if(!isset($_POST['web'])){
								if($fetch_appointment->appointment_type == 1){	
									if($fetch_appointment->telemedical_consult_time != 2){
										$data['patient_id'] = $_POST['patient_id'];
							            $data['booking_id'] = $_POST['submit_id'];          
							            $data['login_token'] = $_POST['login_token'];                     
							            $post_data = json_encode($data);  
							             
							            $curl = url('/')."/api/fetch_doctor";  
							            $doctors = $this->commoncurl($curl,$post_data); 
							            
	                       				
	                       				if($doctors['success'] == 1){
											$UserNotification = new UserNotification([                
				                                'notification_id'   => $this->generateNUniqueNumber(),                                
				                                'assignee_type'     => 4,                    
				                                'patient_id'        => $_POST['patient_id'], 
				                                'event_id'          => $save_telemedical_booking_detail->booking_id,
				                                'notification_type' => "appt",
				                                'change_type'       => "created",
				                                'created_date'      => strtotime('now'),
				                                'status'            => 0                                          
				                            ]);
				                            $UserNotification->save(); 

				                            $msg = "You scheduled a new appointment ";  
				                            $patients_notification = PatientNotificationSetting::where('patient_id', $_POST['patient_id'])->first();
				                            if(isset($patients_notification->patient_id)){
					                            if($patients_notification->appointment_activity_push == 1){
						                            $login_token = PatientLoginToken::where('patient_id',$_POST['patient_id'])->where('token_status',1)->get();	                            
						                            if(count($login_token) > 0 && $login_token[0]->device_type != 2){            
						                                $device_token = $login_token[0]->device_token;
						                                $path = "/var/www/html/projects/renderhealth/ios_notifcation/all_notifications.php";                                              
						                                $nid = $save_telemedical_booking_detail->booking_id;
						                                $type= 'appt';
						                                exec ('php '.$path.' "'.$msg.'" '.$nid.' '.$type.' '.$device_token.' > /dev/null &');
						                            }
						                        }
						                        if($patients_notification->appointment_activity_email == 1){
						                            $url = url('/doctor/send_mail/'.str_replace(" ", "_", $msg).'/'.$_POST['patient_id'].'');   
										            $cmd  = "curl --max-time 60 ";   
										            $cmd .= "'" . $url . "'";   
										            $cmd .= " > /dev/null 2>&1 &";    
										            exec($cmd, $output, $exit);
										        } 
									        }
								    		return response()->json(['success'=>$doctors['success'],"message"=>'Booking added successfully.',"id"=>$save_telemedical_booking_detail->booking_id],200);
				                        }else{                   
				                            return response()->json(['success'=>$doctors['success'],"message"=>$doctors['message']],200); 
				                        }			                                            				
						        	}else{
							        	$UserNotification = new UserNotification([                
				                            'notification_id'   => $this->generateNUniqueNumber(),                                
				                            'assignee_type'     => 4,                    
				                            'patient_id'        => $_POST['patient_id'], 
				                            'event_id'          => $save_telemedical_booking_detail->booking_id,
				                            'notification_type' => "appt",
				                            'change_type'       => "created",
				                            'created_date'      => strtotime('now'),
				                            'status'            => 0                                          
				                        ]);
				                        $UserNotification->save(); 

				                        $login_token = PatientLoginToken::where('patient_id',$_POST['patient_id'])->where('token_status',1)->get();

				                         if($fetch_appointment->appointment_type == 2){
				                            $msg = "You scheduled a new hospital appointment"; 
				                        }else{
				                            $msg = "You scheduled a new telemedical appointment";
				                        }
				                        $patients_notification = PatientNotificationSetting::where('patient_id', $_POST['patient_id'])->first();
			                            if(isset($patients_notification->patient_id)){
				                            if($patients_notification->appointment_activity_push == 1){
						                        if(count($login_token) > 0 && $login_token[0]->device_type != 2){            
						                            $device_token = $login_token[0]->device_token;
						                            $path = "/var/www/html/projects/renderhealth/ios_notifcation/all_notifications.php";
						                            $nid = $save_telemedical_booking_detail->booking_id;
						                            $type= 'appt';
						                            exec ('php '.$path.' "'.$msg.'" '.$nid.' '.$type.' '.$device_token.' > /dev/null &');
						                        }
						                    }
						                    if($patients_notification->appointment_activity_email == 1){
						                        //send email notification
						                        $url = url('/patient/send_mail/'.str_replace(" ", "_", $msg).'/'.$_POST['patient_id'].'');   
						                        $cmd  = "curl --max-time 60 ";   
						                        $cmd .= "'" . $url . "'";   
						                        $cmd .= " > /dev/null 2>&1 &";    
						                        exec($cmd, $output, $exit);
						                    }
						                 }
				                        return response()->json(['success'=>1,'message'=>'Booking added successfully.','id'=>$save_telemedical_booking_detail->booking_id],200);
							        }
							    }else{
							        	$UserNotification = new UserNotification([                
				                            'notification_id'   => $this->generateNUniqueNumber(),                                
				                            'assignee_type'     => 4,                    
				                            'patient_id'        => $_POST['patient_id'], 
				                            'event_id'          => $save_telemedical_booking_detail->booking_id,
				                            'notification_type' => "appt",
				                            'change_type'       => "created",
				                            'created_date'      => strtotime('now'),
				                            'status'            => 0                                          
				                        ]);
				                        $UserNotification->save(); 

				                        $login_token = PatientLoginToken::where('patient_id',$_POST['patient_id'])->where('token_status',1)->get();

				                         if($fetch_appointment->appointment_type == 2){
				                            $msg = "You scheduled a new hospital appointment"; 
				                        }else{
				                            $msg = "You scheduled a new telemedical appointment";
				                        }
				                        $patients_notification = PatientNotificationSetting::where('patient_id', $_POST['patient_id'])->first();
			                            if(isset($patients_notification->patient_id)){
				                            if($patients_notification->appointment_activity_push == 1){
						                        if(count($login_token) > 0 && $login_token[0]->device_type != 2){            
						                            $device_token = $login_token[0]->device_token;
						                            $path = "/var/www/html/projects/renderhealth/ios_notifcation/all_notifications.php";
						                            $nid = $save_telemedical_booking_detail->booking_id;
						                            $type= 'appt';
						                            exec ('php '.$path.' "'.$msg.'" '.$nid.' '.$type.' '.$device_token.' > /dev/null &');
						                        }
						                    }
						                    if($patients_notification->appointment_activity_email == 1){
						                        //send email notification
						                        $url = url('/patient/send_mail/'.str_replace(" ", "_", $msg).'/'.$_POST['patient_id'].'');   
						                        $cmd  = "curl --max-time 60 ";   
						                        $cmd .= "'" . $url . "'";   
						                        $cmd .= " > /dev/null 2>&1 &";    
						                        exec($cmd, $output, $exit);
						                    }
						                 }
				                        return response()->json(['success'=>1,'message'=>'Booking added successfully.','id'=>$save_telemedical_booking_detail->booking_id],200);
							        }
						    }else{
						    	return response()->json(['success'=>1,'message'=>'Booking added successfully.','id'=>$save_telemedical_booking_detail->booking_id],200);
						    }							
						}
					}else{
						return response()->json(['success'=>0,'message'=>'You already have booking with another doctor.'],200);
					}
				}				
				
				if($token_status == 0)
				{
					return response()->json(['success'=>2,'message'=>'Expired login token.'],200);						
				}
				if($token_status == 2)
				{
					return response()->json(['success'=>2,'message'=>'Invalid login token.'],200);					
				}
				
			}

			
		}
		
		/******
		My appointment listing Api
	 	*******/
		public function myAppointments(){
			header('Content-Type: application/x-www-form-urlencoded');
			header('Content-Type: application/json');
			$decodedArray = json_decode( file_get_contents('php://input'));			
			$decodedArray =  (array) $decodedArray;
			$_POST = $decodedArray;		
			
			$result = $this->check_basic_parameters($_POST);
			
			if($result ==1)
			{	
				$check_user_by_ID = $this->check_user_by_ID($_POST['patient_id']);

				if($check_user_by_ID ==0)
				{
					return response()->json(['success'=>0,'message'=>'Please enter correct user id.'],200);					
				}
				
				$token_status = $this->check_token_status($_POST['patient_id'],$_POST['login_token']);
				
				if($token_status ==1)
				{					
					if($_POST['page'] == ""){
						if($_POST['type'] != ""){
							$base_url = asset('/admin/doctor/uploads/profile');
				            $query=SaveTelemedicalBookingDetail::with("doctor.specialist_categories")->with(array("doctor"=>function($q) use($base_url){$q->select('*',DB::Raw('CONCAT("'.$base_url.'/",doctors.doctor_picture) as doctor_picture'));}))->with(array('patient_appoint'=>function($q){$q->select('*',DB::Raw('IFNULL( appointment_details.telemedical_type , 0 ) as telemedical_type'),DB::Raw('IFNULL( appointment_details.telemedical_consult_type , 0 ) as telemedical_consult_type'),DB::Raw('IFNULL( appointment_details.telemedical_consult_time , 0 ) as telemedical_consult_time'));}))->select("save_telemedical_booking_detail.*",DB::Raw('IFNULL( save_telemedical_booking_detail.symptoms , "" ) as symptoms'),DB::Raw('IFNULL( save_telemedical_booking_detail.doctor_id , 0 ) as doctor_id'),DB::Raw('IFNULL( save_telemedical_booking_detail.sharing_status , 0 ) as sharing_status'),DB::Raw('IFNULL( save_telemedical_booking_detail.terms_conditions , 0 ) as terms_conditions'));
				            if($_POST['type'] === '1') {  			                    
				                $query->whereDate('save_telemedical_booking_detail.appointment_time', '=', date('Y-m-d'))->where('save_telemedical_booking_detail.approved_status','!=',2)->where('save_telemedical_booking_detail.patient_id',$_POST['patient_id']);
				            }else if($_POST['type'] === '2'){
				               $query->whereDate('save_telemedical_booking_detail.appointment_time', '>', date('Y-m-d'))->where('save_telemedical_booking_detail.approved_status','!=',2)->where('save_telemedical_booking_detail.patient_id',$_POST['patient_id']);
				            }else if($_POST['type'] === '3'){
				                $query->whereDate('save_telemedical_booking_detail.appointment_time', '<', date('Y-m-d'))->where('save_telemedical_booking_detail.approved_status','!=',2)->where('save_telemedical_booking_detail.patient_id',$_POST['patient_id']);
				            }

				            $appoint_listing = $query->orderBy('save_telemedical_booking_detail.appointment_time','DESC')->get();  
				            if(count($appoint_listing) > 0)
							{	
								$appoint_list = $appoint_listing;						
								return response()->json(['success'=>1,'data'=>$appoint_list],200);
							}
							else
							{
								return response()->json(['success'=>0,'message'=>'No Data Found.'],200);
							} 
            				
				        }else{
				        	$base_url = asset('/admin/doctor/uploads/profile');				        	
							$appoint_listing=SaveTelemedicalBookingDetail::with("doctor.specialist_categories")->with(array("doctor"=>function($q) use($base_url){$q->select('*',DB::Raw('CONCAT("'.$base_url.'/", doctors.doctor_picture) as doctor_picture'));}))->with(array('patient_appoint'=>function($q){$q->select('*',DB::Raw('IFNULL( appointment_details.telemedical_type , 0 ) as telemedical_type'),DB::Raw('IFNULL( appointment_details.telemedical_consult_type , 0 ) as telemedical_consult_type'),DB::Raw('IFNULL( appointment_details.telemedical_consult_time , 0 ) as telemedical_consult_time'));}))->select("save_telemedical_booking_detail.*",DB::Raw('IFNULL( save_telemedical_booking_detail.symptoms , "" ) as symptoms'),DB::Raw('IFNULL( save_telemedical_booking_detail.doctor_id , 0 ) as doctor_id'),DB::Raw('IFNULL( save_telemedical_booking_detail.sharing_status , 0 ) as sharing_status'),DB::Raw('IFNULL( save_telemedical_booking_detail.terms_conditions , 0 ) as terms_conditions'))->where('save_telemedical_booking_detail.approved_status','!=',2)->where('save_telemedical_booking_detail.patient_id',$_POST['patient_id'])->orderBy('save_telemedical_booking_detail.appointment_time','DESC')->get();	

							if(count($appoint_listing) > 0)
							{	
								$appoint_list = $appoint_listing;						
								return response()->json(['success'=>1,'data'=>$appoint_list],200);
							}
							else
							{
								return response()->json(['success'=>0,'message'=>'No Data Found.'],200);
							}
						}								
					}else{
						$limit = 10;
						$page = $_POST['page'];
						if($_POST['type'] != ""){
							$base_url = asset('/admin/doctor/uploads/profile');
				            $query=SaveTelemedicalBookingDetail::with("doctor.specialist_categories")->with(array("doctor"=>function($q) use($base_url){$q->select('*',DB::Raw('CONCAT("'.$base_url.'/",doctors.doctor_picture) as doctor_picture'));}))->with(array('patient_appoint'=>function($q){$q->select('*',DB::Raw('IFNULL( appointment_details.telemedical_type , 0 ) as telemedical_type'),DB::Raw('IFNULL( appointment_details.telemedical_consult_type , 0 ) as telemedical_consult_type'),DB::Raw('IFNULL( appointment_details.telemedical_consult_time , 0 ) as telemedical_consult_time'));}))->select("save_telemedical_booking_detail.*",DB::Raw('IFNULL( save_telemedical_booking_detail.symptoms , "" ) as symptoms'),DB::Raw('IFNULL( save_telemedical_booking_detail.doctor_id , 0 ) as doctor_id'),DB::Raw('IFNULL( save_telemedical_booking_detail.sharing_status , 0 ) as sharing_status'),DB::Raw('IFNULL( save_telemedical_booking_detail.terms_conditions , 0 ) as terms_conditions'));
				            if($_POST['type'] === '1') {     			                     
				                $query->whereDate('save_telemedical_booking_detail.appointment_time', '=', date('Y-m-d'))->where('save_telemedical_booking_detail.approved_status','!=',2)->where('save_telemedical_booking_detail.patient_id',$_POST['patient_id']);
				            }else if($_POST['type'] === '2'){
				               $query->whereDate('save_telemedical_booking_detail.appointment_time', '>', date('Y-m-d'))->where('save_telemedical_booking_detail.approved_status','!=',2)->where('save_telemedical_booking_detail.patient_id',$_POST['patient_id']);
				            }else if($_POST['type'] === '3'){
				                $query->whereDate('save_telemedical_booking_detail.appointment_time', '<', date('Y-m-d'))->where('save_telemedical_booking_detail.approved_status','!=',2)->where('save_telemedical_booking_detail.patient_id',$_POST['patient_id']);
				            }

				            $appoint_listing = $query->orderBy('save_telemedical_booking_detail.appointment_time','DESC')->paginate($limit, ['*'],'page',$page);  
				            $total = $appoint_listing->lastPage(); 
				            if(count($appoint_listing) > 0)
							{	
								$appoint_list = $appoint_listing->toArray()['data'];						
								return response()->json(['success'=>1,'data'=>$appoint_list,'total'=>$total],200);
							}
							else
							{
								return response()->json(['success'=>0,'message'=>'No Data Found.'],200);
							}
            				
				        }else{
				        	$base_url = asset('/admin/doctor/uploads/profile');
							$appoint_listing=SaveTelemedicalBookingDetail::with("doctor.specialist_categories")->with(array("doctor"=>function($q) use($base_url){$q->select('*',DB::Raw('CONCAT("'.$base_url.'/",doctors.doctor_picture) as doctor_picture'));}))->with(array('patient_appoint'=>function($q){$q->select('*',DB::Raw('IFNULL( appointment_details.telemedical_type , 0 ) as telemedical_type'),DB::Raw('IFNULL( appointment_details.telemedical_consult_type , 0 ) as telemedical_consult_type'),DB::Raw('IFNULL( appointment_details.telemedical_consult_time , 0 ) as telemedical_consult_time'));}))->select("save_telemedical_booking_detail.*",DB::Raw('IFNULL( save_telemedical_booking_detail.symptoms , "" ) as symptoms'),DB::Raw('IFNULL( save_telemedical_booking_detail.doctor_id , 0 ) as doctor_id'),DB::Raw('IFNULL( save_telemedical_booking_detail.sharing_status , 0 ) as sharing_status'),DB::Raw('IFNULL( save_telemedical_booking_detail.terms_conditions , 0 ) as terms_conditions'))->where('save_telemedical_booking_detail.approved_status','!=',2)->where('save_telemedical_booking_detail.patient_id',$_POST['patient_id'])->orderBy('save_telemedical_booking_detail.appointment_time','ASC')->paginate($limit, ['*'],'page',$page);					
							$total = $appoint_listing->lastPage();
							
							if(count($appoint_listing) > 0)
							{	
								$appoint_list = $appoint_listing->toArray()['data'];						
								return response()->json(['success'=>1,'data'=>$appoint_list,'total'=>$total],200);
							}
							else
							{
								return response()->json(['success'=>0,'message'=>'No Data Found.'],200);
							}
						}						
					}
				}

				if($token_status == 0)
				{
					return response()->json(['success'=>2,'message'=>'Expired login token.'],200);						
				}
				if($token_status == 2)
				{
					return response()->json(['success'=>2,'message'=>'Invalid login token.'],200);					
				}
			}
		}

		/******
		Patient Appointment Listing Api
	 	*******/
		public function patientAppointments(Request $header_request){
			header('Content-Type: application/x-www-form-urlencoded');
			header('Content-Type: application/json');
			$decodedArray = json_decode( file_get_contents('php://input'));			
			$decodedArray =  (array) $decodedArray;
			$_POST = $decodedArray;		
			
			$this->app_version      = $header_request->header('app-version');
	        $this->device_type      = strtoupper($header_request->header('device-type'));
	        $this->device_token     = $header_request->header('device-token');
	        $this->time_zone        = $header_request->header('time-zone');	        
			
			 if($this->app_version=='' || $this->device_type =='' || $this->device_token=='' || $this->time_zone ==''){        	 
	            return response()->json(['success' => 0,'message'=>'Insufficient data in headers'],200);
	            exit;
	        }  
	        $_POST['login_token'] = $this->device_token;

			$result = $this->check_basic_parameters($_POST);			
			if($result ==1)
			{	
				$check_user_by_ID = $this->check_user_by_ID($_POST['patient_id']);

				if($check_user_by_ID ==0)
				{
					return response()->json(['success'=>0,'message'=>'Please enter correct user id.'],200);					
				}
				
				$token_status = $this->check_token_status($_POST['patient_id'],$_POST['login_token']);
				
				if($token_status ==1)
				{			
					$time_zone = $this->time_zone;
			        $dtz = new DateTimeZone($time_zone);     
			        $date = date('Y-m-d',strtotime($_POST['appoint_date']));   
			        $next_date = date('Y-m-d', strtotime('+1 day', strtotime($date)));
			        $time_in_sofia = new DateTime($date, $dtz);        
			        $date_offset = $time_in_sofia->format('Z');       
			        $start_time = strtotime($date)-$date_offset;
			        
			        $end_time = strtotime($next_date)-$date_offset;

					$appoint_listing=SaveTelemedicalBookingDetail::where('save_telemedical_booking_detail.approved_status','!=',2)->where('save_telemedical_booking_detail.patient_id',$_POST['patient_id'])->where('save_telemedical_booking_detail.appointment_time','>=',$start_time)->where('save_telemedical_booking_detail.appointment_time','<',$end_time)->orderBy('save_telemedical_booking_detail.appointment_time','ASC')->get();					
					if(count($appoint_listing) > 0)
					{													
						return response()->json(['success'=>1,'data'=>$appoint_listing],200);
					}
					else
					{
						return response()->json(['success'=>0,'message'=>'No Data Found.'],200);
					}
				}

				if($token_status == 0)
				{
					return response()->json(['success'=>2,'message'=>'Expired login token.'],200);						
				}
				if($token_status == 2)
				{
					return response()->json(['success'=>2,'message'=>'Invalid login token.'],200);					
				}
			}
		}

		/******
		Doctor Appointment Listing Api
	 	*******/
		public function doctorAppointments(Request $header_request){
			header('Content-Type: application/x-www-form-urlencoded');
			header('Content-Type: application/json');
			$decodedArray = json_decode( file_get_contents('php://input'));			
			$decodedArray =  (array) $decodedArray;
			$_POST = $decodedArray;		
			
			$this->app_version      = $header_request->header('app-version');
	        $this->device_type      = strtoupper($header_request->header('device-type'));
	        $this->device_token     = $header_request->header('device-token');
	        $this->time_zone        = $header_request->header('time-zone');	        
			
			 if($this->app_version=='' || $this->device_type =='' || $this->device_token=='' || $this->time_zone ==''){        	 
	            return response()->json(['success' => 0,'message'=>'Insufficient data in headers'],200);
	            exit;
	        }  
	        $_POST['login_token'] = $this->device_token;
			$result = $this->check_basic_parameters($_POST);
			if(!isset($_POST['doctor_id']) || $_POST['doctor_id'] == ""){
				return response()->json(['success'=>0,'message'=>'Please enter correct doctor id.'],200);	
			}			
			if($result ==1)
			{	
				$check_user_by_ID = $this->check_user_by_ID($_POST['patient_id']);

				if($check_user_by_ID ==0)
				{
					return response()->json(['success'=>0,'message'=>'Please enter correct user id.'],200);					
				}
				
				$token_status = $this->check_token_status($_POST['patient_id'],$_POST['login_token']);
				
				if($token_status ==1)
				{			
					$time_zone = $this->time_zone;
			        $dtz = new DateTimeZone($time_zone);     
			        $date = date('Y-m-d',strtotime($_POST['appoint_date']));   
			        $next_date = date('Y-m-d', strtotime('+1 day', strtotime($date)));
			        $time_in_sofia = new DateTime($date, $dtz);        
			        $date_offset = $time_in_sofia->format('Z');       
			        $start_time = strtotime($date)-$date_offset;
			        
			        $end_time = strtotime($next_date)-$date_offset;

					$appoint_listing=SaveTelemedicalBookingDetail::where('save_telemedical_booking_detail.approved_status','!=',2)->where('save_telemedical_booking_detail.doctor_id',$_POST['doctor_id'])->where('save_telemedical_booking_detail.appointment_time','>=',$start_time)->where('save_telemedical_booking_detail.appointment_time','<',$end_time)->orderBy('save_telemedical_booking_detail.appointment_time','ASC')->get();					
					if(count($appoint_listing) > 0)
					{													
						return response()->json(['success'=>1,'data'=>$appoint_listing],200);
					}
					else
					{
						return response()->json(['success'=>0,'message'=>'No Data Found.'],200);
					}
				}

				if($token_status == 0)
				{
					return response()->json(['success'=>2,'message'=>'Expired login token.'],200);						
				}
				if($token_status == 2)
				{
					return response()->json(['success'=>2,'message'=>'Invalid login token.'],200);					
				}
			}
		}

		/******
		Appointment Detail Api
	 	*******/
		public function appointmentDetail(){
			header('Content-Type: application/x-www-form-urlencoded');
			header('Content-Type: application/json');
			$decodedArray = json_decode( file_get_contents('php://input'));			
			$decodedArray =  (array) $decodedArray;
			$_POST = $decodedArray;		
			
			$result = $this->check_basic_parameters($_POST);
			
			if($result ==1)
			{	
				$check_user_by_ID = $this->check_user_by_ID($_POST['patient_id']);

				if($check_user_by_ID ==0)
				{
					return response()->json(['success'=>0,'message'=>'Please enter correct user id.'],200);					
				}
				
				$token_status = $this->check_token_status($_POST['patient_id'],$_POST['login_token']);
				
				if($token_status ==1)
				{
					//~ $doctor_details = Doctor::select("doctor_first_name","doctor_last_name","doctor_email","doctor_picture", "doctor_education_school","doctor_degree","doctor_speciality","doctor_languages","doctor_religion")->where('doctor_first_name', 'LIKE', '%' . $_POST['search_text'] . '%')->orWhere('doctor_last_name', 'LIKE', '%' . $_POST['search_text'] . '%')->get();					
					$appoint_detail=SaveTelemedicalBookingDetail::with(array("doctor","doctor.specialist_categories","hospital_detail","diary_detail","diary_detail.diary_attachment"))->with(array('patient_appoint'=>function($query){$query->select('*',DB::Raw('IFNULL( appointment_details.telemedical_type , 0 ) as telemedical_type'),DB::Raw('IFNULL( appointment_details.telemedical_consult_type , 0 ) as telemedical_consult_type'),DB::Raw('IFNULL( appointment_details.telemedical_consult_time , 0 ) as telemedical_consult_time'));}))->select("save_telemedical_booking_detail.*",DB::Raw('IFNULL( save_telemedical_booking_detail.symptoms , "" ) as symptoms'),DB::Raw('IFNULL( save_telemedical_booking_detail.doctor_id , 0 ) as doctor_id'),DB::Raw('IFNULL( save_telemedical_booking_detail.sharing_status , 0 ) as sharing_status'),DB::Raw('IFNULL( save_telemedical_booking_detail.terms_conditions , 0 ) as terms_conditions'))->where('save_telemedical_booking_detail.patient_id',$_POST['patient_id'])->where("save_telemedical_booking_detail.booking_id",$_POST['booking_id'])->get();	

					if(count($appoint_detail) > 0)
					{				
													
						return response()->json(['success'=>1,'data'=>$appoint_detail,"diary_details"=>""],200);
					}
					else
					{
						return response()->json(['success'=>0,'message'=>'No Data Found.'],200);
					}
				}

				if($token_status == 0)
				{
					return response()->json(['success'=>2,'message'=>'Expired login token.'],200);						
				}
				if($token_status == 2)
				{
					return response()->json(['success'=>2,'message'=>'Invalid login token.'],200);					
				}
			}
		}
		
		/******
		Doctor Listing Api
	 	*******/
		public function doctorListing(Request $header_request){
		
			header('Content-Type: application/x-www-form-urlencoded');
			header('Content-Type: application/json');
			$decodedArray = json_decode( file_get_contents('php://input'));			
			$decodedArray =  (array) $decodedArray;
			$_POST = $decodedArray;		
			
			if(!isset($_POST['web'])){
				$this->app_version      = $header_request->header('app-version');
		        $this->device_type      = strtoupper($header_request->header('device-type'));
		        $this->device_token     = $header_request->header('device-token');
		        $this->time_zone        = $header_request->header('time-zone');	        
				
				 if($this->app_version=='' || $this->device_type =='' || $this->device_token=='' || $this->time_zone ==''){        	 
		            return response()->json(['success' => 0,'message'=>'Insufficient data in headers'],200);
		            exit;
		        }  
		        $_POST['login_token'] = $this->device_token;
		        $time_zone = $this->time_zone;
			}else if(isset($_POST['time_zone'])){
				$time_zone = $_POST['time_zone'];
			}else{
				$time_zone = 'UTC';
			}
			$result = $this->check_basic_parameters($_POST);
			
			if($result ==1)
			{	
				$check_user_by_ID = $this->check_user_by_ID($_POST['patient_id']);

				if($check_user_by_ID ==0)
				{
					return response()->json(['success'=>0,'message'=>'Please enter correct user id.'],200);					
				}
				
				$token_status = $this->check_token_status($_POST['patient_id'],$_POST['login_token']);
				
				if($token_status ==1)
				{
					
			        $dtz = new DateTimeZone($time_zone);     
			        $date = date('Y-m-d',strtotime($_POST['appoint_date']));   
			        $next_date = date('Y-m-d', strtotime('+1 day', strtotime($date)));
			        $time_in_sofia = new DateTime($date, $dtz);        
			        $date_offset = $time_in_sofia->format('Z');       
			        $start_time = strtotime($date)-$date_offset;
			        
			        $end_time = strtotime($next_date)-$date_offset;			       
					
					if(isset($_POST['web'])){
						if(isset($_POST['speciality_id']) && $_POST['speciality_id'] != ""){
							$value = $_POST['speciality_id'];							
							$doctor_listing=Doctor::with(array('doctor_availability'=>function($q) use($start_time,$end_time) {$q->where('availability_date','>=',$start_time); $q->where('availability_date','<',$end_time); $q->where('type',1); $q->orderBy('availability_date');}))->with('specialist_categories')->whereHas('doctor_availability', function($q) use($start_time,$end_time) {$q->where('availability_date','>=',$start_time); $q->where('availability_date','<',$end_time); $q->where('type',1);})->where('doctors.doctor_timezone','like','%'.$time_zone.'%')->where('doctors.doctor_speciality',$_POST['speciality_id'])->select("*")->get();							
						}else{
							$doctor_listing=Doctor::with(array('doctor_availability'=>function($q) use($start_time,$end_time) {$q->where('availability_date','>=',$start_time); $q->where('availability_date','<',$end_time); $q->where('type',1);$q->orderBy('availability_date');}))->with('specialist_categories')->whereHas('doctor_availability', function($q) use($start_time,$end_time) {$q->where('availability_date','>=',$start_time); $q->where('availability_date','<',$end_time); $q->where('type',1);})->where('doctors.doctor_timezone','like','%'.$time_zone.'%')->select("*")->get();								
						}
						if(count($doctor_listing) > 0)
						{	
							return response()->json(['success'=>1,'data'=>$doctor_listing],200);
						}
						else
						{
							return response()->json(['success'=>0,'message'=>'No Data Found.'],200);
						}
					}else{
						if(isset($_POST['speciality_id']) && $_POST['speciality_id'] != ""){
							$value = $_POST['speciality_id'];							
							$doctor_listing['doctor']=Doctor::with(array('specialist_categories'=>function($query){$query->select('*');}))->whereHas('doctor_availability', function($q) use($start_time,$end_time) {$q->where('availability_date','>=',$start_time); $q->where('availability_date','<',$end_time); $q->where('type',1);})->where('doctors.doctor_timezone','like','%'.$time_zone.'%')->where('doctors.doctor_speciality',$_POST['speciality_id'])->select("doctors.*")->get();						
						}else{

							$doctor_listing['doctor']=Doctor::with(array('specialist_categories'=>function($query){$query->select('*');}))->whereHas('doctor_availability', function($q) use($start_time,$end_time) {$q->where('availability_date','>=',$start_time); $q->where('availability_date','<',$end_time); $q->where('type',1);})->where('doctors.doctor_timezone','like','%'.$time_zone.'%')->select("doctors.*")->get();							
						}
						if(count($doctor_listing['doctor']) > 0)
						{	
							return response()->json(['success'=>1,'data'=>$doctor_listing],200);
						}
						else
						{
							return response()->json(['success'=>0,'message'=>'No Data Found.'],200);
						}
					}					
				}

				if($token_status == 0)
				{
					return response()->json(['success'=>2,'message'=>'Expired login token.'],200);						
				}
				if($token_status == 2)
				{
					return response()->json(['success'=>2,'message'=>'Invalid login token.'],200);					
				}
			}
		}

		/******
		Doctor Avaialability Api
	 	*******/
		public function doctorAvailaibility(Request $header_request){	
			header('Content-Type: application/json');
			header('Content-Type: application/x-www-form-urlencoded');
			$decodedArray = json_decode( file_get_contents('php://input'));			
			$decodedArray =  (array) $decodedArray;
			$_POST = $decodedArray;		
			//echo "<pre>"; print_R($_POST); exit;
			if(!isset($_POST['web'])){
				$this->app_version      = $header_request->header('app-version');
		        $this->device_type      = strtoupper($header_request->header('device-type'));
		        $this->device_token     = $header_request->header('device-token');
		        $this->time_zone        = $header_request->header('time-zone');	        
				
				 if($this->app_version=='' || $this->device_type =='' || $this->device_token=='' || $this->time_zone ==''){        	 
		            return response()->json(['success' => 0,'message'=>'Insufficient data in headers'],200);
		            exit;
		        }  
		        $_POST['login_token'] = $this->device_token;
		        $time_zone = $this->time_zone;
			}else if(isset($_POST['time_zone'])){
				$time_zone = $_POST['time_zone'];
			}else{
				$time_zone = 'UTC';
			}
			$result = $this->check_basic_parameters($_POST);
			
			if(!isset($_POST['doctor_id']) || $_POST['doctor_id'] == ""){
				return response()->json(['success'=>0,'message'=>'Please enter correct doctor id.'],200);	
			}
			if($result ==1)
			{	
				// $check_user_by_ID = $this->check_user_by_ID($_POST['patient_id']);
				
				// if($check_user_by_ID ==0)
				// {
				// 	return response()->json(['success'=>0,'message'=>'Please enter correct user id.'],200);					
				// }
				
				$token_status = $this->check_token_status($_POST['patient_id'],$_POST['login_token']);
				// return response()->json(['success'=>$token_status],200);
				// if($token_status ==1)
				// {
					$time_zone = $time_zone;
			        $dtz = new DateTimeZone($time_zone);     
			        $date = date('Y-m-d',strtotime($_POST['appoint_date']));   
			        $next_date = date('Y-m-d', strtotime('+1 day', strtotime($date)));
			        $time_in_sofia = new DateTime($date, $dtz);        
			        $date_offset = $time_in_sofia->format('Z');       
			        $start_time = strtotime($date)-$date_offset;
			        
			        $end_time = strtotime($next_date)-$date_offset;			       
					
					if(isset($_POST['speciality_id']) && $_POST['speciality_id'] != ""){
						$value = $_POST['speciality_id'];						
						if($_POST['type'] == 1){
							$doctor_listing=DoctorAvailability::where('doctor_availability.availability_date','>=',$start_time)->where('doctor_availability.availability_date','<',$end_time)->where('doctor_id',$_POST['doctor_id'])->where('type',1)->whereHas('doctor', function($q) use($value) {$q->where('doctor_speciality',$_POST['speciality_id']);})->select("*")->get();
						}else if($_POST['type'] == 2){
							$doctor_listing=DoctorAvailability::where('doctor_availability.availability_date','>=',$start_time)->where('doctor_availability.availability_date','<',$end_time)->where('doctor_id',$_POST['doctor_id'])->where('type',2)->whereHas('doctor', function($q) use($value) {$q->where('doctor_speciality',$_POST['speciality_id']);})->select("*")->get();
						}
					}else{
						if($_POST['type'] == 1){
							$doctor_listing=DoctorAvailability::where('doctor_availability.availability_date','>=',$start_time)->where('doctor_availability.availability_date','<',$end_time)->where('type',1)->where('doctor_id',$_POST['doctor_id'])->select("*")->get();
						}else if($_POST['type'] == 2){
							$doctor_listing=DoctorAvailability::where('doctor_availability.availability_date','>=',$start_time)->where('doctor_availability.availability_date','<',$end_time)->where('type',2)->where('doctor_id',$_POST['doctor_id'])->select("*")->get();
						}
						
					}	
					// return response()->json(['success'=>$doctor_listing],200);					
					if(count($doctor_listing) > 0)
					{	
						return response()->json(['success'=>1,'data'=>$doctor_listing],200);
					}
					else
					{
						return response()->json(['success'=>0,'message'=>'No Data Found.'],200);
					}
				// }

				// if($token_status == 0)
				// {
				// 	return response()->json(['success'=>2,'message'=>'Expired login token.'],200);						
				// }
				// if($token_status == 2)
				// {
				// 	return response()->json(['success'=>2,'message'=>'Invalid login token.'],200);					
				// }
			}
		}


		/******
		Doctor Specialities Api
	 	*******/
		public function doctorSpecialistCategories()
		{
			
			header('Content-Type: application/x-www-form-urlencoded');
			header('Content-Type: application/json');
			$decodedArray = json_decode( file_get_contents('php://input'));			
			$decodedArray =  (array) $decodedArray;
			$_POST = $decodedArray;		
			
			$result = $this->check_basic_parameters($_POST);
			
			if($result ==1)
			{	
				$check_user_by_ID = $this->check_user_by_ID($_POST['patient_id']);

				if($check_user_by_ID ==0)
				{
					return response()->json(['success'=>0,'message'=>'Please enter correct user id.'],200);					
				}
				
				$token_status = $this->check_token_status($_POST['patient_id'],$_POST['login_token']);
				
				if($token_status ==1)
				{
				
					$speciality_cat = SpecialistCategories::select('*')->get();
					//~ echo '<pre>'; print_r($hospital); die('here');
					if(count($speciality_cat) > 0)
					{
						
						return response()->json(['success'=>1,'data'=>$speciality_cat],200);
					}
					else
					{
						return response()->json(['success'=>0,'message'=>'No record found.'],200);	
					}
				}
				
				if($token_status == 0)
				{
					return response()->json(['success'=>2,'message'=>'Expired login token.'],200);						
				}
				
				if($token_status == 2)
				{
					return response()->json(['success'=>2,'message'=>'Invalid login token.'],200);					
				}					
			}			
			
		}

		/******
		Hospital Listing Api
	 	*******/
		public function hospitalListing(Request $header_request)
		{
			
			header('Content-Type: application/x-www-form-urlencoded');
			header('Content-Type: application/json');
			$decodedArray = json_decode( file_get_contents('php://input'));			
			$decodedArray =  (array) $decodedArray;
			$_POST = $decodedArray;	

			//echo "<pre>"; print_R($_POST); exit;
			$this->app_version      = $header_request->header('app-version');
	        $this->device_type      = strtoupper($header_request->header('device-type'));
	        $this->device_token     = $header_request->header('device-token');
	        $this->time_zone        = $header_request->header('time-zone');	        
			
			if($this->app_version=='' || $this->device_type =='' || $this->device_token=='' || $this->time_zone ==''){        	 
	            return response()->json(['success' => 0,'message'=>'Insufficient data in headers'],200);
	            exit;
	        }  	

	        $_POST['login_token'] = $this->device_token;
	        $time_zone = $this->time_zone;
			
			$result = $this->check_basic_parameters($_POST);
			
			if($result ==1)
			{	
				$check_user_by_ID = $this->check_user_by_ID($_POST['patient_id']);

				if($check_user_by_ID ==0)
				{
					return response()->json(['success'=>0,'message'=>'Please enter correct user id.'],200);					
				}
				
				$token_status = $this->check_token_status($_POST['patient_id'],$_POST['login_token']);
				
				if($token_status ==1)
				{
				
					$hospital = Hospital::select('*')->orderBy('hosp_name','ASC')->get();
					//~ echo '<pre>'; print_r($hospital); die('here');
					if(count($hospital) > 0)
					{
						
						return response()->json(['success'=>1,'data'=>$hospital],200);
					}
					else
					{
						return response()->json(['success'=>0,'message'=>'No record found.'],200);	
					}
				}
				
				if($token_status == 0)
				{
					return response()->json(['success'=>2,'message'=>'Expired login token.'],200);						
				}
				
				if($token_status == 2)
				{
					return response()->json(['success'=>2,'message'=>'Invalid login token.'],200);					
				}					
			}		
		}

		/******
		Hospital Doctors Api
	 	*******/
		public function hospitalDoctors(Request $header_request)
		{
			
			header('Content-Type: application/x-www-form-urlencoded');
			header('Content-Type: application/json');
			$decodedArray = json_decode( file_get_contents('php://input'));			
			$decodedArray =  (array) $decodedArray;
			$_POST = $decodedArray;				

	        if(!isset($_POST['web'])){
				$this->app_version      = $header_request->header('app-version');
		        $this->device_type      = strtoupper($header_request->header('device-type'));
		        $this->device_token     = $header_request->header('device-token');
		        $this->time_zone        = $header_request->header('time-zone');	        
				
				 if($this->app_version=='' || $this->device_type =='' || $this->device_token=='' || $this->time_zone ==''){        	 
		            return response()->json(['success' => 0,'message'=>'Insufficient data in headers'],200);
		            exit;
		        }  
		        $_POST['login_token'] = $this->device_token;
		        $time_zone = $this->time_zone;
		    }else if(isset($_POST['time_zone'])){
				$time_zone = $_POST['time_zone'];
			}else{
				$time_zone = 'UTC';
			}
			
			$result = $this->check_basic_parameters($_POST);
			
			if($result ==1)
			{	
				$check_user_by_ID = $this->check_user_by_ID($_POST['patient_id']);

				if($check_user_by_ID ==0)
				{
					return response()->json(['success'=>0,'message'=>'Please enter correct user id.'],200);					
				}
				
				$token_status = $this->check_token_status($_POST['patient_id'],$_POST['login_token']);
				
				if($token_status ==1)
				{
					$value = $_POST['hosp_id'];
					if(isset($_POST['web'])){
						$dtz = new DateTimeZone($time_zone);     
				        $date = date('Y-m-d',strtotime($_POST['date']));   
				        $next_date = date('Y-m-d', strtotime('+1 day', strtotime($date)));
				        $time_in_sofia = new DateTime($date, $dtz);        
				        $date_offset = $time_in_sofia->format('Z');       
				        $start_time = strtotime($date)-$date_offset;
				        
				        $end_time = strtotime($next_date)-$date_offset;
				        $base_url = asset('/');
				        
						$doctors=Doctor::with(array('doctor_availability'=>function($q) use($start_time,$end_time) {$q->where('availability_date','>=',$start_time); $q->where('availability_date','<',$end_time); $q->where('type',2); $q->orderBy('availability_date','ASC');}))->with('specialist_categories')->where('doctors.doctor_timezone','like','%'.$time_zone.'%')->where('hospital_id',$value)->select("*",DB::Raw('CONCAT("'.$base_url.'/admin/doctor/uploads/profile/",doctors.doctor_picture) as doctor_picture'))->get();	
					}else{
						$base_url = asset('/');
						$doctors = Doctor::with(array('specialist_categories'))->select('*')->where('hospital_id',$value)->where('doctors.doctor_timezone','like','%'.$time_zone.'%')->select("*",DB::Raw('CONCAT("'.$base_url.'/admin/doctor/uploads/profile/",doctors.doctor_picture) as doctor_picture'))->get();
					}				
					
					if(count($doctors) > 0)
					{
						
						return response()->json(['success'=>1,'data'=>$doctors],200);
					}
					else
					{
						return response()->json(['success'=>0,'message'=>'No record found.'],200);	
					}
				}
				
				if($token_status == 0)
				{
					return response()->json(['success'=>2,'message'=>'Expired login token.'],200);						
				}
				
				if($token_status == 2)
				{
					return response()->json(['success'=>2,'message'=>'Invalid login token.'],200);					
				}					
			}		
		}

		/******
		User Notification Api
	 	*******/
		public function userNotification(Request $header_request)
		{
			
			header('Content-Type: application/x-www-form-urlencoded');
			header('Content-Type: application/json');
			$decodedArray = json_decode( file_get_contents('php://input'));			
			$decodedArray =  (array) $decodedArray;
			$_POST = $decodedArray;	

			//echo "<pre>"; print_R($_POST); exit;
			$this->app_version      = $header_request->header('app-version');
	        $this->device_type      = strtoupper($header_request->header('device-type'));
	        $this->device_token     = $header_request->header('device-token');
	        $this->time_zone        = $header_request->header('time-zone');	        
			
			if($this->app_version=='' || $this->device_type =='' || $this->device_token=='' || $this->time_zone ==''){        	 
	            return response()->json(['success' => 0,'message'=>'Insufficient data in headers'],200);
	            exit;
	        }  	

	        $_POST['login_token'] = $this->device_token;
	        $time_zone = $this->time_zone;
			
			$result = $this->check_basic_parameters($_POST);
			
			if($result ==1)
			{	
				$check_user_by_ID = $this->check_user_by_ID($_POST['patient_id']);

				if($check_user_by_ID ==0)
				{
					return response()->json(['success'=>0,'message'=>'Please enter correct user id.'],200);					
				}
				
				$token_status = $this->check_token_status($_POST['patient_id'],$_POST['login_token']);
				
				if($token_status ==1)
				{
					$limit = 5;
					if(isset($_POST['page']) && $_POST['page'] != ""){
						$page = $_POST['page'];
						$base_url = asset('/admin/doctor/uploads/profile');
						$notifications=UserNotification::with(array("doctor"=>function($q) use($base_url){$q->select('*',DB::Raw('CONCAT("'.$base_url.'/",doctors.doctor_picture) as doctor_picture'));}))->with('nurse','employee','hospital')->where('patient_id',$_POST['patient_id'])->orderBy('created_date','DESC')->paginate($limit, ['*'],'page',$page); 
						foreach($notifications as $notify)
					    {
					        UserNotification::where('notification_id', $notify['notification_id'])->update(['status' => 1]);
					    } 
						if(count($notifications) > 0)
						{
							$total = $notifications->lastPage();
							$notifications = $notifications->toArray()['data'];
							return response()->json(['success'=>1,'data'=>$notifications, 'total'=>$total],200);
						}
						else
						{
							return response()->json(['success'=>0,'message'=>'No record found.'],200);	
						}
					}else{
						$base_url = asset('/admin/doctor/uploads/profile');
						$notifications=UserNotification::with(array("doctor"=>function($q) use($base_url){$q->select('*',DB::Raw('CONCAT("'.$base_url.'/",doctors.doctor_picture) as doctor_picture'));}))->with('nurse','employee','hospital')->where('patient_id',$_POST['patient_id'])->orderBy('created_date','DESC')->get(); 
						foreach($notifications as $notify)
					    {
					        UserNotification::where('notification_id', $notify['notification_id'])->update(['status' => 1]);
					    } 
						if(count($notifications) > 0)
						{
							
							return response()->json(['success'=>1,'data'=>$notifications],200);
						}
						else
						{
							return response()->json(['success'=>0,'message'=>'No record found.'],200);	
						}
					}                   
					//~ echo '<pre>'; print_r($hospital); die('here');
					
				}
				
				if($token_status == 0)
				{
					return response()->json(['success'=>2,'message'=>'Expired login token.'],200);						
				}
				
				if($token_status == 2)
				{
					return response()->json(['success'=>2,'message'=>'Invalid login token.'],200);					
				}					
			}		
		}

		protected function check_basic_parameters($data)
		{
			
			if(!isset($data['login_token']) || empty($data['login_token']))
			{
				echo json_encode(array('success'=>0,'message'=>'Please provide Login token'));
				exit;
			}
			return 1;
		}

		protected function check_user_by_ID($user_id)
		{
			$check_user_by_ID = Patient::where('patient_unique_id', '=', $user_id)->get();

			if(!empty($check_user_by_ID) && count($check_user_by_ID)==1)
			{
				if($check_user_by_ID[0]->patient_unique_id == $user_id)
				{
					return 1;
				}
				if($check_user_by_ID[0]->patient_unique_id != $user_id)
				{
					return 0;
				}
			}
			if(empty($check_user_by_ID))
			{
				return 0;
			}
		}

		private function check_token_status($user_id,$login_token)
		{
			$where_condition_user = array('patient_id'=>$user_id,'login_token'=>$login_token);

			$token_status= PatientLoginToken::where($where_condition_user)->get();
			//echo "<pre>"; print_R($token_status); exit;
			if(count($token_status)<=0)
			{
				return 2;
			}
			if(count($token_status)>0)
			{
				return $token_status[0]->token_status;
			}
		}
		
		protected function generateUniqueNumber() {
		    $number = mt_rand(1000000000, 9999999999); // better than rand()
		    // call the same function if the uniwue id exists already
		    if ($this->uniqueNumberExists($number)) {
		        return $this->generateUniqueNumber();
		    }
		    // otherwise, it's valid and can be used
		    return strval($number);
		}

		protected function uniqueNumberExists($number) {
		    // query the database and return a boolean		   
		    return Patient::wherepatient_unique_id($number)->exists();
		}

		protected function generateNUniqueNumber() {
	        $number = mt_rand(1000000000, 9999999999); // better than rand()
	        // call the same function if the uniwue id exists already
	        if ($this->uniqueNNumberExists($number)) {
	            return $this->generateNUniqueNumber();
	        }
	        // otherwise, it's valid and can be used
	        return strval($number);
	    }

	    protected function uniqueNNumberExists($number) {
	        // query the database and return a boolean         
	        return UserNotification::wherenotification_id($number)->exists();
	    }

	    private function commoncurl($url,$post_data){
	        $ch1 = curl_init();       
	        curl_setopt($ch1, CURLOPT_URL,$url);
	        curl_setopt($ch1, CURLOPT_HEADER, 0);
	        curl_setopt($ch1, CURLOPT_POST, 1);
	        curl_setopt($ch1, CURLOPT_POSTFIELDS, $post_data);  
	        curl_setopt($ch1, CURLOPT_RETURNTRANSFER, 1);
	        curl_setopt($ch1, CURLOPT_SSL_VERIFYPEER, 0);
	        $output = curl_exec($ch1);  
	        //echo "<pre>"; print_R($output);
	        curl_close ($ch1);
	        $output= json_decode($output,true);
	        
	        return $output;
		} 
		 //Get all type of specialist and display
		 public function typeSpecialist(Request $request)
		 {
			 $speciality = Speciality::orderBy('name')->where('image','!=','')->get();
			 $specialityAll = Speciality::orderBy('name')->get();
			 $states = StatesNigeria::orderBy('name')->get();
			 $facility = Facility::orderBy('name')->get();
			 $hospital = Hospital::orderBy('hosp_name')->get();
			 return response()->json(['speciality'=>$speciality,'states'=>$states,'facility_type'=>$facility,'specialityAll'=>$specialityAll,'hospital'=>$hospital]);
		 }
	}
