<?php
	
	namespace App\Http\Controllers\Api;
	
	use App\Http\Requests;
	use Illuminate\Http\Request;
	use Illuminate\Support\Facades\Input;
	use GuzzleHttp\Client;
	use Auth;
	use Validator;
	use Redirect;
	use Session;
	use Response;
	use DB;
	use Hash;
	use View;
	use Mail;
	use Cookie;
	use DateTime;	
	use DateTimeZone;
	use App\Http\Controllers\Controller;
	use Illuminate\Routing\UrlGenerator;
	use App\Models\Patient;
	use App\Models\Doctor;
	use App\Models\Hospital;
	use App\Models\PatientAppointment;
	use App\Models\PatientLoginToken;
	use App\Models\DoctorAvailability;
	use App\Models\DoctorLogin;
	use App\Models\SaveTelemedicalBookingDetail;
	use App\Models\DoctorLoginToken;	
	use OpenTok\OpenTok;
	use OpenTok\MediaMode;
	use OpenTok\ArchiveMode;
	use OpenTok\Session as OSession;
	use OpenTok\Role;
	
	class DoctorAppointmentController extends Controller
	{
		public function __construct()
		{
			
		}

		/******
		Doctor Appointment Listing
	 	*******/
		public function doctor_appointment_listing(){
			header('Content-Type: application/x-www-form-urlencoded');
			header('Content-Type: application/json');
			$decodedArray = json_decode( file_get_contents('php://input'));			
			$decodedArray =  (array) $decodedArray;
			$_POST = $decodedArray;					
				
			$validator = Validator::make($_POST, [ 
	            'doctor_id' => 'required'			                    
	        ]);
			if ($validator->fails()) { 
				$errorMsg=$validator->messages();				
			    return response()->json(['success'=>0, 'message'=>$validator->messages()->first()], 401);            
			}		

			//~ $doctor_id=$_POST['doctor_id'];
			$doctor_id="123456";
			$appointments=DB::table('save_telemedical_booking_detail')->select('*')->where('save_telemedical_booking_detail.doctor_id',$doctor_id)->leftJoin('patients', 'save_telemedical_booking_detail.patient_id','=', 'patients.patient_unique_id')->leftJoin('appointment_details', 'appointment_details.appointment_id','=', 'save_telemedical_booking_detail.appointment_id')->get();
			
			if(count($appointments)>0)
			{
				return response()->json(['success'=>1,'message'=>'Appointment Listing.','data'=>$appointments],200);
			}
			else
			{
				return response()->json(['success'=>0, 'message'=>'No record found'], 200);    
			}
		}

		/******
		Doctor Search Patient
	 	*******/
		public function search_patient()
		{
			header('Content-Type: application/x-www-form-urlencoded');
			header('Content-Type: application/json');
			$decodedArray = json_decode( file_get_contents('php://input'));			
			$decodedArray =  (array) $decodedArray;
			$_POST = $decodedArray;				
			
			$validator = Validator::make($_POST, [ 
	            'patient_name' => 'required'			                    
	        ]);
			if ($validator->fails()) { 
				$errorMsg=$validator->messages();				
			    return response()->json(['success'=>0, 'message'=>$validator->messages()->first()], 401);            
			}		

			$patient_detail=Patient::where('patient_first_name','like','%'.$_POST['patient_name'].'%')->orWhere('patient_last_name','like','%'.$_POST['patient_name'].'%')->get();
			
			if(count($patient_detail)>0)
			{
				return response()->json(['success'=>1,'message'=>'Patient Detail.','data'=>$patient_detail],200);
			}
			else
			{
				return response()->json(['success'=>0, 'message'=>'No record found'], 200);    
			}		
		}
	
		/******
		Doctor Search Patient Result
	 	*******/
		public function search_patient_data(Request $request)
		{
			header('Content-Type: application/x-www-form-urlencoded');
			header('Content-Type: application/json');
			$decodedArray = json_decode( file_get_contents('php://input'));			
			$decodedArray =  (array) $decodedArray;
			$_POST = $decodedArray;		
			
			if ($request->isMethod('post')) {  				
				$validator = Validator::make($_POST, [ 
		            'patient_first_name' => 'required'			                    
		        ]);
				if ($validator->fails()) { 
					$errorMsg=$validator->messages();				
				    return response()->json(['success'=>0, 'message'=>$validator->messages()->first()], 401);            
				}		
				
				
				$query = Patient::query();
			
					if(!empty($_POST['patient_first_name']))
					{
						$query=$query->where('patient_first_name','like','%'.$_POST['patient_first_name'].'%');
					}
				
					if(!empty($_POST['patient_last_name']))
					{
						$query=$query->where('patient_last_name','like','%'.$_POST['patient_last_name'].'%');
					}
				
					if(!empty($_POST['patient_medical_record']))
					{	
						$query=$query->where('patient_unique_id','=',$_POST['patient_medical_record']);
					}
				
					if(!empty($_POST['patient_date_of_birth']))
					{	
						$query=$query->where('patient_date_of_birth','=',date('Y-m-d',strtotime($_POST['patient_date_of_birth'])));
					}
				
				
				$all= $query->get();
				
				if(count($all)>0)
				{
					return response()->json(['success'=>1,'message'=>'Patient Detail.','data'=>$all],200);
				}
				else
				{
					return response()->json(['success'=>0, 'message'=>'No record found'], 200);    
				} 				
			}//request method post
			
		}

		/******
		Doctor tokbox connection api
	 	*******/
		public function tokBoxConnection(){       
	        header('Content-Type: application/x-www-form-urlencoded');
			header('Content-Type: application/json');
			$decodedArray = json_decode( file_get_contents('php://input'));			
			$decodedArray =  (array) $decodedArray;
			$_POST = $decodedArray;	

			$validator = Validator::make($_POST, [ 
	            'doctor_id' => 'required',
	            'appoint_id'=> 'required'			                    
	        ]);
			if ($validator->fails()) { 
				$errorMsg=$validator->messages();				
			    return response()->json(['success'=>0, 'message'=>$validator->messages()->first()], 401);            
			}	

			$call_status = SaveTelemedicalBookingDetail::where('appointment_id',$_POST['appoint_id'])->get();
			$doctor_get = Doctor::where('doctor_id',$_POST['doctor_id'])->first();			
	        
	        if(count($call_status) > 0){
				if($call_status[0]->call_status  == 0){
					 return response()->json(['success'=>1,'data'=>$doctor_get,'status'=>1],200);
				}else{
					return response()->json(['success'=>1,'data'=>$doctor_get,'status'=>0],200);
				}
			}else{
				return response()->json(['success'=>1,'data'=>$doctor_get,'status'=>0],200);
			}  
		}

	    /******
		Doctor update diconnect call
	 	*******/
	    public function updateDisconnectStatus(Request $header_request){
	    	$decodedArray = json_decode( file_get_contents('php://input'),true);			
			$_POST = $decodedArray;			
	        try{ 
	        	$validator = Validator::make($_POST, [ 		            
		            'appoint_id'	=> 'required'		                    
		        ]);

				if ($validator->fails()) { 
					$errorMsg=$validator->messages();				
				    return response()->json(['success'=>0, 'message'=>$validator->messages()->first()], 200);            
				}      	

	        	$check_appiointid = SaveTelemedicalBookingDetail::where('appointment_id',$_POST['appoint_id'])->count();
				if($check_appiointid > 0){					
					SaveTelemedicalBookingDetail::where('appointment_id',$_POST['appoint_id'])->update(['call_status'=>0]);
					return response()->json(['success'=>1], 200);

				}else{
					return response()->json(['success' => 0,'message'=>'Appointment id does not exists.']);
				}	
	        }catch(\Exception $e){
				return response()->json(['success' => 0,'message'=>$e->getMessage()]);
			}			
	    }



	  /******
		Doctor Avaialability Api
	 	*******/
		public function doctorAvailaibility(Request $header_request){
			header('Content-Type: application/x-www-form-urlencoded');
			header('Content-Type: application/json');
			$decodedArray = json_decode( file_get_contents('php://input'));			
			$decodedArray =  (array) $decodedArray;
			$_POST = $decodedArray;		
			//echo "<pre>"; print_R($_POST); exit;
			if(!isset($_POST['web'])){
				$this->app_version      = $header_request->header('app-version');
		        $this->device_type      = strtoupper($header_request->header('device-type'));
		        $this->device_token     = $header_request->header('device-token');
		        $this->time_zone        = $header_request->header('time-zone');	        
				
				 if($this->app_version=='' || $this->device_type =='' || $this->device_token=='' || $this->time_zone ==''){        	 
		            return response()->json(['success' => 0,'message'=>'Insufficient data in headers'],200);
		            exit;
		        }  
		        $_POST['login_token'] = $this->device_token;
		        $time_zone = $this->time_zone;
			}else if(isset($_POST['time_zone'])){
				$time_zone = $_POST['time_zone'];
			}else{
				$time_zone = 'UTC';
			}

			$result = $this->check_basic_parameters($_POST);
			
			if(!isset($_POST['doctor_id']) || $_POST['doctor_id'] == ""){
				return response()->json(['success'=>0,'message'=>'Please enter correct doctor id.'],200);	
			}
			//print_r($_POST);die;
			if($result ==1)
			{						
					$time_zone = $time_zone;
			        $dtz = new DateTimeZone($time_zone);     
			        $date = date('Y-m-d',strtotime($_POST['appoint_date']));   
			        $next_date = date('Y-m-d', strtotime('+1 day', strtotime($date)));
			        $time_in_sofia = new DateTime($date, $dtz);        
			        $date_offset = $time_in_sofia->format('Z');       
			        $start_time = strtotime($date)-$date_offset;
			        
			        $end_time = strtotime($next_date)-$date_offset;			       
					
					if(isset($_POST['speciality_id']) && $_POST['speciality_id'] != ""){
						$value = $_POST['speciality_id'];						
						if($_POST['type'] == 1){
							$doctor_listing=DoctorAvailability::where('doctor_availability.availability_date','>=',$start_time)->where('doctor_availability.availability_date','<',$end_time)->where('doctor_id',$_POST['doctor_id'])->where('type',1)->whereHas('doctor', function($q) use($value) {$q->where('doctor_speciality',$_POST['speciality_id']);})->select("*")->groupBy('doctor_availability.availability_time')->orderBy('doctor_availability.availability_date','ASC')->get();
						}else if($_POST['type'] == 2){
							$doctor_listing=DoctorAvailability::where('doctor_availability.availability_date','>=',$start_time)->where('doctor_availability.availability_date','<',$end_time)->where('doctor_id',$_POST['doctor_id'])->where('type',2)->whereHas('doctor', function($q) use($value) {$q->where('doctor_speciality',$_POST['speciality_id']);})->select("*")->groupBy('doctor_availability.availability_time')->orderBy('doctor_availability.availability_date','ASC')->get();
						}
					}else{
						if($_POST['type'] == 1){
							$doctor_listing=DoctorAvailability::where('doctor_availability.availability_date','>=',$start_time)->where('doctor_availability.availability_date','<',$end_time)->where('type',1)->where('doctor_id',$_POST['doctor_id'])->select("*")->groupBy('doctor_availability.availability_time')->orderBy('doctor_availability.availability_date','ASC')->get();
						}else if($_POST['type'] == 2){
							$doctor_listing=DoctorAvailability::where('doctor_availability.availability_date','>=',$start_time)->where('doctor_availability.availability_date','<',$end_time)->where('type',2)->where('doctor_id',$_POST['doctor_id'])->select("*")->groupBy('doctor_availability.availability_time')->orderBy('doctor_availability.availability_date','ASC')->get();
						}
						
					}					
					if(count($doctor_listing) > 0)
					{	
						return response()->json(['success'=>1,'data'=>$doctor_listing],200);
					}
					else
					{
						return response()->json(['success'=>0,'message'=>'No Data Found.'],200);
					}
				

			}
		}
  

  			protected function check_basic_parameters($data)
		{
			
			if(!isset($data['login_token']) || empty($data['login_token']))
			{
				echo json_encode(array('success'=>0,'message'=>'Please provide Login token'));
				exit;
			}
			
			return 1;
		}
	
	}
