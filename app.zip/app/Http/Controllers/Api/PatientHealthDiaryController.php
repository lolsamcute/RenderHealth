<?php
	
	namespace App\Http\Controllers\Api;
	
	use App\Http\Requests;
	use Illuminate\Http\Request;
	use Illuminate\Support\Facades\Input;
	use GuzzleHttp\Client;
	use Auth;
	use Validator;
	use Redirect;
	use Session;
	use Response;
	use DB;
	use Hash;
	use View;
	use Mail;
	use Cookie;
	use DateTime;	
	use DateTimeZone;
	use App\Http\Controllers\Controller;
	use Illuminate\Routing\UrlGenerator;	
	use App\Models\Patient;	
	use App\Models\PatientLoginToken;	
	use App\Models\PatientHealthDiary;
	use App\Models\PatientDiaryAttachment;
	
	class PatientHealthDiaryController extends Controller
	{
		public function __construct()
		{
			
		}


		/******
		Patient Add Health Diary Api
	 	*******/
		public function addHealthDiary(Request $header_request){			
			try{
			//echo 'jkrhgj';					
				//print_r($_POST);die;
				if(!is_object(json_decode( file_get_contents('php://input')))){					
					$this->app_version      = $header_request->header('app-version');
			        $this->device_type      = strtoupper($header_request->header('device-type'));
			        $this->device_token     = $header_request->header('device-token');
			        $this->time_zone        = $header_request->header('time-zone');	        
			        //$this->server           = $header_request->server('HTTP_HOST');		       

			        if($this->app_version=='' || $this->device_type =='' || $this->device_token=='' || $this->time_zone ==''){        	 
			            return response()->json(['success' => 0,'message'=>'Insufficient data in headers'],200);
			            exit;
		        	}  
		        	$_POST['login_token'] = $this->device_token;
		        	$time_zone = $this->time_zone;
		        }else{
		        	$decodedArray = json_decode( file_get_contents('php://input'));			
					$decodedArray =  (array) $decodedArray;
					$_POST = $decodedArray;						
		        	if(isset($_POST['time_zone'])){
						$time_zone = $_POST['time_zone'];		        	
					}else{
						$time_zone = 'UTC';
					}
				}
	        	
	        	$result = $this->check_basic_parameters($_POST);

	        	if($result ==1)
				{	
					$check_user_by_ID = $this->check_user_by_ID($_POST['patient_id']);

					if($check_user_by_ID ==0)
					{
						return response()->json(['success'=>0,'message'=>'Please enter correct user id.'],200);					
					}
					
					if(!isset($_POST['web'])){
						$token_status = $this->check_token_status($_POST['patient_id'], $_POST['login_token']);
					}else{
						$token_status = $this->check_web_token_status($_POST['patient_id'], $_POST['login_token']);
					}
					
					if($token_status ==1)
					{
						$validator = Validator::make($_POST, [ 
							'patient_id'=>'required',							 
							'feeling_details' => 'required'						            
						]);

						if($validator->fails()) { 
							$errorMsg=$validator->messages();				
							return response()->json(['success'=>0, 'message'=>$validator->messages()->first()], 401);            
						}

						$user_id = $_POST['patient_id'];
						$symptom_details=NULL;							
						if(isset($_POST['symptom_details'])){
							$symptom_details = $_POST['symptom_details'];
						}

						$medication_details = NULL;
						if(isset($_POST['medication_details'])){
							$medication_details = $_POST['medication_details'];
						}

						$describe_feeling_other=NULL;							
						if(isset($_POST['other_health_diary'])){
							$describe_feeling_other = $_POST['other_health_diary'];
						}
	
						
						$dtz = new DateTimeZone($time_zone);     
				        $date = date('Y-m-d H:i:s',strtotime('now'));   				        
				        $time_in_sofia = new DateTime($date, $dtz);        
				        $date_offset = $time_in_sofia->format('Z');       
				        $diary_time = strtotime($date);
						// return response()->json(['message'=>$describe_feeling_other],200);
						$PatientHealthDiary = new PatientHealthDiary([
							'diary_id'				=> $this->generateUniqueNumber(),
						    'patient_id'			=> $_POST['patient_id'],
						    'feeling_details'		=> $_POST['feeling_details'],
						    'symptom_details'		=> $symptom_details,	
						    'medication_details'	=> $medication_details,
						    'created_date'			=> $diary_time					    			     			
						]);	
						$PatientHealthDiary->save();
					

						if(isset($_FILES['attachments']) && count($_FILES['attachments']) > 0){								
							$count = 0;
							foreach( $_FILES['attachments']['name'] as $key=>$attachment){	
								// the message
								$msg = json_encode($attachment);
								// send email								

								$path = public_path('uploads/diary');
								$date = strtotime('now');
								if(!is_dir($path."/".$user_id))
								{
									mkdir($path."/".$user_id);
									chmod($path."/".$user_id, 0777);
								}
								
								if(!is_dir($path."/".$user_id."/".$date))
								{
									mkdir($path."/".$user_id."/".$date);
									chmod($path."/".$user_id."/".$date, 0777);
								}

								$extension = pathinfo($attachment, PATHINFO_EXTENSION); // getting image extension
								$dir = $path."/".$user_id."/".$date;
								$filename = $user_id."_".$date.'_'.$count.'.'.$extension;
								$count++;
								
								move_uploaded_file($_FILES['attachments']['tmp_name'][$key], $dir."/".$filename."");

								$PatientDiaryAttachment = new PatientDiaryAttachment([
									'attachment_id'		=> $this->generateUniqueNumber(),
								    'diary_id'			=> $PatientHealthDiary->diary_id,
								    'attachment_name'	=> $filename,
								    'folder_name'		=> $date,
								    'attachment_path'	=> "uploads/diary/".$user_id."/".$date."/".$filename					    				    			     			
								]);	

								$PatientDiaryAttachment->save();
							}
						}elseif(is_object(json_decode( file_get_contents('php://input')))){	
							if(isset($_POST["attachment_path"]) && count($_POST["attachment_path"]) > 0){
								foreach($_POST["attachment_path"] as $key=>$attachment_path){
									$PatientDiaryAttachment = new PatientDiaryAttachment([
										'attachment_id'		=> $this->generateUniqueNumber(),
									    'diary_id'			=> $PatientHealthDiary->diary_id,
									    'attachment_name'	=> $_POST["attachment_name"][$key],
									    'folder_name'		=> $_POST["folder_name"][$key],
									    'attachment_path'	=> $attachment_path					    				    			     			
									]);	
									$PatientDiaryAttachment->save();
								}
							}
							
						}
						return response()->json(['success'=>1,'message'=>'Diary added successfully.'],200);
					}

					if($token_status == 0)
					{
						return response()->json(['success'=>2,'message'=>'Expired login token.'],200);						
					}
					if($token_status == 2)
					{
						return response()->json(['success'=>2,'message'=>'Invalid login token.'],200);					
					}
				}
			}catch(Exception $e) {
				return response()->json(['error'=>1,"message"=>$e->getMessage()],200);		 
			}
		}

		/******
		Patient Monthly Health Diary Api
	 	*******/
		public function monthlyHealthDiary(Request $header_request){			
			try{
				$decodedArray = json_decode( file_get_contents('php://input'));			
				$decodedArray =  (array) $decodedArray;
				$_POST = $decodedArray;	
                if(!isset($_POST['web'])){
    				$this->app_version      = $header_request->header('app-version');
    		        $this->device_type      = strtoupper($header_request->header('device-type'));
    		        $this->device_token     = $header_request->header('device-token');
    		        $this->time_zone        = $header_request->header('time-zone');	        
    		        //$this->server           = $header_request->server('HTTP_HOST');
    		       
    		        if($this->app_version=='' || $this->device_type =='' || $this->device_token=='' || $this->time_zone ==''){        	 
    		            return response()->json(['success' => 0,'message'=>'Insufficient data in headers'],200);
    		            exit;
    	        	}  
    	        	$_POST['login_token'] = $this->device_token;
                    $time_zone = $this->time_zone;
                }else{
                    if(isset($_POST['time_zone'])){
                        $time_zone = $_POST['time_zone'];
                    }else{
                        $time_zone = 'UTC';
                    }
                }
	        	
	        	$result = $this->check_basic_parameters($_POST);

	        	if($result ==1)
				{	
					$check_user_by_ID = $this->check_user_by_ID($_POST['patient_id']);

					if($check_user_by_ID ==0)
					{
						return response()->json(['success'=>0,'message'=>'Please enter correct user id.'],200);					
					}
					
					if(!isset($_POST['web'])){
						$token_status = $this->check_token_status($_POST['patient_id'], $_POST['login_token']);
					}else{
						$token_status = $this->check_web_token_status($_POST['patient_id'], $_POST['login_token']);
					}
					
					if($token_status ==1)
					{
						$validator = Validator::make($_POST, [ 
							'patient_id'=>'required',							 
							'diary_month' => 'required'						            
						]);
						$user_id = $_POST['patient_id'];
						if($validator->fails()) { 
							$errorMsg=$validator->messages();				
							return response()->json(['success'=>0, 'message'=>$validator->messages()->first()], 401);            
						}
						
				        $dtz = new DateTimeZone($time_zone);     
				        $date = date('Y-m-d',strtotime($_POST['diary_month']));   
				        $next_date = date('Y-m-t 23:59:59', strtotime($date));
				        $time_in_sofia = new DateTime($date, $dtz);        
				        $date_offset = $time_in_sofia->format('Z');       
				        $start_time = strtotime($date)-$date_offset;				        
				        $end_time = strtotime($next_date)-$date_offset;
						$base_url = asset('/');
						$patient_diary = PatientHealthDiary::with(array('diary_attachment'=>function($q) use($base_url){$q->select('*',DB::Raw('CONCAT("'.$base_url.'",health_diary_attachments.attachment_path) as attachments'));}))->where('created_date','>=',$start_time)->where('created_date','<=',$end_time)->orderBy('created_date')->where('patient_id',$_POST['patient_id'])->get();


						
						$diary_start = PatientHealthDiary::select('created_date')->where('patient_id',$_POST['patient_id'])->orderBy('created_date','ASC')->first();	
						if(isset($diary_start->created_date)){
							if(count($patient_diary) > 0){
								$patient_diary = $patient_diary->toArray();
								array_walk ( $patient_diary, function (&$key) { $key["feeling_details"] = (string)$key["feeling_details"]; } );
								return response()->json(['success'=>1,'start_date'=>$diary_start->created_date,'data'=>$patient_diary],200);
							}else{
								return response()->json(['success'=>3, 'message'=>'Diary not found','start_date'=>$diary_start->created_date],200);
							}
						}else{
							return response()->json(['success'=>3,'message'=>'No Diary Created',],200);
						}	
						return response()->json(['success'=>1,'data'=>$patient_diary],200);
					}

					if($token_status == 0)
					{
						return response()->json(['success'=>2,'message'=>'Expired login token.'],200);						
					}
					if($token_status == 2)
					{
						return response()->json(['success'=>2,'message'=>'Invalid login token.'],200);					
					}
				}
			}catch(Exception $e) {
				return response()->json(['error'=>1,"message"=>$e->getMessage()],200);		 
			}
		}

		/******
		Patient View Health Diary Api
	 	*******/
		public function viewHealthDiary(Request $header_request){			
			try{
				$decodedArray = json_decode( file_get_contents('php://input'));			
				$decodedArray =  (array) $decodedArray;
				$_POST = $decodedArray;	
				$this->app_version      = $header_request->header('app-version');
		        $this->device_type      = strtoupper($header_request->header('device-type'));
		        $this->device_token     = $header_request->header('device-token');
		        $this->time_zone        = $header_request->header('time-zone');	        
		        //$this->server           = $header_request->server('HTTP_HOST');
		       
		        if($this->app_version=='' || $this->device_type =='' || $this->device_token=='' || $this->time_zone ==''){        	 
		            return response()->json(['success' => 0,'message'=>'Insufficient data in headers'],200);
		            exit;
	        	}  
	        	$_POST['login_token'] = $this->device_token;
	        	
	        	$result = $this->check_basic_parameters($_POST);

	        	if($result ==1)
				{	
					$check_user_by_ID = $this->check_user_by_ID($_POST['patient_id']);

					if($check_user_by_ID ==0)
					{
						return response()->json(['success'=>0,'message'=>'Please enter correct user id.'],200);					
					}
					
					$token_status = $this->check_token_status($_POST['patient_id'], $_POST['login_token']);
					
					if($token_status ==1)
					{
						$validator = Validator::make($_POST, [ 
							'patient_id'=>'required',							 
							'diary_id' => 'required'						            
						]);
						$user_id = $_POST['patient_id'];
						if($validator->fails()) { 
							$errorMsg=$validator->messages();				
							return response()->json(['success'=>0, 'message'=>$validator->messages()->first()], 401);            
						}						
						$base_url = asset('/');
						$patient_diary = PatientHealthDiary::with(array('diary_attachment'=>function($q) use($base_url){$q->select('*',DB::Raw('CONCAT("'.$base_url.'",health_diary_attachments.attachment_path) as attachments'));}))->where('diary_id',$_POST['diary_id'])->get();
						
						return response()->json(['success'=>1,'data'=>$patient_diary],200);
					}

					if($token_status == 0)
					{
						return response()->json(['success'=>2,'message'=>'Expired login token.'],200);						
					}
					if($token_status == 2)
					{
						return response()->json(['success'=>2,'message'=>'Invalid login token.'],200);					
					}
				}
			}catch(Exception $e) {
				return response()->json(['error'=>1,"message"=>$e->getMessage()],200);		 
			}
		}

		/******
		Patient Delete Health Diary Api
	 	*******/
		public function deleteHealthDiary(Request $header_request){			
			try{
				$decodedArray = json_decode( file_get_contents('php://input'));			
				$decodedArray =  (array) $decodedArray;
				$_POST = $decodedArray;	
                if(!isset($_POST['web'])){
    				$this->app_version      = $header_request->header('app-version');
    		        $this->device_type      = strtoupper($header_request->header('device-type'));
    		        $this->device_token     = $header_request->header('device-token');
    		        $this->time_zone        = $header_request->header('time-zone');	        
    		        //$this->server           = $header_request->server('HTTP_HOST');
    		       
    		        if($this->app_version=='' || $this->device_type =='' || $this->device_token=='' || $this->time_zone ==''){        	 
    		            return response()->json(['success' => 0,'message'=>'Insufficient data in headers'],200);
    		            exit;
    	        	}  
    	        	$_POST['login_token'] = $this->device_token;
                    $time_zone = $this->time_zone;
                }else{                                
                    if(isset($_POST['time_zone'])){
                        $time_zone = $_POST['time_zone'];                   
                    }else{
                        $time_zone = 'UTC';
                    }
                }
	        	
	        	$result = $this->check_basic_parameters($_POST);

	        	if($result ==1)
				{	
					$check_user_by_ID = $this->check_user_by_ID($_POST['patient_id']);

					if($check_user_by_ID ==0)
					{
						return response()->json(['success'=>0,'message'=>'Please enter correct user id.'],200);					
					}
					
					if(!isset($_POST['web'])){
						$token_status = $this->check_token_status($_POST['patient_id'], $_POST['login_token']);
					}else{
						$token_status = $this->check_web_token_status($_POST['patient_id'], $_POST['login_token']);
					}
					
					if($token_status ==1)
					{
						$validator = Validator::make($_POST, [ 
							'patient_id'=>'required',							 
							'diary_id' => 'required'						            
						]);
						$user_id = $_POST['patient_id'];
						if($validator->fails()) { 
							$errorMsg=$validator->messages();				
							return response()->json(['success'=>0, 'message'=>$validator->messages()->first()], 401);            
						}	
                        $patient_diary = PatientHealthDiary::with(array('diary_attachment'))->where('diary_id',$_POST['diary_id'])->get();						
						$delete_diary = PatientHealthDiary::where('diary_id',$_POST['diary_id'])->delete();
						if($delete_diary > 0){
                            if(count($patient_diary[0]->diary_attachment) > 0){                                 
                                foreach($patient_diary[0]->diary_attachment as $attachment){                                    
                                    $path = public_path('/');
                                    if(file_exists($path."/".$attachment->attachment_path)){
                                        unlink($path."/".$attachment->attachment_path);
                                    }
                                }
                                PatientDiaryAttachment::where('diary_id',$_POST['diary_id'])->delete(); 
                            }   						

							return response()->json(['success'=>1,'message'=>"Diary deleted successfully"],200);
						}else{
							return response()->json(['success'=>0,'message'=>"Diary not found"],200);
						}
					}

					if($token_status == 0)
					{
						return response()->json(['success'=>2,'message'=>'Expired login token.'],200);						
					}
					if($token_status == 2)
					{
						return response()->json(['success'=>2,'message'=>'Invalid login token.'],200);					
					}
				}
			}catch(Exception $e) {
				return response()->json(['error'=>1,"message"=>$e->getMessage()],200);		 
			}
		}

		/******
		Patient Edit Health Diary Api
	 	*******/
		public function editHealthDiary(Request $header_request){			
			try{
				if(!is_object(json_decode( file_get_contents('php://input')))){					
					$this->app_version      = $header_request->header('app-version');
			        $this->device_type      = strtoupper($header_request->header('device-type'));
			        $this->device_token     = $header_request->header('device-token');
			        $this->time_zone        = $header_request->header('time-zone');	        
			        //$this->server           = $header_request->server('HTTP_HOST');		       

			        if($this->app_version=='' || $this->device_type =='' || $this->device_token=='' || $this->time_zone ==''){        	 
			            return response()->json(['success' => 0,'message'=>'Insufficient data in headers'],200);
			            exit;
		        	}  
		        	$_POST['login_token'] = $this->device_token;
		        	$time_zone = $this->time_zone;
		        }else{
		        	$decodedArray = json_decode( file_get_contents('php://input'));			
					$decodedArray =  (array) $decodedArray;
					$_POST = $decodedArray;						
		        	if(isset($_POST['time_zone'])){
						$time_zone = $_POST['time_zone'];		        	
					}else{
						$time_zone = 'UTC';
					}
				}
	        	
	        	$result = $this->check_basic_parameters($_POST);

	        	if($result ==1)
				{	
					$check_user_by_ID = $this->check_user_by_ID($_POST['patient_id']);

					if($check_user_by_ID ==0)
					{
						return response()->json(['success'=>0,'message'=>'Please enter correct user id.'],200);					
					}
					
					if(!isset($_POST['web'])){
						$token_status = $this->check_token_status($_POST['patient_id'], $_POST['login_token']);
					}else{
						$token_status = $this->check_web_token_status($_POST['patient_id'], $_POST['login_token']);
					}
					
					if($token_status ==1)
					{
						$validator = Validator::make($_POST, [ 
							'patient_id'=>'required',							 
							'feeling_details' => 'required',
							'diary_id'=> 'required'						            
						]);

						if($validator->fails()) { 
							$errorMsg=$validator->messages();				
							return response()->json(['success'=>0, 'message'=>$validator->messages()->first()], 401);            
						}

						$user_id = $_POST['patient_id'];
						$symptom_details=NULL;							
						if(isset($_POST['symptom_details'])){
							$symptom_details = $_POST['symptom_details'];
						}

						$medication_details = NULL;
						if(isset($_POST['medication_details'])){
							$medication_details = $_POST['medication_details'];
						}		

						$patient_diary = PatientHealthDiary::with(array('diary_attachment'))->where('diary_id',$_POST['diary_id'])->get();
						
						if(count($patient_diary) > 0){
							PatientHealthDiary::where('diary_id', $_POST['diary_id'])->update(['feeling_details'=> trim($_POST['feeling_details']),'describe_feeling_other'=> trim($_POST['other_health_diary']),'symptom_details' => trim($symptom_details),'medication_details'=> trim($medication_details)]);
							if(isset($_FILES['attachments']) && count($_FILES['attachments']) > 0){	
								$count = count($patient_diary[0]['diary_attachment']);
								foreach( $_FILES['attachments']['name'] as $key=>$attachment){								
									$path = public_path('uploads/diary');
									$date = $patient_diary[0]['created_date'];
									$folder = $patient_diary[0]['diary_attachment'][0]['folder_name'];
									if(!is_dir($path."/".$user_id))
									{
										mkdir($path."/".$user_id);
										chmod($path."/".$user_id, 0777);
									}
									
									if(!is_dir($path."/".$user_id."/".$folder))
									{
										mkdir($path."/".$user_id."/".$folder);
										chmod($path."/".$user_id."/".$folder, 0777);
									}

									$extension = pathinfo($attachment, PATHINFO_EXTENSION); // getting image extension									
									$dir = $path."/".$user_id."/".$folder;
									$filename = $user_id."_".$folder.'_'.$count.'.'.$extension;
									$count++;
									
									move_uploaded_file($_FILES['attachments']['tmp_name'][$key], $dir."/".$filename."");

									$PatientDiaryAttachment = new PatientDiaryAttachment([
										'attachment_id'		=> $this->generateUniqueNumber(),
									    'diary_id'			=> $_POST['diary_id'],
									    'attachment_name'	=> $filename,
									    'folder_name'		=> $folder,
									    'attachment_path'	=> "uploads/diary/".$user_id."/".$folder."/".$filename					    				    			     			
									]);	

									$PatientDiaryAttachment->save();
								}
								
							}elseif(is_object(json_decode( file_get_contents('php://input')))){									
								if(isset($_POST["attachment_path"]) && count($_POST["attachment_path"]) > 0){
									PatientDiaryAttachment::where('diary_id',$_POST['diary_id'])->delete(); 
									foreach($_POST["attachment_path"] as $key=>$attachment_path){
										$PatientDiaryAttachment = new PatientDiaryAttachment([
											'attachment_id'		=> $this->generateUniqueNumber(),
										    'diary_id'			=> $_POST['diary_id'],
										    'attachment_name'	=> $_POST["attachment_name"][$key],
										    'folder_name'		=> $_POST["folder_name"][$key],
										    'attachment_path'	=> $attachment_path					    				    			     			
										]);	
										$PatientDiaryAttachment->save();
									}
								}
								
							}
							return response()->json(['success'=>1,'message'=>'Diary edited successfully.'],200);
						}else{
							return response()->json(['success'=>1,'message'=>'No Diary Found.'],200);
						}					
					}

					if($token_status == 0)
					{
						return response()->json(['success'=>2,'message'=>'Expired login token.'],200);						
					}
					if($token_status == 2)
					{
						return response()->json(['success'=>2,'message'=>'Invalid login token.'],200);					
					}
				}
			}catch(Exception $e) {
				return response()->json(['error'=>1,"message"=>$e->getMessage()],200);		 
			}
		}

		/******
		Diary Start Date Api
	 	*******/
		public function startDateDiary(Request $header_request){			
			try{
				$decodedArray = json_decode( file_get_contents('php://input'));			
				$decodedArray =  (array) $decodedArray;
				$_POST = $decodedArray;	
				$this->app_version      = $header_request->header('app-version');
		        $this->device_type      = strtoupper($header_request->header('device-type'));
		        $this->device_token     = $header_request->header('device-token');
		        $this->time_zone        = $header_request->header('time-zone');	        
		        //$this->server           = $header_request->server('HTTP_HOST');
		       
		        if($this->app_version=='' || $this->device_type =='' || $this->device_token=='' || $this->time_zone ==''){        	 
		            return response()->json(['success' => 0,'message'=>'Insufficient data in headers'],200);
		            exit;
	        	}  
	        	$_POST['login_token'] = $this->device_token;
	        	
	        	$result = $this->check_basic_parameters($_POST);

	        	if($result ==1)
				{	
					$check_user_by_ID = $this->check_user_by_ID($_POST['patient_id']);

					if($check_user_by_ID ==0)
					{
						return response()->json(['success'=>0,'message'=>'Please enter correct user id.'],200);					
					}
					
					$token_status = $this->check_token_status($_POST['patient_id'], $_POST['login_token']);
					
					if($token_status ==1)
					{
						$validator = Validator::make($_POST, [ 
							'patient_id'=>'required'					 
													            
						]);

						if($validator->fails()) { 
							$errorMsg=$validator->messages();				
							return response()->json(['success'=>0, 'message'=>$validator->messages()->first()], 401);            
						}

						$user_id = $_POST['patient_id'];					

						$patient_diary = PatientHealthDiary::select('created_date')->where('patient_id',$_POST['patient_id'])->orderBy('created_date','ASC')->first();	
						if(isset($patient_diary->created_date)){
							return response()->json(['success'=>1,'data'=>$patient_diary],200);
						}else{
							return response()->json(['success'=>0],200);
						}				
					}

					if($token_status == 0)
					{
						return response()->json(['success'=>2,'message'=>'Expired login token.'],200);						
					}
					if($token_status == 2)
					{
						return response()->json(['success'=>2,'message'=>'Invalid login token.'],200);					
					}
				}
			}catch(Exception $e) {
				return response()->json(['error'=>1,"message"=>$e->getMessage()],200);		 
			}
		}

		protected function check_basic_parameters($data)
		{
			
			if(!isset($data['login_token']) || empty($data['login_token']))
			{
				echo json_encode(array('success'=>0,'message'=>'Please provide Login token'));
				exit;
			}
			if(!isset($data['patient_id']) || empty($data['patient_id']))
			{
				echo json_encode(array('success'=>0,'message'=>'Please provide user id'));
				exit;
			}
			return 1;
		}

		protected function check_user_by_ID($user_id)
		{
			$check_user_by_ID = Patient::where('patient_unique_id', '=', $user_id)->get();

			if(!empty($check_user_by_ID) && count($check_user_by_ID)==1)
			{
				if($check_user_by_ID[0]->patient_unique_id == $user_id)
				{
					return 1;
				}
				if($check_user_by_ID[0]->patient_unique_id != $user_id)
				{
					return 0;
				}
			}
			if(empty($check_user_by_ID))
			{
				return 0;
			}
		}

		private function check_token_status($user_id,$login_token)
		{
			$where_condition_user = array('patient_id'=>$user_id,'login_token'=>$login_token,'device_type'=>1);

			$token_status= PatientLoginToken::where($where_condition_user)->get();
			//echo "<pre>"; print_R($token_status); exit;
			if(count($token_status)<=0)
			{
				return 2;
			}
			if(count($token_status)>0)
			{
				return $token_status[0]->token_status;
			}
		}

		private function check_web_token_status($user_id,$login_token)
		{
			$where_condition_user = array('patient_id'=>$user_id,'login_token'=>$login_token,'device_type'=>2);

			$token_status= PatientLoginToken::where($where_condition_user)->get();
			//echo "<pre>"; print_R($token_status); exit;
			if(count($token_status)<=0)
			{
				return 2;
			}
			if(count($token_status)>0)
			{
				return $token_status[0]->token_status;
			}
		}
		
		protected function generateUniqueNumber() {
		    $number = mt_rand(1000000000, 9999999999); // better than rand()
		    // call the same function if the uniwue id exists already
		    if ($this->uniqueNumberExists($number)) {
		        return $this->generateUniqueNumber();
		    }
		    // otherwise, it's valid and can be used
		    return strval($number);
		}

		protected function uniqueNumberExists($number) {
		    // query the database and return a boolean		   
		    return Patient::wherepatient_unique_id($number)->exists();
		}
	}

?>