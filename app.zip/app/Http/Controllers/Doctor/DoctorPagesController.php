<?php
namespace App\Http\Controllers\Doctor;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Auth;
use DB;
use Validator;
use Redirect;
use DateTime;
use DateTimeZone;
use Session;
use Mail;
use App\Models\SaveTelemedicalBookingDetail;
use App\Models\Patient;
use App\Models\BillingDetail;
use App\Models\Hospital;
use App\Models\Doctor;
use App\Models\DoctorLoginToken;
use App\Models\PatientLoginToken;
use App\Models\PaidBillingDetail;
use App\Models\PatientAppointment;
use App\Models\SpecialistCategories;
use Illuminate\Pagination\LengthAwarePaginator;
use Illuminate\Support\Facades\Input;
use App\Models\UserNotification;
use App\Models\PatientNotificationSetting;
use App\Models\DoctorAvailability;
use App\Models\PatientHealthDiary;
use App\Models\Speciality;
use Twilio\Rest\Client;
class DoctorPagesController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
   
    public function __construct()
    {
        $this->middleware('auth:doctor');
    }

    /** telemedical appoinment section*/

    public function telemedicalAppoinment(Request $request,$time=""){         
        if(!Auth::check()){            
	            return redirect('/doctor/login');
	       }
        $user = $request->user();
        $doctor_id= $user->doctor_id;
        $doctor_details = Doctor::where('doctor_id',$doctor_id)->first();  
        $time_zone = $doctor_details->doctor_timezone;                 
        $dtz = new DateTimeZone($time_zone);
        $time_in_sofia = new DateTime('now', $dtz);        
        $date_offset = $time_in_sofia->format('Z');
        $start_time = strtotime(date("Y-m-d"))-$date_offset;
        $end_time = strtotime(date("Y-m-d",strtotime("+1 day")))-$date_offset;

        //$PatientAppointment_details = SaveTelemedicalBookingDetail::with("patient_detail")->with('patient_appoint')->where('save_telemedical_booking_detail.approved_status','!=',2)->select('save_telemedical_booking_detail.*','save_telemedical_booking_detail.id as st_id','save_telemedical_booking_detail.status as st_status')->whereHas('patient_appoint', function($q){$q->where('appointment_type',1);})->where('doctor_id',$doctor_id)->orderBy('appointment_time', 'DESC')->paginate(5);

        if($time == ""){            
            $PatientAppointment_details=SaveTelemedicalBookingDetail::select('save_telemedical_booking_detail.*','appointment_details.*','patients.*','save_telemedical_booking_detail.id as st_id','save_telemedical_booking_detail.status as st_status')->leftJoin('appointment_details', 'appointment_details.appointment_id','=', 'save_telemedical_booking_detail.appointment_id')->leftJoin('patients', 'save_telemedical_booking_detail.patient_id','=', 'patients.patient_unique_id')->whereHas('patient_appoint', function($q){$q->where('appointment_type',1);})->where('save_telemedical_booking_detail.approved_status','!=',2)->where('save_telemedical_booking_detail.doctor_id',$doctor_id)->orderBy('save_telemedical_booking_detail.appointment_time','DESC')->paginate(20);
        }else{
            $query=SaveTelemedicalBookingDetail::select('save_telemedical_booking_detail.*','appointment_details.*','patients.*','save_telemedical_booking_detail.id as st_id','save_telemedical_booking_detail.status as st_status')->leftJoin('appointment_details', 'appointment_details.appointment_id','=', 'save_telemedical_booking_detail.appointment_id')->leftJoin('patients', 'save_telemedical_booking_detail.patient_id','=', 'patients.patient_unique_id')->whereHas('patient_appoint', function($q){$q->where('appointment_type',1);});
                if($time === '1') {                                
                    $query->where('save_telemedical_booking_detail.appointment_time', '>=', $start_time)->where('save_telemedical_booking_detail.appointment_time', '<', $end_time)->where('save_telemedical_booking_detail.approved_status','!=',2)->whereHas('patient_appoint', function($q){$q->where('appointment_type',1);})->where('save_telemedical_booking_detail.doctor_id',$doctor_id);
                }else if($time === '2'){
                   $query->where('save_telemedical_booking_detail.appointment_time', '>', $end_time)->where('save_telemedical_booking_detail.approved_status','!=',2)->whereHas('patient_appoint', function($q){$q->where('appointment_type',1);})->where('save_telemedical_booking_detail.doctor_id',$doctor_id);
                }else if($time === '3'){
                    $query->where('save_telemedical_booking_detail.appointment_time', '<', $start_time)->where('save_telemedical_booking_detail.approved_status','!=',2)->whereHas('patient_appoint', function($q){$q->where('appointment_type',1);})->where('save_telemedical_booking_detail.doctor_id',$doctor_id);
                }
                $PatientAppointment_details = $query->orderBy('save_telemedical_booking_detail.appointment_time','DESC')->paginate(20);
            }

        foreach($PatientAppointment_details as $app)
        {
            SaveTelemedicalBookingDetail::where('id', $app->st_id)->update(['status' => 0]);
        }

        $today_appointment=SaveTelemedicalBookingDetail::where('doctor_id',$doctor_id)->where('save_telemedical_booking_detail.approved_status','!=',2)->where('appointment_time','>=',$start_time)->where('appointment_time','<',$end_time)->get();

        $status = SaveTelemedicalBookingDetail::where('doctor_id',$doctor_id)->where('call_status','>',0)->count();  
        $disabled = 0;
        if($status > 0){
            $disabled = 1;
        }
          $disputed_billing = BillingDetail::where('doctor_id',$doctor_id)->where('disputed',1)->orderBy('billing_date','DESC')->get();
             if($request->ajax()){   
        return view('doctor.telemedical_appointment_ajax')->with(array('controller'=> 'pages','PatientAppointment_details'=>$PatientAppointment_details,'page'=>'inner','page_type'=>'time_count','doctor_details'=>$doctor_details,'timezone'=>$time_zone,'disabled'=>$disabled,'today_appointments_count'=>$today_appointment->count(),'type'=>1,'disputed_billing_count'=>$disputed_billing->count() ));
    }else{
         return view('doctor.telemedical_appointment')->with(array('controller'=> 'pages','PatientAppointment_details'=>$PatientAppointment_details,'page'=>'inner','page_type'=>'time_count','doctor_details'=>$doctor_details,'timezone'=>$time_zone,'disabled'=>$disabled,'today_appointments_count'=>$today_appointment->count(),'type'=>1,'disputed_billing_count'=>$disputed_billing->count() ));
    }
    }

    /** telemedical appoinment section end*/


     /** Hospital appoinment section*/

    public function hospitalAppoinment(Request $request,$time=""){  
        if(!Auth::check()){            
                return redirect('/doctor/login');
           }
         //  echo $request->time;die;
        $user = $request->user();
        $doctor_id= $user->doctor_id;
        $doctor_details = Doctor::where('doctor_id',$doctor_id)->first();  
        $time_zone = $doctor_details->doctor_timezone;                 
        $dtz = new DateTimeZone($time_zone);
        $time_in_sofia = new DateTime('now', $dtz);        
        $date_offset = $time_in_sofia->format('Z');
        $start_time = strtotime(date("Y-m-d"))-$date_offset;
        $end_time = strtotime(date("Y-m-d",strtotime("+1 day")))-$date_offset;

       // $PatientAppointment_details = SaveTelemedicalBookingDetail::with("patient_detail")->with('patient_appoint')->where('save_telemedical_booking_detail.approved_status','!=',2)->select('save_telemedical_booking_detail.*','save_telemedical_booking_detail.id as st_id','save_telemedical_booking_detail.status as st_status')->whereHas('patient_appoint', function($q){$q->where('appointment_type',2);})->where('doctor_id',$doctor_id)->orderBy('appointment_time', 'DESC')->paginate(5);
       if($time == ""){          
            $PatientAppointment_details=SaveTelemedicalBookingDetail::select('save_telemedical_booking_detail.*','appointment_details.*','patients.*','save_telemedical_booking_detail.id as st_id','save_telemedical_booking_detail.status as st_status')->leftJoin('appointment_details', 'appointment_details.appointment_id','=', 'save_telemedical_booking_detail.appointment_id')->leftJoin('patients', 'save_telemedical_booking_detail.patient_id','=', 'patients.patient_unique_id')->whereHas('patient_appoint', function($q){$q->where('appointment_type',2);})->where('save_telemedical_booking_detail.approved_status','!=',2)->where('save_telemedical_booking_detail.doctor_id',$doctor_id)->orderBy('save_telemedical_booking_detail.appointment_time','DESC')->paginate(20);
        }else{
            $query=SaveTelemedicalBookingDetail::select('save_telemedical_booking_detail.*','appointment_details.*','patients.*','save_telemedical_booking_detail.id as st_id','save_telemedical_booking_detail.status as st_status')->leftJoin('appointment_details', 'appointment_details.appointment_id','=', 'save_telemedical_booking_detail.appointment_id')->leftJoin('patients', 'save_telemedical_booking_detail.patient_id','=', 'patients.patient_unique_id')->whereHas('patient_appoint', function($q){$q->where('appointment_type',2);});
                if($time === '1') {                                
                    $query->where('save_telemedical_booking_detail.appointment_time', '>=', $start_time)->where('save_telemedical_booking_detail.appointment_time', '<', $end_time)->where('save_telemedical_booking_detail.approved_status','!=',2)->whereHas('patient_appoint', function($q){$q->where('appointment_type',2);})->where('save_telemedical_booking_detail.doctor_id',$doctor_id);
                }else if($time === '2'){
                   $query->where('save_telemedical_booking_detail.appointment_time', '>', $end_time)->where('save_telemedical_booking_detail.approved_status','!=',2)->whereHas('patient_appoint', function($q){$q->where('appointment_type',2);})->where('save_telemedical_booking_detail.doctor_id',$doctor_id);
                }else if($time === '3'){
                    $query->where('save_telemedical_booking_detail.appointment_time', '<', $start_time)->where('save_telemedical_booking_detail.approved_status','!=',2)->whereHas('patient_appoint', function($q){$q->where('appointment_type',2);})->where('save_telemedical_booking_detail.doctor_id',$doctor_id);
                }
                $PatientAppointment_details = $query->orderBy('save_telemedical_booking_detail.appointment_time','DESC')->paginate(20);
            }
        foreach($PatientAppointment_details as $app)
        {
            SaveTelemedicalBookingDetail::where('id', $app->st_id)->update(['status' => 0]);
        }

        $today_appointment=SaveTelemedicalBookingDetail::where('doctor_id',$doctor_id)->where('save_telemedical_booking_detail.approved_status','!=',2)->where('appointment_time','>=',$start_time)->where('appointment_time','<',$end_time)->get();

        $status = SaveTelemedicalBookingDetail::where('doctor_id',$doctor_id)->where('call_status','>',0)->count();  
        $disabled = 0;
        if($status > 0){
            $disabled = 1;
        }
         $disputed_billing = BillingDetail::where('doctor_id',$doctor_id)->where('disputed',1)->orderBy('billing_date','DESC')->get();
      
        if($request->ajax()){   
        return view('doctor.telemedical_appointment_ajax')->with(array('controller'=> 'pages','PatientAppointment_details'=>$PatientAppointment_details,'page'=>'inner','page_type'=>'time_count','doctor_details'=>$doctor_details,'timezone'=>$time_zone,'disabled'=>$disabled,'today_appointments_count'=>$today_appointment->count(),'type'=>2,"disputed_billing_count"=>$disputed_billing->count()));
    }
    else{
        return view('doctor.telemedical_appointment')->with(array('controller'=> 'pages','PatientAppointment_details'=>$PatientAppointment_details,'page'=>'inner','page_type'=>'time_count','doctor_details'=>$doctor_details,'timezone'=>$time_zone,'disabled'=>$disabled,'today_appointments_count'=>$today_appointment->count(),'type'=>2,"disputed_billing_count"=>$disputed_billing->count()));
    }
    }

    /** Hospital appoinment section end*/

    public function immediateTelemedical(Request $request,$id,$pid,$speciality=null){         
        if(!Auth::check()){            
                return redirect('/doctor/login');
        }
        $user = $request->user();
        $doctor_id= $user->doctor_id;
        $doctor_details = Doctor::where('doctor_id',$doctor_id)->first();  
        $time_zone = $doctor_details->doctor_timezone;                 
        $dtz = new DateTimeZone($time_zone);
        $time_in_sofia = new DateTime('now', $dtz);        
        $date_offset = $time_in_sofia->format('Z');
        $start_time = strtotime(date("Y-m-d"))-$date_offset;
        $end_time = strtotime(date("Y-m-d",strtotime("+1 day")))-$date_offset;
        
        $today_appointment=SaveTelemedicalBookingDetail::where('doctor_id',$doctor_id)->where('save_telemedical_booking_detail.approved_status','!=',2)->where('appointment_time','>=',$start_time)->where('appointment_time','<',$end_time)->get();

        $book_details = SaveTelemedicalBookingDetail::where('appointment_id',$id)->orderBy('created_at','DESC')->get();
         $health_diaries=PatientHealthDiary::where(array('patient_id'=>$pid,))->orderBy('id','DESC')->get();

        $disputed_billing = BillingDetail::where('doctor_id',$doctor_id)->where('disputed',1)->orderBy('billing_date','DESC')->get();
        return view('doctor.immediate_telemedical')->with(array('controller'=> 'pages','doctor_details'=>$doctor_details,'appointment_id'=>$id,'book_details'=>$book_details,'page'=>'inner','speciality'=>$speciality,'timezone'=>$time_zone,'page_type'=>'appoint_search','pid'=>$pid,'today_appointments_count'=>$today_appointment->count(),'disputed_billing_count'=>$disputed_billing->count(),"health_diaries"=>$health_diaries));        
    }

    /******
    Future telemedical appointment
    *******/
    public function futureTelemedical(Request $request,$id,$doctor_id,$pid,$date,$time,$speciality=null)
    {       
        $value = Session::get('doctor_token');
        $doctor_id = Auth::user()->doctor_id;
        $login_token =DoctorLoginToken::where(array('doctor_id'=>$doctor_id,'login_token'=>$value))->first();        
        if(isset($login_token->token_status) && $login_token->token_status == 0){ 
            Auth::guard('doctor')->logout();           
            return response()->json(['redirect'=>1,"redirect_url"=>asset('/doctor/login')],200);
        }
        if(!Auth::check()){            
            return response()->json(['redirect'=>1,"redirect_url"=>asset('/doctor/login')],200);
        } 
        $doctor_details = $request->user();               
        $time_zone = $doctor_details->doctor_timezone;
        $doctor_detail = Doctor::with('specialist_categories')->where('doctor_id',$doctor_id)->first();         
        $book_details = SaveTelemedicalBookingDetail::where('appointment_id',$id)->orderBy('created_at','DESC')->get();
$health_diaries=PatientHealthDiary::where(array('patient_id'=>$pid,))->orderBy('id','DESC')->get();
        return view('doctor.future_tele')->with(array('controller'=> 'pages','doctor_details'=>$doctor_details,'doctor_id'=>$doctor_id,'appointment_id'=>$id,'doctor_apponitment_date'=>$date,'doctor_apponitment_time'=>$time,'doctor_detail'=>$doctor_detail,'book_details'=>$book_details,'page_type'=>'appoint_search','page'=>'inner','speciality'=>$speciality,'timezone'=>$time_zone,'pid'=>$pid,"health_diaries"=>$health_diaries));
    }

    /******
    Doctor Listing
    *******/
    public function doctorListing(Request $request,$id,$pid,$date,$type,$speciality=null)
    {        
        $value = Session::get('doctor_token');
        $doctor_id = Auth::user()->doctor_id;
        $login_token =DoctorLoginToken::where(array('doctor_id'=>$doctor_id,'login_token'=>$value))->first();        
        if(isset($login_token->token_status) && $login_token->token_status == 0){ 
            Auth::guard('doctor')->logout();           
            return response()->json(['redirect'=>1,"redirect_url"=>asset('/doctor/login')],200);
        }
        if(!Auth::check()){            
            return response()->json(['redirect'=>1,"redirect_url"=>asset('/doctor/login')],200);
        } 
        $doctor_details = $request->user();               
        $time_zone = $doctor_details->doctor_timezone;   
        $dtz = new DateTimeZone($time_zone);     
        $date = date('Y-m-d',strtotime($date));               
        $next_date = date('Y-m-d', strtotime('+1 day', strtotime($date)));
        $time_in_sofia = new DateTime($date, $dtz);        
        $date_offset = $time_in_sofia->format('Z');       
        $start_time = strtotime($date)-$date_offset;            
        $end_time = strtotime($next_date)-$date_offset;           
        $speciality_detail = SpecialistCategories::select('*')->get();   
        $disputed_billing = BillingDetail::where('doctor_id',$doctor_id)->where('disputed',1)->orderBy('billing_date','DESC')->get();
        
        if(isset($speciality) && $speciality != ""){
            $value = $speciality;
            //$doctor_listing=DoctorAvailability::with("doctor")->with('doctor.specialist_categories')->where('doctor_availability.availability_date',date('Y-m-d',strtotime($_POST['appoint_date'])))->whereHas('doctor', function($q) use($value) {$q->where('doctor_speciality',$_POST['speciality_id']);})->select("*")->get();
            $doctor_listing=Doctor::with(array('doctor_availability'=>function($q) use($start_time,$end_time) {$q->where('availability_date','>=',$start_time); $q->where('availability_date','<',$end_time); $q->where('type',1); $q->orderBy('availability_date');}))->with('specialist_categories')->whereHas('doctor_availability', function($q) use($start_time,$end_time) {$q->where('availability_date','>=',$start_time); $q->where('availability_date','<',$end_time); $q->where('type',1);})->where('doctors.doctor_timezone','like','%'.$time_zone.'%')->where('doctors.doctor_speciality',$speciality)->select("*")->get();                         
        }else{
            $doctor_listing=Doctor::with(array('doctor_availability'=>function($q) use($start_time,$end_time) {$q->where('availability_date','>=',$start_time); $q->where('availability_date','<',$end_time); $q->where('type',1);$q->orderBy('availability_date');}))->with('specialist_categories')->whereHas('doctor_availability', function($q) use($start_time,$end_time) {$q->where('availability_date','>=',$start_time); $q->where('availability_date','<',$end_time); $q->where('type',1);})->where('doctors.doctor_timezone','like','%'.$time_zone.'%')->select("*")->get();  
            //$doctor_listing=DoctorAvailability::with("doctor")->with('doctor.specialist_categories')->select("*")->groupBy("doctor_availability.doctor_id")->get();
        }
                
        
        $doc_appoint_listing=SaveTelemedicalBookingDetail::where('save_telemedical_booking_detail.approved_status','!=',2)->where('save_telemedical_booking_detail.appointment_time','>=',$start_time)->where('save_telemedical_booking_detail.appointment_time','<',$end_time)->orderBy('save_telemedical_booking_detail.appointment_time','ASC')->get();

        //echo "<pre>"; print_r($doc_appoint_listing); exit;
        if($request->ajax()){               
          return view('doctor.ajax_doctor_listing')->with(array('controller'=> 'pages','doctor_details'=>$doctor_details,'date'=>$date,'doctors'=>$doctor_listing,'id'=>$id,'type'=>$type,'speciality_detail'=>$speciality_detail,'timezone'=>$time_zone,'doc_appoint_listing'=>$doc_appoint_listing,'page_type'=>'appoint_search','pid'=>$pidm,"disputed_billing_count"=>$disputed_billing->count()));      
        }else{
          return view('doctor.doctors_listing')->with(array('controller'=> 'pages','doctor_details'=>$doctor_details,'date'=>$date,'doctors'=>$doctor_listing,'page'=>'inner','page_type'=>'appoint_search','id'=>$id,'type'=>$type,'speciality_detail'=>$speciality_detail,'timezone'=>$time_zone,'doc_appoint_listing'=>$doc_appoint_listing,'pid'=>$pid,"disputed_billing_count"=>$disputed_billing->count()));
        }
    }

    /******
    Speciality Telemedical Appointment
    *******/
    public function specialityTelemedical(Request $request,$id,$pid)
    {       
        $value = Session::get('doctor_token');
        $doctor_id = Auth::user()->doctor_id;
        $login_token =DoctorLoginToken::where(array('doctor_id'=>$doctor_id,'login_token'=>$value))->first();        
        if(isset($login_token->token_status) && $login_token->token_status == 0){ 
            Auth::guard('doctor')->logout();           
            return response()->json(['redirect'=>1,"redirect_url"=>asset('/doctor/login')],200);
        }
        if(!Auth::check()){            
            return response()->json(['redirect'=>1,"redirect_url"=>asset('/doctor/login')],200);
        } 
        $doctor_details = $request->user();               
        $time_zone = $doctor_details->doctor_timezone;
        $speciality_detail = SpecialistCategories::select('*')->get(); 
        if(count($speciality_detail) > 0){
            $speciality_detail = $speciality_detail->toArray();
        }                
        return view('doctor.speciality_listing')->with(array('controller'=> 'patient','doctor_details'=>$doctor_details,'appointment_id'=>$id,'speciality_detail'=>$speciality_detail,'page'=>'inner','timezone'=>$time_zone,'page_type'=>'appoint_search','pid'=>$pid));
    }

    /**  search patient view section */
    public function searchPatient(Request $request){
      	if(!Auth::check()){            
            return redirect('/doctor/login');
        }
        $user = $request->user();
        $doctor_id= $user->doctor_id;
        $doctor_details = Doctor::where('doctor_id',$doctor_id)->first();  
        $time_zone = $doctor_details->doctor_timezone;                 
        $dtz = new DateTimeZone($time_zone);
        $time_in_sofia = new DateTime('now', $dtz);        
        $date_offset = $time_in_sofia->format('Z');
        $start_time = strtotime(date("Y-m-d"))-$date_offset;
        $end_time = strtotime(date("Y-m-d",strtotime("+1 day")))-$date_offset;

        $today_appointment=SaveTelemedicalBookingDetail::where('doctor_id',$doctor_id)->where('save_telemedical_booking_detail.approved_status','!=',2)->where('appointment_time','>=',$start_time)->where('appointment_time','<',$end_time)->get(); 
           $disputed_billing = BillingDetail::where('doctor_id',$doctor_id)->where('disputed',1)->orderBy('billing_date','DESC')->get();

     	  return view('doctor.search_patient')->with(array('controller'=> 'pages', 'page_type'=>'search','doctor_details'=>$doctor_details,'timezone'=>$time_zone,'today_appointments_count'=>$today_appointment->count(),"disputed_billing_count"=>$disputed_billing->count()));

    }
    /**  search patient view end section */

    /**  search patient filter  section */
    public function patientSearchResult(Request $request){
     	if(!Auth::check()){            
            return redirect('/doctor/login');
        }
        $user = $request->user();
        $doctor_id= $user->doctor_id;
        $doctor_details = Doctor::where('doctor_id',$doctor_id)->first();  
        $time_zone = $doctor_details->doctor_timezone;                 
        $dtz = new DateTimeZone($time_zone);
        $time_in_sofia = new DateTime('now', $dtz);        
        $date_offset = $time_in_sofia->format('Z');
        $start_time = strtotime(date("Y-m-d"))-$date_offset;
        $end_time = strtotime(date("Y-m-d",strtotime("+1 day")))-$date_offset;

      	$validatedData = $request->validate([
	           'patient_name' => 'required_without_all:medical_record,surename,dob',
	     ]);

        $form_data =  $request->input();       
        $patient_name =  $request->input('patient_name');
        $medical_record =  $request->input('medical_record');
        $surename =  $request->input('surename');
       
        if(!empty($request->input('dob')))
        {
            $dob= str_replace('/', '-', $request->input('dob')); 
           $dob = strtotime($dob);
        }else{
            $dob = "";
        }  
       $medical_record=preg_replace("/[^0-9]/", '', $medical_record);
        // DB::enableQueryLog();
        $result = Patient::select('*');
                if($patient_name!="" AND $medical_record!="" AND $surename!="" AND $dob!="" )
                {
                $result = $result->where('patient_first_name', 'like', '%'.$patient_name.'%')->where('patient_last_name',  'like', '%'.$surename.'%')->where('patient_date_of_birth','like','%'.$dob.'%')->where('patient_unique_id','like', '%'.$medical_record.'%')->paginate(20);/*->whereIn('patient_unique_id', function($query) use($doctor_id)
                {
                $query->select(DB::raw('patient_id'))
                ->from('save_telemedical_booking_detail')
                ->whereRaw('doctor_id = '.$doctor_id);
                })->whereIn('patient_unique_id', function($query) use($medical_record){
                $query->select(DB::raw('patient_id'))
                ->from('health_history')
                ->whereRaw('history_id = '.$medical_record);
                })*/
                //print_r($result); die;
                $result->appends(array('patient_name'=>Input::get('patient_name'),'medical_record'=>Input::get('medical_record'),'surename'=>Input::get('surename'),'dob'=>Input::get('dob')));
                }
                DB::enableQueryLog();
                if($patient_name=="" AND $medical_record!="" AND $surename=="" AND $dob=="" )
                {
                $result = $result->where('patient_unique_id','like', '%'.$medical_record.'%')->whereIn('patient_unique_id', function($query) use($doctor_id){
                 $query->select(DB::raw('patient_id'))
                ->from('save_telemedical_booking_detail')
                ->whereRaw('doctor_id = '.$doctor_id);
                })->paginate(20);
                /*$result = $result->whereIn('patient_unique_id', function($query) use($medical_record){
                $query->select(DB::raw('patient_id'))
                ->from('health_history')
                ->whereRaw('history_id = '.$medical_record);
                })->whereIn('patient_unique_id', function($query) use($doctor_id)
                {
                $query->select(DB::raw('patient_id'))
                ->from('save_telemedical_booking_detail')
                ->whereRaw('doctor_id = '.$doctor_id);
                })->paginate(5); */    
                /*print_r(DB::connection('mysql')->getQueryLog());           
                die("sasa");*/
                }
                if($patient_name!="" AND $medical_record=="" AND $surename!="" AND $dob!="" )
                {
                $result = $result->where('patient_first_name', 'like', '%'.$patient_name.'%')->where('patient_last_name',  'like', '%'.$surename.'%')->where('patient_date_of_birth','like','%'.$dob.'%')->whereIn('patient_unique_id', function($query) use($doctor_id)
                {
                $query->select(DB::raw('patient_id'))
                ->from('save_telemedical_booking_detail')
                ->whereRaw('doctor_id = '.$doctor_id);
                })->paginate(20);
                //print_r($result); die;
                $result->appends(array('patient_name'=>Input::get('patient_name'),'medical_record'=>Input::get('medical_record'),'surename'=>Input::get('surename'),'dob'=>Input::get('dob')));                
                }
        if(count($result)>0)
        {         
          $today_appointment=SaveTelemedicalBookingDetail::where('doctor_id',$doctor_id)->where('save_telemedical_booking_detail.approved_status','!=',2)->where('appointment_time','>=',$start_time)->where('appointment_time','<',$end_time)->get(); 

          $hospital_listing = Hospital::select('*')->get();
        $disputed_billing = BillingDetail::where('doctor_id',$doctor_id)->where('disputed',1)->orderBy('billing_date','DESC')->get();
          return view('doctor.patient_search_result')->with(array('controller'=> 'pages', 'form_data'=>$form_data,'result'=>$result,'page_type'=>'search','doctor_details'=>$doctor_details,'timezone'=>$time_zone,"hospital_listing"=>$hospital_listing,'today_appointments_count'=>$today_appointment->count(),'disputed_billing_count'=>$disputed_billing->count()));
        }else{
          return Redirect::back()->withErrors(['Result Not found']);
        }
    }
      /**  search patient filter  section end */


    /* scheduling appointment modal */

    public function scheduleAppointment(Request $request){
        $value = Session::get('doctor_token');
        $doctor_id = Auth::user()->doctor_id;
        $login_token =DoctorLoginToken::where(array('doctor_id'=>$doctor_id,'login_token'=>$value))->first();        
        if(isset($login_token->token_status) && $login_token->token_status == 0){ 
            Auth::guard('doctor')->logout();           
            return response()->json(['redirect'=>1,"redirect_url"=>asset('/doctor/login')],200);
        }
        if(!Auth::check()){            
            return response()->json(['redirect'=>1,"redirect_url"=>asset('/doctor/login')],200);
        } 
        $doctor_details = $request->user();               
        $time_zone = $doctor_details->doctor_timezone;
        $dtz = new DateTimeZone($time_zone);     
        if(isset($_POST['appoint_date'])){
          $date = date('Y-m-d',strtotime($_POST['appoint_date'])); 
        }else{
          $date = date('Y-m-d',strtotime('now')); 
        }  
        $next_date = date('Y-m-d', strtotime('+1 day', strtotime($date)));
        $time_in_sofia = new DateTime($date, $dtz);        
        $date_offset = $time_in_sofia->format('Z');       
        $start_time = strtotime($date)-$date_offset;
        
        $end_time = strtotime($next_date)-$date_offset;

        if(isset($_POST['appointment_type'])){
          $appointment_type = $_POST['appointment_type'];
        }else{
          $appointment_type = 2;
        }       
        
        if($appointment_type == 2){
            $doctor_avail_time=Doctor::with(array('doctor_availability'=>function($q) use($start_time,$end_time) {$q->where('availability_date','>=',$start_time); $q->where('availability_date','<',$end_time); $q->where('type',2);}))->with('specialist_categories')->whereHas('doctor_availability', function($q) use($start_time,$end_time) {$q->where('availability_date','>=',$start_time); $q->where('availability_date','<',$end_time); $q->where('type',2);})->where('doctor_id',$doctor_id)->select("*")->first();
            if(isset($doctor_avail_time->doctor_id)){
                $doctor_avail_time = $doctor_avail_time->toArray();
            }
        }elseif($appointment_type == 1){
            $doctor_avail_time=Doctor::with(array('doctor_availability'=>function($q) use($start_time,$end_time) {$q->where('availability_date','>=',$start_time); $q->where('availability_date','<',$end_time);$q->where('type',1);}))->with('specialist_categories')->whereHas('doctor_availability', function($q) use($start_time,$end_time) {$q->where('availability_date','>=',$start_time); $q->where('availability_date','<',$end_time);$q->where('type',1);})->where('doctor_id',$doctor_id)->select("*")->first();
            if(isset($doctor_avail_time->doctor_id)){
                $doctor_avail_time = $doctor_avail_time->toArray();
            }
        }
        
        $doc_appoint_listing=SaveTelemedicalBookingDetail::where('save_telemedical_booking_detail.approved_status','!=',2)->where('save_telemedical_booking_detail.appointment_time','>=',$start_time)->where('save_telemedical_booking_detail.appointment_time','<',$end_time)->orderBy('save_telemedical_booking_detail.appointment_time','ASC')->get();

        $hospital_listing = Hospital::select('*')->get();
        $patient_detail = Patient::where('patient_unique_id',$_POST['patient_id'])->first();
         $disputed_billing = BillingDetail::where('doctor_id',$doctor_id)->where('disputed',1)->orderBy('billing_date','DESC')->get();
        return view('doctor.add_new_appointment')->with(array('controller'=> 'doctor','doctor_avail_time'=>$doctor_avail_time,'doctor_details'=>$doctor_details,'doc_appoint_listing'=>$doc_appoint_listing,'timezone'=>$time_zone,'appoint_date'=>$date,'hospital_listing'=>$hospital_listing,'patient_detail'=>$patient_detail,'appointment_type'=>$appointment_type,'disputed_billing_count'=>$disputed_billing->count()));
    
    }    

    /******
    Add New Appointment
    *******/
    public function addNewAppointment(Request $request){
        $value = Session::get('doctor_token');
        $doctor_id = Auth::user()->doctor_id;
        $login_token =DoctorLoginToken::where(array('doctor_id'=>$doctor_id,'login_token'=>$value))->first();        
        if(isset($login_token->token_status) && $login_token->token_status == 0){ 
            Auth::guard('doctor')->logout();           
            return response()->json(['redirect'=>1,"redirect_url"=>asset('/doctor/login')],200);
        }
        if(!Auth::check()){            
            return response()->json(['redirect'=>1,"redirect_url"=>asset('/doctor/login')],200);
        } 
        $doctor_details = $request->user();               
        $time_zone = $doctor_details->doctor_timezone;
        $hospital_id = $doctor_details->hospital_id;
        if($_POST['appointment_type'] == 1){            
            if($_POST['appointment_type'] == 1){
                $validator = Validator::make($_POST, [                     
                    'appointment_type' => 'required',                 
                    'telemedical_consult_type' => 'required',                 
                    'telemedical_consult_time' => 'required'                  
                ]);
            }else{
                $validator = Validator::make($_POST, [                     
                    'appointment_type' => 'required'        
                ]);
            }
            if ($validator->fails()) { 
                  $errorMsg=$validator->messages();       
                  return response()->json(['success'=>0, 'message'=>$validator->messages()->first()], 401);            
            }   

            $telemedical=NULL;
            if($_POST['appointment_type'] == 1){            
                if(!empty($_POST['telemedical_type']))
                {
                  $telemedical = $_POST['telemedical_type'];
                }            
                else
                {
                  return response()->json(['success'=>0,'message'=>'telemedical type missing.'],200); 
                }               
            }else{
                $telemedical = NULL;
            }

            $telemedical_consult_type = NULL;
            if(isset($_POST['telemedical_consult_type'])){
                $telemedical_consult_type = $_POST['telemedical_consult_type'];
            }

            $telemedical_consult_time = NULL;
            if(isset($_POST['telemedical_consult_time'])){
                $telemedical_consult_time = $_POST['telemedical_consult_time'];
            }
            
            $PatientAppointment = new PatientAppointment([
                'appointment_id'              => $this->generateAUniqueNumber(),
                'patient_id'                  => $_POST['patient_id'],
                'appointment_type'            => $_POST['appointment_type'],
                'telemedical_type'            => $telemedical,  
                'telemedical_consult_type'    => $telemedical_consult_type, 
                'telemedical_consult_time'    => $telemedical_consult_time, 
                'appoint_booking_status'      => 0,
                'appoint_created_date'        => strtotime("now"),    
                'status'                      => 1                
            ]); 

            $PatientAppointment->save();

            if($_POST['appointment_type'] == 1 && $_POST['telemedical_consult_type'] == 1 && $_POST['telemedical_consult_time'] == 1) {
                return response()->json(['success'=>1,"id"=>$PatientAppointment->appointment_id, "redirect_url"=>asset('/doctor/immediate_telemedical/'.$PatientAppointment->appointment_id.'/'.$_POST['patient_id'])],200);
            }else if(($_POST['appointment_type'] == 1 && $_POST['telemedical_consult_type'] == 1 && $_POST['telemedical_consult_time'] == 2) || ($_POST['appointment_type'] == 1 && $_POST['telemedical_consult_type'] == 2 && $_POST['telemedical_consult_time'] == 2)) {
                return response()->json(['success'=>1,"id"=>$PatientAppointment->appointment_id],200);
            }
            if($_POST['appointment_type'] == 1 && $_POST['telemedical_consult_type'] == 2 && $_POST['telemedical_consult_time'] == 1) {
                return response()->json(['success'=>1,"id"=>$PatientAppointment->appointment_id, "redirect_url"=>asset('/doctor/immediate_speciality_details/'.$PatientAppointment->appointment_id.'/'.$_POST['patient_id'])],200);
            }

        }else{
            if($_POST['appointment_type'] == 1){
                $validator = Validator::make($_POST, [                     
                    'appointment_type' => 'required',                 
                    'telemedical_consult_type' => 'required',                 
                    'telemedical_consult_time' => 'required'                  
                ]);
            }else{
                $validator = Validator::make($_POST, [                     
                    'appointment_type' => 'required'        
                ]);
            }
            if ($validator->fails()) { 
                  $errorMsg=$validator->messages();       
                  return response()->json(['success'=>0, 'message'=>$validator->messages()->first()], 401);            
            }   

            $telemedical=NULL;
            if($_POST['appointment_type'] == 1){            
                if(!empty($_POST['telemedical_type']))
                {
                  $telemedical = $_POST['telemedical_type'];
                }            
                else
                {
                  return response()->json(['success'=>0,'message'=>'telemedical type missing.'],200); 
                }               
            }else{
                $telemedical = NULL;
            }

            $telemedical_consult_type = NULL;
            if(isset($_POST['telemedical_consult_type'])){
                $telemedical_consult_type = $_POST['telemedical_consult_type'];
            }

            $telemedical_consult_time = NULL;
            if(isset($_POST['telemedical_consult_time'])){
                $telemedical_consult_time = $_POST['telemedical_consult_time'];
            }
            
            $PatientAppointment = new PatientAppointment([
                'appointment_id'              => $this->generateAUniqueNumber(),
                'patient_id'                  => $_POST['patient_id'],
                'appointment_type'            => $_POST['appointment_type'],
                'telemedical_type'            => $telemedical,  
                'telemedical_consult_type'    => $telemedical_consult_type, 
                'telemedical_consult_time'    => $telemedical_consult_time, 
                'appoint_booking_status'      => 0,
                'appoint_created_date'        => strtotime("now"),    
                'status'                      => 1                
            ]); 

            $PatientAppointment->save();

            $check_appointment_id=false;
            if(!empty($PatientAppointment->appointment_id))
            {
                $fetch_appointment=DB::table('appointment_details')->where('appointment_id',$PatientAppointment->appointment_id)->first(); 
                if($fetch_appointment->appointment_type == 1){          
                   if($fetch_appointment->telemedical_consult_time==2)
                   {
                     $check_appointment_id=true;
                   }
                }else{
                  $check_appointment_id=true;
                }                
            }
            
            if($check_appointment_id)
            {
                $validator = Validator::make($_POST, [                             
                    'patient_id' => 'required',
                    'appoint_date' => 'required|date', 
                    'appoint_time'   => 'required',                 
                ]);           
            }
            else
            {             
                $validator = Validator::make($_POST, [               
                    'booking_name' => 'required', 
                    'mobile_number' => 'required',                  
                    //~ 'symptoms ' => 'required',                  
                    'terms_conditions' => 'required',                 
                    'appoint_date' => 'required|date', 
                    'appoint_time'   => 'required',                 
                    'hospital_name' => 'required',
                    'sharing_status' => 'required',
                    'patient_id' => 'required'                  
                ]);
                    
            }

            if($validator->fails()) { 
                $errorMsg=$validator->messages();       
                return response()->json(['success'=>0, 'message'=>$validator->messages()->first()], 401);            
            }

            $appointment_date = $_POST['appoint_date']." ".$_POST['appoint_time'];          

            if(!empty($_POST['symptoms'])){
                $symptoms = trim($_POST['symptoms']);
            }else{
                $symptoms = NULL;
            }

            $patient_id = $_POST['patient_id'];          
              
            if(!empty($_POST['booking_name'])){
                $booking_name = $_POST['booking_name'];
            }else{
                $booking_name = NULL;
            }
              
            if(!empty($_POST['mobile_number'])){
                $mobile_number = $_POST['mobile_number'];
            }else{
                $mobile_number = NULL;
            }
              
            if(!empty($_POST['terms_conditions'])){
                $terms_conditions = $_POST['terms_conditions'];
            }else{
                $terms_conditions = NULL;
            }
              
            if(!empty($appointment_date)){            
                    $dtz = new DateTimeZone($time_zone);     
                    $date = date('Y-m-d H:i:s',strtotime($appointment_date));                  
                    $time_in_sofia = new DateTime($date, $dtz);        
                    $date_offset = $time_in_sofia->format('Z');       
                    $appointment_time = strtotime($date)-$date_offset;             
            }else{
                $appointment_time = NULL;
            }
              
            if(!empty($_POST['hospital_name'])){
                $hospital_name = $_POST['hospital_name'];
            }else{
                $hospital_name = NULL;
            }

           /* if(!empty($_POST['hospital_id'])){
                $hospital_id = $_POST['hospital_id'];
            }else{
                $hospital_id = 0;
            }*/
              
            if(!empty($_POST['sharing_status'])){
                $sharing_status = $_POST['sharing_status'];
            }else{
                $sharing_status = NULL;
            }

            if(!empty($_POST['speciality_id'])){
                $specialist_id = $_POST['speciality_id'];
            }else{
                $specialist_id = 0;
            }

            $status = 0;

            if(isset($PatientAppointment->appointment_id)){
                $booking_count = SaveTelemedicalBookingDetail::where('appointment_id',$PatientAppointment->appointment_id)->get();
                if(count($booking_count) > 0){
                  $status = 1;
                  $_POST['submit_id'] = $booking_count[0]['booking_id'];
                }
            }

            $booking_exists=SaveTelemedicalBookingDetail::where('save_telemedical_booking_detail.patient_id',$_POST['patient_id'])->where('save_telemedical_booking_detail.appointment_time',$appointment_time)->where('appointment_id','!=',$PatientAppointment->appointment_id)->where('approved_status','!=',2)->count();

            if($booking_exists == 0){
                if(((isset($_POST['submit_status']) && $_POST['submit_status'] == 1) && (isset($_POST['submit_id']) && !empty($_POST['submit_id']))) || ($status == 1)){
                  
                  //~ SaveTelemedicalBookingDetail::where('booking_id', $_POST['submit_id'])->update(['appointment_id'=> $_POST['appointment_id'],'booking_name' => trim($_POST['booking_name']),'patient_id'   => $_POST['patient_id'],'hospital_name'=> $_POST['hospital_name'],'mobile_number'=> trim($_POST['mobile_number']),'symptoms'  => $symptoms,'terms_conditions'=> $_POST['terms_conditions'],'sharing_status'=> $_POST['sharing_status'],'appointment_time'=> date('Y-m-d H:i:s',strtotime($_POST['appointment_time']))]);
                  
                  SaveTelemedicalBookingDetail::where('booking_id', $_POST['submit_id'])->update(['appointment_id'=> $PatientAppointment->appointment_id,'booking_name' => trim($booking_name),'patient_id'=> $_POST['patient_id'],'hospital_id'=>$hospital_id,'specialist_id'=> $specialist_id,'hospital_name'=> trim($hospital_name),'mobile_number'=> trim($mobile_number),'symptoms' => trim($symptoms),'terms_conditions'=> $terms_conditions,'sharing_status'=> $sharing_status]);
                  return response()->json(['success'=>1,'message'=>'Booking updated successfully.','id'=>$_POST['submit_id']],200);
                }else{              
                  $save_telemedical_booking_detail = new SaveTelemedicalBookingDetail([                
                    'booking_id'    => $this->generateBUniqueNumber(),
                    'appointment_id'  => $PatientAppointment->appointment_id,
                    'booking_name'    => trim($booking_name),
                    'patient_id'    => $_POST['patient_id'],
                    'hospital_id'   => $hospital_id,
                    'doctor_id'     => $doctor_id,
                    'specialist_id'   => $specialist_id,
                    'hospital_name'   => trim($hospital_name), 
                    'mobile_number'   => trim($mobile_number),
                    'symptoms'      => $symptoms,
                    'terms_conditions'  => $terms_conditions, 
                    'appointment_time'  => $appointment_time,
                    'sharing_status'  => $sharing_status, 
                    'approved_status' => 0,
                    'status'      => 1,
                    'created_at'    => strtotime("now")                             
                  ]); 

                  $save_telemedical_booking_detail->save();
                  if(isset($PatientAppointment->appointment_id)){
                    PatientAppointment::where('appointment_id', $PatientAppointment->appointment_id)->update(['appoint_booking_status' => 1]);
                  }
                  $UserNotification = new UserNotification([                
                    'notification_id'   => $this->generateNUniqueNumber(),
                    'doctor_id'         => $doctor_id, 
                    'assignee_type'     => 1,                    
                    'patient_id'        => $_POST['patient_id'], 
                    'event_id'          => $save_telemedical_booking_detail->booking_id,
                    'notification_type' => "appt",
                    'change_type'       => "created",
                    'created_date'      => strtotime('now'),
                    'status'            => 0                                          
                  ]);
                  $UserNotification->save(); 

                    $login_token = PatientLoginToken::where('patient_id',$_POST['patient_id'])->where('token_status',1)->get();

                    $msg = "Dr.".Auth::user()->doctor_first_name." ".Auth::user()->doctor_last_name." scheduled a new hospital appointment with you";

                    $patients_notification = PatientNotificationSetting::where('patient_id', $_POST['patient_id'])->first();
                    if(isset($patients_notification->patient_id)){
                        if($patients_notification->appointment_activity_push == 1){
                            if(count($login_token) > 0 && $login_token[0]->device_type != 2){            
                                $device_token = $login_token[0]->device_token;
                                $path = base_path()."/ios_notifcation/all_notifications.php";
                                $nid = $save_telemedical_booking_detail->booking_id;
                                $type= 'appt';
                                exec ('php '.$path.' "'.$msg.'" '.$nid.' '.$type.' '.$device_token.' > /dev/null &');
                            }
                        }

                        if($patients_notification->appointment_activity_email == 1){
                            $url = url('/doctor/send_mail/'.str_replace(" ", "_", $msg).'/'.$_POST['patient_id'].'');   
                            $cmd  = "curl --max-time 60 ";   
                            $cmd .= "'" . $url . "'";   
                            $cmd .= " > /dev/null 2>&1 &";    
                            exec($cmd, $output, $exit); 
                        }
                    }

                         // Send message on phone
                          $message= $this->appointment_message($save_telemedical_booking_detail->booking_id,$_POST['patient_id'],$doctor_id,2);
                            $this->sendMessage($message,'+919800186999');   

                      return response()->json(['success'=>1,'message'=>'Booking added successfully.','id'=>$save_telemedical_booking_detail->booking_id,'telemedical_type'=>$_POST['appointment_type']],200);
                    
                }
            }else{
                return response()->json(['success'=>0,'message'=>'You already have booking with another doctor.'],200);
            }
        }
    }

    /******
    Save Booking Detail
    *******/
    public function saveBookDetails(Request $request){
        $value = Session::get('doctor_token');
        $doctor_id = Auth::user()->doctor_id;
        $login_token =DoctorLoginToken::where(array('doctor_id'=>$doctor_id,'login_token'=>$value))->first();        
        if(isset($login_token->token_status) && $login_token->token_status == 0){ 
            Auth::guard('doctor')->logout();           
            return response()->json(['redirect'=>1,"redirect_url"=>asset('/doctor/login')],200);
        }
        if(!Auth::check()){            
            return response()->json(['redirect'=>1,"redirect_url"=>asset('/doctor/login')],200);
        } 
        $doctor_details = $request->user();               
        $time_zone = $doctor_details->doctor_timezone;
        $check_appointment_id=false;
        if(!empty($_POST['appointment_id']))
        {
            $fetch_appointment=DB::table('appointment_details')->where('appointment_id',$_POST['appointment_id'])->first(); 
            if($fetch_appointment->appointment_type == 1){                  
                if($fetch_appointment->telemedical_consult_time==2)
                {
                    $check_appointment_id=true;
                }
            }else{
                $check_appointment_id=true;
            }
            //~ echo '<pre>'; print_r($fetch_appointment->telemedical_consult_time); die('here');
        }
        
        if($check_appointment_id)
        {
            $validator = Validator::make($_POST, [ 
                'appointment_id'=>'required',                   
                'patient_id' => 'required'                       
            ]);                     
        }
        else
        {                           
            $validator = Validator::make($_POST, [ 
                'appointment_id'=>'required',
                'booking_name' => 'required', 
                'mobile_number' => 'required',                      
                //~ 'symptoms ' => 'required',                      
                'terms_conditions' => 'required',                       
                'doctor_appoint_date' => 'required|date',                      
                'hospital_name' => 'required',
                'sharing_status' => 'required'                      
            ]);
                    
        }

        if ($validator->fails()) { 
                $errorMsg=$validator->messages();               
                return response()->json(['success'=>0, 'message'=>$validator->messages()->first()], 401);            
        }

        if(!empty($_POST['symptoms'])){
            $symptoms = trim($_POST['symptoms']);
        }else{
            $symptoms = NULL;
        }
        
        if(!empty($_POST['booking_name'])){
            $booking_name = $_POST['booking_name'];
        }else{
            $booking_name = NULL;
        }
        
        if(!empty($_POST['mobile_number'])){
            $mobile_number = $_POST['mobile_number'];
        }else{
            $mobile_number = NULL;
        }
        
        if(!empty($_POST['terms_conditions'])){
            $terms_conditions = $_POST['terms_conditions'];
        }else{
            $terms_conditions = NULL;
        }
        
        if(!empty($_POST['doctor_appoint_date'])){     
            $appointment_time = date('d-m-Y H:i:s',strtotime($_POST['doctor_appoint_date']));
            $dtz = new DateTimeZone($time_zone);     
            $date = date('Y-m-d H:i:s',strtotime($appointment_time));                          
            $time_in_sofia = new DateTime($date, $dtz);        
            $date_offset = $time_in_sofia->format('Z');       
            $appointment_time = strtotime($date)-$date_offset;                 
        }else{
            $appointment_time = NULL;
        }
        
        if(!empty($_POST['hospital_name'])){
            $hospital_name = $_POST['hospital_name'];
        }else{
            $hospital_name = NULL;
        }
         //return response()->json(['success'=>1,'message'=>$_POST['health_diary']],200); die;
        if(!empty($_POST['health_diary'])){
         $health_diary = implode(',',$_POST['health_diary']);
            $health_diary= $health_diary;
        }else{
            $health_diary = NULL;
        }
        //echo  $health_diary; die;
        
        if(!empty($_POST['hospital_id'])){
            $hospital_id = $_POST['hospital_id'];
        }else{
            $hospital_id = 0;
        }
        
        if(!empty($_POST['sharing_status'])){
            $sharing_status = $_POST['sharing_status'];
        }else{
            $sharing_status = NULL;
        }

        if(!empty($_POST['speciality_id'])){
            $specialist_id = $_POST['speciality_id'];
        }else{
            $specialist_id = 0;
        }

        $status = 0;

        if(isset($_POST['appointment_id'])){
            $booking_count = SaveTelemedicalBookingDetail::where('appointment_id',$_POST['appointment_id'])->get();
            if(count($booking_count) > 0){
                $status = 1;
                $_POST['submit_id'] = $booking_count[0]['booking_id'];
            }
        }

        $booking_exists=SaveTelemedicalBookingDetail::where('save_telemedical_booking_detail.patient_id',$_POST['patient_id'])->where('save_telemedical_booking_detail.appointment_time',$appointment_time)->where('appointment_id','!=',$_POST['appointment_id'])->where('approved_status','!=',2)->count();

        if($booking_exists == 0){
            if(((isset($_POST['submit_status']) && $_POST['submit_status'] == 1) && (isset($_POST['submit_id']) && !empty($_POST['submit_id']))) || ($status == 1)){
                
                //~ SaveTelemedicalBookingDetail::where('booking_id', $_POST['submit_id'])->update(['appointment_id'=> $_POST['appointment_id'],'booking_name' => trim($_POST['booking_name']),'patient_id'     => $_POST['patient_id'],'hospital_name'=> $_POST['hospital_name'],'mobile_number'=> trim($_POST['mobile_number']),'symptoms'    => $symptoms,'terms_conditions'=> $_POST['terms_conditions'],'sharing_status'=> $_POST['sharing_status'],'appointment_time'=> date('Y-m-d H:i:s',strtotime($_POST['appointment_time']))]);
                
                SaveTelemedicalBookingDetail::where('booking_id', $_POST['submit_id'])->update(['appointment_id'=> $_POST['appointment_id'],'booking_name' => trim($booking_name),'patient_id'=> $_POST['patient_id'],'hospital_id'=>$hospital_id,'specialist_id'=> $specialist_id,'hospital_name'=> trim($hospital_name),'mobile_number'=> trim($mobile_number),'symptoms' => trim($symptoms),'terms_conditions'=> $terms_conditions,'sharing_status'=> $sharing_status,'health_diary' =>$health_diary]);
                return response()->json(['success'=>1,'message'=>'Booking updated successfully.','id'=>$_POST['submit_id']],200);
            }else{
                
                $save_telemedical_booking_detail = new SaveTelemedicalBookingDetail([
                    //~ 'booking_id'        => $this->generateUniqueNumber(),
                    //~ 'appointment_id'    => $_POST['appointment_id'],
                    //~ 'booking_name'      => trim($_POST['booking_name']),
                    //~ 'patient_id'        => $_POST['patient_id'],
                    //~ 'doctor_id'         => $doctor_id,
                    //~ 'hospital_name'     => trim($_POST['hospital_name']), 
                    //~ 'mobile_number'     => trim($_POST['mobile_number']),
                    //~ 'symptoms'          => $symptoms,
                    //~ 'terms_conditions'  => $_POST['terms_conditions'],  
                    //~ 'appointment_time'  => date('Y-m-d H:i:s',strtotime($_POST['appointment_time'])),
                    //~ 'sharing_status'    => $_POST['sharing_status'],    
                    //~ 'created_at'        => strtotime("now"),        
                    'booking_id'        => $this->generateBUniqueNumber(),
                    'appointment_id'    => $_POST['appointment_id'],
                    'booking_name'      => trim($booking_name),
                    'patient_id'        => $_POST['patient_id'],
                    'hospital_id'       => $hospital_id,
                    'doctor_id'         => $doctor_id,
                    'specialist_id'     => $specialist_id,
                    'hospital_name'     => trim($hospital_name), 
                    'mobile_number'     => trim($mobile_number),
                    'symptoms'          => $symptoms,
                    'terms_conditions'  => $terms_conditions,   
                    'appointment_time'  => $appointment_time,
                    'sharing_status'    => $sharing_status, 
                    'approved_status'   => 0,
                    'status'            => 1,
                    'created_at'        => strtotime("now"),  
                    'health_diary'      =>$health_diary      
                                        
                ]); 

                $save_telemedical_booking_detail->save();
                if($fetch_appointment->appointment_type == 1 && $fetch_appointment->telemedical_consult_time == 1){    
                    SaveTelemedicalBookingDetail::where('booking_id', $save_telemedical_booking_detail->booking_id)->update(['doctor_id' => $doctor_id]);
                }
                if(isset($_POST['appointment_id'])){
                    PatientAppointment::where('appointment_id', $_POST['appointment_id'])->update(['appoint_booking_status' => 1]);
                }
                $UserNotification = new UserNotification([                
                    'notification_id'   => $this->generateNUniqueNumber(),
                    'doctor_id'         => $doctor_id, 
                    'assignee_type'     => 1,                    
                    'patient_id'        => $_POST['patient_id'], 
                    'event_id'          => $save_telemedical_booking_detail->booking_id,
                    'notification_type' => "appt",
                    'change_type'       => "created",
                    'created_date'      => strtotime('now'),
                    'status'            => 0                                          
                  ]);
                  $UserNotification->save(); 

                    $login_token = PatientLoginToken::where('patient_id',$_POST['patient_id'])->where('token_status',1)->get();

                    $msg = "Dr.".Auth::user()->doctor_first_name." ".Auth::user()->doctor_last_name." scheduled a new telemedical appointment with you"; 
                    $patients_notification = PatientNotificationSetting::where('patient_id', $_POST['patient_id'])->first();
                    if(isset($patients_notification->patient_id)){
                        if($patients_notification->appointment_activity_push == 1){
                            if(count($login_token) > 0 && $login_token[0]->device_type != 2){            
                                $device_token = $login_token[0]->device_token;
                                $path = base_path()."/ios_notifcation/all_notifications.php";
                                $nid = $save_telemedical_booking_detail->booking_id;
                                $type= 'appt';
                                exec ('php '.$path.' "'.$msg.'" '.$nid.' '.$type.' '.$device_token.' > /dev/null &');
                            }
                        }

                        if($patients_notification->appointment_activity_email == 1){
                            //send email notification
                            $url = url('/doctor/send_mail/'.str_replace(" ", "_", $msg).'/'.$_POST['patient_id'].'');   
                            $cmd  = "curl --max-time 60 ";   
                            $cmd .= "'" . $url . "'";   
                            $cmd .= " > /dev/null 2>&1 &";    
                            exec($cmd, $output, $exit); 
                        }
                    }
                      // Send message on phone
                $message= $this->appointment_message($save_telemedical_booking_detail->booking_id,$_POST['patient_id'],$doctor_id,1);

                       $this->sendMessage($message,'+919800186999');   
                    if($fetch_appointment->telemedical_consult_time == 1){
                        $patient_detail = Patient::where('patient_unique_id',$_POST['patient_id'])->first();
                        date_default_timezone_set($patient_detail->timezone);
                        $current_time = strtotime('now');
                        $beginOfDay = strtotime("midnight", $current_time);
                        $endOfDay   = strtotime("tomorrow", $beginOfDay) - 1;
                        
                        $doctor_details = DoctorAvailability::select('*')->where('availability_date','>=',$beginOfDay)->where('availability_date','<=',$endOfDay)->where('type','=',1)->where('booking_status',0)->orderBy('id','ASC')->get();      

                        $last_booking_row = SaveTelemedicalBookingDetail::select('*')->where('save_telemedical_booking_detail.booking_id',$save_telemedical_booking_detail->booking_id)->where('patient_id',$_POST['patient_id'])->first();

                        if(!empty($doctor_details))
                        {                       
                            $count =0;
                            foreach($doctor_details as $doctor_detail){
                                $availability_time = $doctor_detail['availability_time'];
                                $selectedTime = date('h:i A');
                                $LessTime = strtotime("-15 minutes", strtotime($selectedTime));
                                $GraterTime = strtotime("+15 minutes", strtotime($selectedTime));                          
                                if((strtotime($availability_time) > $LessTime) OR( strtotime($availability_time) < $GraterTime)){
                                    $doctor_details_arr = array();
                                    $doctor_details_arr['doctor_id'] = $doctor_detail['doctor_id'];
                                    $doctor_details_arr = (object) $doctor_details_arr;
                                    if(!empty($last_booking_row) && $last_booking_row->doctor_id == "")
                                    {
                                        $count =1;
                                        SaveTelemedicalBookingDetail::where('booking_id', $last_booking_row->booking_id)->update(['doctor_id' => $doctor_details_arr->doctor_id]);                                  
                                    }
                                    DoctorAvailability::where('doctor_id', $doctor_details_arr->doctor_id)->update(['booking_status' => 1]);
                                    $doc_det = SaveTelemedicalBookingDetail::with('doctor','doctor.specialist_categories')->where('booking_id', $last_booking_row->booking_id)->get();
                                    $doc_name = "Dr. ".$doc_det[0]->doctor->doctor_first_name." ".$doc_det[0]->doctor->doctor_last_name.", ".$doc_det[0]->doctor->doctor_degree; 
                                    $doc_spe = $doc_det[0]->doctor->specialist_categories->speciality_name;
                                    return response()->json(['success'=>1,'message'=>'Booking added successfully.','id'=>$save_telemedical_booking_detail->booking_id,'doc_name'=>$doc_name,'doc_pic'=>$doc_det[0]->doctor->doctor_picture,'doc_spe'=>$doc_spe],200);                                
                                }
                            }   

                            if($count == 0) {
                                SaveTelemedicalBookingDetail::where('booking_id', $last_booking_row->booking_id)->update(['approved_status' => 2]);
                                return response()->json(['success'=>3,'message'=>'No doctor available just now please schedule again after some time','id'=>$save_telemedical_booking_detail->booking_id,],200);    
                            }       
                        }
                        else
                        {
                            SaveTelemedicalBookingDetail::where('booking_id', $last_booking_row->booking_id)->update(['approved_status' => 2]);
                            return response()->json(['success'=>3,'message'=>'No doctor available just now again after some time.','id'=>$save_telemedical_booking_detail->booking_id,],200);   
                        }
                    }

                return response()->json(['success'=>1,'message'=>'Booking added successfully.','id'=>$save_telemedical_booking_detail->booking_id,'telemedical_type'=>$_POST['appointment_type']],200);
            }
        }else{
            return response()->json(['success'=>0,'message'=>'You already have booking with another doctor.'],200);
        }
    }

    /******
    Billing View
    *******/
    public function billings(Request $request,$id=''){
     	if(!Auth::check()){            
        return redirect('/doctor/login');
      }

      $user = $request->user();
      $doctor_id= $user->doctor_id;
      $doctor_details = Doctor::where('doctor_id',$doctor_id)->first();
      $hospital_id =  $doctor_details->hospital_id; 
      $time_zone = $doctor_details->doctor_timezone;                 
      $dtz = new DateTimeZone($time_zone);
      $time_in_sofia = new DateTime('now', $dtz);        
      $date_offset = $time_in_sofia->format('Z');
      $start_time = strtotime(date("Y-m-d"))-$date_offset;
      $end_time = strtotime(date("Y-m-d",strtotime("+1 day")))-$date_offset;

      $today_appointment=SaveTelemedicalBookingDetail::where('doctor_id',$doctor_id)->where('save_telemedical_booking_detail.approved_status','!=',2)->where('appointment_time','>=',$start_time)->where('appointment_time','<',$end_time)->get(); 
      if($id != ''){
          $billing_count = BillingDetail::where('doctor_id',$doctor_id)->where('patient_id',$id)->orderBy('billing_date','DESC')->count();
          $outstanding_count = BillingDetail::where('doctor_id',$doctor_id)->where('patient_id',$id)->whereRaw('payable_amount-paid_amount > 0')->orderBy('billing_date','DESC')->count();
          $paid_count = BillingDetail::where('doctor_id',$doctor_id)->where('patient_id',$id)->whereRaw('payable_amount-paid_amount = 0')->orderBy('paid_date','DESC')->count();
      }else{
          $billing_count = BillingDetail::where('doctor_id',$doctor_id)->orderBy('billing_date','DESC')->count();
          $outstanding_count = BillingDetail::where('doctor_id',$doctor_id)->whereRaw('payable_amount-paid_amount > 0')->orderBy('billing_date','DESC')->count();
          $paid_count = BillingDetail::where('doctor_id',$doctor_id)->whereRaw('payable_amount-paid_amount = 0')->orderBy('paid_date','DESC')->count();
      }
      if(isset($_GET['type'])){        
        if($_GET['type'] == "all_page"){
            $page = $_GET['page'];
            $limit =20;            
        }else{
            $page = $_GET['all_page_no'];
            $limit = 20;            
        }      
        if($_GET['type'] == "out_billings"){
          $out_page = $_GET['page'];
          $limit = 20;          
        }else{
          $out_page = $_GET['out_page'];
          $limit = 20;          
        }

        if($_GET['type'] == "paid_billings"){
            $paid_page = $_GET['page'];
            $limit = 20;           
        }else{
            $paid_page = $_GET['paid_page'];
            $limit = 20;            
        }        
      }else{
          $page = 1;
          $out_page =1;
          $paid_page = 1;
          $limit = 20;          
      }
      if($id != ''){
            if(isset($_GET['sort_id'])){
            if($_GET['sort_id'] == 1){
              $billing_detail = BillingDetail::where('doctor_id',$doctor_id)->where('patient_id',$id)->orderBy('billing_date','DESC')->paginate($limit, ['*'],'page',$page);
              $outstanding_detail = BillingDetail::where('doctor_id',$doctor_id)->where('patient_id',$id)->whereRaw('payable_amount-paid_amount > 0')->orderBy('billing_date','DESC')->paginate($limit, ['*'],'page',$out_page);
              $paid_detail = BillingDetail::where('doctor_id',$doctor_id)->where('patient_id',$id)->whereRaw('payable_amount-paid_amount = 0')->orderBy('paid_date','DESC')->paginate($limit, ['*'],'page',$paid_page);
            }elseif($_GET['sort_id'] == 2){
              $billing_detail = BillingDetail::where('doctor_id',$doctor_id)->where('patient_id',$id)->orderBy('payable_amount','DESC')->paginate($limit, ['*'],'page',$page);
              $outstanding_detail = BillingDetail::where('doctor_id',$doctor_id)->where('patient_id',$id)->whereRaw('payable_amount-paid_amount > 0')->orderBy('payable_amount','DESC')->paginate($limit, ['*'],'page',$out_page);
              $paid_detail = BillingDetail::where('doctor_id',$doctor_id)->where('patient_id',$id)->whereRaw('payable_amount-paid_amount = 0')->orderBy('paid_date','DESC')->paginate($limit, ['*'],'page',$paid_page);
            }elseif($_GET['sort_id'] == 3){
              
              $billing_detail = BillingDetail::where('doctor_id',$doctor_id)->where('patient_id',$id)->orderBy('payable_amount','ASC')->paginate($limit, ['*'],'page',$page);
              $outstanding_detail = BillingDetail::where('doctor_id',$doctor_id)->where('patient_id',$id)->whereRaw('payable_amount-paid_amount > 0')->orderBy('payable_amount','ASC')->paginate($limit, ['*'],'page',$out_page);
              $paid_detail = BillingDetail::where('doctor_id',$doctor_id)->where('patient_id',$id)->whereRaw('payable_amount-paid_amount = 0')->orderBy('paid_date','ASC')->paginate($limit, ['*'],'page',$paid_page);
            }
          }else{
            $billing_detail = BillingDetail::where('doctor_id',$doctor_id)->where('patient_id',$id)->orderBy('billing_date','DESC')->paginate($limit, ['*'],'page',$page);
            $outstanding_detail = BillingDetail::where('doctor_id',$doctor_id)->where('patient_id',$id)->whereRaw('payable_amount-paid_amount > 0')->orderBy('billing_date','DESC')->paginate($limit, ['*'],'page',$out_page);
            $paid_detail = BillingDetail::where('doctor_id',$doctor_id)->where('patient_id',$id)->whereRaw('payable_amount-paid_amount = 0')->orderBy('paid_date','DESC')->paginate($limit, ['*'],'page',$paid_page);
          }
      }else{
          if(isset($_GET['sort_id'])){
            if($_GET['sort_id'] == 1){
              $billing_detail = BillingDetail::where('doctor_id',$doctor_id)->orderBy('billing_date','DESC')->paginate($limit, ['*'],'page',$page);
              $outstanding_detail = BillingDetail::where('doctor_id',$doctor_id)->whereRaw('payable_amount-paid_amount > 0')->orderBy('billing_date','DESC')->paginate($limit, ['*'],'page',$out_page);
              $paid_detail = BillingDetail::where('doctor_id',$doctor_id)->whereRaw('payable_amount-paid_amount = 0')->orderBy('paid_date','DESC')->paginate($limit, ['*'],'page',$paid_page);
            }elseif($_GET['sort_id'] == 2){
              $billing_detail = BillingDetail::where('doctor_id',$doctor_id)->orderBy('payable_amount','DESC')->paginate($limit, ['*'],'page',$page);
              $outstanding_detail = BillingDetail::where('doctor_id',$doctor_id)->whereRaw('payable_amount-paid_amount > 0')->orderBy('payable_amount','DESC')->paginate($limit, ['*'],'page',$out_page);
              $paid_detail = BillingDetail::where('doctor_id',$doctor_id)->whereRaw('payable_amount-paid_amount = 0')->orderBy('paid_date','DESC')->paginate($limit, ['*'],'page',$paid_page);
            }elseif($_GET['sort_id'] == 3){
              
              $billing_detail = BillingDetail::where('doctor_id',$doctor_id)->orderBy('payable_amount','ASC')->paginate($limit, ['*'],'page',$page);
              $outstanding_detail = BillingDetail::where('doctor_id',$doctor_id)->whereRaw('payable_amount-paid_amount > 0')->orderBy('payable_amount','ASC')->paginate($limit, ['*'],'page',$out_page);
              $paid_detail = BillingDetail::where('doctor_id',$doctor_id)->whereRaw('payable_amount-paid_amount = 0')->orderBy('paid_date','ASC')->paginate($limit, ['*'],'page',$paid_page);
            }
          }else{         
            $billing_detail = BillingDetail::where('doctor_id',$doctor_id)->orderBy('billing_date','DESC')->paginate($limit, ['*'],'page',$page);
            $outstanding_detail = BillingDetail::where('doctor_id',$doctor_id)->whereRaw('payable_amount-paid_amount > 0')->orderBy('billing_date','DESC')->paginate($limit, ['*'],'page',$out_page);
            $paid_detail = BillingDetail::where('doctor_id',$doctor_id)->whereRaw('payable_amount-paid_amount = 0')->orderBy('paid_date','DESC')->paginate($limit, ['*'],'page',$paid_page);
          }
      }

      foreach($billing_detail as $billing_det){
          BillingDetail::where('billing_id', $billing_det->billing_id)->update(['seen_status' => 1]);
      }
       $disputed_billing = BillingDetail::where('hospital_id',$hospital_id)->where('doctor_id',$doctor_id)->where('disputed',1)->orderBy('billing_date','DESC')->get();
      if($request->ajax()){
        return view('doctor.all_billings_inner')->with(array('controller'=> 'pages','doctor_details'=>$doctor_details,'timezone'=>$time_zone,'billing_detail'=>$billing_detail,'outstanding_detail'=>$outstanding_detail,'paid_detail'=>$paid_detail,'billing_count'=>$billing_count,'page_type'=>'billing','id'=>$id,"disputed_billing_count"=>$disputed_billing->count()));
      }else{
        return view('doctor.view_all_billings')->with(array('controller'=> 'pages','doctor_details'=>$doctor_details,'timezone'=>$time_zone,'billing_detail'=>$billing_detail,'outstanding_detail'=>$outstanding_detail,'paid_detail'=>$paid_detail,'billing_count'=>$billing_count,'outstanding_count'=>$outstanding_count,'paid_count'=>$paid_count,'page_type'=>'billing','id'=>$id,'today_appointments_count'=>$today_appointment->count(),"disputed_billing_count"=>$disputed_billing->count()));
      }
    }

    /******
    Dispute Billing View
    *******/
    public function disputeBillings(Request $request){
     	if(!Auth::check()){            
            return redirect('/doctor/login');
      }
      $user = $request->user();
      $doctor_id= $user->doctor_id;
      $doctor_details = Doctor::where('doctor_id',$doctor_id)->first();  
    $hospital_id =  $doctor_details->hospital_id; 
      $time_zone = $doctor_details->doctor_timezone;                 
      $dtz = new DateTimeZone($time_zone);
      $time_in_sofia = new DateTime('now', $dtz);        
      $date_offset = $time_in_sofia->format('Z');
      $start_time = strtotime(date("Y-m-d"))-$date_offset;
      $end_time = strtotime(date("Y-m-d",strtotime("+1 day")))-$date_offset;    
      $today_appointment=SaveTelemedicalBookingDetail::where('doctor_id',$doctor_id)->where('save_telemedical_booking_detail.approved_status','!=',2)->where('appointment_time','>=',$start_time)->where('appointment_time','<',$end_time)->get(); 
    //  DB::enableQueryLog();
      if(isset($_GET['page'])){
            $page = $_GET['page'];
            $limit = 20;           
        }else{
            $page = 1;
            $limit = 20;            
        }    
      $disputed_billing = BillingDetail::where('hospital_id',$hospital_id)->where('doctor_id',$doctor_id)->where('disputed',1)->orderBy('billing_date','DESC')->paginate($limit, ['*'],'page',$page);
        if($request->ajax()){
        return view('doctor.dispute_billing_inner')->with(array('controller'=> 'pages','doctor_details'=>$doctor_details,'timezone'=>$time_zone,'today_appointments_count'=>$today_appointment->count(),"disputed_billing"=>$disputed_billing,"disputed_billing_count"=>$disputed_billing->total()));
        }
        else{
        return view('doctor.dispute_billing')->with(array('controller'=> 'pages','doctor_details'=>$doctor_details,'timezone'=>$time_zone,'today_appointments_count'=>$today_appointment->count(),"disputed_billing"=>$disputed_billing,"disputed_billing_count"=>$disputed_billing->total()));
        }     

    }

    /******
    Dispute Billing Detail
    *******/
    public function disputeBillingDetail(Request $request,$id){
     	if(!Auth::check()){            
            return redirect('/doctor/login');
      }
      $user = $request->user();
      $doctor_id= $user->doctor_id;
      $doctor_details = Doctor::where('doctor_id',$doctor_id)->first();  
      $time_zone = $doctor_details->doctor_timezone;                 
      $dtz = new DateTimeZone($time_zone);
      $time_in_sofia = new DateTime('now', $dtz);        
      $date_offset = $time_in_sofia->format('Z');
      $start_time = strtotime(date("Y-m-d"))-$date_offset;
      $end_time = strtotime(date("Y-m-d",strtotime("+1 day")))-$date_offset;

      $today_appointment=SaveTelemedicalBookingDetail::where('doctor_id',$doctor_id)->where('save_telemedical_booking_detail.approved_status','!=',2)->where('appointment_time','>=',$start_time)->where('appointment_time','<',$end_time)->get(); 
      $billing_detail = BillingDetail::with(array('doctor','nurse','hospital','employee','billing_service','doctor.specialist_categories','nurse.specialist_categories','employee.specialist_categories','hospital.specialist_categories'))->where('billing_id',$id)->where('disputed',1)->first();  
      
      return view('doctor.dispute_billing_detail')->with(array('controller'=> 'pages','doctor_details'=>$doctor_details,'timezone'=>$time_zone,"billing_detail"=>$billing_detail,'today_appointments_count'=>$today_appointment->count()));
    }

    /******
    Billing Detail
    *******/
    public function billingDetail(Request $request,$id,$pid=''){
     	if(!Auth::check()){            
            return redirect('/doctor/login');
      }
      $user = $request->user();
      $doctor_id= $user->doctor_id;
      $doctor_details = Doctor::where('doctor_id',$doctor_id)->first();  
      $time_zone = $doctor_details->doctor_timezone;                 
      $dtz = new DateTimeZone($time_zone);
      $time_in_sofia = new DateTime('now', $dtz);        
      $date_offset = $time_in_sofia->format('Z');
      $start_time = strtotime(date("Y-m-d"))-$date_offset;
      $end_time = strtotime(date("Y-m-d",strtotime("+1 day")))-$date_offset;

      $today_appointment=SaveTelemedicalBookingDetail::where('doctor_id',$doctor_id)->where('save_telemedical_booking_detail.approved_status','!=',2)->where('appointment_time','>=',$start_time)->where('appointment_time','<',$end_time)->get(); 
      $billing_detail = BillingDetail::with(array('doctor','nurse','hospital','employee','billing_service','doctor.specialist_categories','nurse.specialist_categories','employee.specialist_categories','hospital.specialist_categories'))->where('billing_id',$id)->first();  
      return view('doctor.billing_detail')->with(array('controller'=> 'pages','doctor_details'=>$doctor_details,'timezone'=>$time_zone,'billing_detail'=>$billing_detail,'page_type'=>'billing','pid'=>$pid,'today_appointments_count'=>$today_appointment->count()));
    }


  /******
  Patient pay bill view
  *******/
   public function paybill(Request $request,$id){
    try{
     $value = Session::get('doctor_token');
          $doctor_id = Auth::user()->doctor_id;
          $login_token =DoctorLoginToken::where(array('doctor_id'=>$doctor_id,'login_token'=>$value))->first();        
          if(isset($login_token->token_status) && $login_token->token_status == 0){ 
              Auth::guard('doctor')->logout();           
              return response()->json(['redirect'=>1,"redirect_url"=>asset('/doctor/login')],200);
          }
          if(!Auth::check()){            
              return response()->json(['redirect'=>1,"redirect_url"=>asset('/doctor/login')],200);
          }
          $user = $request->user();            
          $doctor_details = Doctor::where('doctor_id',$doctor_id)->first();  
          $time_zone = $doctor_details->doctor_timezone;$request->user();
      $billing_detail = BillingDetail::with(array('doctor','billing_service','doctor.doctor_hospital_details','doctor.specialist_categories'))->where('billing_id',$id)->first();  
      return view('admin.paybill')->with(array('controller'=> 'pages','doctor_details'=>$doctor_details,'page'=>'billing','page_type'=>'billing','billing_detail'=>$billing_detail));
    }catch(Exception $e){
      echo 'Message: ' .$e->getMessage(); 
    }    
  }

    /******
    Pay Billing
    *******/
    public function payBilling(Request $request){
      try{  
          $value = Session::get('doctor_token');
          $doctor_id = Auth::user()->doctor_id;
          $login_token =DoctorLoginToken::where(array('doctor_id'=>$doctor_id,'login_token'=>$value))->first();        
          if(isset($login_token->token_status) && $login_token->token_status == 0){ 
              Auth::guard('doctor')->logout();           
              return response()->json(['redirect'=>1,"redirect_url"=>asset('/doctor/login')],200);
          }
          if(!Auth::check()){            
              return response()->json(['redirect'=>1,"redirect_url"=>asset('/doctor/login')],200);
          }
          $user = $request->user();            
          $doctor_details = Doctor::where('doctor_id',$doctor_id)->first();  
         $time_zone = $doctor_details->doctor_timezone;             
          $dtz = new DateTimeZone($time_zone);     
          $date = date('Y-m-d H:i:s',strtotime("now"));                   
          $time_in_sofia = new DateTime($date, $dtz);        
          $date_offset = $time_in_sofia->format('Z');       
          $billing_time = strtotime($date)-$date_offset;  
          DB::enableQueryLog();
          $PayBilling = new PaidBillingDetail([
              'transaction_id'  => $_POST['transaction_id'],
              'billing_id'      => $_POST['billing_id'],
              'patient_id'      => $_POST['patient_id'],
              'doctor_id'       => $doctor_id,             
              'created_date'    => strtotime("now")                       
          ]); 

          $PayBilling->save();        
          $update_amt = BillingDetail::where('billing_id',$_POST['billing_id'])->update(['paid_amount'=>DB::raw('paid_amount + '.$_POST['amt']),'cash_card'=>"card","paid_date"=>$billing_time]);
           $UserNotification = new UserNotification([                
              'notification_id'   => $this->generateNUniqueNumber(),              
              'assignee_type'     => 4,                    
              'patient_id'        => $_POST['patient_id'], 
              'event_id'          => $_POST['billing_id'],
              'notification_type' => "bill",
              'change_type'       => "paid",
              'created_date'      => strtotime('now'),
              'status'            => 0                                          
          ]);
          $UserNotification->save();

          $login_token = PatientLoginToken::where('patient_id',$_POST['patient_id'])->where('token_status',1)->get();
          $msg = "You paid a bill"; 
          
          if(count($login_token) > 0 && $login_token[0]->device_type != 2){            
              $device_token = $login_token[0]->device_token;
              $path = base_path()."/ios_notifcation/all_notifications.php";                            
              $nid = $_POST['billing_id'];
              $type= 'bill';
              exec ('php '.$path.' "'.$msg.'" '.$nid.' '.$type.' '.$device_token.' > /dev/null &');
          }

          $url = url('/patient/send_mail/'.str_replace(" ", "_", $msg).'/'.$_POST['patient_id'].'');   
          $cmd  = "curl --max-time 60 ";   
          $cmd .= "'" . $url . "'";   
          $cmd .= " > /dev/null 2>&1 &";    
          exec($cmd, $output, $exit); 
           //print_r(DB::connection('mysql')->getQueryLog());
          return response()->json(['success'=>1,'message'=>'Bill paid successfully.','data'=>$_POST['transaction_id']],200);

      }catch(Exception $e) {
            return response()->json(['error'=>1,"message"=>$e->getMessage()],200);       
      } 
    }
// Pay billing by cash
       public function payBillingCash(Request $request){ 
            try{             
         $value = Session::get('doctor_token');
          $doctor_id = Auth::user()->doctor_id;
          $login_token =DoctorLoginToken::where(array('doctor_id'=>$doctor_id,'login_token'=>$value))->first();        
          if(isset($login_token->token_status) && $login_token->token_status == 0){ 
              Auth::guard('doctor')->logout();           
              return response()->json(['redirect'=>1,"redirect_url"=>asset('/doctor/login')],200);
          }
          if(!Auth::check()){            
              return response()->json(['redirect'=>1,"redirect_url"=>asset('/doctor/login')],200);
          }
          $user = $request->user();            
          $doctor_details = Doctor::where('doctor_id',$doctor_id)->first();  
          $time_zone = $doctor_details->doctor_timezone;             
          $dtz = new DateTimeZone($time_zone);     
          $date = date('Y-m-d H:i:s',strtotime("now"));                   
          $time_in_sofia = new DateTime($date, $dtz);        
          $date_offset = $time_in_sofia->format('Z');       
          $billing_time = strtotime($date)-$date_offset;  
          //DB::enableQueryLog();
          $update_amt = BillingDetail::where('billing_id',$_POST['billing_id'])->update(['paid_amount'=> DB::raw('paid_amount + '.$_POST['amt']),'paid_date'=>$billing_time,'cash_card'=>"cash"]);
         //print_r(DB::connection('mysql')->getQueryLog());
          $UserNotification = new UserNotification([                
              'notification_id'   => $this->generateNUniqueNumber(),              
              'assignee_type'     => 4,                    
              'patient_id'        => $_POST['patient_id'], 
              'event_id'          => $_POST['billing_id'],
              'notification_type' => "bill",
              'change_type'       => "paid",
              'created_date'      => strtotime('now'),
              'status'            => 0                                          
          ]);
          $UserNotification->save();

          $login_token = PatientLoginToken::where('patient_id',$_POST['patient_id'])->where('token_status',1)->get();
          $msg = "You paid a bill"; 
          
          if(count($login_token) > 0 && $login_token[0]->device_type != 2){            
              $device_token = $login_token[0]->device_token;
              $path = base_path()."/ios_notifcation/all_notifications.php";                            
              $nid = $_POST['billing_id'];
              $type= 'bill';
              exec ('php '.$path.' "'.$msg.'" '.$nid.' '.$type.' '.$device_token.' > /dev/null &');
          }

          $url = url('/patient/send_mail/'.str_replace(" ", "_", $msg).'/'.$_POST['patient_id'].'');   
          $cmd  = "curl --max-time 60 ";   
          $cmd .= "'" . $url . "'";   
          $cmd .= " > /dev/null 2>&1 &";    
          exec($cmd, $output, $exit); 

          return response()->json(['success'=>1,"message"=>"Bill paid successfully"],200);

        }catch(Exception $e) {
            return response()->json(['error'=>1,"message"=>$e->getMessage()],200);       
        }

       }




    /******
    Doctor Settings
    *******/
    public function settings(Request $request){
     	if(!Auth::check()){            
            return redirect('/doctor/login');
      }
      $user = $request->user();
      $doctor_id= $user->doctor_id;
      $doctor_details = Doctor::where('doctor_id',$doctor_id)->first();  
      $time_zone = $doctor_details->doctor_timezone;                 
      $dtz = new DateTimeZone($time_zone);
      $time_in_sofia = new DateTime('now', $dtz);        
      $date_offset = $time_in_sofia->format('Z');
      $start_time = strtotime(date("Y-m-d"))-$date_offset;
      $end_time = strtotime(date("Y-m-d",strtotime("+1 day")))-$date_offset;
      $speciality = Speciality::where('id',$doctor_details->doctor_speciality)->first();
      $hospital = Hospital::where('hosp_id',$doctor_details->hospital_id)->first();
      $today_appointment=SaveTelemedicalBookingDetail::where('doctor_id',$doctor_id)->where('save_telemedical_booking_detail.approved_status','!=',2)->where('appointment_time','>=',$start_time)->where('appointment_time','<',$end_time)->get(); 
    $disputed_billing = BillingDetail::where('doctor_id',$doctor_id)->where('disputed',1)->orderBy('billing_date','DESC');
      return view('doctor.settings')->with(array('controller'=> 'pages','doctor_details'=>$doctor_details,'timezone'=>$time_zone,'page_type'=>'settings','today_appointments_count'=>$today_appointment->count(),'speciality'=>$speciality,'hospital'=>$hospital,'disputed_billing_count'=>$disputed_billing->count()));
    }

    private function commoncurl($url,$post_data){
        $ch1 = curl_init();       
        curl_setopt($ch1, CURLOPT_URL,$url);
        curl_setopt($ch1, CURLOPT_HEADER, 0);
        curl_setopt($ch1, CURLOPT_POST, 1);
        curl_setopt($ch1, CURLOPT_POSTFIELDS, $post_data);  
        curl_setopt($ch1, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch1, CURLOPT_SSL_VERIFYPEER, 0);
        $output = curl_exec($ch1);  
        //echo "<pre>"; print_R($output);     
        curl_close ($ch1);
        $output= json_decode($output,true);
        
        return $output;
    }

    protected function generateAUniqueNumber() {
        $number = mt_rand(1000000000, 9999999999); // better than rand()
        // call the same function if the uniwue id exists already
        if ($this->uniqueANumberExists($number)) {
            return $this->generateAUniqueNumber();
        }
        // otherwise, it's valid and can be used
        return strval($number);
    }

    protected function uniqueANumberExists($number) {
        // query the database and return a boolean       
        return PatientAppointment::whereappointment_id($number)->exists();
    }

    protected function generateBUniqueNumber() {
        $number = mt_rand(1000000000, 9999999999); // better than rand()
        // call the same function if the uniwue id exists already
        if ($this->uniqueBNumberExists($number)) {
            return $this->generateBUniqueNumber();
        }
        // otherwise, it's valid and can be used
        return strval($number);
    }

    protected function uniqueBNumberExists($number) {
        // query the database and return a boolean       
        return SaveTelemedicalBookingDetail::wherebooking_id($number)->exists();
    }

    protected function generateNUniqueNumber() {
        $number = mt_rand(1000000000, 9999999999); // better than rand()
        // call the same function if the uniwue id exists already
        if ($this->uniqueNNumberExists($number)) {
            return $this->generateNUniqueNumber();
        }
        // otherwise, it's valid and can be used
        return strval($number);
    }

    protected function uniqueNNumberExists($number) {
        // query the database and return a boolean         
        return UserNotification::wherenotification_id($number)->exists();
    }
    /*  public function healthDiary(Request $request){


      if(!Auth::check()){            
            return redirect('/doctor/login');
        }
        $user = $request->user();
        return view('patien.health_diary')->with(array('controller'=> 'pages','user'=>$user,'page'=>'dashboard','page_type'=>'extra_links'));
     }*/
// make billing dispute
     public function AddBillingDispute(Request $request){
            try
        {   
            if(!Auth::check()){            
            return redirect('/doctor/login');
            }   
           
            $billing_id = isset($request->billing_id) ? $request->billing_id:'0'; 
             $dispute = isset($request->dispute) ? $request->dispute:'';   
               // DB::enableQueryLog();
                BillingDetail::where('billing_id', $billing_id)->update(['disputed' => $dispute]);
               // print_r(DB::connection('mysql')->getQueryLog());
            return response()->json(['success'=>1,"message"=>"success"],200);
        }
        catch(Exception $e)
        {
            return response()->json(['error'=>1,"message"=>$e->getMessage()],200);   
        }
     }

     // Send messsage to user
      private function sendMessage($message, $recipients)
        {
        $account_sid = getenv("TWILIO_SID");
        $auth_token = getenv("TWILIO_AUTH_TOKEN");
        $twilio_number = getenv("TWILIO_NUMBER");
        $client = new Client($account_sid, $auth_token);

       /* $validation_request = $client->validationRequests
        ->create($recipients, // phoneNumber
        array(
        "friendlyName" => "Newuser"
        )
        );
        print($validation_request);
        if(!empty($validation_request->friendlyName)){*/
        $client->messages->create($recipients, ['from' => $twilio_number, 'body' => $message]);
  // }
       return 1;
    }
            protected function appointment_message($booking_id,$patient_id,$doctor_id,$type){
            $message="";
            if($type==2){
            $app="hospital";
            }else{
            $app="telemedical";
            }
              $patient_detail = Patient::where('patient_unique_id',$patient_id)->first();
            $patient_first_name = $patient_detail->patient_first_name;
            $patient_timezone = Auth::user()->doctor_timezone;
            $doc_det = SaveTelemedicalBookingDetail::with('doctor','doctor.specialist_categories')->where('booking_id', $booking_id)->get();
            date_default_timezone_set($patient_timezone);          
            $date1=date("F d, Y",$doc_det[0]['appointment_time']);
            $time_of= date("g:i A",$doc_det[0]['appointment_time']);
            $doctor_details = Doctor::where('doctor_id',$doctor_id)->first();
            $message="Hello ".$patient_first_name.", \n ";
            $message.="Your new ".$app." appointment is scheduled.\n ";
            $message.="Here are the details:\n ";
            if(!empty($doctor_details)){
            $message.="Doctor: Dr.".$doctor_details->doctor_first_name." ".$doctor_details->doctor_last_name." \n ";
            }
            $message.="Date: ".$date1." \n ";
            $message.="Time: ". $time_of." \n ";
            $message.="For any queries, you can contact us at: contact@renderhealth.com \n ";  
            return $message;
            }
             /******
  Patient update profile
  *******/
  public function profile(Request $request){
    try{
      
        $value = Session::get('doctor_token');
          $doctor_id = Auth::user()->doctor_id;
          $login_token =DoctorLoginToken::where(array('doctor_id'=>$doctor_id,'login_token'=>$value))->first();        
          if(isset($login_token->token_status) && $login_token->token_status == 0){ 
              Auth::guard('doctor')->logout();           
              return response()->json(['redirect'=>1,"redirect_url"=>asset('/doctor/login')],200);
          }
          if(!Auth::check()){            
              return response()->json(['redirect'=>1,"redirect_url"=>asset('/doctor/login')],200);
          }
      $image = $request->file('images');
      $validator = Validator::make($request->all(),[
        'doctor_email'=>'required',
        'doctor_phone'=>'required',
        'biography'=>'required',
        'images'=>'image|max:2000'
        ], [
          'images.max' => 'Image size should be as less then 2 Mb',
        ]);

      if($validator->fails()){
          return response()->json(['success'=>0, 'message'=>$validator->messages()->first()], 200);
      }else{
        if(isset($image)){
          $image = time().'.'.$image->getClientOriginalExtension();
          $destinationPath = public_path().'/doctorimages';
          $request->file('images')->move($destinationPath, $image);
          Doctor::where('id', $request->input('profile_id'))->update([        
          'doctor_email'      => $request->input('doctor_email'),
          'doctor_phone'      => $request->input('doctor_phone'),
          'biography'       => $request->input('biography'),
          'doctor_picture'     =>$image
          ]);
        }else{
            Doctor::where('id', $request->input('profile_id'))->update([        
            'doctor_email'      => $request->input('doctor_email'),
            'doctor_phone'      => $request->input('doctor_phone'),
            'biography'       => $request->input('biography'),
          ]);
        }
        //return response()->json(['success'=>'your data submited']);
         return response()->json(['success'=>1,'message'=>'Your information has been updated successfully!']);
        }
    }catch(Exception $e){
      return response()->json(['error'=>1,"message"=>$e->getMessage()],200);       
    }      
  }
  }
  
