<?php
namespace App\Http\Controllers\Doctor;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Auth;
use DB;
use Validator;
use Redirect;
use DateTime;
use DateTimeZone;
use Session;
use Mail;
use App\Models\SaveTelemedicalBookingDetail;
use App\Models\Patient;
use App\Models\BillingDetail;
use App\Models\Hospital;
use App\Models\Doctor;
use App\Models\DoctorLoginToken;
use App\Models\PatientLoginToken;
use App\Models\PaidBillingDetail;
use App\Models\PatientAppointment;
use App\Models\SpecialistCategories;
use Illuminate\Pagination\LengthAwarePaginator;
use Illuminate\Support\Facades\Input;
use App\Models\UserNotification;
use App\Models\PatientNotificationSetting;
use App\Models\DoctorAvailability;
use App\Models\PatientHealthDiary;
use App\Models\PatientsDependent;
use App\Models\PossibleDiagnosis;
use App\Models\HealthHistory;
use Twilio\Rest\Client;
use App\Models\StatesNigeria;
use App\Models\Nurse;
use App\Models\Administrator;
class PatientsController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
   
    public function __construct()
    {
        $this->middleware('auth:doctor');
        if(!Auth::check()){            
            return redirect('/doctor/login');
        }
    }

    public function CheckValidPath()
    {
        $value = Session::get('doctor_token');
        $doctor_id = Auth::user()->doctor_id;
        $login_token =DoctorLoginToken::where(array('doctor_id'=>$doctor_id,'login_token'=>$value))->first();        
        if(isset($login_token->token_status) && $login_token->token_status == 0){ 
            Auth::guard('doctor')->logout(); 
            if($request->ajax()){ 
                 return response()->json(['redirect'=>1,"redirect_url"=>asset('/doctor/login')],200); 
            }else{        
                return redirect('/doctor/login');
            }
        }
        if(!Auth::check()){  
            if($request->ajax()){ 
                 return response()->json(['redirect'=>1,"redirect_url"=>asset('/doctor/login')],200); 
            }else{          
                return redirect('/doctor/login');
            }
        }
    }
    /** telemedical appoinment section*/
    public function index(Request $request,$time=""){ 
        $this->CheckValidPath();
        $user = $request->user();
        $doctor_id= $user->doctor_id;
        $doctor_details = Doctor::where('doctor_id',$doctor_id)->first();
        //get pagination params
        if(isset($_GET['type'])){        
            if($_GET['type'] == "mem_page"){
                $mem_page = $_GET['page'];
                $limit = 20;            
            }
        }else{
          $mem_page = 1;
          $limit = 20;          
        }

        //get all patients
        $all_patients = Patient::where(['patient_visited_hospital' => $doctor_details->hospital_id]);
        
        if(isset($_GET['patient_name']) && $_GET['patient_name'] != ''){
            $all_patients = $all_patients->where('patient_first_name', 'like', '%' . $_GET['patient_name'] . '%');
        }
        
        if(isset($_GET['patient_surname']) && $_GET['patient_surname'] != ''){
            $all_patients = $all_patients->where('patient_last_name', 'like', '%' . $_GET['patient_surname'] . '%');
        }

        if(isset($_GET['patient_dob']) && $_GET['patient_dob'] != '' ){
            $date = strtotime($_GET['patient_dob']);
            $all_patients = $all_patients->where(['patient_date_of_birth' => $date]);
        }

        if(isset($_GET['patient_recno']) && $_GET['patient_recno'] != '' ){
            $all_patients = $all_patients->where(['patient_unique_id' => $_GET['patient_recno']]);
        }

        $all_patients = $all_patients->orderBy('patients.id', 'desc')->paginate($limit, ['*'],'page',$mem_page);
        $hospitals = Hospital::get();
        
        $statesNigeria = StatesNigeria::all();
        if($request->ajax()){
            return view('doctor.patients.index_ajax')->with(array('doctor_details'=>$doctor_details,'all_patients'=>$all_patients,'statesNigeria'=>$statesNigeria));
        }else{
            return view('doctor.patients.index')->with(array('doctor_details'=>$doctor_details,'all_patients'=>$all_patients,'statesNigeria'=>$statesNigeria));
        }
    }

    // Create new patient
    public function create(Request $request)
    {
        try
        { 
            $this->CheckValidPath();
            $user = $request->user();
            $doctor_id= $user->doctor_id;
            $doctor_details = Doctor::where('doctor_id',$doctor_id)->first();

            $unique_number = mt_rand(1000000000, 9999999999); 
            $patient_address = isset($request->patient_address) ? $request->patient_address:'';
            $patient_gender = isset($request->patient_gender) ? $request->patient_gender:'';
            $patient_martial_status = isset($request->patient_martial_status) ? $request->patient_martial_status:'';
            $patient_origin_state = isset($request->patient_origin_state) ? $request->patient_origin_state:'';
            $patient_blood_type = isset($request->patient_blood_type) ? $request->patient_blood_type:'';
            $religion = isset($request->religion) ? $request->religion:'';
            $patient_languages = isset($request->languages) ? $request->languages:'';
            $patient_insurance = isset($request->patient_insurance) ? $request->patient_insurance:'';
            $patient_visited_hospital = isset($doctor_details->hospital_id) ? $doctor_details->hospital_id:'';
            $next_first_name = isset($request->next_first_name) ? $request->next_first_name:'';
            $next_surname = isset($request->next_surname) ? $request->next_surname:'';
            $next_phone = isset($request->next_phone) ? $request->next_phone:'';
            $member_username = isset($request->patient_username) ? $request->patient_username:'';
            $patient_first_name = isset($request->patient_first_name) ? $request->patient_first_name:'';
            $patient_middle_name = isset($request->patient_middle_name) ? $request->patient_middle_name:'';
            $patient_last_name = isset($request->patient_last_name) ? $request->patient_last_name:'';
            $patient_email = isset($request->patient_email) ? $request->patient_email:'';
            $patient_phone = isset($request->patient_phone) ? $request->patient_phone:'';
            $patient_password = isset($request->patient_password) ? $request->patient_password:'';
            $patient_state = isset($request->patient_state) ? $request->patient_state:'';
            $lga = isset($request->lga) ? $request->lga:'';
            $patient_city = isset($request->patient_city) ? $request->patient_city:'';
            $unique_number = $unique_number;
            $date = $request->day;
            $month =$request->month;
            $month = date('m',strtotime($month));
            $year = $request->years;
            $patient_dob = $year.'-'.$month.'-'.$date;     
            //check for existing employee 
            $member_id = Patient::where('patient_unique_id',$unique_number)->count();

            if($member_id > 0){
                return response()->json(['error'=>1,"message"=>"Member/Patient already exists."],200); 
            }else{
                //save details in Member/Patient table
                $member = new Patient([
                'patient_address' => $patient_address,
                'patient_gender' => $patient_gender,
                'patient_martial_status' => $patient_martial_status,
                'patient_origin_state' => $patient_origin_state,
                'patient_blood_type' => $patient_blood_type,
                'religion' => $religion,
                'patient_languages' => $patient_languages,
                'patient_insurance' => $patient_insurance,
                'patient_visited_hospital' => $patient_visited_hospital,
                'next_first_name' => $next_first_name,
                'next_surname' => $next_surname,
                'next_phone' => $next_phone,
                'patient_unique_id' => $unique_number,
                'patient_username' => $member_username,
                'patient_password' => bcrypt($patient_password),
                'patient_first_name' => $patient_first_name,
                'patient_middle_name' => $patient_middle_name,
                'patient_last_name' => $patient_last_name,
                'patient_email' => $patient_email,
                'patient_phone' => $patient_phone,
                'patient_date_of_birth' => strtotime($patient_dob),
                'doctor_timezone' => date_default_timezone_get(),
                'patient_state' => $patient_state,
                'lga' => $lga,
                'patient_city' => $patient_city,
                'created_at'=> strtotime("now") ,                  
                ]); 
                
                $member->save();
                //dependent table
                foreach($request->dependentname as $name => $valname){
                    $array[$name]['name'] = $valname;
                }
                foreach($request->dependentday as $day => $valday){
                    $array[$day]['day'] = $valday;
                }
                foreach($request->dependentmonth as $month => $valmonth){
                    $array[$month]['month'] = $valmonth;
                }
                foreach($request->dependentyears as $years => $valyears){
                    $array[$years]['years'] = $valyears;
                }
                foreach($request->dependentrelationship as $relationship => $valrelationship){
                    $array[$relationship]['relationship'] = $valrelationship;
                }

                // $array['patients_id'] = 123;
                foreach($array as $key => $value){
                    $value['patients_id'] = $member->id;
                    $PatientsDependent = new PatientsDependent($value); 
                    $PatientsDependent->save();
                }

                $send_email_from = isset($_ENV['send_email_from'])?$_ENV['send_email_from']:"";
                $get_email = Patient::select('patient_first_name','patient_middle_name','patient_last_name','patient_email')->where('patient_unique_id',$unique_number)->get();
                $data = array('name'=>$get_email[0]->patient_first_name,'email'=>$get_email[0]->patient_email,'password'=>$_POST['patient_password'],"type"=>"patient");    
                $email =$get_email[0]->patient_email;
                $res = Mail::send('admin.signupemail1', $data, function ($message) use ($email,$send_email_from)  {
                $message->to($email)->subject('Account Registration');
                if($send_email_from!=''){ 
                    $message->from($send_email_from,'Render Health');
                }              
                });

                // Send message on phone
                $message= $this->registrationmessage($unique_number,4);
                // $this->sendMessage($message,$patient_phone ? $patient_phone : '+918699499852'); 

                return response()->json(['success'=>1,'message'=>'Member added successfully.'],200);
            }
        }
        catch(Exception $e)
        {
            return response()->json(['error'=>1,"message"=>$e->getMessage()],200);   
        }
    }
    private function sendMessage($message, $recipients)
        {
        $account_sid = getenv("TWILIO_SID");
        $auth_token = getenv("TWILIO_AUTH_TOKEN");
        $twilio_number = getenv("TWILIO_NUMBER");
        $client = new Client($account_sid, $auth_token);

       /* $validation_request = $client->validationRequests
        ->create($recipients, // phoneNumber
        array(
        "friendlyName" => "Newuser"
        )
        );
        print($validation_request);
        if(!empty($validation_request->friendlyName)){*/
        $client->messages->create($recipients, ['from' => $twilio_number, 'body' => $message]);
  // }
       return 1;
    }
    protected function registrationmessage($id,$type){
        $message="";
            if($type==1){
            $get_email = Doctor::select('doctor_email','doctor_first_name','doctor_last_name','doctor_password')->where('doctor_id',$id)->get();
            $email=$get_email[0]->doctor_email;
            }
            elseif($type==2){
            $get_email = Nurse::select('nurse_email','nurse_first_name','nurse_last_name','nurse_password')->where('nurse_id',$id)->get();
            $email=$get_email[0]->nurse_email;
            }
            elseif($type==3){
            $get_email = Administrator::select('administrator_email','administrator_name','administrator_password')->where('admin_id',$id)->get();
            $email=$get_email[0]->administrator_email;
            }
            elseif($type==4){
           $get_email = Patient::select('patient_first_name','patient_middle_name','patient_last_name','patient_email')->where('patient_unique_id',$id)->get();
            $email=$get_email[0]->patient_email;
            }
         
        if(!empty($id)){
        $message="Thank you for registering with Render Health \n";
        $message.= "Here are your details:\n";
        $message.= "Email: ".$email."\n";
        $message.= "Password: as chosen by you at the time of registration \n";
        $message.= "For any queries you can contact us at: contact@renderhealth.com \n";
        return $message;
    }
    }

    // Get information
    public function show(Request $request)
    {

    }

    // Update information
    public function edit(Request $request)
    {

    }

    public function medicalRecordList(Request $request,$id)
    {    
        $this->CheckValidPath();
        $user = $request->user();
        $doctor_id= $user->doctor_id;
        $doctor_details = Doctor::where('doctor_id',$doctor_id)->first();
        $health_history = HealthHistory::with(array('patient','doctor','history_attachments','doctor.doctor_hospital_details','nurse.nurse_hospital_details','employee.employee_hospital_details'))->where('patient_id',$id)->orderBy('created_date','DESC')->paginate(20);  
        $patient_details = Patient::where('patient_unique_id',$id)->first();
        if($request->ajax()){
            return view('doctor.patients.history_inner')->with(array('health_history' => $health_history,'page' => 'inner','doctor_details' => $doctor_details,'page_type' => 'health_history','patient_detail' => $patient_details)); 
        }else{        
            return view('doctor.patients.medical_record')->with(array('health_history' => $health_history,'page' => 'inner','doctor_details' => $doctor_details,'page_type' => 'health_history','patient_detail' => $patient_details)); 
        }    
    }

    public function addRecord(Request $request,$id)
    {    
        $this->CheckValidPath();
        $user = $request->user();
        $doctor_id= $user->doctor_id;
        $doctor_details = Doctor::where('doctor_id',$doctor_id)->first();
        $hospital_details = Hospital::all();
        $patient_details = Patient::where('patient_unique_id',$id)->first();
        $possibleDiagnosis = PossibleDiagnosis::get();
        return view('doctor.patients.add_medical_record')->with(array('doctor_details'=>$doctor_details,'patient_detail'=>$patient_details,
        'patient_id'=>$id,"hospital_details"=>$hospital_details,'possibleDiagnosis'=>$possibleDiagnosis));    
        
    }


    public function editRecord(Request $request,$id)
    {    
        $this->CheckValidPath();
        $user = $request->user();
        $doctor_id= $user->doctor_id;
        $doctor_details = Doctor::where('doctor_id',$doctor_id)->first();
        $possibleDiagnosis = PossibleDiagnosis::get();
        $health_history=HealthHistory::with(array('patient','doctor','history_attachments','doctor_update'))->where('health_history.history_id',$id)->first();
        return view('admin.edit_medical_record')->with(array('controller'=> 'admin','page'=>'inner','page_type'=>'appointments','health_history'=>$health_history,'admin_details'=>$admin_details,'possibleDiagnosis'=>$possibleDiagnosis));    
        
    }

    public function viewRecord(Request $request,$id)
    {    

        $value = Session::get('doctor_token');
        $doctor_id = Auth::user()->doctor_id;
        $login_token =DoctorLoginToken::where(array('doctor_id'=>$doctor_id,'login_token'=>$value))->first();        
        if(isset($login_token->token_status) && $login_token->token_status == 0){ 
            Auth::guard('doctor')->logout();           
            return redirect('/doctor/login');
        }
        if(!Auth::check()){            
            return redirect('/doctor/login');
        }
        $user = $request->user();
        $doctor_id= $user->doctor_id;
        $doctor_details = Doctor::where('doctor_id',$doctor_id)->first();  
        $time_zone = $doctor_details->doctor_timezone;                 
        $dtz = new DateTimeZone($time_zone);
        $time_in_sofia = new DateTime('now', $dtz);        
        $date_offset = $time_in_sofia->format('Z');
        $start_time = strtotime(date("Y-m-d"))-$date_offset;
        $end_time = strtotime(date("Y-m-d",strtotime("+1 day")))-$date_offset;    

        $today_appointment=SaveTelemedicalBookingDetail::where('doctor_id',$doctor_id)->where('save_telemedical_booking_detail.approved_status','!=',2)->where('appointment_time','>=',$start_time)->where('appointment_time','<',$end_time)->get();
        $health_history=HealthHistory::with(array('patient','doctor','history_attachments','doctor_update','history_medication','hospital'))->where('health_history.history_id',$id)->first();

        $billing_detail = BillingDetail::where('patient_id',$health_history->patient->patient_unique_id)->where('history_id',$id)->orderBy('billing_date','DESC')->paginate(5);
        if($request->ajax()){
            return view('doctor.health_history_bill_inner')->with(array('controller'=> 'doctor','page'=>'inner','doctor_details'=>$doctor_details,'timezone'=>$time_zone,'page_type'=>'health_history','health_history'=>$health_history,'billing_detail'=>$billing_detail)); 
        }else{
            return view('doctor.view_medical_record')->with(array('controller'=> 'doctor','page'=>'inner','doctor_details'=>$doctor_details,'timezone'=>$time_zone,'page_type'=>'health_history','health_history'=>$health_history,'billing_detail'=>$billing_detail,'today_appointments_count'=>$today_appointment->count())); 
        }
    }
  }
  
