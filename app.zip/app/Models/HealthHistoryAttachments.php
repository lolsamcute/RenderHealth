<?php
namespace App\Models;

use Illuminate\Database\Eloquent\Model;


class HealthHistoryAttachments extends Model
{       
    protected $table = 'health_history_attachments';

    public $timestamps = false;

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'patient_attachment_id', 'patient_history_id', 'patient_id', 'patient_lab_name','attachment_type','patient_attachment_name','type','created_at'];

    /**
     * The attributes that should be hidden for arrays.
     *
     * @var array
     */
    protected $hidden = [
        'id', 
    ];

    public function health_history()
    {
        return $this->belongsTo('App\Models\HealthHistory','patient_history_id','history_id');

    }  
    
}
