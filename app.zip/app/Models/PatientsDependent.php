<?php
namespace App\Models;
use Illuminate\Notifications\Notifiable;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Laravel\Passport\HasApiTokens;

class PatientsDependent extends Authenticatable
{   
     use HasApiTokens, Notifiable;
    protected $guard = 'patients_dependents';

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    public $timestamps = false;
    protected $fillable = ['name','dob','day','month','years','relationship','patients_id','created_at'];

    /**
     * The attributes that should be hidden for arrays.
     *
     * @var array
     */
    
}
