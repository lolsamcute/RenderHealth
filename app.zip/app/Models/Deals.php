<?php
namespace App\Models;
use Illuminate\Notifications\Notifiable;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Laravel\Passport\HasApiTokens;

class Deals extends Authenticatable
{   
    use HasApiTokens, Notifiable;
    protected $guard = 'deals';

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    public $timestamps = false;

    protected $fillable = [
        'facility_id', 
        'category_id', 
        'dob', 
        'start_date', 
        'end_date', 
        'title', 
        'previous_price', 
        'current_price', 
        'details', 
        'restriction', 
        'about_us', 
        'read_term_condition', 
        'status', 
        'is_deleted',
        'created_at',
        'updated_at',
        'image', 
    ];

    public function facility_details()
    {
        return $this->belongsTo('App\Models\Hospital','facility_id','id');
    }

    public function categories_details()
    {
        return $this->belongsTo('App\Models\DealCategories','category_id','id');
    }
}
