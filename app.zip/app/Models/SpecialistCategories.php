<?php
namespace App\Models;

use Illuminate\Database\Eloquent\Model;


class SpecialistCategories extends Model
{       
    protected $table = 'speciality_categories';

    public $timestamps = false;

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'speciality_id ', 'speciality_name'];

    /**
     * The attributes that should be hidden for arrays.
     *
     * @var array
     */
    protected $hidden = [
        'id',
    ];

    public function doctor()
    {
        return $this->hasMany('App\Models\Doctor','speciality_id','doctor_speciality');
    }
}
