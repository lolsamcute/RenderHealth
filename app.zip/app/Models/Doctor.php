<?php
namespace App\Models;
use Illuminate\Notifications\Notifiable;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Laravel\Passport\HasApiTokens;


class Doctor extends Authenticatable
{   
     use HasApiTokens, Notifiable;
    protected $guard = 'doctor';

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    public $timestamps = false;
    protected $fillable = [
        'doctor_id', 'doctor_password', 'hospital_id', 'doctor_first_name', 'doctor_last_name', 'doctor_email', 'doctor_picture', 'doctor_hospital_name', 'doctor_education_school', 'doctor_degree', 'doctor_speciality', 'doctor_languages', 'doctor_religion', 'doctor_ethnicity', 'doctor_years_practised','doctor_tokbox_id ',' doctor_tokbox_token ','doctor_created_date','doctor_state','doctor_country','doctor_phone','folio_number','doctor_info','active_status','doctor_timezone','access_to_hospital','access_to_patient_record','telemedical','doctor_gender','marital_status','doctor_title','doctor_middle_name','doctor_role','biography','doctor_username','doctor_dob','doctor_city','doctor_address','lga','doctor_access'];

    /**
     * The attributes that should be hidden for arrays.
     *
     * @var array
     */
    protected $hidden = [
        'id', 'doctor_created_date',
    ];

    public function getAuthPassword()
    {
        return $this->doctor_password;
    }

    public function doctor_availability()
    {
        return $this->hasMany('App\Models\DoctorAvailability','doctor_id','doctor_id');
    }

    public function doctor_tele_booking()
    {
        return $this->hasMany('App\Models\SaveTelemedicalBookingDetail','doctor_id','doctor_id');
    }

    public function specialist_categories()
    {
        return $this->belongsTo('App\Models\SpecialistCategories','doctor_speciality','speciality_id');
    }

    public function doctor_hospital_details()
    {
        return $this->belongsTo('App\Models\Hospital','hospital_id','hosp_id');
    }
}
