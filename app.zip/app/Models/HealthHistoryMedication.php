<?php
namespace App\Models;

use Illuminate\Database\Eloquent\Model;


class HealthHistoryMedication extends Model
{       
    protected $table = 'health_history_medications';

    public $timestamps = false;

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'health_history_id', 'doctor_id', 'patient_id', 'medi_name','medi_type','medi_procedure','quantity','created_date'];

    /**
     * The attributes that should be hidden for arrays.
     *
     * @var array
     */
    protected $hidden = [
        
    ];

    public function health_history()
    {
        return $this->belongsTo('App\Models\HealthHistory','health_history_id','history_id');

    }  
    
}
