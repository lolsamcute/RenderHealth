<?php
namespace App\Models;

use Illuminate\Database\Eloquent\Model;


class BillingDetail extends Model
{       
    protected $table = 'billing_details';

    public $timestamps = false;

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'billing_id', 'billing_date', 'patient_id','doctor_id','nurse_id','employee_id','hospital_id','assignee_type','history_id','invoice_number','payable_amount','paid_amount','seen_status','paid_date'];

    /**
     * The attributes that should be hidden for arrays.
     *
     * @var array
     */
    protected $hidden = [
        'id'
    ];    

    public function doctor()
    {
        return $this->belongsTo('App\Models\Doctor','doctor_id','doctor_id');
    }

    public function nurse()
    {
        return $this->belongsTo('App\Models\Nurse','nurse_id','nurse_id');
    }

    public function employee()
    {
        return $this->belongsTo('App\Models\Employee','employee_id','employee_id');
    }
    
    public function hospital()
    {
        return $this->belongsTo('App\Models\Hospital','hospital_id','hosp_id');
    }  

    public function patient(){
        return $this->belongsTo('App\Models\Patient','patient_id','patient_unique_id');
    }

    public function billing_service(){
        return $this->hasMany('App\Models\BillingService','pbilling_id','billing_id');
    }

    public function paid_billing(){
        return $this->hasOne('App\Models\PaidBillingDetail','billing_id','billing_id');
    }    
}
