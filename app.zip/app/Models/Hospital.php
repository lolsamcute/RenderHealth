<?php
namespace App\Models;
use Illuminate\Notifications\Notifiable;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Laravel\Passport\HasApiTokens;


class Hospital extends Authenticatable
{   
     use HasApiTokens, Notifiable;
    protected $guard = 'hospital';

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    public $timestamps = false;
    protected $fillable = [
        'hosp_id', 'hosp_password', 'hosp_name','hosp_email', 'hosp_picture', 'hosp_hospital_name', 'hosp_education_school', 'hosp_degree', 'hosp_speciality', 'hosp_languages', 'hosp_religion', 'hosp_ethnicity', 'hosp_years_practised','hosp_created_date','hosp_state','hosp_country','hosp_phone','pending_status','access_to_record','hosp_address','name_of_facility','lga','type_of_facility','point_first_name','point_surname','point_email','point_phone','point2_first_name','point2_surname','point2_email','point2_phone','hosp_city','hmo','serviceofferd'];

    /**
     * The attributes that should be hidden for arrays.
     *
     * @var array
     */
    protected $hidden = [
        'id',
    ];

    public function getAuthPassword()
    {
        return $this->hosp_password;
    }

    public function specialist_categories()
    {
        return $this->belongsTo('App\Models\SpecialistCategories','nurse_speciality','speciality_id');
    }
    public function hospital_hours()
    {
        return $this->belongsTo('App\Models\HospitalHour','hosp_id','hospital_id');
    }
    public function doctor_hospital_details()
    {
        return $this->hasOne('App\Models\Doctor','hospital_id','hosp_id');
    }
}
