<?php
namespace App\Models;

use Illuminate\Database\Eloquent\Model;


class DoctorAvailability extends Model
{       
    protected $table = 'doctor_availability';

    public $timestamps = false;

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'availability_id', 'doctor_id', 'availability_date','availability_time', 'type', 'booking_status','created_date'];

    /**
     * The attributes that should be hidden for arrays.
     *
     * @var array
     */
    protected $hidden = [
        'id','created_date'
    ];

   /* protected $casts = [
        'availability_time' => 'array'   
    ];*/


    public function doctor()
    {
        return $this->belongsTo('App\Models\Doctor','doctor_id','doctor_id');
    }

    
}
