<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;

class PatientNotificationSetting extends Model
{   
    protected $guard = 'patient_notification_settings';
     public $timestamps = false;

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = ['patient_id','Notification_unique_id','appointment_activity_email','newsletter_subscription','patient_history_notification','appointment_activity_push','appointment_activity_sms','appointment_cancel_email','appointment_cancel_push','appointment_cancel_sms','appointment_reschedule_email','appointment_reschedule_push','appointment_reschedule_sms','patient_history_push','patient_appt_reminder_push','patient_appt_reminder_sms','patient_bill_push','patient_bill_sms','heath_diary_push','outstanding_bill_push','outstanding_bill_email'];

    /**
     * The attributes that should be hidden for arrays.
     *
     * @var array
     */

    	 protected $hidden = ['id'];
   }
