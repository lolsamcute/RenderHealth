<?php
namespace App\Models;
use Illuminate\Notifications\Notifiable;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Laravel\Passport\HasApiTokens;

class HospitalHour extends Authenticatable
{   
     use HasApiTokens, Notifiable;
    protected $guard = 'hospital_hours';

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    public $timestamps = false;
    protected $fillable = ['monday','tuesday','wednesday','thursday','friday','saturday','sunday','hospital_id'];

    /**
     * The attributes that should be hidden for arrays.
     *
     * @var array
     */
    
}
