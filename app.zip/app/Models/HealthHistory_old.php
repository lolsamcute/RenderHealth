<?php
namespace App\Models;

use Illuminate\Database\Eloquent\Model;


class HealthHistory extends Model
{       
    protected $table = 'health_history';

    public $timestamps = false;

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'history_id', 'patient_id', 'doctor_id', 'nurse_id', 'employee_id','hospital_id','assignee_type','temperature', 'temprature_type', 'measuring_type','pulse', 'respiratory_rate', 'bp_sys', 'bp_dia', 'general_notes', 'plan', 'cvs_det', 'respiratory_det', 'abdomen_det', 'cns_det', 'rbc_det', 'wbc_det', 'hb_det', 'hmt_det', 'plt_det', 'ch_ldl_det','ch_hdl_det','created_date','updated_date','updated_doc','updated_nurse','updated_employee','updated_hospital','musculoskeletal','heent','urinary','other_system','height','weight','date_of_consutaltion','possible_diagnosis'];

    /**
     * The attributes that should be hidden for arrays.
     *
     * @var array
     */
    protected $hidden = [
        'id'
    ];    

    protected $casts = [
        'rbc_det' => 'string',
        'wbc_det' => 'string',
        'hb_det' => 'string',
        'hmt_det' => 'string',
        'plt_det' => 'string',
        'ch_ldl_det' => 'string',
        'ch_hdl_det' => 'string' 
    ];

    public function patient()
    {
        return $this->belongsTo('App\Models\Patient','patient_id','patient_unique_id');
    }

    public function doctor()
    {
        return $this->belongsTo('App\Models\Doctor','doctor_id','doctor_id');
    }

    public function nurse()
    {
        return $this->belongsTo('App\Models\Nurse','nurse_id','nurse_id');
    }

    public function employee()
    {
        return $this->belongsTo('App\Models\Employee','employee_id','employee_id');
    }
    
    public function hospital()
    {
        return $this->belongsTo('App\Models\Hospital','hospital_id','hosp_id');
    }    

    public function doctor_update()
    {
        return $this->belongsTo('App\Models\Doctor','updated_doc','doctor_id');
    }

    public function nurse_update()
    {
        return $this->belongsTo('App\Models\Nurse','updated_nurse','nurse_id');
    }

    public function employee_update()
    {
        return $this->belongsTo('App\Models\Employee','updated_employee','employee_id');
    }

    public function hospital_update()
    {
        return $this->belongsTo('App\Models\Hospital','updated_hospital','hosp_id');
    }

    public function history_attachments()
    {
        return $this->hasMany('App\Models\HealthHistoryAttachments','patient_history_id','history_id');
    }

    public function history_medication()
    {
        return $this->hasMany('App\Models\HealthHistoryMedication','health_history_id','history_id');
    }


    
}
