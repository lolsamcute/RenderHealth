<?php
namespace App\Models;
use Illuminate\Notifications\Notifiable;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Laravel\Passport\HasApiTokens;

class DealCategories extends Authenticatable
{   
    use HasApiTokens, Notifiable;
    protected $guard = 'deal_categories';

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    public $timestamps = false;

    protected $fillable = [
        'facility_id', 
        'name',
        'image',  
        'is_deleted',
        'created_at',
        'updated_at' 
    ];

    /**
     * The attributes that should be hidden for arrays.
     *
     * @var array
     */
    protected $hidden = [
        'is_deleted', 'created_at',
    ];

    public function facility_details()
    {
        return $this->belongsTo('App\Models\Facility','facility_id','id');
    }
}
