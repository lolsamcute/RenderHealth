<?php
namespace App\Models;

use Illuminate\Database\Eloquent\Model;


class PatientAppointment extends Model
{       
    protected $table = 'appointment_details';

    public $timestamps = false;

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'appointment_id', 'patient_id', 'appointment_type', 'telemedical_type', 'appoint_created_date', 'status','telemedical_consult_type','telemedical_consult_time','call_status','appoint_booking_status','appointment_time','reanson_for_visit'];

    /**
     * The attributes that should be hidden for arrays.
     *
     * @var array
     */
    protected $hidden = [
        'id', 'appoint_created_date',
    ];

    public function tele_booking_details()
    {
        return $this->hasOne('App\Models\SaveTelemedicalBookingDetail','appointment_id','appointment_id');

    }

    public function patient_detail(){
        return $this->belongsTo('App\Models\Patient','patient_id','patient_unique_id');
    }
    
}
