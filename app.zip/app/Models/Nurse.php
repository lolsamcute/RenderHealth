<?php
namespace App\Models;
use Illuminate\Notifications\Notifiable;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Laravel\Passport\HasApiTokens;

class Nurse extends Authenticatable
{   
     use HasApiTokens, Notifiable;
    protected $guard = 'nurses';

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    public $timestamps = false;
    protected $fillable = [
        'nurse_id', 'hospital_id','nurse_password', 'nurse_first_name', 'nurse_last_name', 'nurse_email', 'nurse_picture', 'nurse_hospital_name', 'nurse_education_school', 'nurse_degree', 'nurse_speciality', 'nurse_languages', 'nurse_religion', 'nurse_ethnicity', 'nurse_years_practised','folio_number','nurse_tokbox_id ',' nurse_tokbox_token ','nurse_created_date','nurse_state','nurse_country','nurse_phone','nurse_timezone','active_status','access_to_hospital','access_to_patient_record','nurse_info','nurse_gender','nurse_marital_status','nurse_title','nurse_middle_name','nurse_dob','nurse_role','nurse_username'];

    /**
     * The attributes that should be hidden for arrays.
     *
     * @var array
     */
    protected $hidden = [
        'id', 'nurse_created_date',
    ];

    public function getAuthPassword()
    {
        return $this->nurse_password;
    }

    public function specialist_categories()
    {
        return $this->belongsTo('App\Models\SpecialistCategories','nurse_speciality','speciality_id');
    }

    public function nurse_hospital_details()
    {
        return $this->belongsTo('App\Models\Hospital','hospital_id','hosp_id');
    }

    
}
