<?php
namespace App\Models;

use Illuminate\Database\Eloquent\Model;


class CallSession extends Model
{       
    protected $table = 'call_sessions';

    public $timestamps = false;

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'call_id', 'doct_id', 'patient_id','appoint_id','call_status','patient_call_status'];

    /**
     * The attributes that should be hidden for arrays.
     *
     * @var array
     */
    protected $hidden = [
        'id'
    ];

    
   }
