<?php
namespace App\Models;
use Illuminate\Notifications\Notifiable;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Laravel\Passport\HasApiTokens;


class Patient extends Authenticatable
{   
     use HasApiTokens, Notifiable;
    protected $guard = 'patient';

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'patient_unique_id', 'patient_username','patient_password', 'patient_first_name', 'patient_middle_name', 'patient_last_name', 'patient_gender', 'patient_email', 'patient_phone', 'patient_address', 'patient_visited_hospital', 'patient_doctor_name', 'patient_doctor_phone', 'patient_martial_status', 'patient_date_of_birth','patient_date_of_birth', 'patient_blood_type', 'patient_origin_state', 'patient_languages', 'patient_insurance', 'patient_profile_img','timezone','remember_token','fp_token','created_at', 'updated_at','religion','next_first_name','next_surname','next_phone','patient_city','patient_state','lga','patient_title','edu_school','emergency_phone'];

    /**
     * The attributes that should be hidden for arrays.
     *
     * @var array
     */
    protected $hidden = [
        'patient_password', 'remember_token',
    ];

    public function getAuthPassword()
    {
        return $this->patient_password;
    }

    public function patient_appoint(){

        return $this->hasMany('App\Models\PatientAppointment','patient_unique_id','patient_id');
    }

    public function save_booking(){

        return $this->hasMany('App\Models\SaveTelemedicalBookingDetail','patient_id','patient_unique_id');
    }

   
   }
