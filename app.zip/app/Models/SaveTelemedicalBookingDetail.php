<?php
namespace App\Models;

use Carbon\Carbon;
use Illuminate\Database\Eloquent\Model;


class SaveTelemedicalBookingDetail extends Model
{       
    protected $table = 'save_telemedical_booking_detail';

    public $timestamps = false;

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'booking_id', 'id','appointment_id', 'booking_name', 'patient_id','doctor_id','specialist_id','mobile_number','symptoms','terms_conditions','appointment_time','hospital_name','hospital_id','sharing_status','status','approved_status','call_status','allowed_status ','created_at','health_diary'];

    /**
     * The attributes that should be hidden for arrays.
     *
     * @var array
     */
    protected $hidden = [
        'id',
    ];  
    protected $casts = [
        'health_diary' => 'array'   
    ];  

    /*public function getAppointmentTimeAttribute($value)
    {
        return Carbon::parse($value)->timezone('Asia/Kolkata');
    }  */   


    public function patient_appoint()
    {
        return $this->belongsTo('App\Models\PatientAppointment','appointment_id','appointment_id');
    }

    public function doctor()
    {       
            return $this->belongsTo('App\Models\Doctor','doctor_id','doctor_id');
        
    }   

    public function patient_detail(){
        return $this->belongsTo('App\Models\Patient','patient_id','patient_unique_id');
    }
        
    public function hospital_detail(){
        return $this->belongsTo('App\Models\Hospital','hospital_id','hosp_id');
    }

    public function call_det(){
        return $this->hasMany('App\Models\CallSession','appoint_id','appointment_id');
    }
     public function diary_detail(){
        return $this->belongsTo('App\Models\PatientHealthDiary','health_diary','diary_id');
    }
    public function specialityFacility(){
        return $this->hasMany('App\Models\Speciality','id','specialist_id');
    }
    
   }
