<?php
namespace App\Models;
use Illuminate\Notifications\Notifiable;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Laravel\Passport\HasApiTokens;


class Administrator extends Authenticatable
{   
     use HasApiTokens, Notifiable;
    protected $guard = 'administrator';

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    public $timestamps = false;
    protected $fillable = [
       'admin_id', 'hospital_id', 'administrator_password', 'administrator_name','administrator_email', 'administrator_picture', 'administrator_info','administrator_created_date','administrator_state','administrator_country','administrator_phone','pending_status','administrator_country','access_to_record','administrator_address','administrator_timezone','administrator_gender','administrator_marital_status','active_status','administrator_title','administrator_dob','administrator_role','administrator_username']; 

    /**
     * The attributes that should be hidden for arrays.
     *
     * @var array
     */
    protected $hidden = [
        'id', 'administrator_created_date',
    ];

    public function getAuthPassword()
    {
        return $this->administrator_password;
    }

    public function doctor_availability()
    {
        return $this->hasMany('App\Models\DoctorAvailability','doctor_id','doctor_id');
    }

    public function doctor_tele_booking()
    {
        return $this->hasMany('App\Models\SaveTelemedicalBookingDetail','doctor_id','doctor_id');
    }

    public function specialist_categories()
    {
        return $this->belongsTo('App\Models\SpecialistCategories','doctor_speciality','speciality_id');
    }

    public function doctor_hospital_details()
    {
        return $this->belongsTo('App\Models\Hospital','hospital_id','hosp_id');
    }
}
