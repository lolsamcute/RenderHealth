<?php
namespace App\Models;

use Illuminate\Database\Eloquent\Model;


class EmployeeLoginToken extends Model
{       
    protected $table = 'employee_login_token';  

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'employee_id', 'login_token', 'device_token','token_status', 'device_type'];

    /**
     * The attributes that should be hidden for arrays.
     *
     * @var array
     */
    protected $hidden = [
        'id'
    ];

    
   }
