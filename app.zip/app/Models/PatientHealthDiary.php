<?php
namespace App\Models;

use Illuminate\Database\Eloquent\Model;


class PatientHealthDiary extends Model
{       
    protected $table = 'patient_health_diary';

    public $timestamps = false;

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'diary_id', 'patient_id', 'feeling_details', 'describe_feeling_other','symptom_details', 'medication_details', 'created_date'];

    /**
     * The attributes that should be hidden for arrays.
     *
     * @var array
     */
    protected $hidden = [
        'id', 
    ];

    public function diary_attachment()
    {
        return $this->hasMany('App\Models\PatientDiaryAttachment','diary_id','diary_id');

    }

    public function patient_detail(){
        return $this->belongsTo('App\Models\Patient','patient_id','patient_unique_id');
    }
    
}
