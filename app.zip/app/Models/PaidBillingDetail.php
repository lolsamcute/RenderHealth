<?php
namespace App\Models;

use Illuminate\Database\Eloquent\Model;


class PaidBillingDetail extends Model
{       
    protected $table = 'paid_billing_detail';

    public $timestamps = false;

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'transaction_id', 'billing_id', 'patient_id','doctor_id','appointment_id','created_date','cash_card'];

    /**
     * The attributes that should be hidden for arrays.
     *
     * @var array
     */
    protected $hidden = [
        'id'
    ];    

    public function doctor()
    {
        return $this->belongsTo('App\Models\Doctor','doctor_id','doctor_id');
    }

    public function patient(){
        return $this->belongsTo('App\Models\Patient','patient_id','patient_unique_id');
    }

    public function billing(){
        return $this->belongsTo('App\Models\BillingDetail','billing_id','billing_id');
    }

    
}
