<?php
namespace App\Models;

use Illuminate\Database\Eloquent\Model;


class UserNotification extends Model
{       
    protected $table = 'user_notifications';

    public $timestamps = false;

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'notification_id', 'doctor_id', 'nurse_id', 'employee_id', 'hospital_id', 'assignee_type', 'patient_id', 'event_id', 'notification_type', 'change_type', 'created_date', 'status'];

    /**
     * The attributes that should be hidden for arrays.
     *
     * @var array
     */
    protected $hidden = [
        'id',
    ];

    public function doctor()
    {               
        return $this->belongsTo('App\Models\Doctor','doctor_id','doctor_id');
    }

    public function nurse()
    {
        return $this->belongsTo('App\Models\Nurse','nurse_id','nurse_id');
    }

    public function employee()
    {
        return $this->belongsTo('App\Models\Employee','employee_id','employee_id');
    }

    public function hospital()
    {
        return $this->belongsTo('App\Models\Hospital','hospital_id','hosp_id');
    }

    public function patient()
    {
        return $this->belongsTo('App\Models\Patient','patient_id','patient_unique_id');
    }

   
}
