<?php
namespace App\Models;
use Illuminate\Notifications\Notifiable;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Laravel\Passport\HasApiTokens;

class Employee extends Authenticatable
{   
     use HasApiTokens, Notifiable;
    protected $guard = 'employees';

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    public $timestamps = false;
    protected $fillable = [
        'employee_id', 'employee_password', 'employee_first_name', 'employee_last_name', 'employee_email', 'employee_picture', 'employee_hospital_name', 'employee_education_school', 'employee_degree', 'employee_speciality ', 'employee_languages', 'employee_religion', 'employee_ethnicity', 'employee_years_practised','employee_created_date','employee_state','employee_country','employee_phone','active_status','access_to_hospital','access_to_patient_record','employee_address','employee_role','employee_gender','employee_marital_status','employee_middle_name','employee_dob','state_of_origin','position','employee_alternative_phone','nextofkin_first_name','nextofkin_surname','nextofkin_phone','reference_first_name','reference_surname','reference_phone','reference2_first_name','reference2_surname','reference2_phone','username','employee_city','employee_title','employee_timezone'];

    /**
     * The attributes that should be hidden for arrays.
     *
     * @var array
     */
    protected $hidden = [
        'id', 'employee_created_date',
    ];

    public function getAuthPassword()
    {
        return $this->employee_password;
    }

    public function specialist_categories()
    {
        return $this->belongsTo('App\Models\SpecialistCategories','employee_speciality','speciality_id');
    }

    public function employee_hospital_details()
    {
        return $this->belongsTo('App\Models\Hospital','hospital_id','hosp_id');
    }

    
}
