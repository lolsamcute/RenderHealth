<?php
namespace App\Models;

use Illuminate\Database\Eloquent\Model;


class BillingService extends Model
{       
    protected $table = 'billing_services';

    public $timestamps = false;

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'pbilling_id', 'service_name', 'service_amount','service_date'];

    /**
     * The attributes that should be hidden for arrays.
     *
     * @var array
     */
    protected $hidden = [
        'id'
    ];    

    public function billing_detail()
    {
        return $this->belongsTo('App\Models\BillingDetail','pbilling_id','billing_id');
    }    
}
