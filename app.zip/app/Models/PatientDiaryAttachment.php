<?php
namespace App\Models;

use Illuminate\Database\Eloquent\Model;


class PatientDiaryAttachment extends Model
{       
    protected $table = 'health_diary_attachments';

    public $timestamps = false;

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'attachment_id', 'diary_id', 'attachment_name', 'folder_name','attachment_path'];

    /**
     * The attributes that should be hidden for arrays.
     *
     * @var array
     */
    protected $hidden = [
        'id', 
    ];

    public function health_diary()
    {
        return $this->belongsTo('App\Models\PatientHealthDiary','diary_id','diary_id');

    }  
    
}
