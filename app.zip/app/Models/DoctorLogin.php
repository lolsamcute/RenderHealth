<?php
namespace App\Models;

use Illuminate\Database\Eloquent\Model;


class DoctorLogin extends Model
{       
    protected $table = 'doctor_login';

    public $timestamps = false;

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'doctor_id', 'login_time', 'status','booking_status'];

    /**
     * The attributes that should be hidden for arrays.
     *
     * @var array
     */
    protected $hidden = [
        'id', 'created_date',
    ];

    
   }
