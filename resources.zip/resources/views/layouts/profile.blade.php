@extends('layouts.app')

@section('content')
<div class="page">
  <div class="page-single">
        <div class="container">
            <div class="row">
                <div class="col col-signup mx-auto">
                    <div class="text-center mb-6">
                        <h3><i class="fe fe-map-pin mr-2"></i>Location Plotting</h3>
                    </div>
											@if(isset($msg))
												<div class="alert alert-success">
													<a href="#" class="close" data-dismiss="alert" aria-label="close"></a>
													{{$msg}}
												</div>
											@endif
                    <form class="form-horizontal card" role="form" method="POST" action="{{ url('/updateProfile') }}" enctype="multipart/form-data">
                        <div class="card-body p-6">
                            {{ csrf_field() }}
                            
														<input type="hidden" name="user_id" value="{{ $user_data[0]->user_id }}">
                            <div class="col-auto text-center mb-3">
                              <span id="profile_preview" class="avatar avatar-xxl" style="background-image: url({{ URL::to('/') }}/assets/images/profile/{{ $user_data[0]->user_profile_pic }})"></span>				  
                            </div>
                            <div class="col-auto text-center mb-6">
                              <label for="browse" class="btn btn-outline-primary btn-sm">Upload Image</label>
                              <input style="display:none;" id="browse" type="file" name="profile_pic" value="Upload Image"/> 
                            </div>
            
                            <div class="row">
                                <div class="col-sm-6">
                                    <div class="form-group{{ $errors->has('name') ? ' has-error' : '' }}">
                                        <label for="name" class="form-label">First Name</label>
                                        <input id="name" type="text" class="form-control" name="name" value="<?php echo ($user_data[0]->user_firstname)?($user_data[0]->user_firstname):'';?>" placeholder="Enter first name" required>
                                        @if ($errors->has('name'))
                                            <span class="help-block error">
                                                <p>{{ $errors->first('name') }}</p>
                                            </span>
                                        @endif
                                    </div>
                                </div>
                                    
                                <div class="col-sm-6">
                                    <div class="form-group">
                                      <label class="form-label">Last name</label>
                                      <input type="text" name="last_name" class="form-control" placeholder="Enter last name" value="<?php echo ($user_data[0]->user_lastname)?($user_data[0]->user_lastname):'';?>" required>
                                    </div>
                                </div>
																	
                                <div class="col-sm-6">
                                    <div class="form-group{{ $errors->has('email') ? ' has-error' : '' }}">
                                        <label for="email" class="form-label">E-Mail Address</label>
																				<input id="email" type="email" class="form-control" name="email" value="{{ ($user_data[0]->email)?($user_data[0]->email):'' }}" placeholder="Enter email address" required readonly>
																				@if ($errors->has('email'))
																						<span class="help-block errpr">
																								<p>{{ $errors->first('email') }}</p>
																						</span>
																				@endif
                                    </div>
                                </div>
                                
                                <div class="col-sm-6">
                                    <div class="form-group">
                                      <label class="form-label">Gender</label>
                                      <div class="selectgroup selectgroup-pills">
                                        <label class="selectgroup-item">
                                          <input type="radio" name="icon-input" value="1" class="selectgroup-input" <?php if(isset($user_data[0]->user_gender)) { echo ($user_data[0]->user_gender == "1")?"checked":""; }else{ echo "checked"; } ?>>
                                          <span class="selectgroup-button selectgroup-button-icon"><i class="fa fa-male"></i></span>
                                        </label>
                                        <label class="selectgroup-item">
                                          <input type="radio" name="icon-input" value="2" class="selectgroup-input">
                                          <span class="selectgroup-button selectgroup-button-icon"><i class="fa fa-female" <?php if(isset($user_data[0]->user_gender)) { echo ($user_data[0]->user_gender == "2")?"checked":""; }else{ echo "checked"; } ?>></i></span>
                                        </label>
                                      </div>
                                    </div>
                                </div>
                                
                                <!--<div class="col-sm-4">
                                    <div class="form-group">
                                        <label for="country" class="form-label">Country</label>
                                        <select id="country" name="country" class="form-control custom-select changeCountry">
                                        <?php
                                       /* foreach($countries as $country){ ?>
                                            <option value="<?php echo $country->id; ?>"><?php echo $country->name; ?></option>
                                <?php   }*/ ?>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-sm-4">
                                    <div class="form-group">
                                        <label for="state" class="form-label">State</label>
                                        <select id="state" name="state" class="form-control custom-select changeCity">
                                        </select>
                                    </div>
                                </div>
                                <div class="col-sm-4"> 
                                    <div class="form-group">
                                        <label for="city" class="form-label">City/Town</label>
                                        <select id="city" name="city" class="form-control custom-select">
                                        </select>
                                    </div>
                                </div>-->
                                  
                                <div class="col-sm-12">
                                    <div class="form-group mb-4">
                                        <div class="form-group">
                                            <label for="address" class="form-label">Address line</label>
                                            <input type"text" id="address" name="address" class="form-control" placeholder="Enter your address" value="{{ ($user_data[0]->user_address)?($user_data[0]->user_address):'' }}" required></input>
                                        </div>
                                    </div>
                                </div>
																	
																<input type="hidden" id="user_lat" name="user_lat" value="{{ ($user_data[0]->user_lat)?($user_data[0]->user_lat):'' }}">
                                <input type="hidden" id="user_long" name="user_long" value="{{ ($user_data[0]->user_long)?($user_data[0]->user_long):'' }}">
                                
                              </div>
                              <div class="form-footer">
                                <button type="submit" class="btn btn-primary btn-block"> Update </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection

<?php $url = URL::current(); 
if (strpos($url,'profile') !== false || strpos($url,'updateProfile')) { ?>

		<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script type="text/javascript" src="//maps.googleapis.com/maps/api/js?v=3.exp&libraries=places&key=AIzaSyBOSqbYotHbNt_v9A_nTXqayTMx721_a08&ver=3.exp"></script>
    <script>
       //// GET PLACES BY AUTOCOMPLETE IN ADDRESS FIELD AT REGISTARTION
          google.maps.event.addDomListener(window, 'load', function () {
              var places = new google.maps.places.Autocomplete(document.getElementById('address'));
              google.maps.event.addListener(places, 'place_changed', function () {
                  var place = places.getPlace();
                  $("#user_lat").val(place.geometry.location.lat());
                  $("#user_long").val(place.geometry.location.lng());
              });
          });
          
          $(window).on("load",function(){
              $(".c_sidebar , .content").mCustomScrollbar({
                   theme:"minimal-dark",
                   mouseWheelPixels: 300
              });
          });
    </script>
<?php } ?>