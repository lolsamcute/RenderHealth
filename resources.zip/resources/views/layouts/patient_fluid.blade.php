<!doctype html>
<html lang="{{ config('app.locale') }}">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <meta http-equiv="cache-control" content="no-cache" />
    <meta http-equiv="Pragma" content="no-cache" />
    <meta http-equiv="Expires" content="-1" />
    <link rel="icon" href="{{ asset('images/favicon.png') }}">
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <title>Render Health</title>
    <!-- Bootstrap core CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.0/css/bootstrap.min.css" integrity="sha384-9gVQ4dYFwwWSjIDZnLEWnxCjeSWFphJiwGPXr1jddIhOegiu1FwO5qRGvFXOdJZ4" crossorigin="anonymous">
    <!-- Custom styles for this template -->
    <link rel="stylesheet" href="https://maxcdn.icons8.com/fonts/line-awesome/1.1/css/line-awesome-font-awesome.min.css">
    <link href="{{ asset('css/prettyCheckable.css') }}" rel="stylesheet">
    @if(isset($page_type) && ($page_type == 'extra_links' || $page_type == 'health_diary'))
      <link href="{{ asset('css/icon.css') }}" rel="stylesheet">
      <link href="{{ asset('css/datepicker.css') }}" rel="stylesheet" type="text/css" />
    @endif
    <link href="{{ asset('css/style.css') }}" rel="stylesheet">
  
    <link href="{{ asset('css/developer.css') }}" rel="stylesheet">
       <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/Swiper/4.3.5/css/swiper.css" integrity="sha256-I23rKKBc0+Qh38KLk0F8kfmLoQQ9F4dS0f8064Jfu8I=" crossorigin="anonymous" />
    <script src="https://code.jquery.com/jquery-3.3.1.js" type="text/javascript" crossorigin="anonymous"></script> 
    @if(isset($back_btn) && $back_btn == "immediate")
      <script type="text/javascript">
        var refferer = document.referrer;       
        var present_url  = window.location.href;
        if(refferer.indexOf("immediate_tele_details") > 0 || refferer.indexOf("future_tele_details") > 0 || present_url.indexOf("my_appointments") > 0){
           history.pushState(null, null, '<?php echo $_SERVER["REQUEST_URI"]; ?>');
           window.addEventListener('popstate', function(event) {
              window.location.assign("{!! url('patient/dashboard') !!}");
          });
        }
    </script>
    @endif
    <script>
        window.Laravel = {!! json_encode([
            'csrfToken' => csrf_token(),
        ]) !!};
    </script>
  </head>

  <body>
      <nav class="navbar navbar-expand navbar-light navbar_custom">
          <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
          </button>
          <div class="collapse navbar-collapse" id="navbarSupportedContent">  
            @if(isset($page))          
              @if($page == "dashboard")
                <div class="header_search my-2 my-lg-0 mr-md-auto">
                <form class="form-inline" style="visibility: hidden;">
                      <img src="{{ asset('images/Search.svg') }}" alt="icon"/>
                      <input class="form-control mr-sm-2" type="search" placeholder="Search for ..." aria-label="Search">
                    </form>
               </div>
              @elseif($page == "inner")
                <div class="header_search my-2 my-lg-0 mr-auto">
                  <a href="{{ url('patient/my_appointments')}}" class="go_back">
                        <img src="{{ asset('images/back.svg') }}" alt="icon"> Back to My Appointments
                    </a>
               </div>
               @elseif($page == "history")
                <div class="header_search my-2 my-lg-0 mr-auto">
                  <a href="{{ url('patient/health_history_list')}}" class="go_back">
                        <img src="{{ asset('images/back.svg') }}" alt="icon"> Back to Health History
                    </a>
               </div>
              @endif
            @endif
            @if($user)
            <ul class="navbar-nav navbar_menu">
              <li class="nav-item dropdown profile_link">
                <a class="nav-link dropdown-toggle" href="javascript:;" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                  @if(!empty($user->patient_profile_img))
                    <span class="profile_image" style="background-image:url({{ asset('uploads/patient/'.$user->patient_profile_img) }});"></span>
                  @else
                    <span class="profile_image" style="background-image:url({{ asset('images/profile.svg') }});"></span>
                  @endif
                  Hi, &nbsp; <span class="username">{{ ucwords($user->patient_first_name)  }} {{ ucwords($user->patient_last_name)  }}</span>
                </a>
                <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                  <a class="dropdown-item" href="{{url('patient/my_profile')}}"><span><img src="{{ asset('images/my_profile.svg') }}" alt="icon"></span>My Profile</a>
                  <a class="dropdown-item" href="{{url('patient/settings')}}"><span><img src="{{ asset('images/settings.svg') }}" alt="icon"></span>Settings</a>
                   <a class="dropdown-item" href="{{ url('patient/logout') }}"><span><img src="{{ asset('images/logout.svg') }}" alt="icon"></span>Logout</a>
                </div>
              </li>
              <li class="nav-item notifications">
                <a class="nav-link" href="{{ url('patient/notifications') }}">
                    <span class="counter">2</span>
                    <img src="{{ asset('images/Notifications.svg') }}" alt="Notifications">
                </a>
              </li>
              <li class="nav-item emergency">
                <a href="tel:08-043-043-955" class="nav-link" href="#">
                    <div class="emer_image">
                        <img src="{{ asset('images/Phone.svg') }}" alt="Phone">
                    </div>
                    <div class="emer_desc">
                        <span class="emer_phone_number">{{ isset($user->emergency_phone)?$user->emergency_phone:'-'  }}</span>
                        <span class="emer_text">EMERGENCY CALL</span>
                    </div>
                </a>
              </li>
            </ul>
            @endif
          </div>
        </nav>

        <div class="container-fluid" id="notAllow">
          <div class="row flex-xl-nowrap">
          @if($user)
            <div class="bd-sidebar">
                <a class="navbar-brand" href="{{ url('patient/dashboard') }}"><img src="{{ asset('images/logo_white.png') }}" width="42" alt="logo"/></a>
                <div class="main_menu">
                    <ul>
                        <li class="active">
                            <a href="{{ url('patient/dashboard') }}" data-toggle="tooltip" data-placement="right" title="Dashboard">
                                    <img src="{{ asset('images/home.svg') }}" alt="Homepage"/>
                                </a>
                        </li>
                        <li>
                            <a href="{{ url('patient/my_appointments') }}" data-toggle="tooltip" data-placement="right" title="Appointment">
                                    <img src="{{ asset('images/appointment.svg') }}" alt="Appointment"/>
                                </a>
                        </li>
                        <li>
                        <a href="javascript:void(0)" onclick="blockPopupFn()" data-toggle="tooltip"  data-placement="right" title="Health History">
                                    <img src="{{ asset('images/history.svg') }}" alt="Health History"/>
                                </a>
                            <!-- <a href="javascript:;" data-toggle="tooltip" data-placement="right" title="Health History"> -->
                            <!-- <a href="{{ url('patient/health_history_list') }}" data-toggle="tooltip" data-placement="right" title="Health History">
                                    <img src="{{ asset('images/history.svg') }}" alt="Health History"/>
                                </a> -->
                        </li>
                        <li>
                            <a href="{{url('patient/health_diary')}}" data-toggle="tooltip" data-placement="right" title="Health Diary">
                                    <img src="{{ asset('images/diary.svg') }}" alt="Health Diary"/>
                                </a>
                        </li>
                        <li>
                        <a href="javascript:void(0)" onclick="blockPopupFn()" data-placement="right" data-toggle="tooltip"  title="Billing">
                            <img src="{{ asset('images/billing.svg') }}" alt="Billing"/>
                        </a>
                            <!-- <a href="{{url('/patient/billing')}}" data-toggle="tooltip" data-placement="right" title="Billing">
                                    <img src="{{ asset('images/billing.svg') }}" alt="Billing"/>
                                </a> -->
                        </li>
                    </ul>
                </div>
            </div>
            @endif
            @yield('content')
          <div id="site_url" style="display:none">{{ url('/') }}</div>
          @if($user)
          <div id="user_login" style="display:none">{{ $user?'true':'' }}</div>
          <input type="hidden" class="patient_unique_id" value="{{ $user->patient_unique_id }}">
          @endif
          <!-- Pay Bill Modal -->
          <div class="modal fade" id="call" data-backdrop="static" data-keyboard="false">
              <div class="modal-dialog modal-md-345 modal-dialog-centered genModal">
                  <div class="modal-content">
                      <div class="modal-header">
                          <h4 class="modal-title">Incoming Call</h4>                          
                       </div>
                      <div class="modal-body">
                          <div class="incoming_call">
                              <img src="{{ asset('images/profile.svg') }}" class="doctor_pic" alt="profile">
                              <h4 class="doctor_name">Mr. Ayo Akintunde</h4>
                          </div>
                          <div class="genModalfooter_center">
                              <button type="button" class="btn btn-danger call_button mt-3 mx-2 reject_btn" onclick="disconnectCall(this); return false;">
                                  <img src="{{ asset('images/decline.png') }}" alt="Decline">
                              </button>
                              <button type="submit" class="btn btn-primary call_button mt-3 mx-2 accept_btn" onclick="connectCall(this); return false;">
                                  <img src="{{ asset('images/pick.png') }}" alt="Recieve">
                              </button>
                          </div>
                      </div>
                  </div>
              </div>
          </div>
        </div>
    </div>    
         
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.0/umd/popper.min.js" crossorigin="anonymous"></script>   
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.0/js/bootstrap.min.js" crossorigin="anonymous"></script>
    <script src="{{ asset('js/call.js') }}"></script> 
    <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
    @if(isset($page_type) && $page_type == 'settings')
     <script src="{{ asset('js/bootstrap-datepicker.js') }}" type="text/javascript"></script>
     <script src="{{ asset('js/main.js') }}"></script>
     <script src="{{ asset('js/prettyCheckable.min.js') }}"></script>
     <script src="{{ asset('js/patient_first.js') }}"></script>
     @endif      
    @if(isset($controller) && $controller == 'patient')
      <script src="{{ asset('js/bootstrap-datepicker.js') }}"></script>
      <script src="{{ asset('js/prettyCheckable.min.js') }}"></script>
      <script src="{{ asset('js/main.js') }}"></script>           
      <script type="text/javascript"  src="{{ asset('js/patient_dashboard.js') }}"></script>        
      <script src="{{ asset('js/moment.min.js') }}"></script>
      <script src="{{ asset('js/moment-with-locales.min.js') }}"></script>
      <script src="https://js.paystack.co/v1/inline.js"></script> 
    @endif 
    @if(isset($page_type) && $page_type == 'health_diary')
      <script src="{{ asset('js/bootstrap-datepicker.js') }}" type="text/javascript"></script>
      <script src="{{ asset('js/main.js') }}"></script>
      <script src="{{ asset('js/prettyCheckable.min.js') }}"></script>
      <script src="{{ asset('js/patient_diary.js') }}"></script>
    @endif
     @if(isset($page_type) && $page_type == 'health_history')
      <script src="{{ asset('js/bootstrap-datepicker.js') }}" type="text/javascript"></script>
      <script src="{{ asset('js/main.js') }}"></script>
      <script src="{{ asset('js/prettyCheckable.min.js') }}"></script>  
      <script src="{{ asset('js/patient_history.js') }}"></script>   
      <script src="https://cdnjs.cloudflare.com/ajax/libs/Swiper/4.3.5/js/swiper.min.js"></script>
    @endif
    @if(isset($page_type) && $page_type == 'billing')
      <script src="{{ asset('js/bootstrap-datepicker.js') }}" type="text/javascript"></script>
      <script src="{{ asset('js/main.js') }}"></script>
      <script src="{{ asset('js/prettyCheckable.min.js') }}"></script> 
      <script src="https://js.paystack.co/v1/inline.js"></script> 
      <script src="{{ asset('js/patient_billing.js') }}"></script>   
    @endif
    <script type="text/javascript">
    $(function () {
        $('[data-toggle="tooltip"]').tooltip()
    })
    </script>
  </body>
</html>