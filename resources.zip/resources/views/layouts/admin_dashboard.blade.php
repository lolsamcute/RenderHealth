<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <link rel="icon" href="{{asset('admin/adminimages/favicon.png')}}">
    <title>Render Health</title>
    <!-- Bootstrap core CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.0/css/bootstrap.min.css" integrity="sha384-9gVQ4dYFwwWSjIDZnLEWnxCjeSWFphJiwGPXr1jddIhOegiu1FwO5qRGvFXOdJZ4" crossorigin="anonymous">
    <!-- Custom styles for this template -->
    <link rel="stylesheet" href="https://maxcdn.icons8.com/fonts/line-awesome/1.1/css/line-awesome-font-awesome.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/Swiper/4.3.5/css/swiper.css" integrity="sha256-I23rKKBc0+Qh38KLk0F8kfmLoQQ9F4dS0f8064Jfu8I=" crossorigin="anonymous" />
    <link href="{{ asset('admin/admincss/datepicker.css') }}" rel="stylesheet" type="text/css" />
    <link href="{{ asset('admin/admincss/prettyCheckable.css') }}" rel="stylesheet">
    <link href="{{ asset('admin/admincss/style.css') }}" rel="stylesheet">
     <!--   date piker -->
    <link href="//code.jquery.com/ui/1.10.4/themes/ui-lightness/jquery-ui.css" rel="stylesheet">
    <script src="//code.jquery.com/jquery-1.10.2.js"></script>
    <script src="//code.jquery.com/ui/1.10.4/jquery-ui.js"></script>
     <script type="text/javascript"  src="{{ asset('admin/adminjs/admin_dashboard.js') }}"></script>
     <link href="https://cdn.jsdelivr.net/npm/select2@4.0.13/dist/css/select2.min.css" rel="stylesheet" />
     <script src="https://js.paystack.co/v1/inline.js"></script>
    <!-- date piker -->
     <script>
        window.Laravel = {!! json_encode([
            'csrfToken' => csrf_token(),
        ]) !!};
    </script>
    <style type="text/css">
        option {color: #353638;}
    </style>
    <?php
      header("Cache-Control: no-cache, must-revalidate");
      header("Expires: Mon, 26 Jul 1997 05:00:00 GMT");
    ?>
</head>

<body class="slide_left">
<div class="loading">Loading&#8230;</div>
    <nav class="navbar navbar-expand navbar-light navbar_custom">
        <button id="menu" class="navbar-toggler" type="button">
            <span class="navbar-toggler-icon"></span>
          </button>
        <a class="navbar-brand" href="{{url('/admin/dashboard')}}"><img src="{{ asset('admin/adminimages/render_logo_white.svg') }}" alt="logo"/></a>
        <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <div class="header_search my-2 my-lg-0 mr-auto">
                <form class="form-inline">
                    <div class="search_icon">
                        <img src="{{ asset('admin/adminimages/search.svg') }}" alt="icon">
                    </div>
                    <input class="form-control mr-sm-2" placeholder="Search Appointment records" aria-label="Search" type="search">
                </form>
            </div>
            <ul class="navbar-nav navbar_menu">
                <li class="nav-item notifications">
                    <a class="nav-link" href="javascript:;">
                      <span class="counter"></span>
                      <img src="{{ asset('admin/adminimages/notifications.svg') }}" alt="Notifications">
                  </a>
                </li>
                <li class="nav-item dropdown profile_link">
                    <a class="nav-link dropdown-toggle" href="javascript:;" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                    @if(isset($admin_details->employee_picture) && $admin_details->employee_picture!='')<span class="profile_image" style="background-image:url({{ asset('employeeimages/'.$admin_details->employee_picture) }});"></span>@else <span class="profile_image" style="background-image:url({{ asset('admin/adminimages/profile.svg') }});"></span> @endif
                    
                  Hi, &nbsp; <span class="username">@if(isset($admin_details->first_name)){{$admin_details->first_name}}@endif
                    @if(isset($admin_details->last_name)){{$admin_details->last_name}}@endif</span>
                </a>
                    <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdown">
                            <a class="dropdown-item" href="javascript:;"><span><img src="{{ asset('admin/adminimages/help_center.svg') }}" alt="icon"></span>Help Center</a>
                            <a class="dropdown-item" href="{{ url('admin/logout') }}"><span><img src="{{ asset('admin/adminimages/logout.svg') }}" alt="icon"></span>Logout</a>
                    </div>
                </li>
            </ul>
        </div>
    </nav>

    <div class="container-fluid">
        <div class="row flex-xl-nowrap">
            <div class="bd-sidebar">
                <div class="main_menu">
                    <ul>
                        <li>
                            <a href="{{url('/admin/dashboard')}}">
                                <div class="icon_main">
                                    <svg width="16px" height="16px" viewBox="0 0 16 16" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
                                            <defs></defs>
                                            <g id="Symbols" stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">
                                                <g id="color_icon" transform="translate(-12.000000, -12.000000)" fill="#353638" fill-rule="nonzero">
                                                    <g id="Group-13">
                                                        <path d="M15.5555556,13.7777778 C15.5555556,14.7555556 14.7555556,15.5555556 13.7777778,15.5555556 C12.8,15.5555556 12,14.7555556 12,13.7777778 C12,12.8 12.8,12 13.7777778,12 C14.7555556,12 15.5555556,12.8 15.5555556,13.7777778 Z M20,12 C19.0222222,12 18.2222222,12.8 18.2222222,13.7777778 C18.2222222,14.7555556 19.0222222,15.5555556 20,15.5555556 C20.9777778,15.5555556 21.7777778,14.7555556 21.7777778,13.7777778 C21.7777778,12.8 20.9777778,12 20,12 Z M26.2222222,15.5555556 C27.2,15.5555556 28,14.7555556 28,13.7777778 C28,12.8 27.2,12 26.2222222,12 C25.2444444,12 24.4444444,12.8 24.4444444,13.7777778 C24.4444444,14.7555556 25.2444444,15.5555556 26.2222222,15.5555556 Z M13.7777778,18.2222222 C12.8,18.2222222 12,19.0222222 12,20 C12,20.9777778 12.8,21.7777778 13.7777778,21.7777778 C14.7555556,21.7777778 15.5555556,20.9777778 15.5555556,20 C15.5555556,19.0222222 14.7555556,18.2222222 13.7777778,18.2222222 Z M20,18.2222222 C19.0222222,18.2222222 18.2222222,19.0222222 18.2222222,20 C18.2222222,20.9777778 19.0222222,21.7777778 20,21.7777778 C20.9777778,21.7777778 21.7777778,20.9777778 21.7777778,20 C21.7777778,19.0222222 20.9777778,18.2222222 20,18.2222222 Z M26.2222222,18.2222222 C25.2444444,18.2222222 24.4444444,19.0222222 24.4444444,20 C24.4444444,20.9777778 25.2444444,21.7777778 26.2222222,21.7777778 C27.2,21.7777778 28,20.9777778 28,20 C28,19.0222222 27.2,18.2222222 26.2222222,18.2222222 Z M13.7777778,24.4444444 C12.8,24.4444444 12,25.2444444 12,26.2222222 C12,27.2 12.8,28 13.7777778,28 C14.7555556,28 15.5555556,27.2 15.5555556,26.2222222 C15.5555556,25.2444444 14.7555556,24.4444444 13.7777778,24.4444444 Z M20,24.4444444 C19.0222222,24.4444444 18.2222222,25.2444444 18.2222222,26.2222222 C18.2222222,27.2 19.0222222,28 20,28 C20.9777778,28 21.7777778,27.2 21.7777778,26.2222222 C21.7777778,25.2444444 20.9777778,24.4444444 20,24.4444444 Z M26.2222222,24.4444444 C25.2444444,24.4444444 24.4444444,25.2444444 24.4444444,26.2222222 C24.4444444,27.2 25.2444444,28 26.2222222,28 C27.2,28 28,27.2 28,26.2222222 C28,25.2444444 27.2,24.4444444 26.2222222,24.4444444 Z" id="Shape"></path>
                                                    </g>
                                                </g>
                                            </g>
                                        </svg>
                                </div>
                                Dashboard
                            </a>
                        </li>
                    </ul>
                    <div class="menu_heading">Appointment</div>
                    <ul>
                        <li class="active">
                            <a class="collapsed has_submenu" href="javascript:;" data-toggle="collapse" data-target="#collapseTwo" aria-expanded="true" aria-controls="collapseTwo">
                                <div class="icon_main">
                                    <svg width="21px" height="19px" viewBox="0 0 21 19" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
                                        <defs></defs>
                                        <g id="Symbols" stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">
                                            <g id="color_icon" transform="translate(-9.000000, -110.000000)" fill="#FFFFFF" fill-rule="nonzero">
                                                <path d="M11.8636364,114.75 C11.8636364,112.09 13.9636364,110 16.6363636,110 C19.3090909,110 21.4090909,112.09 21.4090909,114.75 C21.4090909,117.41 19.3090909,119.5 16.6363636,119.5 C13.9636364,119.5 11.8636364,117.41 11.8636364,114.75 Z M16.6363636,120.45 C12.4363636,120.45 9,123.87 9,128.05 L9,128.525 C9,128.81 9.19090909,129 9.47727273,129 L23.7954545,129 C24.0818182,129 24.2727273,128.81 24.2727273,128.525 L24.2727273,128.05 C24.2727273,123.87 20.8363636,120.45 16.6363636,120.45 Z M25.2272727,117.6 C26.85,117.6 28.0909091,116.365 28.0909091,114.75 C28.0909091,113.135 26.85,111.9 25.2272727,111.9 C23.6045455,111.9 22.3636364,113.135 22.3636364,114.75 C22.3636364,116.365 23.6045455,117.6 25.2272727,117.6 Z M23.7954545,123.3 L30,123.3 C30,120.64 27.9,118.55 25.2272727,118.55 C23.5090909,118.55 21.9818182,119.5 21.2181818,120.83 C22.1727273,121.495 23.1272727,122.255 23.7954545,123.3 Z" id="Shape"></path>
                                            </g>
                                        </g>
                                    </svg>
                                </div>
                                Manage Users
                            </a>
                            <div id="collapseTwo" class="collapse {{ (url('/admin/dashboard') == Request::url()) || (url('/admin/all_hospitals') == Request::url()) || (url('/admin/all_employees') == Request::url())  || (url('/admin/all_doctors') == Request::url()) || (url('/admin/deals') == Request::url()) ? 'show' : '' }}">
                                <ul class="submenu" id="sidebar_menu">
                                    <li id="option_1">
                                        <a href="{{url('/admin/dashboard')}}">Members/Patient</a>
                                    </li>
                                    <li id="option_2">
                                        <a href="{{url('/admin/all_hospitals')}}">Hospitals/Labs</a>
                                    </li>
                                    <li id="option_3">
                                        <a href="javascript:void(0)">HMO</a>
                                    </li>
                                    @if(isset($admin_details) && $admin_details->role_type!='employee')
                                    <li id="option_4">
                                        <a href="{{url('/admin/all_employees')}}">Render Employees</a>
                                    </li>
                                    @endif
                                    <li id="option_5">
                                        <a href="{{url('/admin/all_doctors')}}">Doctors</a>
                                    </li>
                                    <li id="option_6">
                                        <a href="{{url('/admin/deals')}}">Deals</a>
                                    </li>
                                </ul>
                            </div>
                        </li>
                        <li class="">
                            <a href="{{url('/admin/appointment')}}">
                                <div class="icon_main">
                                <svg xmlns="http://www.w3.org/2000/svg" height="20px" viewBox="0 0 512 512" width="20px"><g><path d="m298.667969 106.667969c0 58.910156-47.757813 106.664062-106.667969 106.664062s-106.667969-47.753906-106.667969-106.664062c0-58.910157 47.757813-106.667969 106.667969-106.667969s106.667969 47.757812 106.667969 106.667969zm0 0" data-original="#000000" class="active-path" data-old_color="#000000" fill="#000"/><path d="m202.667969 373.332031c0-45.460937 17.984375-86.71875 47.058593-117.332031h-148.394531c-55.871093 0-101.332031 45.460938-101.332031 101.332031v74.667969c0 8.832031 7.167969 16 16 16h204.097656c-11.050781-22.59375-17.429687-47.871094-17.429687-74.667969zm0 0" data-original="#000000" class="active-path" data-old_color="#000000" fill="#000"/><path d="m373.332031 234.667969c-76.457031 0-138.664062 62.207031-138.664062 138.664062 0 76.460938 62.207031 138.667969 138.664062 138.667969 76.460938 0 138.667969-62.207031 138.667969-138.667969 0-76.457031-62.207031-138.664062-138.667969-138.664062zm47.082031 185.746093c-4.15625 4.160157-9.621093 6.253907-15.082031 6.253907-5.460937 0-10.921875-2.09375-15.082031-6.253907l-32-32c-4.011719-3.988281-6.25-9.40625-6.25-15.082031v-53.332031c0-11.796875 9.558594-21.332031 21.332031-21.332031 11.777344 0 21.335938 9.535156 21.335938 21.332031v44.5l25.746093 25.75c8.34375 8.34375 8.34375 21.824219 0 30.164062zm0 0" data-original="#000000" class="active-path" data-old_color="#000000" fill="#000"/></g> </svg>
                                </div>
                                Appointment
                            </a>
                        </li>
                        <li class="">
                            <a href="{{url('/admin/health-record')}}">
                                <div class="icon_main">
                                <svg width="18px" height="18px" viewBox="0 0 18 18" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
                                            <defs></defs>
                                            <g id="Symbols" stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">
                                                <g id="color_icon" transform="translate(-11.000000, -111.000000)" fill="#353638" fill-rule="nonzero">
                                                    <g id="Group-13">
                                                        <path d="M29,113.16 L29,116.04 L11,116.04 L11,113.16 C11,112.728 11.288,112.44 11.72,112.44 L15.32,112.44 L15.32,111.36 C15.32,111.144 15.464,111 15.68,111 C15.896,111 16.04,111.144 16.04,111.36 L16.04,112.44 L23.96,112.44 L23.96,111.36 C23.96,111.144 24.104,111 24.32,111 C24.536,111 24.68,111.144 24.68,111.36 L24.68,112.44 L28.28,112.44 C28.712,112.44 29,112.728 29,113.16 Z M11,116.76 L29,116.76 L29,127.56 C29,127.992 28.712,128.28 28.28,128.28 L11.72,128.28 C11.288,128.28 11,127.992 11,127.56 L11,116.76 Z M23.96,120.36 L25.4,120.36 L25.4,118.92 L23.96,118.92 L23.96,120.36 Z M20.36,120.36 L21.8,120.36 L21.8,118.92 L20.36,118.92 L20.36,120.36 Z M18.2,123.96 L19.64,123.96 L19.64,122.52 L18.2,122.52 L18.2,123.96 Z M14.6,123.96 L16.04,123.96 L16.04,122.52 L14.6,122.52 L14.6,123.96 Z" id="Shape"></path>
                                                    </g>
                                                </g>
                                            </g>
                                        </svg>
                                </div>
                                Health Record
                            </a>
                        </li>
                        <!--li>
                            <a href="javascript:void(0)">
                                <div class="icon_main">
                                    <svg width="18px" height="17px" viewBox="0 0 18 17" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
                                            <defs></defs>
                                            <g id="Symbols" stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">
                                                <g id="color_icon" transform="translate(-11.000000, -177.000000)" fill="#353638" fill-rule="nonzero">
                                                    <g id="Group-13">
                                                        <path d="M27.92,177 L12.08,177 C11.504,177 11,177.504 11,178.08 L11,189.6 C11,190.176 11.504,190.68 12.08,190.68 L21.224,190.68 C21.296,190.68 21.368,190.68 21.44,190.752 L24.968,193.416 C25.112,193.488 25.256,193.56 25.4,193.56 C25.544,193.56 25.616,193.56 25.688,193.488 C25.904,193.344 26.12,193.128 26.12,192.84 L26.12,190.68 L27.92,190.68 C28.496,190.68 29,190.176 29,189.6 L29,178.08 C29,177.504 28.496,177 27.92,177 Z M23.96,186.36 L21.8,184.92 L21.8,185.64 C21.8,186.072 21.512,186.36 21.08,186.36 L16.76,186.36 C16.328,186.36 16.04,186.072 16.04,185.64 L16.04,182.04 C16.04,181.608 16.328,181.32 16.76,181.32 L21.08,181.32 C21.512,181.32 21.8,181.608 21.8,182.04 L21.8,182.76 L23.96,181.32 L23.96,186.36 Z" id="Shape"></path>
                                                    </g>
                                                </g>
                                            </g>
                                        </svg>
                                </div>
                                Teleconsultan App
                            </a>
                        </li-->
                    </ul>
                    <div class="menu_heading">OTHERS</div>
                    <ul>
                    
                       <li>
                            <a href="{{url('/admin/search_patient')}}">
                                <div class="icon_main">
                                    <svg width="20px" height="17px" viewBox="0 0 20 17" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
                                            <defs></defs>
                                            <g id="Symbols" stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">
                                                <g id="color_icon" transform="translate(-12.000000, -277.000000)" fill="#353638" fill-rule="nonzero">
                                                    <g id="Group-13">
                                                        <path d="M28.3785275,278.520842 C26.9337276,278.520842 25.717054,279.737516 25.717054,281.182315 C25.717054,281.790652 25.9451803,282.322947 26.2493487,282.7792 L24.196212,284.832336 L24.7285067,285.364631 L26.7816434,283.311494 C27.237896,283.615663 27.7701907,283.843789 28.3785275,283.843789 C29.8233273,283.843789 31.0400009,282.627115 31.0400009,281.182315 C31.0400009,279.737516 29.8233273,278.520842 28.3785275,278.520842 Z M28.3785275,283.083368 C27.3139381,283.083368 26.477475,282.246905 26.477475,281.182315 C26.477475,280.117726 27.3139381,279.281263 28.3785275,279.281263 C29.4431168,279.281263 30.2795799,280.117726 30.2795799,281.182315 C30.2795799,282.246905 29.4431168,283.083368 28.3785275,283.083368 Z M26.477475,291.828209 C26.6295592,292.436546 26.1733066,293.044883 25.5649698,293.196967 C24.196212,293.425093 21.6868227,293.729262 19.2534756,293.729262 C16.8961705,293.729262 14.3107391,293.425093 12.9419814,293.196967 C12.3336446,293.120925 11.877392,292.512588 12.0294762,291.828209 L12.4096867,289.775073 C12.4857288,289.394862 12.7138551,289.090694 13.0940656,288.93861 L16.0597074,287.87402 C16.3638758,287.721936 16.5920021,287.49381 16.7440863,287.189641 L16.8961705,286.809431 L18.6451388,287.569852 C19.0253493,287.721936 19.4816019,287.721936 19.8618124,287.569852 L21.6107806,286.809431 L21.7628648,287.189641 C21.8389069,287.49381 22.1430753,287.797978 22.4472437,287.87402 L25.4128856,288.93861 C25.7930961,289.090694 26.0212224,289.394862 26.0972645,289.775073 L26.477475,291.828209 Z M15.2232443,280.041684 L15.0711601,278.748968 C14.995118,278.140631 15.3753285,277.684379 15.9836653,277.532295 C16.9722126,277.304168 18.5690967,277 19.2534756,277 C19.4816019,277 19.8618124,277.076042 20.2420229,277.076042 C19.7857703,278.977095 17.5045073,279.965642 15.2232443,280.041684 Z M21.0024438,277.228126 C21.5347385,277.304168 22.0670332,277.456253 22.5232858,277.532295 C23.0555805,277.684379 23.435791,278.216674 23.435791,278.748968 L22.8274542,284.832336 C22.7514121,285.212547 22.5232858,285.592757 22.1430753,285.744841 L19.8618124,286.733389 C19.4816019,286.885473 19.0253493,286.885473 18.6451388,286.733389 L16.3638758,285.744841 C15.9836653,285.592757 15.755539,285.212547 15.6794969,284.832336 L15.2992864,280.802105 C17.8847178,280.726063 20.4701492,279.509389 21.0024438,277.228126 Z" id="Shape"></path>
                                                    </g>
                                                </g>
                                            </g>
                                        </svg>
                                </div>
                                Search Patient
                            </a>
                        </li>
                        <li>
                            <a class="collapsed has_submenu" href="javascript:;" data-toggle="collapse" data-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
                                <div class="icon_main has_notification">
                                    <svg width="22px" height="16px" viewBox="0 0 22 16" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
                                        <defs></defs>
                                        <g id="Symbols" stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">
                                            <g id="color_icon" transform="translate(-9.000000, -470.000000)" fill="#353638" fill-rule="nonzero">
                                                <g id="Group-14" transform="translate(0.000000, 458.000000)">
                                                    <path d="M30.0526316,15.7894737 L30.0526316,26.7368421 C30.0526316,27.4105263 29.4631579,28 28.7894737,28 L12.7894737,28 C12.1157895,28 11.5263158,27.4105263 11.5263158,26.7368421 L11.5263158,26.3157895 L27.5263158,26.3157895 C28.0315789,26.3157895 28.3684211,25.9789474 28.3684211,25.4736842 L28.3684211,14.5263158 L28.7894737,14.5263158 C29.4631579,14.5263158 30.0526316,15.1157895 30.0526316,15.7894737 Z M26.2631579,25.4736842 L10.2631579,25.4736842 C9.58947368,25.4736842 9,24.8842105 9,24.2105263 L9,13.2631579 C9,12.5894737 9.58947368,12 10.2631579,12 L26.2631579,12 C26.9368421,12 27.5263158,12.5894737 27.5263158,13.2631579 L27.5263158,24.2105263 C27.5263158,24.8842105 26.9368421,25.4736842 26.2631579,25.4736842 Z M13.2105263,23.3684211 C13.2105263,23.1157895 13.0421053,22.9473684 12.7894737,22.9473684 L11.1052632,22.9473684 C10.8526316,22.9473684 10.6842105,23.1157895 10.6842105,23.3684211 C10.6842105,23.6210526 10.8526316,23.7894737 11.1052632,23.7894737 L12.7894737,23.7894737 C13.0421053,23.7894737 13.2105263,23.6210526 13.2105263,23.3684211 Z M20.7894737,18.7368421 C20.7894737,16.8842105 19.6947368,15.3684211 18.2631579,15.3684211 C16.8315789,15.3684211 15.7368421,16.8842105 15.7368421,18.7368421 C15.7368421,20.5894737 16.8315789,22.1052632 18.2631579,22.1052632 C19.6947368,22.1052632 20.7894737,20.5894737 20.7894737,18.7368421 Z M25.8421053,14.1052632 C25.8421053,13.8526316 25.6736842,13.6842105 25.4210526,13.6842105 L23.7368421,13.6842105 C23.4842105,13.6842105 23.3157895,13.8526316 23.3157895,14.1052632 C23.3157895,14.3578947 23.4842105,14.5263158 23.7368421,14.5263158 L25.4210526,14.5263158 C25.6736842,14.5263158 25.8421053,14.3578947 25.8421053,14.1052632 Z" id="Shape"></path>
                                                </g>
                                            </g>
                                        </g>
                                    </svg>
                                </div>
                                Billings
                            </a>
                            <div id="collapseOne" class="collapse">
                                <ul class="submenu">
                                    <li>
                                        <a href="{{url('/admin/view_doctors_billing')}}">View All Bilings</a>
                                    </li>
                                    <li>
                                        <a href="{{url('/admin/view_hospital_billing')}}">Billings by Hospital</a>
                                    </li>
                                    <li>
                                        <a href="{{url('/admin/view_disputes_billing')}}">Disputed Billings <span class="sub_counter">@if(isset($disputed_billing_count)) {{$disputed_billing_count}} @else {{0}} @endif</span></a>
                                    </li>
                                </ul>
                            </div>
                        </li>
                        <li>
                            <a href="javascript:void(0)">
                                <div class="icon_main">
                                    <svg width="18px" height="18px" viewBox="0 0 18 18" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
                                            <defs></defs>
                                            <g id="Symbols" stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">
                                                <g id="color_icon" transform="translate(-11.000000, -404.000000)" fill="#353638">
                                                    <g id="Group-13">
                                                        <path d="M28.5,411.571429 L27,411.142857 C26.8571429,411.142857 26.7857143,411 26.7857143,410.928571 C26.6428571,410.5 26.5,410.071429 26.2857143,409.714286 C26.2142857,409.642857 26.2142857,409.5 26.2857143,409.357143 L27,408 C27.1428571,407.714286 27.0714286,407.357143 26.8571429,407.142857 L25.8571429,406.142857 C25.6428571,405.928571 25.2857143,405.857143 25,406 L23.6428571,406.714286 C23.5714286,406.785714 23.4285714,406.785714 23.2857143,406.714286 C22.8571429,406.5 22.5,406.357143 22.0714286,406.214286 C21.9285714,406.214286 21.8571429,406.071429 21.8571429,406 L21.4285714,404.5 C21.3571429,404.214286 21.0714286,404 20.7142857,404 L19.2857143,404 C19,404 18.7142857,404.214286 18.5714286,404.5 L18.1428571,406 C18.1428571,406.142857 18,406.214286 17.9285714,406.214286 C17.5,406.357143 17.0714286,406.5 16.7142857,406.714286 C16.6428571,406.785714 16.5,406.785714 16.3571429,406.714286 L15,406 C14.7142857,405.857143 14.3571429,405.928571 14.1428571,406.142857 L13.1428571,407.142857 C12.9285714,407.357143 12.8571429,407.714286 13,408 L13.7142857,409.357143 C13.7857143,409.428571 13.7857143,409.571429 13.7142857,409.714286 C13.5,410.142857 13.3571429,410.5 13.2142857,410.928571 C13.2142857,411.071429 13.0714286,411.142857 13,411.142857 L11.5,411.571429 C11.2142857,411.642857 11,411.928571 11,412.285714 L11,413.714286 C11,414 11.2142857,414.285714 11.5,414.428571 L13,414.857143 C13.1428571,414.857143 13.2142857,415 13.2142857,415.071429 C13.3571429,415.5 13.5,415.928571 13.7142857,416.285714 C13.7857143,416.357143 13.7857143,416.5 13.7142857,416.642857 L13,418 C12.8571429,418.285714 12.9285714,418.642857 13.1428571,418.857143 L14.1428571,419.857143 C14.3571429,420.071429 14.7142857,420.142857 15,420 L16.3571429,419.285714 C16.4285714,419.214286 16.5714286,419.214286 16.7142857,419.285714 C17.1428571,419.5 17.5,419.642857 17.9285714,419.785714 C18.0714286,419.785714 18.1428571,419.928571 18.1428571,420 L18.5714286,421.5 C18.6428571,421.785714 18.9285714,422 19.2857143,422 L20.7142857,422 C21,422 21.2857143,421.785714 21.4285714,421.5 L21.8571429,420 C21.8571429,419.857143 22,419.785714 22.0714286,419.785714 C22.5,419.642857 22.9285714,419.5 23.2857143,419.285714 C23.3571429,419.214286 23.5,419.214286 23.6428571,419.285714 L25,420 C25.2857143,420.142857 25.6428571,420.071429 25.8571429,419.857143 L26.8571429,418.857143 C27.0714286,418.642857 27.1428571,418.285714 27,418 L26.2857143,416.642857 C26.2142857,416.571429 26.2142857,416.428571 26.2857143,416.285714 C26.5,415.857143 26.6428571,415.5 26.7857143,415.071429 C26.7857143,414.928571 26.9285714,414.857143 27,414.857143 L28.5,414.428571 C28.7857143,414.357143 29,414.071429 29,413.714286 L29,412.285714 C29,411.928571 28.7857143,411.642857 28.5,411.571429 Z M20.0714286,416.142857 C18.2857143,416.142857 16.8571429,414.714286 16.8571429,412.928571 C16.8571429,411.142857 18.2857143,409.714286 20.0714286,409.714286 C21.8571429,409.714286 23.2857143,411.142857 23.2857143,412.928571 C23.2857143,414.714286 21.8571429,416.142857 20.0714286,416.142857 Z" id="Shape"></path>
                                                    </g>
                                                </g>
                                            </g>
                                        </svg>
                                </div>
                                Settings
                            </a>
                        </li>
                    </ul>
                </div>
                <a class="help_sm" href="tel:021-000-1234">
                    <div class="help_icon_sm">
                        <img src="{{ asset('admin/adminimages/call_sm.svg') }}" alt="icon">
                    </div>
                    <div class="help_desc_sm">
                        <h3>Need Help?</h3>
                        <h4>Call. 0703 242 1768</h4>
                    <small>contact@renderhealth.com</small>
                    </div>
                </a>
            </div>
            <div class='black_overlay'></div>
            @yield('content')
            <div id="site_url" style="display:none">{{ url('/') }}</div>
           
            </div>
        </div>

        <script src="https://code.jquery.com/jquery-3.3.1.js" integrity="sha256-2Kok7MbOyxpgUVvAk/HJ2jigOSYS2auK4Pfzbm7uH60=" crossorigin="anonymous">
        </script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.0/umd/popper.min.js" integrity="sha384-cs/chFZiN24E4KMATLdqdvsezGxaGsi4hLGOzlXwp5UZB1LY//20VyM2taTB4QvJ" crossorigin="anonymous">
        </script>
         <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.0/js/bootstrap.min.js" integrity="sha384-uefMccjFJAIv6A+rW+L4AHf99KvxDjWSu1z9VI8SKNVmz4sk7buKt/6v9KI65qnm" crossorigin="anonymous">
        </script>  
        <script src="https://cdn.jsdelivr.net/npm/select2@4.0.13/dist/js/select2.min.js"></script>
              <script type="text/javascript"  src="{{ asset('js/intlTelInput.js') }}"></script>       
        <script src="https://cdnjs.cloudflare.com/ajax/libs/Swiper/4.3.5/js/swiper.min.js"></script>
        <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
        <script src="{{ asset('admin/adminjs/bootstrap-datepicker.js') }}" type="text/javascript"></script>
        <script src="{{ asset('admin/adminjs/prettyCheckable.min.js') }}"></script>
        <script src="{{ asset('admin/adminjs/main.js') }}"></script>
        <script src="{{ asset('admin/adminjs/admin.js') }}"></script>
               <link rel="stylesheet" href="{{ asset('css/intlTelInput.css')}}"> 
        <script type="text/javascript">
            
            if (window.location.href.indexOf("dashboard") > -1) {
                $('#sidebar_menu li ').removeClass('active');
                $("#option_1").addClass('active');

            }
            else if(window.location.href.indexOf("all_hospitals") > -1){
                $('#sidebar_menu li').removeClass('active');
                $("#option_2").addClass('active');
            }
            else if (window.location.href.indexOf("all_employees") > -1) {
                $('#sidebar_menu li').removeClass('active');
                $("#option_4").addClass('active');
            }else if (window.location.href.indexOf("all_doctors") > -1) {
                $('#sidebar_menu li').removeClass('active');
                $("#option_5").addClass('active');
            }else if (window.location.href.indexOf("deals") > -1) {
                $('#sidebar_menu li').removeClass('active');
                $("#option_6").addClass('active');
            } 


            $('.datepicker').datepicker({format: 'dd/mm/yyyy'})
      
                
        </script>

</body>

</html>
