<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
     <meta name="csrf-token" content="{{ csrf_token() }}">
    <meta name="author" content="">
    <link rel="icon" href="{{ asset('admin/doctor/images/favicon.png') }}">
    <title>Render Health</title>
    <!-- Bootstrap core CSS -->
    <link rel="stylesheet"
          href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.0/css/bootstrap.min.css"
          integrity="sha384-9gVQ4dYFwwWSjIDZnLEWnxCjeSWFphJiwGPXr1jddIhOegiu1FwO5qRGvFXOdJZ4"
          crossorigin="anonymous">
    <!-- Custom styles for this template -->
    <link rel="stylesheet" href="https://maxcdn.icons8.com/fonts/line-awesome/1.1/css/line-awesome-font-awesome.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/Swiper/4.3.5/css/swiper.css" integrity="sha256-I23rKKBc0+Qh38KLk0F8kfmLoQQ9F4dS0f8064Jfu8I=" crossorigin="anonymous" />
    <link href="{{ asset('admin/doctor/css/datepicker.css') }}" rel="stylesheet" type="text/css" />
    <link href="{{ asset('admin/doctor/css/prettyCheckable.css') }}" rel="stylesheet">
    <link href="{{ asset('admin/doctor/css/style.css') }}" rel="stylesheet">
    <link href="{{ asset('admin/doctor/css/developer.css') }}" rel="stylesheet">
        <link href="//code.jquery.com/ui/1.10.4/themes/ui-lightness/jquery-ui.css" rel="stylesheet">
    <script src="//code.jquery.com/jquery-1.10.2.js"></script>
    <script src="//code.jquery.com/ui/1.10.4/jquery-ui.js"></script>
  </head>

  <body class="slide_left">
      <nav class="navbar navbar-expand navbar-light navbar_custom">
          <button id="menu" class="navbar-toggler" type="button">
            <span class="navbar-toggler-icon"></span>
          </button>
          <a class="navbar-brand" href="{{url('/doctor/dashboard')}}"><img src="{{ asset('admin/doctor/images/render_logo_white.svg') }}" alt="logo"/></a>
          <div class="collapse navbar-collapse" id="navbarSupportedContent">
              <div class="header_search my-2 my-lg-0 mr-auto">
                   <div class="notify">
                       Hi, {{$doctor_details->doctor_first_name}}. You’ve <b>@if(isset($today_appointments_count) && $today_appointments_count > 0){{ $today_appointments_count }}@else {{ "0" }}@endif appointments today</b>
                   </div>
             </div>
            <ul class="navbar-nav navbar_menu">
                <li class="nav-item notifications">
                  <a class="nav-link" href="javascript:;">
                      <span class="counter"></span>
                      <img src="{{ asset('admin/doctor/images/notifications.svg') }}" alt="Notifications">
                  </a>
                </li>
              <li class="nav-item dropdown profile_link">
                <a class="nav-link dropdown-toggle" href="javascript:;" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                  <span class="profile_image" style="background-image:url({{ asset('admin/doctor/uploads/profile/'.$doctor_details->doctor_picture) }});"></span>
                  Hi, &nbsp; <span class="username">{{$doctor_details->doctor_title}} {{$doctor_details->doctor_first_name}} {{$doctor_details->doctor_last_name}}</span>
                </a>
                <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdown">
                    <a class="dropdown-item" href="javascript:;"><span><img src="{{ asset('admin/doctor/images/help_center.svg') }}" alt="icon"></span>Help Center</a>
                     <a class="dropdown-item" href="{{ url('doctor/logout') }}"><span><img src="{{ asset('admin/doctor/images/logout.svg') }}" alt="icon"></span>Logout</a>
                </div>
              </li>
            </ul>
          </div>
        </nav>

        <div class="container-fluid">
            <div class="row flex-xl-nowrap">
              @yield('content')
              <div id="site_url" style="display:none">{{ url('/') }}</div>
            </div>
        </div>


        <script src="https://code.jquery.com/jquery-3.3.1.js" integrity="sha256-2Kok7MbOyxpgUVvAk/HJ2jigOSYS2auK4Pfzbm7uH60=" crossorigin="anonymous">
        </script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.0/umd/popper.min.js" integrity="sha384-cs/chFZiN24E4KMATLdqdvsezGxaGsi4hLGOzlXwp5UZB1LY//20VyM2taTB4QvJ" crossorigin="anonymous">
        </script>
        <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.0/js/bootstrap.min.js" integrity="sha384-uefMccjFJAIv6A+rW+L4AHf99KvxDjWSu1z9VI8SKNVmz4sk7buKt/6v9KI65qnm" crossorigin="anonymous">
        </script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/Swiper/4.3.5/js/swiper.min.js"></script>
        <script src="{{ asset('admin/doctor/js/bootstrap-datepicker.js') }}" type="text/javascript"></script>
        <script src="{{ asset('admin/doctor/js/prettyCheckable.min.js') }}"></script>
        <script src="{{ asset('admin/doctor/js/main.js') }}"></script>
        <script src="https://js.paystack.co/v1/inline.js"></script>
        <script src="{{ asset('admin/doctor/js/doctor_health_history.js') }}"></script>       
 @if(!isset($page_type) || (isset($page_type) && $page_type != 'health_history'))
            <script type="text/javascript"  src="{{ asset('admin/doctor/js/doctor_dashboard.js') }}"></script>
        @endif       
        @if(isset($page_type) && ($page_type == 'time_count' || $page_type == 'appointments'))
            <script type="text/javascript"  src="{{ asset('admin/doctor/js/first.js') }}"></script>
            <script type="text/javascript"  src="{{ asset('admin/doctor/js/appointments.js') }}"></script>
        @endif 

        @if(isset($page_type) && ($page_type == 'search' || $page_type == 'appoint_search'))
            <script type="text/javascript"  src="{{ asset('admin/doctor/js/first.js') }}"></script>            
        @endif 
        @if(isset($page_type) && ($page_type == 'health_history'))
            <script type="text/javascript"  src="{{ asset('admin/doctor/js/doctor_history_main.js') }}"></script>
        @endif  
        @if(isset($page_type) && ($page_type == 'settings'))
            <script type="text/javascript"  src="{{ asset('admin/doctor/js/doctor_settings.js') }}"></script>
        @endif
        @if(isset($page_type) && ($page_type == 'billing'))
            <script src="https://js.paystack.co/v1/inline.js"></script>
            <script type="text/javascript"  src="{{ asset('admin/doctor/js/doctor_billings.js') }}"></script>
        @endif 
  </body>
</html>