 @if(count($doctors_availability) > 0)
    @php           
        $count = 0;                                                     
        date_default_timezone_set($timezone);
    @endphp
        @foreach($doctors_availability as $key=>$availability) 
    @php

                      
              
    @endphp
                                <li>
                                   
                                    <label for="">{{$availability['availability_time']}}</label>
                                     <i class="fas fa-trash-alt availability_delete" id="{{$availability['availability_id']}}"></i>
                                </li>
    @php                             
           
                      
                
           
    @endphp                                                             
        @endforeach
    @else
    <!--  <li>
        <span>No available time set by doctor yet</span>
        
    </li> -->
@endif                                                          
