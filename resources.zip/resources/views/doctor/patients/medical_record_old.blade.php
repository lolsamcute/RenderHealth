@extends('layouts.doctor')
@section('content')

    <main class="col-12 col-md-12 col-xl-12 bd-content">
        <div class="main_div">
            <div class="row">
                <div class="col-12">
                    <div class="page_head">
                        <div class="patient">
                            <div class="patient_image">

                                @if($patient_detail['patient_profile_img'] != "")
                                    <img src="{{ asset('uploads/patient/'.$patient_detail['patient_profile_img']) }}" alt="image"/>
                                @else
                                    <img src="{{ asset('images/profile.svg') }}" alt="image"/>
                                @endif  
                            </div>
                            <div class="patient_detail">
                                <h2>
                                    @if($patient_detail['patient_gender'] == 1)
                                        @if($patient_detail['patient_martial_status'] == 1)
                                            {{ 'Mrs.' }}
                                        @else
                                            {{ 'Miss' }}
                                        @endif
                                    @else
                                        {{ 'Mr.'}}
                                    @endif
                                    {{ ucfirst($patient_detail['patient_first_name']).' '.ucfirst($patient_detail['patient_last_name']) }}</h2>
                                <span>PATIENT ID: Patient-{{ $patient_detail['patient_unique_id'] }}</span>
                            </div>
                        </div>
                        <div>
                        <a href="{{url('doctor/patients/add_new_record/'.$patient_detail['patient_unique_id'])}}" class="btn btn-primary btn-sm btn-medical">Add Medical Record</a> 

                        </div>
                    </div>
                </div>
            </div>

            @if(count($health_history) >0)    
                <div class="row">
                    <div class="col-12">
                        <div class="table_hospital pagination_fixed_bottom">
                        <div class="table-responsive">
                        <table class="table" cellspacing="10">
                            <tr>
                                <th>DATE</th>
                                <th>HOSPITAL </th>
                                <th>DOCTOR NAME</th>
                                <th>MEDICAL RECORD NUMBER</th>
                                <th></th>
                            </tr>
                            @foreach($health_history as $health_his)
                                <tr>

                                    <td>@if(date('Y-m-d' ,$health_his['created_date'])==date('Y-m-d'))
                                        {{ 'Today' }}<br>
                                        @elseif(date('Y-m-d' ,$health_his['created_date'])==date('Y-m-d',strtotime('+1 day')))
                                        {{ 'Tomorrow' }}<br>
                                        @endif
                                        {{ date('d F Y' ,$health_his['created_date']) }}
                                    </td>
                                    @if(!empty($health_his->doctor_id))                                
                                        <td>{{$health_his->doctor->doctor_hospital_details->hosp_name}}</td>
                                    @elseif(!empty($health_his->nurse_id))
                                        <td>{{$health_his->nurse->nurse_hospital_details->hosp_name}}</td>
                                    @elseif(!empty($health_his->employee_id))
                                        <td>{{$health_his->employee->employee_hospital_details->hosp_name}}</td>
                                    @elseif(!empty($health_his->hospital_id))
                                        <td>{{$health_his->hospital->hosp_name}}</td> 
                                    @endif
                                    <td>

                                        <div class="d_profile">
                                            @if(!empty($health_his->doctor_id))
                                            <div class="d_pro_img">
                                                    @php
                                        if(!empty($health_his->doctor->doctor_picture)){
                                        if(file_exists(getcwd().'/doctorimages/'.$health_his->doctor->doctor_picture)){
                                            @endphp
                                                            <img src="{{ asset('/doctorimages/'.$health_his->doctor->doctor_picture) }}" alt="image">
                                                    @php     }
                                                        else { @endphp
                                                            <img src="{{ asset('admin/doctor/images/profile.svg') }}" alt="image">
                                                    @php   }
                                                    }
                                                    else { @endphp
                                                            <img src="{{ asset('admin/doctor/images/profile.svg') }}" alt="image">
                                                    @php   }

                                                    @endphp
                                            </div>
                                            <div class="d_pro_text">
                                                <h4> @if($health_his->doctor->doctor_gender === 0) Mr.
                                                @elseif($health_his->doctor->doctor_gender== 1 && $health_his->doctor->marital_status== 1)Mrs
                                                @elseif($health_his->doctor->doctor_gender== 1) Miss
                                                    @endif 
                                                    {{$health_his->doctor->doctor_first_name}} {{$health_his->doctor->doctor_last_name}}</h4>
                                                <!--  <a href="javascript:;">View Profile</a> -->
                                            </div>
                                            @elseif(!empty($health_his->nurse_id))
                                                <div class="d_pro_img">
                                                    @if(!empty($health_his->nurse->nurse_picture))
                                                        <img src="{{ asset('admin/nurse/uploads/profile/'.$health_his->nurse->nurse_picture) }}" alt="image">                               
                                                    @else
                                                        <img src="{{ asset('admin/nurse/images/profile.svg') }}" alt="image">                                                
                                                    @endif
                                            </div>
                                            <div class="d_pro_text">
                                                <h4>Mr. {{$health_his->nurse->nurse_first_name}} {{$health_his->nurse->nurse_last_name}}</h4>
                                                <a href="javascript:;">View Profile</a>
                                            </div>
                                            @elseif(!empty($health_his->employee_id))
                                                <div class="d_pro_img">
                                                    @if(!empty($health_his->employee->employee_picture))
                                                        <img src="{{ asset('admin/employee/uploads/profile/'.$health_his->employee->employee_picture) }}" alt="image">                               
                                                    @else
                                                        <img src="{{ asset('admin/employee/images/profile.svg') }}" alt="image">                                                
                                                    @endif
                                            </div>
                                            <div class="d_pro_text">
                                                <h4>Mr. {{$health_his->employee->employee_first_name}} {{$health_his->employee->employee_last_name}}</h4>
                                                <a href="javascript:;">View Profile</a>
                                            </div>
                                            @elseif(!empty($health_his->hospital_id))
                                                <div class="d_pro_img">
                                                    @if(!empty($health_his->hospital->hospital_picture))
                                                        <img src="{{ asset('admin/hospital/uploads/profile/'.$health_his->hospital->hospital_picture) }}" alt="image">                               
                                                    @else
                                                        <img src="{{ asset('admin/hospital/images/profile.svg') }}" alt="image">                                                
                                                    @endif
                                            </div>
                                            <div class="d_pro_text">
                                                <h4>{{$health_his->hospital->hosp_name}}</h4>
                                                <a href="javascript:;">View Profile</a>
                                            </div>
                                            @endif
                                        </div>
                                    </td>
                                        <td>MRN-{{$health_his->history_id}}</td>
                                        <td>
                                            <a href="{{ url('doctor/patients/view_record/'.$health_his->history_id) }}" class="btn btn-light btn-xs mr-2" name="button"><img class="icon" src="{{ asset('admin/doctor/images/eye.svg') }}" alt="icon">View Detail</a>
                                            <div class="dropdown d-inline-block">
                                            <a class="option no_caret btn-xs dropdown-toggle" href="javascript:;" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                                <img src="{{ asset('admin/doctor/images/options.svg') }}" alt="icon"/>
                                            </a>
                                            <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdown">
                                                <a class="dropdown-item" href="javascript:;" onclick="billingInfo(this); return false;" data-id="{{$health_his->history_id}}"><span><img src="{{ asset('admin/doctor/images/billling.svg') }}" alt="icon"></span>Billing Info</a>
                                                <a class="dropdown-item" href="{{url('doctor/edit_medical_record/'. $health_his->history_id)}}"><span><img src="{{ asset('admin/doctor/images/enter.svg') }}" alt="icon"></span>Enter Record</a>
                                            </div>
                                        </div>
                                        </td>
                                </tr>
                                @endforeach                       
                        </table>
                        </div>
                        <div class="table_pagination">
                            <button type="button" class="btn btn-light btn-xs pre1" <?php if($health_history->previousPageUrl()){  } else{ echo "disabled"; } ?> data-url="<?php echo $health_history->previousPageUrl(); ?>">Previous Page</button>
                            <span>Page {{ $health_history->currentPage() }} of {{ $health_history->lastPage() }} Pages</span>
                            <button type="button" class="btn btn-light btn-xs next1"  <?php if($health_history->nextPageUrl()){  } else{ echo "disabled"; } ?>  data-url="<?php echo $health_history->nextPageUrl(); ?>">Next Page</button>
                            </div>
                        </div>
                    </div>
                </div>
            @else
                <div class="row">
                    <div class="col-12">
                        <div class="widget padding-40">
                            <div class="empty_record">
                                <img src="{{ asset('admin/doctor/images/no_record.svg') }}" alt="icon">
                                <h3>This Patient doesn’t have medical record history before</h3>
                                <p>Please add new medical record on the top right button of this page</p>
                            </div>
                        </div>
                    </div>
                </div>
            @endif
        </div>
    </main>

@endsection