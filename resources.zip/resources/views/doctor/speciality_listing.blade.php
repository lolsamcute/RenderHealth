@extends('layouts.doctor')

@section('content')
<main class="col-12 col-md-12 col-xl-12 bd-content-center">
    <div class="row">
        <div class="col-12">
            <div class="page_head">
                <div class="">
                    <h1 class="heading">Telemedical appointment</h1>
                    <h4>No Doctors available for this consultation</h4>
                </div>

                <div class="dropdown dropdown_widgetin">
                     <button type="button" class="btn btn-black dropdown-toggle text-capitalize btn-sm" data-toggle="dropdown">
                       All Doctor Specialist
                     </button>
                     <div class="dropdown-menu">
                       @if(count($speciality_detail) > 0)
                            @foreach($speciality_detail as $speciality)
                               <a class="dropdown-item" href="javascript:void(0);" data-patient_id="{{ $pid}}" data-id="{{ $speciality['speciality_id'] }}" data-appoint_id="{{ $appointment_id }}"" onclick="specialityimmediatebooking(this); return false;">{{ $speciality['speciality_name']}}</a>
                             @endforeach
                        @endif
                     </div>
                </div>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-12">
                <div class="widget widget_body mb-3">
                    <div class="no_data">
                           <img src="{{ asset('images/no_data.svg') }}" alt="images">
                           <h4>No Doctor Available, Please Select speciality</h4>
                       </div>
                </div>

        </div>
    </div>
</main>
@endsection