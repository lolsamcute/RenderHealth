<div class="row">
    <div class="col-12">
        <div class="page_head">
            <div class="">
                <h1 class="heading">Telemedical appointment</h1>
                @php $inc=0 @endphp
                @php $val=0 @endphp
                <h4>@if(count($doctors) > 0)                        
                    @foreach($doctors as $key1=>$doctor)
                        @if(count($doctor['doctor_availability']) > 0)
                            @php                                                                
                                date_default_timezone_set($timezone);
                            @endphp
                                @foreach($doctor['doctor_availability'] as $key=>$availability) 
                            @php
                                    $availability_time = $availability['availability_time'];               
                                    $availability = explode("-",$availability_time[0]); 
                                    $start_time = date('Y-m-d H:i',$availability[0]);                               
                                    $end_time = date('Y-m-d H:i',$availability[1]);                                         
                                    $begin = new DateTime($start_time);
                                    $end   = new DateTime($end_time);
                                    $interval = DateInterval::createFromDateString('1 hour');
                                    $times    = new DatePeriod($begin, $interval, $end);
                                    foreach ($times as $i_key => $time) {                                                           
                                        if(date("Y-m-d H:i",strtotime($time->format("Y-m-d H:i")))  >= date('Y-m-d H:i')){
                                            $val =1;
                                        }
                                    }                                       
                            @endphp
                                @endforeach
                        @endif
                        @if($val == 1)
                            @php $inc++; @endphp
                        @endif
                    @endforeach
                @endif
                @if($inc > 0) {{ $inc }} @if($inc == 1){{ "Doctor available for consultation"}} @else{{ "Doctors available for consultation" }} @endif @else {{ "No Doctors available for consultation"}} @endif
                </h4>
            </div>
            @if($type == 2)
                <div class="dropdown dropdown_widgetin">
                     <button type="button" class="btn btn-black dropdown-toggle text-capitalize btn-sm selected_speciality" data-toggle="dropdown">
                       All Doctor Specialist
                     </button>
                     <div class="dropdown-menu">
                        <a class="dropdown-item speciality_list" href="javascript:void(0);" data-id="" data-appoint_id="{{ $id }}" data-type="{{ $type }}" data-patient_id="{{ $pid }}" data-date="{{ $date }}" onclick="specialityfuturebooking(this); return false;">All doctor Specialist</a>
                       @if(count($speciality_detail) > 0)
                        
                        @foreach($speciality_detail as $speciality)
                           <a class="dropdown-item speciality_list" href="javascript:void(0);" data-id="{{ $speciality['speciality_id'] }}" data-patient_id="{{ $pid }}" data-appoint_id="{{ $id }}" data-type="{{ $type }}" data-date="{{ $date }}" onclick="specialityfuturebooking(this); return false;">{{ $speciality['speciality_name']}}</a>
                         @endforeach
                    @endif
                     </div>
                </div>
            @endif
        </div>
    </div>
</div>
<div class="row">
    <div class="col-12">
        @if(count($doctors) > 0)
            <div id="accordion" class="widget_doctor">
                @php $count=1 @endphp
                @php $index=0 @endphp
                @foreach($doctors as $key1=>$doctor)
                    @if(count($doctor['doctor_availability']) > 0)
                        @php                                                                
                            date_default_timezone_set($timezone);
                        @endphp
                            @foreach($doctor['doctor_availability'] as $key=>$availability) 
                        @php
                                $availability_time = $availability['availability_time'];               
                                $availability = explode("-",$availability_time[0]); 
                                $start_time = date('Y-m-d H:i',$availability[0]);                               
                                $end_time = date('Y-m-d H:i',$availability[1]);                                         
                                $begin = new DateTime($start_time);
                                $end   = new DateTime($end_time);
                                $interval = DateInterval::createFromDateString('1 hour');
                                $times    = new DatePeriod($begin, $interval, $end);
                                foreach ($times as $i_key => $time) {                                                           
                                    if(date("Y-m-d H:i",strtotime($time->format("Y-m-d H:i")))  >= date('Y-m-d H:i')){
                                        $index++;
                                    }
                                }                                       
                            @endphp
                            @endforeach
                        @endif      
                        @if($index > 0)                                 
                            <div class="widget widget_body mb-3">
                                <div class="widget_doctor_list" id="heading{{($key1+1)}}">
                                    <button class="widget_doctor_list_button collapsed" data-toggle="collapse" data-target="#collapse{{($key1+1)}}" aria-expanded="true" aria-controls="collapse{{($key1+1)}}">
                                       <img src="{{ asset('images/open.svg') }}" alt="open">
                                       <img src="{{ asset('images/close.svg') }}" alt="close">
                                    </button>
                                    <div class="doctor_list">
                                        <div class="doc_detail">
                                            <div class="doc_data_outer">
                                                <div class="doc_name">
                                                    <div class="doc_img">
                                                        <img src="{{ asset('admin/doctor/uploads/profile/'.$doctor['doctor_picture']) }}" alt="image">
                                                    </div>
                                                    <div class="doc_desc">
                                                        <h5>Dr. {{ $doctor['doctor_first_name'] }} {{ $doctor['doctor_last_name'] }}, {{ $doctor['doctor_degree'] }}</h5>
                                                        <a href="javascript:;">{{ $doctor['specialist_categories']['speciality_name'] }} </a>
                                                    </div>
                                                </div>
                                                <div class="doc_experience">
                                                    <img src="{{ asset('images/briefcase.svg') }}" alt="icon">Praticing for {{ $doctor['doctor_years_practised'] }} years
                                                </div>
                                            </div>
                                            <div class="doc_other_outer">
                                                <div class="doc_other">
                                                    <h6>Languages</h6>
                                                    <h4>{{ $doctor['doctor_languages'] }}</h4>
                                                </div>
                                                <div class="doc_other">
                                                    <h6>Education</h6>
                                                    <h4>{{ $doctor['doctor_education_school'] }}</h4>
                                                </div>
                                            </div>
                                            <div class="doc_other_outer">
                                                <div class="doc_other">
                                                    <h6>Religion</h6>
                                                    <h4>{{ $doctor['doctor_religion'] }}</h4>
                                                </div>
                                                <div class="doc_other">
                                                    <h6>Ethnicity</h6>
                                                    <h4>{{ $doctor['doctor_ethnicity'] }}</h4>
                                                </div>
                                            </div>

                                        </div>


                                    </div>

                                </div>
                                <div id="collapse{{($key1+1)}}" class="collapse main_data" aria-labelledby="heading{{($key1+1)}}" data-parent="#accordion">
                                    <div class="doc_extra_detail widget_profile">
                                        <div class="doc_data">
                                            <div class="doc_appoint_date no_caret">
                                                    {{date('j F Y', strtotime($date)) }}
                                             </div>
                                            <div class="time_indicators">
                                                <ul>
                                                    <li>
                                                        <span class="red"></span> Not Available
                                                    </li>
                                                    <li>
                                                        <span class="green"></span> Available
                                                    </li>
                                                </ul>
                                            </div>
                                        </div>                                              
                                        <div class="doc_appoint_time">                                                  
                                            <ul>    
                                                @if(count($doctor['doctor_availability']) > 0)
                                                @php                                                                
                                                    date_default_timezone_set($timezone);
                                                @endphp
                                                    @foreach($doctor['doctor_availability'] as $key=>$availability) 
                                                @php
                                                        $availability_time = $availability['availability_time'];               
                                                        $availability = explode("-",$availability_time[0]); 
                                                        $start_time = date('Y-m-d H:i',$availability[0]);                               
                                                        $end_time = date('Y-m-d H:i',$availability[1]);                                         
                                                        $begin = new DateTime($start_time);
                                                        $end   = new DateTime($end_time);
                                                        $interval = DateInterval::createFromDateString('1 hour');
                                                        $times    = new DatePeriod($begin, $interval, $end);
                                                        foreach ($times as $i_key => $time) {                                                           
                                                            if(date("Y-m-d H:i",strtotime($time->format("Y-m-d H:i")))  >= date('Y-m-d H:i')){      
                                                            if(count($doctor['doctor_availability']) == ($key+1) && ($i_key+1) == count($availability)){        if($time->format("Y-m-d H:i") <= $end->sub($interval)->format('Y-m-d H:i')){        
                                                                    if(count($doc_appoint_listing) > 0){
                                                                    $inc =0;
                                                                        foreach($doc_appoint_listing as $doc_appoint){
                                                                            if($doctor['doctor_id'] == $doc_appoint['doctor_id']){
                                                                                if(date("H:i",strtotime($time->format("Y-m-d H:i"))) ==  date('H:i',$doc_appoint['appointment_time'])){
                                                                                    $inc = 1;
                                                                                }
                                                                            }
                                                                        }
                                                                        if($inc == 1){                                                                                      
                                                        @endphp
                                                                            <li>
                                                                                <input id="time{{$count}}" type="radio" name="doctor_apponitment_time{{($key1+1)}}" class="doctor_apponitment_time" value='{{ encrypt(date("h:i A",strtotime($time->format("Y-m-d H:i")))) }}' data-doctor_id="{{ $doctor['doctor_id'] }}" data-appoint_id="{{$id}}" disabled>
                                                                                <label for="time{{$count}}">{{ date("h:i A",strtotime($time->format("Y-m-d H:i"))) }}</label>
                                                                            </li>
                                                @php                        }else{
                                                 @endphp                        
                                                                            <li>
                                                                                <input id="time{{$count}}" type="radio" name="doctor_apponitment_time{{($key1+1)}}" class="doctor_apponitment_time" value='{{ encrypt(date("h:i A",strtotime($time->format("Y-m-d H:i")))) }}' data-doctor_id="{{ $doctor['doctor_id'] }}" data-patient_id="{{ $pid }}" data-appoint_id="{{$id}}" onclick="futuretelemedical(this); return false;">
                                                                                <label for="time{{$count}}">{{ date("h:i A",strtotime($time->format("Y-m-d H:i"))) }}</label>
                                                                            </li>
                                                @php                            
                                                                        }
                                                                    }else{
                                                @endphp
                                                                    <li>
                                                                        <input id="time{{$count}}" type="radio" name="doctor_apponitment_time{{($key1+1)}}" class="doctor_apponitment_time" value='{{ encrypt(date("h:i A",strtotime($time->format("Y-m-d H:i")))) }}' data-doctor_id="{{ $doctor['doctor_id'] }}" data-patient_id="{{ $pid }}" data-appoint_id="{{$id}}" onclick="futuretelemedical(this); return false;">
                                                                        <label for="time{{$count}}">{{ date("h:i A",strtotime($time->format("Y-m-d H:i"))) }}</label>
                                                                    </li>   
                                               @php
                                                                    }
                                                                }
                                                            }else if($time->format("Y-m-d H:i") <= $end){   
                                                                if(count($doc_appoint_listing) > 0){
                                                                    $index =0;
                                                                    foreach($doc_appoint_listing as $doc_appoint){                                          
                                                                        if($doctor['doctor_id'] == $doc_appoint['doctor_id']){                          
                                                                            if(date("H:i",strtotime($time->format("Y-m-d H:i"))) ==  date('H:i',$doc_appoint['appointment_time'])){
                                                                                $index = 1;
                                                                            }
                                                                        }
                                                                    }
                                                                    if($index == 1){                                                    
                                                @endphp
                                                                        <li>
                                                                            <input id="time{{$count}}" type="radio" name="doctor_apponitment_time{{($key1+1)}}" class="doctor_apponitment_time" value='{{ encrypt(date("h:i A",strtotime($time->format("Y-m-d H:i")))) }}' data-doctor_id="{{ $doctor['doctor_id'] }}" data-appoint_id="{{$id}}" disabled>
                                                                            <label for="time{{$count}}">{{ date("h:i A",strtotime($time->format("Y-m-d H:i"))) }}</label>
                                                                        </li>

                                                @php                }else{
                                                @endphp
                                                                        <li>
                                                                            <input id="time{{$count}}" type="radio" name="doctor_apponitment_time{{($key1+1)}}" class="doctor_apponitment_time" value='{{ encrypt(date("h:i A",strtotime($time->format("Y-m-d H:i")))) }}' data-doctor_id="{{ $doctor['doctor_id'] }}" data-patient_id="{{ $pid }}" data-appoint_id="{{$id}}" onclick="futuretelemedical(this); return false;">
                                                                            <label for="time{{$count}}">{{ date("h:i A",strtotime($time->format("Y-m-d H:i"))) }}</label>
                                                                        </li>

                                                @php                }
                                                                }else{
                                                @endphp
                                                                    <li>
                                                                        <input id="time{{$count}}" type="radio" name="doctor_apponitment_time{{($key1+1)}}" class="doctor_apponitment_time" value='{{ encrypt(date("h:i A",strtotime($time->format("Y-m-d H:i")))) }}' data-doctor_id="{{ $doctor['doctor_id'] }}" data-patient_id="{{ $pid }}" data-appoint_id="{{$id}}" onclick="futuretelemedical(this); return false;">
                                                                        <label for="time{{$count}}">{{ date("h:i A",strtotime($time->format("Y-m-d H:i"))) }}</label>
                                                                    </li>
                                                @php
                                                                }
                                                                $time->add($interval)->format('Y-m-d H:i');                                                     
                                                            }                                                                       
                                                            $count++;
                                                        } 
                                                    }  
                                            @endphp                                                             
                                                @endforeach
                                            @else
                                             <li>
                                                <span>No available time set by doctor yet</span>
                                                
                                            </li>
                                        @endif                                                      
                                    </ul>                                                   
                                </div>                                             
                            </div>                                      
                        </div>
                    </div>
                    @endif
                @endforeach                                                    
            </div>
            @else
                <div class="widget widget_body mb-3">
                    <div class="no_data">
                        <img src="{{ asset('images/no_data.svg') }}" alt="images">
                        <h4>No Doctor Available</h4>
                    </div>
                </div>
        @endif
    </div>
</div>