
@extends('layouts.doctor')
@section('content')
 <main class="col-12 col-md-12 col-xl-12 bd-content">
    <div class="row">
        <div class="col-12">
            <div class="page_head">
                <h1 class="heading">Patient search results</h1>
                @php  date_default_timezone_set($timezone); @endphp
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-12">
            <div class="widget widget_search mb-4">
                <form class="search_content" action="search_patient">                             
                <?php $emp ="-";?>
                    <dl>
                      <dt>First Name :</dt>
                      <dd>@if(!empty($form_data['patient_name'])){{$form_data['patient_name']}}@else{{'----'}}@endif</dd>
                    </dl>
                    <dl>
                      <dt>Surname :</dt>
                      <dd>@if(!empty($form_data['surename'])){{$form_data['surename']}}@else{{'----'}}@endif</dd>
                    </dl>
                    <dl>
                      <dt>Date of Birth :</dt>
                       <dd>@if(!empty($form_data['dob']))  @php    $date = str_replace('/', '-', $form_data['dob']);  echo date('d F,Y',strtotime($date)) @endphp @else{{'----'}}@endif</dd>
                    </dl>
                    <dl>
                      <dt>Patient ID</dt>
                      <dd>@if(!empty($form_data['medical_record'])){{$form_data['medical_record']}}@else{{'----'}}@endif</dd>
                    </dl>
                    <dl>
                     <button type="button" id="page_url_change" class="btn btn-primary btn-sm">Change Search</button>
                    </dl>
                    
                </form>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-12">
            <div class="table_hospital">
                <table class="table" cellspacing="10">
                    <tr>
                        <th>First NAME</th>
                        <th>SURNAME</th>
                        <th>DATE OF BIRTH</th>
                        <th>PATIENT ID</th>
                        <th></th>
                    </tr>
                      @foreach($result as $results)
                        <tr>
                        <td>
                            <div class="d_profile">
                                <div class="d_pro_img">
                                    @if(!empty($results->patient_profile_img))
                                      <img src="{{ asset('uploads/patient/'.$results->patient_profile_img) }}" alt="image">                                                 
                                    @else
                                      <img src="{{ asset('images/profile.svg') }}" alt="image">                                                      
                                    @endif
                                    
                                </div>
                                <div class="d_pro_text">
                                    <h4>{{$results->patient_first_name}} </h4>
                                   
                                </div>
                            </div>
                        </td>
                        <td>{{$results->patient_last_name}}</td>
                       
                        <td>
                          @if(!empty($results->patient_date_of_birth))
                            {{date('j F Y',$results->patient_date_of_birth)}}
                          @else
                            {{ "-" }}
                          @endif
                        </td>                                        
                        <td>PATIENT-{{$results->patient_unique_id}}</td>
                        <td>
                      <a href="{{url('doctor/medical_records/'.$results->patient_unique_id)}}" class="btn btn-light btn-xs mr-2 <?php if(($doctor_details->health_record_access==0)){ echo 'disabled_cancel'; } ?>" name="button"><img class="icon" src="{{asset('admin/doctor/images/eye.svg')}}" alt="icon">View Record(s)</a>
                             <div class="dropdown d-inline-block">
                              <a class="option no_caret btn-xs dropdown-toggle" href="javascript:;" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                <img src="{{asset('admin/doctor/images/options.svg')}}" alt="icon"/>
                              </a>
                              <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdown">
                                  <a class="dropdown-item <?php if(($doctor_details->billings_access==0)){ echo 'disabled_cancel'; } ?>" href="{{url('doctor/view_all_billings/'.$results->patient_unique_id)}}"><span><img src="{{ asset('admin/nurse/images/billling.svg') }}" alt="icon"></span>Billing Info</a>
                                  <a class="dropdown-item <?php if(($doctor_details->health_record_access==0)){ echo 'disabled_cancel'; } ?>" href="{{url('doctor/add_new_record/'.$results->patient_unique_id)}}"><span><img src="{{ asset('admin/nurse/images/enter.svg') }}" alt="icon"></span>Enter Record</a>
                                   <a class="dropdown-item" href="javascript:;" data-patient_id="{{$results->patient_unique_id}}" onclick="scheduleAppointment(this); return false;"><span><img src="{{asset('admin/doctor/images/schedule.svg')}}" alt="icon"></span>Schedule Appointment</a>
                              </div>
                          </div>
                        </td>
                    </tr>
                   @endforeach
                </table>
                     <div class="table_pagination">
                   <span>                   
                         {{$result->appends(Request::except('page'))->links('pagination.search')}}
                    </span>
               </div>
            </div>
        </div>
    </div>
</main>

<!-- reschedule screen -->
<div class="modal fade" id="schedule_appointment">
    <div class="modal-dialog modal-md modal-dialog-centered genmodal genmodal_custom custom_width855">
        <div class="modal-content">
            <div class="modal-header">
                <h3>Add Appointment</h3>
                <button type="button" class="close" data-dismiss="modal"><img src="{{ asset('images/popup_close.svg') }}"/></button>
            </div>
            <div class="modal-body schedule_detail">                
            </div>
        </div>
    </div>
</div>

<!-- teleconsultation reschedule screen -->
<div class="modal fade" id="schedule_appointment_teleconsultation">
    <div class="modal-dialog modal-md modal-dialog-centered genmodal genmodal_custom custom_width675">
        <div class="modal-content">
            <div class="modal-header">
                <h3>Schedule Telelconsultation Appointment</h3>
                <button type="button" class="close" data-dismiss="modal"><img src="{{ asset('images/popup_close.svg') }}"/></button>
            </div>
            <div class="modal-body">
                <div class="consultation py-3 mb-3 first_step" style="display:none;">
                   <!--  <div class="consult_type ">
                        <img src="{{ asset('images/video_consult.svg') }}" alt="icon">
                        <h5>Video Consultation</h5>
                        <p>You can make conversation use our Video call API</p>
                        <button type="button" class="btn btn-black btn-sm text-capitalize consult_btn" name="button" data-id="Video">Use Video Call</button>
                    </div> -->
                   <!--  <div class="consult_type">
                        <img src="{{ asset('images/audio_consult.svg') }}" alt="icon">
                        <h5>Audio Consultation</h5>
                        <p>You can make conversation with call doctor’s number</p>
                        <button type="button" class="btn btn-black btn-sm text-capitalize consult_btn" name="button" data-id="Audio">Use Phone Call</button>
                    </div> -->
                </div>
                <div class="consultation py-2 mb-3 second_step">
                    <div class="video_consult_detail">
                        <img src="{{ asset('images/video_consult.svg') }}" alt="icon">
                        <h5 class="second_head">Video Consultation</h5>
                        <!-- <p>You can make conversation use our Video call API</p> -->
                        <input type="hidden" class="second_text" value="Video">
                        <div class="form-group">
                            <div class="alert alert-danger-outline alert-dismissible alert_icon fade show error_msg select_fxwidth mb-3 text-left" id="error_msg" role="alert" style="display:none;">
                                <div class="d-flex align-items-center">
                                    <div class="alert-icon-col">
                                        <span class="fa fa-warning"></span>
                                    </div>
                                    <div class="alert_text error_text">
                                        Email field is required
                                    </div>
                                    <a href="#" class="close alert_close" data-dismiss="alert" aria-label="close"><i class="fa fa-close"></i></a>
                                </div>
                            </div>
                             <div class="select_box select_fxwidth mb-2">
                                 <select class="form-control consult_type1" name="consult_type" onchange="disableoption(this)">
                                    <option value="1">General Consultation</option>
                                    <option value="2">Speciality Consultation</option> 
                                 </select>
                             </div>
                             <div class="select_box select_fxwidth">
                                 <select class="form-control consult_time" name="consult_time">
                                     <option value="1" data-id="1">Immediate Appointment</option>
                                     <option value="2" data-id="2">Future Appointment</option>                                     
                                 </select>
                             </div>
                        </div>
                        <button type="button" class="btn btn-primary find_doctor" name="button" onclick="savetelemedicaldetails(this); return false;" data-patient_id="">Find Doctor</button>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>


<!-- set availability screen -->
<div class="modal fade" id="future_appointment">
    <div class="modal-dialog modal-md modal-dialog-centered genmodal setup_availability">
        <div class="modal-content">
            <div class="modal-header">
                <h3>Schedule Telelconsultation Appointment</h3>
                <button type="button" class="close" data-dismiss="modal"><img src="{{ asset('images/popup_close_w.svg') }}"/></button>
            </div>
            <div class="modal-body">
             <div class="consult_detail">
                 <div class="picker">
                     <div class="datepicker_input mb-2 tele_appoint" data-date="{{date('d F Y')}}" data-date-format="dd-mm-yyyy"></div>
                 </div>

                <div class="text-center mt-2">
                    <button type="button" class="btn btn-primary appointment_next" name="button" data-patient_id="" data-appoint_id="2651113391" data-consult_type="1" onclick="appointemntnext(this); return false;">Next</button>
                </div>
              </div>
            </div>
        </div>
    </div>
</div>

@endsection