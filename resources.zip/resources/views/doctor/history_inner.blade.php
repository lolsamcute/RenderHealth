<div class="row">
    <div class="col-12">
        <div class="page_head">
            <div class="patient">
                <div class="patient_image">
                    @if($patient_detail['patient_profile_img'] != "")
                        <img src="{{ asset('uploads/patient/'.$patient_detail['patient_profile_img']) }}" alt="image"/>
                    @else
                        <img src="{{ asset('images/profile.svg') }}" alt="image"/>
                    @endif  
                </div>
                <div class="patient_detail">
                    <h2>
                        @if($patient_detail['patient_gender'] == 1)
                            @if($patient_detail['patient_martial_status'] == 1)
                                {{ 'Mrs.' }}
                            @else
                                {{ 'Miss' }}
                            @endif
                        @else
                            {{ 'Mr.'}}
                        @endif
                        {{ ucfirst($patient_detail['patient_first_name']).' '.ucfirst($patient_detail['patient_last_name']) }}</h2>
                    <span>PATIENT ID: Patient-{{ $patient_detail['patient_unique_id'] }}</span>
                </div>
            </div>
            <div>
                 <a href="{{url('doctor/add_new_record/'.$patient_detail['patient_unique_id'])}}" class="btn btn-primary btn-sm btn-medical">Add Medical Record</a>
            </div>
        </div>
    </div>
</div>
@if(count($health_history) >0)    
    <div class="row">
        <div class="col-12">
            <div class="table_hospital pagination_fixed_bottom">
                <div class="table-responsive">
               <table class="table" cellspacing="10">
                   <tr>
                       <th>DATE</th>
                       <th>HOSPITAL </th>
                       <th>DOCTOR NAME</th>
                       <th>MEDICAL RECORD NUMBER</th>
                       <th></th>
                   </tr>
                   @foreach($health_history as $health_his)
                       <tr>
                           <td>@if(date('Y-m-d' ,$health_his['created_date'])==date('Y-m-d'))
                            {{ 'Today' }}<br>
                            @elseif(date('Y-m-d' ,$health_his['created_date'])==date('Y-m-d',strtotime('+1 day')))
                            {{ 'Tomorrow' }}<br>
                            @endif
                            {{ date('d F Y' ,$health_his['created_date']) }}
                        </td>
                           <td>{{$health_his->doctor->doctor_hospital_details->hosp_name}}</td>
                           <td>
                               <div class="d_profile">
                                   <div class="d_pro_img">
                                        @if(!empty($health_his->doctor->doctor_picture))
                                            <img src="{{ asset('admin/doctor/uploads/profile/'.$health_his->doctor->doctor_picture) }}" alt="image">                               
                                        @else
                                            <img src="{{ asset('admin/doctor/images/profile.svg') }}" alt="image">                                                
                                        @endif
                                   </div>
                                   <div class="d_pro_text">
                                       <h4>Mr. {{$health_his->doctor->doctor_first_name}} {{$health_his->doctor->doctor_last_name}}</h4>
                                       <a href="javascript:;">View Profile</a>
                                   </div>
                               </div>
                           </td>
                            <td>ID-Patient-{{$health_his->history_id}}</td>
                            <td>
                                <a href="{{ url('doctor/view_record/'.$health_his->history_id) }}" class="btn btn-light btn-xs mr-2" name="button"><img class="icon" src="{{ asset('admin/doctor/images/eye.svg') }}" alt="icon">View Detail</a>
                                 <div class="dropdown d-inline-block">
                                  <a class="option no_caret btn-xs dropdown-toggle" href="javascript:;" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                    <img src="{{ asset('admin/doctor/images/options.svg') }}" alt="icon"/>
                                  </a>
                                  <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdown">
                                      <a class="dropdown-item" href="javascript:;"><span><img src="{{ asset('admin/doctor/images/billling.svg') }}" alt="icon"></span>Billing Info</a>
                                      <a class="dropdown-item" href="javascript:;"><span><img src="{{ asset('admin/doctor/images/enter.svg') }}" alt="icon"></span>Enter Record</a>
                                      <a class="dropdown-item" href="javascript:;"><span><img src="{{ asset('admin/doctor/images/schedule.svg') }}" alt="icon"></span>Schedule Appointment</a>
                                  </div>
                              </div>
                            </td>
                       </tr>
                    @endforeach                       
               </table>
             </div>
               <div class="table_pagination">
                   <button type="button" class="btn btn-light btn-xs pre1" <?php if($health_history->previousPageUrl()){  } else{ echo "disabled"; } ?> data-url="<?php echo $health_history->previousPageUrl(); ?>">Previous Page</button>
                   <span>Page {{ $health_history->currentPage() }} of {{ $health_history->lastPage() }} Pages</span>
                   <button type="button" class="btn btn-light btn-xs next1"  <?php if($health_history->nextPageUrl()){  } else{ echo "disabled"; } ?>  data-url="<?php echo $health_history->nextPageUrl(); ?>">Next Page</button>
                </div>
            </div>
        </div>
    </div>
@endif