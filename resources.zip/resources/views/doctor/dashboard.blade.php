@extends('layouts.doctor')
@section('content')
<main class="col-12 col-md-12 col-xl-12 bd-content">
	<div class="row">
		<div class="col-12">
			<div class="page_head">
				<h1 class="heading">Dashboard Overview</h1>
			</div>
		</div>
		<div class="col-12">
			<div class="action_container">
				<div class="action_box">
					<a href="{{ asset('doctor/search_patient') }}" class="action action_schedule">
						<div class="action_icon">
							<img src="{{ asset('admin/doctor/images/plus_date.svg') }}" alt="icon">
						</div>
						<div class="action_text">
							<h3>New Schedule</h3>
							<p>appointment with member</p>
						</div>
					</a>
				</div>
				<div class="action_box doctor_availabilitybtn">
					<a href="javascript:;" data-toggle="modal" data-target="#setup_availability" class="action action_availability" >
						<div class="action_icon">
							<img src="{{ asset('admin/doctor/images/setup.svg') }}" alt="icon">
						</div>
						<div class="action_text">
							<h3>Enter Availablity</h3>
						<p> </p>
						</div>
					</a>
				</div>
				<div class="action_box">
					<a href="javascript:;" class="action action_patient">
						<div class="action_text">
							<h2>{{$patient_count}}</h2>
							<h5>Completed Appointments</h5>
						</div>
					</a>
				</div>
				<div class="action_box">
					<a href="javascript:;" class="action action_appointment">
						<div class="action_text">
							<h2>{{$appointment_cnt}}</h2>
							<h5>Appointment</h5>
						</div>
					</a>
				</div>
			</div>
		</div>
	</div>

	<div class="row">
		<div class="col-12">
		<div class="table_head">Upcoming Appointment</div>
			<div class="table_hospital">
				<table class="table appointment_scehdule" cellspacing="10">
					<tr>
						<th>DATE</th>
						<th>TYPE OF APPOINTMENT</th>
						<th>Member profile</th>
						<th>TIME SCHEDULED</th>
						<th></th>
					</tr>
					<input type="hidden" name="url" id="url" value="{{ url('/') }}">
						@php date_default_timezone_set($timezone); @endphp
					@if(count($appointments) > 0) 
					@php date_default_timezone_set($timezone); @endphp
					@php $i = 1; @endphp
					@foreach($appointments as $key=>$appointment)
					<tr>
						
						<td>@if(date('Y-m-d' ,$appointment['appointment_time'])==date('Y-m-d'))
							{{ 'Today' }},
							@elseif(date('Y-m-d' ,$appointment['appointment_time'])==date('Y-m-d',strtotime('+1 day')))
							{{ 'Tomorrow' }},
							@endif
							{{ date('d F Y' ,$appointment['appointment_time']) }}
						</td>
						<td>
							@if($appointment['appointment_type']==2)
								<div class="med_center">	
									<h5>{{ $appointment['hospital_name'] }}</h5>
									<input type="hidden" class="a_id" name="a_id" id="a_id" value="{{$appointment['appointment_id']}}"> 
							   		<input type="hidden" class="doctor_id" name="doctor_id" id="doctor_id" value="123456"> 
							   		<input type="hidden" class="p_id" name="p_id" id="p_id" value="{{$appointment['patient_id']}}">
									<span id="table_date{{($i)}}" class="appt_time" style="display: none;">{{ $appointment['appointment_time'] }}</span>
									<p>{{ 'Hospital Appointment' }}</p>
								</div>
							@else
								<div class="tel_center">
                                    <h5><img src="{{ asset('admin/doctor/images/tele_video.svg') }}" alt="icon">Teleconsultan Call</h5>
                                    <input type="hidden" class="a_id" name="a_id" id="a_id" value="{{$appointment['appointment_id']}}"> 
						   			<input type="hidden" class="doctor_id" name="doctor_id" id="doctor_id" value="123456"> 
						   			<input type="hidden" class="p_id" name="p_id" id="p_id" value="{{$appointment['patient_id']}}">
                                    <span id="table_date{{($i)}}" class="appt_time" style="display: none;">{{ $appointment['appointment_time'] }}</span>
                                    @if($appointment['appointment_time'] >=  strtotime('now'))                                   
                                    	<span id="demo{{($i)}}" class="demo" style="display: none;"></span>   
                                    @endif                                     
                               	</div>
                            @php $i++; @endphp
                            @endif
						</td>
						<td>
							<div class="d_profile">
								<div class="d_pro_img">
									  @php if((file_exists(getcwd().'/uploads/patient/'.basename($appointment['patient_profile_img']))) && (!empty($appointment['patient_profile_img']))){
                                      @endphp
                                      <img src="{{ asset('/uploads/patient/'.$appointment['patient_profile_img']) }}" alt="image">
                                      @php     }
                                      else { @endphp
                                       <img src="{{ asset('images/profile.svg') }}" alt="image">
                                      @php   } @endphp

									
								</div>
								<div class="d_pro_text">
<!--
									<h4>Mr. Ayo Akintunde</h4>
-->
									<h4>{{ ucfirst($appointment['patient_first_name']).' '.ucfirst($appointment['patient_last_name']) }}</h4>
								 <a href="javascript:;" onclick="ViewPatientProfile(<?php echo $appointment['patient_unique_id'];?>);">View Profile</a>
								</div>
							</div>
						</td>
<!--
						 <td>08.00 AM (EST)</td>
-->
						<td>{{ date('h:i A' ,$appointment['appointment_time']) }}</td>
						<td>
					   		@if($appointment['appointment_type']==1)
						   		@if($disabled > 0)
						   			<button type="button" disabled class="btn btn-light btn-xs mr-2 call_btn" name="button" onclick="callPatient(this); return false;" data-doctor_id="123456" data-call_type="{{$appointment['telemedical_type']}}" data-appoint_id="{{$appointment['appointment_id']}}" data-patient_id="{{$appointment['patient_id']}}"><img class="icon" src="{{ asset('admin/doctor/images/call_blue.svg') }}" alt="icon">Call</button>
						   		@elseif(date('Y-m-d',$appointment['appointment_time']) >= date('Y-m-d'))
							  	 	<button type="button" class="btn btn-light btn-xs mr-2 call_btn" name="button" onclick="callPatient(this); return false;" data-doctor_id="123456" data-call_type="{{$appointment['telemedical_type']}}" data-appoint_id="{{$appointment['appointment_id']}}" data-patient_id="{{$appointment['patient_id']}}"><img class="icon" src="{{ asset('admin/doctor/images/call_blue.svg') }}" alt="icon">Call</button>

							  	@else
							  		<button type="button" disabled class="btn btn-light btn-xs mr-2 call_btn" name="button" onclick="callPatient(this); return false;" data-doctor_id="123456" data-call_type="{{$appointment['telemedical_type']}}" data-appoint_id="{{$appointment['appointment_id']}}" data-patient_id="{{$appointment['patient_id']}}"><img class="icon" src="{{ asset('admin/doctor/images/call_blue.svg') }}" alt="icon">Call</button>
							  	
							  	@endif
							@else
								@if($appointment['booking_id'] != "")
									<a href="{{ url('doctor/appointment_detail/'.$appointment['booking_id'])}}" class="btn btn-light btn-xs mr-2" name="button"><img class="icon" src="{{ asset('admin/doctor/images/eye.svg')}}" alt="">View</a>
								@else
									<a href="javascript:;" class="btn btn-light btn-xs mr-2" name="button"><img class="icon" src="{{ asset('admin/doctor/images/eye.svg') }}" alt="">View</a>
								@endif
							@endif

						   	<div class="dropdown d-inline-block">
						   		@if(date('Y-m-d H:i',$appointment['appointment_time']) <= date('Y-m-d H:i',strtotime('-15 min')))
									<a class="btn btn-danger no_caret btn-xs dropdown-toggle disabled_cancel" href="javascript:;" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" >
								  	Cancel
									</a>
								@else
									<a class="btn btn-danger no_caret btn-xs dropdown-toggle" href="javascript:;" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
								  	Cancel
									</a>
								@endif
								<div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdown">
									<div class="sure">
										<h5>Are you sure want to cancel the appointment?</h5>
										<button type="button" class="btn btn-light btn-xs mr-2" onclick="cancelBooking(this); return false;"  data-patient_id="{{$appointment['patient_id']}}" data-booking_id="{{$appointment['booking_id']}}">Yes, I am Sure</button>
										<button type="button" class="btn btn-blue btn-xs mr-2 reschedule_book" data-appoint_date="{{ date('Y-m-d' ,$appointment['appointment_time']) }}" data-appoint_time="{{ date('h:i A' ,$appointment['appointment_time']) }}" data-booking_id="{{$appointment['booking_id']}}" onclick="resheduleBooking(this); return false;">Reschedule</button>
									</div>
								</div>
							</div>
					   </td>
					</tr>
				   @endforeach
				   @else
				   <tr><td></td><td></td><td>No appointments found</td><td></td><td></td></tr>
				   @endif
				</table>
				<a class="btn btn-primary btn-sm" href="{{ url('/doctor/all_appointments') }}">View All Schedule</a>
			</div>
		</div>
	</div>
</main>

 <!-- set availability screen -->
<div class="modal fade" id="setup_availability">

    <div class="modal-dialog modal-md modal-dialog-centered genmodal setup_availability">
        <div class="modal-content">
            <div class="modal-header">
                <h3>Enter Appointment Availability</h3>
                <button type="button" class="close" data-dismiss="modal"><img src="{{ asset('admin/doctor/images/popup_close_w.svg') }}"/></button>
            </div>
            <div class="modal-body">
                <div class="popup_tabs">
                    <ul class="nav nav-pills tabs_main" role="tablist">
                        <li><a class="active tabs_head" role="tab"  data-toggle="pill" href="#hostpital_appointment" data-id ="1">Hospital Appointment</a></li>
                        <?php $telemedical= $doctor_details['telemedical'];
                        if($telemedical>0){ ?>
                        <li><a role="tab" class="tabs_head" data-toggle="pill"  href="#telemedical_appointment" data-id="2">Telemedical Appointment</a></li>
                    <?php }?>
                     </ul>
                </div>
                
                <div class="tab-content">
                	 {{ csrf_field() }}
                     <div id="hostpital_appointment" class="tab-pane fade show active">
						<form id="hosp_form">
							 <div class="consult_detail">
								 <label>Time Duration</label>
								 <div class="time-main">
									<div class="time-button disabled-time">
										<input id="time15" checked type="radio" name="doctor_apponitment_time_interval" class="form-check-custom appointment_time_sel time_set doctor_apponitment_time" value='15'>
										<p>15 mins</p>
									</div>
									<div class="time-button disabled-time">
										<input id="time30" type="radio" name="doctor_apponitment_time_interval" class="form-check-custom appointment_time_sel time_set doctor_apponitment_time" value='30'>
										<p>30 mins</p>
									</div>
									<div class="time-button disabled-time">
										<input id="time45" type="radio" name="doctor_apponitment_time_interval" class="form-check-custom appointment_time_sel time_set doctor_apponitment_time" value='45'>
										<p>45 mins</p>
									</div>
									<div class="time-button disabled-time">
										<input id="time60" type="radio" name="doctor_apponitment_time_interval" class="form-check-custom appointment_time_sel time_set doctor_apponitment_time" value='60'>
										<p>60 mins</p>
									</div>
								</div>
								 <div class="picker">
									 <div class=" mb-2 availability_date" id="date1" data-date="{{ date('d F Y') }}" data-date-format="dd-mm-yyyy"></div>
									  
									  
								 </div>
								<div class="row">
									<div class="col-sm-6">
										<div class="form-group">
											<label>Start time</label>
											<div class="select_box">																 	
												 	<select class="form-control start_time" name="hosp_start_time">											 	
													 		<?php $array= hoursRange();

													 		foreach($array as $key=>$single){ ?>
													 			<option value='{{ date("H:i",strtotime($key)) }}' <?php if(date("H:i",strtotime($key)) < date("H:i",strtotime("now"))){ ?>disabled <?php } ?>>{{ $single }}</option>
													 	<?php 	} ?>
													 	
												 	</select>
											 </div>
										</div>
									</div>
									<div class="col-sm-6">
										<div class="form-group">
											<label>End time</label>
											<div class="select_box">
												 <select class="form-control end_time" name="hosp_end_time">
													<?php foreach($array as $key=>$single){ ?>
													 			<option value='{{ date("H:i",strtotime($key)) }}' <?php if(date("H:i",strtotime($key)) < date("H:i",strtotime("now"))){ ?>disabled <?php } ?>>{{ $single }}</option>
													 	<?php 	} ?>
												 </select>
											 </div>
										</div>
									</div>
								</div>
								<div class="text-center mt-2">
									<input type="hidden" name="hidden_date_hosp[]" actualdate="" id="hidden_date_hosp" class="hidden_date" value="<?php echo date('d-m-Y'); ?>">	
									<input type="hidden" name="hidden_hosp_type" value="2">	
									<button type="button" class="btn btn-primary save_availbility" id="hosp_save" name="button">Confirm & Save</button>
								</div>
			                        <ul class="availability_listing"></ul>

							  </div>
                         </form>
                     </div>
                     <div id="telemedical_appointment" class="tab-pane fade">
						<form id="tele_form">	
							 <div class="consult_detail">
								 <div class="picker">
									 <div class="datepicker_input mb-2 availability_date" id="date2" data-date="<?php echo date('d-m-Y');  ?>" data-date-format="dd-mm-yyyy"></div>
								 </div>
								<div class="row">
									<div class="col-sm-6">
										<div class="form-group">
											<label>Start time</label>
											<div class="select_box">	

												 <select class="form-control start_time" name="hosp_start_time">	
												 		<?php foreach($array as $key=>$single){ ?>
													 			<option value='{{ date("H:i",strtotime($key)) }}' <?php if(date("H:i",strtotime($key)) < date("H:i",strtotime("now"))){ ?>disabled <?php } ?>>{{ $single }}</option>
													 	<?php 	} ?>
												 </select>
											 </div>
										</div>
									</div>
									<div class="col-sm-6">
										<div class="form-group">
											<label>End time</label>
											<div class="select_box">
												 <select class="form-control end_time" name="hosp_end_time">
												<?php 	foreach($array as $key=>$single){ ?>
													 			<option value='{{ date("H:i",strtotime($key)) }}' <?php if(date("H:i",strtotime($key)) < date("H:i",strtotime("now"))){ ?>disabled <?php } ?>>{{ $single }}</option>
													 	<?php 	} ?>
												 </select>
											 </div>
										</div>
									</div>
								</div>
								<div class="text-center mt-2">
									<input type="hidden" name="hidden_date_hosp" id="hidden_date_tele" class="hidden_date" value="<?php echo date('d-m-Y'); ?>">
									<input type="hidden" name="hidden_hosp_type" value="1">	
									<button type="button" class="btn btn-primary save_availbility" id="tele_save" name="button">Confirm & Save</button>
								</div>
								<ul class="availability_listing"></ul>
							  </div>
						</form>
                     </div>
                 </div>
            </div>
        </div>
    </div>
</div>

<!-- reschedule screen -->
<div class="modal fade" id="reschedule_appointment" data-backdrop="static" data-keyboard="false">
    <div class="modal-dialog modal-md modal-dialog-centered genmodal genmodal_custom custom_width2">
        <div class="modal-content">
            <div class="modal-header">
                <h3>Reschedule Appointment</h3>
                <button type="button" class="close" data-dismiss="modal"><img src="{{ asset('admin/doctor/images/popup_close.svg') }}"/></button>
            </div>
            <div class="modal-body reshedule_detail">                
            </div>
        </div>
    </div>
</div>

<?php 
function hoursRange( $lower = 0, $upper = 86400, $step = 3600, $format = '' ) {
    $times = array();

    if ( empty( $format ) ) {
        $format = 'g:iA';
    }

    foreach ( range( $lower, $upper, $step ) as $increment ) {
        $increment = gmdate( 'H:i', $increment );

        list( $hour, $minutes ) = explode( ':', $increment );

        $date = new DateTime( $hour . ':' . $minutes );

        $times[(string) $increment] = $date->format( $format );
    }

    return $times;
}
?>
<!-- View Profile Modal -->
        <div class="modal fade" id="view_profile">
            <div class="modal-dialog modal-lg modal-dialog-centered genmodal view_profile_modal">
                <div class="modal-content">
                    <div class="modal-header">
                        <h3>Patient Profile</h3>
                        <button type="button" class="close" data-dismiss="modal"><img src="{{asset('admin/doctor/images/popup_close_w.svg')}}"/></button>
                    </div>
                    <div class="modal-body">
                        <div class="my_profile_section">
                            <div class="profile_name">
                                <div class="profile_d_image">
                                    <img src="{{asset('admin/doctor/images/profile.svg')}}" alt="">
                                </div>
                                <h4></h4>
                                <h6></h6>
                                <span class="patient_id_detail"></span>
                            </div>
                            <div class="widget_profile_desc patient_profile_md mb-0">
                            <ul>
                                <li id="address">
                                    <span>
                                        <img src="{{asset('admin/doctor/images/location.svg')}}" alt="icon">
                                    </span>
                                    <p></p>
                                </li>
                                <li id="marital_status">
                                    <span>
                                        <img src="{{asset('admin/doctor/images/gender.svg')}}" alt="icon">
                                    </span>
                                    <p></p>
                                </li>
                             <li id="language">
                                    <span>
                                        <img src="{{asset('admin/doctor/images/mic.svg')}}" alt="icon">
                                    </span>
                                    <p></p>
                                </li>
                                    <li id="Birthday">
                                    <span>
                                      <img src="{{asset('admin/doctor/images/bday.svg')}}" alt="icon">
                                    </span>
                                    <p></p>
                                </li>
                              <li >
                                    <span>
                                        <img src="{{asset('admin/doctor/images/drop.svg')}}" alt="icon">
                                    </span>
                                    <p id="blood_group"> </p><div class="d_pro_text" id="pro_edit">&nbsp;<a onclick="showbloodgroups()" style="cursor:pointer;">Edit</a></div>&nbsp;&nbsp;
                                 
                                    <p class="blood_group2" style="display: none;">Blood type : </p>
                                    <div class="select_box select_blood_type blood_group2"  style="display: none;">
                                                            <select class="form-control" data-patient="" onchange="editbloodbroup(this)">
                                                                <option value="O-">O-</option>
                                                                <option value="O+">O+</option>
                                                                <option value="A-">A-</option>
                                                                <option value="A+">A+</option>
                                                                <option value="B-">B-</option>
                                                                <option value="B+">B+</option>
                                                                <option value="AB-">AB-</option>
                                                                <option value="AB+">AB+</option>
                                                            </select>
                                                        </div>
                                                   
                                </li>
                                <li >
                                    <span>
                                        <img src="{{asset('admin/doctor/images/group.svg')}}" alt="icon">
                                    </span>
                                    <p>State Of Origin : <span id="state_of_origin">Yoruba</span></p>
                                </li>
                            </ul>
                        </div>

                        </div>
                    </div>
                </div>
            </div>
        </div>

@endsection

