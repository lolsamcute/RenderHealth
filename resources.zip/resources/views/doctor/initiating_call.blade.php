<!DOCTYPE html>
<html>
    <head>
        <title>Intiating Call.</title>

        <link href="https://fonts.googleapis.com/css?family=Lato:100" rel="stylesheet" type="text/css">
        <script src="https://code.jquery.com/jquery-3.3.1.js" integrity="sha256-2Kok7MbOyxpgUVvAk/HJ2jigOSYS2auK4Pfzbm7uH60=" crossorigin="anonymous"> </script>
        <style>
            html, body {
                height: 100%;
            }

            body {
                margin: 0;
                padding: 0;
                width: 100%;
                color: #B0BEC5;
                
                font-weight: 100;
                font-family: 'Lato';
            }

            .container {
                text-align: center;
                display: flex;
                justify-content: center;
                align-items: center;
                height:100vh;
            }

            .content {
                text-align: center;
                display: inline-block;
            }

            .title {
                font-size: 72px;
                margin-bottom: 40px;
            }
        </style>
    </head>
    <body>
        <div class="container">
            <div class="content">
                <div class="title">We are intiating your call...</div>
                <input type="hidden" class="site_url" name="site_url" id="site_url" value="{{ url('/') }}">
                <input type="hidden" class="a_id" name="a_id" value="{{ $a_id }}">
                {{ csrf_field() }}
            </div>
        </div>
        <script type="text/javascript">
            /*window.onbeforeunload = function(event){                
                var a_id = $(".a_id").val();                    
                var site_url = $('#site_url').val();        
                var url = site_url+"/doctor/disconnect_conn_status";  
                $.ajaxSetup({
                    headers:{ 'X-CSRF-Token': $('input[name="_token"]').val() }
                });
                $.ajax({
                    url:url,
                    type:'POST',
                    data:{"appoint_id":a_id},
                    success:function(result){     
                      
                    }
                });
            };*/
        </script>
    </body>         
</html>
