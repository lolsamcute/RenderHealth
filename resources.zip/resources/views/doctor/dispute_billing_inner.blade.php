 <div class="row">
                        <div class="col-12">
                            <div class="tab-content">
                                <div class="table_hospital pagination_fixed_bottom">
                                      <div class="table-responsive">
                                   <table class="table" cellspacing="10">
                                       <tr>
                                           <th>DATE CREATED</th>
                                           <th>INVOICE ID</th>
                                           <th>HOSPITAL / LABS</th>
                                           <th>HMO OFFICER</th>
                                           <th>AMOUNT</th>
                                           <th>PAID</th>
                                           <th>BALANCE</th>
                                       </tr>
                                        @if(count($disputed_billing) > 0)

                                @foreach($disputed_billing as $billing_det) 
                                      
                                      <tr <?php if($billing_det['seen_status'] == 0){ ?> class="recent" <?php } else if($billing_det['payable_amount'] - $billing_det['paid_amount'] > 0){ ?> class="pending" <?php } ?>>
                                           <td>{{ date('j F Y',$billing_det['billing_date']) }}</td>
                                           <td>{{ $billing_det['invoice_number'] }}</td>
                                           <td>{{ $billing_det['hospital']['hosp_name'] }}</td>
                                           <td>Mrs. Rosetta Potter</td>
                                           <td>₦ {{ $billing_det['payable_amount'] }}</td>
                                           <td>₦ {{ $billing_det['paid_amount'] }}</td>
                                           <td>₦ {{ $billing_det['payable_amount'] - $billing_det['paid_amount'] }}</td>
                                           <td><a href="dispute_billing_detail" class="btn btn-light btn-xs" name="button"><img class="icon" src="{{asset('admin/doctor/images/eye.svg')}}" alt="icon">View Detail</a></td>
                                       </tr>
                              @endforeach
                                     @else
                              <tr>
                              <td colspan="7" class="text-center">No Disputed Bills Found</td>
                              </tr>
                                          @endif 
                                   </table>
                                 </div>
                                 <div class="table_pagination">
                                       <button type="button" class="btn btn-light btn-xs pre_bill" <?php if($disputed_billing->previousPageUrl()){  } else{ echo "disabled"; } ?> data-url="<?php echo $disputed_billing->previousPageUrl(); ?>">Previous Page</button>
                           <input type="hidden" class="all_hidden" value="{{$disputed_billing->currentPage()}}">
                           <span>Page {{ $disputed_billing->currentPage() }} of {{ $disputed_billing->lastPage() }} Pages</span>
                           <button type="button" class="btn btn-light btn-xs next_bill"  <?php if($disputed_billing->nextPageUrl()){  } else{ echo "disabled"; } ?>  data-url="<?php echo $disputed_billing->nextPageUrl(); ?>">Next Page</button>
                                   </div> 
                                </div>
                              </div>
                        </div>
                    </div>