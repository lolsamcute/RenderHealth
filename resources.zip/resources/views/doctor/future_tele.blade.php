@extends('layouts.doctor')

@section('content')
<main class="col-12 col-md-12 col-xl-12 bd-content-center">
    <div class="row">
        <div class="col-12">
            <div class="page_head">
                 <h1 class="heading">Telemedical appointment</h1>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-12">
            <div class="widget widget_body mb-3">
                <div class="widget_doctor_list">
                    <div class="doctor_list">
                        <div class="doc_detail">
                            <div class="doc_data_outer">
                                <div class="doc_name">
                                    <div class="doc_img">
                                        <img src="{{ asset('admin/doctor/uploads/profile/'.$doctor_detail['doctor_picture']) }}" alt="image">
                                    </div>
                                    <div class="doc_desc">
                                        <h5>Dr. {{ $doctor_detail['doctor_first_name'] }} {{ $doctor_detail['doctor_last_name'] }}, {{ $doctor_detail['doctor_degree'] }}</h5>

                                        <a href="javascript:;">{{ $doctor_detail['specialist_categories']['speciality_name'] }} </a>
                                    </div>
                                </div>
                            </div>
                            <div class="doc_other_outer">
                                <div class="doc_other">
                                    <h6>Languages</h6>
                                    <h4>{{ $doctor_detail['doctor_languages'] }}</h4>
                                </div>
                                <div class="doc_other">
                                    <h6>Education</h6>
                                    <h4>{{ $doctor_detail['doctor_education_school'] }}</h4>
                                </div>
                            </div>
                            <div class="doc_other_outer">
                                <div class="doc_other">
                                    <h6>Religion</h6>
                                    <h4>{{ $doctor_detail['doctor_religion'] }}</h4>
                                </div>
                                <div class="doc_other">
                                    <h6>Ethnicity</h6>
                                    <h4>{{ $doctor_detail['doctor_ethnicity'] }}</h4>
                                </div>
                            </div>

                        </div>
                        <div class="alert alert-danger-outline alert-dismissible alert_icon fade show error_msg_tele text-left mt-3" id="error_msg_tele" role="alert" style="display:none;">
                        <div class="d-flex align-items-center">
                            <div class="alert-icon-col">
                                <span class="fa fa-warning"></span>
                            </div>
                            <div class="alert_text error_text_tele">
                                Email field is required
                            </div>
                            <a href="#" class="close alert_close" data-dismiss="alert" aria-label="close"><i class="fa fa-close"></i></a>
                        </div>
                    </div>
                        <form action="" method="POST" onsubmit="savefuturebooking(this); return false;" id="save_tele_book" class="mt-3">
                        	{{ csrf_field() }}
                        	<input type="hidden" class="submit_status" value="<?php if(isset($book_details) && count($book_details) > 0){ echo 1; }else{ echo 0; } ?>">
                        	<input type="hidden" class="submit_id" value="<?php if(isset($book_details[0])){if(isset($book_details[0]->booking_id)){echo trim($book_details[0]->booking_id); }} ?>">
                            <input type="hidden" class="appointment_id" value="{{ $appointment_id }}">
                            <input type="hidden" class="doctor_id" id="doctor_id" name="doctor_id" value ="{{ $doctor_id }}">
                            <input type="hidden" class="doctor_appoint_date" id="doctor_appoint_date" name="doctor_appoint_date" value ='{{ date("Y-m-d H:i:s", strtotime("$doctor_apponitment_date $doctor_apponitment_time")) }}'>
                            <input type="hidden" class="speciality_id" name="speciality_id" value="<?php if(!empty($speciality)){ echo $speciality; } ?>">
                            <input type="hidden" class="patient_id" name="patient_id" value="<?php if(!empty($pid)){ echo $pid; } ?>">

                            <div class="row">
                                <div class="col-sm-12">
                                    <div class="form-group">
                                        <label>Describe Symptoms</label>
                                        <textarea class="form-control symptoms" name="name" rows="4" cols="40" placeholder="Enter text here.."><?php if(isset($book_details[0])){if(isset($book_details[0]->symptoms)){ echo $book_details[0]->symptoms; } } ?></textarea>
                                     </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-sm-12">
                                     @if(count($health_diaries)>0)
                                        <a class="attachment mb-4 mt-2" href="javascript:;" data-toggle="modal" data-target="#select_diary">
                                                  <img src="{{ asset('images/attachment.svg') }}" alt="icon">
                                                 Attach My Health Diary
                                             </a> 
                                                        @else
                                                        <a class="attachment mb-4 mt-2" href="javascript:;" onClick="(function(){
                                                        alert('No health diary found');
                                                        return false;
                                                        })();return false;">
                                                        <img src="{{ asset('images/attachment.svg') }}" alt="icon">
                                                        Attach My Health Diary
                                                        </a> 
                                                        @endif

                                             <div class="attachdoaries">
                                         
                                             </div>
                                </div>
                            </div>


                            <div class="row mt-4">
                                <div class="col-sm-7">
                                    <a href="{{url('doctor/search_patient')}} " class="btn btn-danger btn-min-width-auto mr-2">Cancel</a>
                                    <button class="btn btn-primary" type="submit">Save Appointment</button>
                                </div>
                                <div class="col-sm-5 text-right">
                                    <div class="time_appointment">
                                        <div class="time_appointment_icon">
                                            <img src="{{ asset('images/cal_time.svg') }}" alt="icon">
                                        </div>
                                        <div class="time_appointment_text">
                                            <h5>{{ date('j M,Y',strtotime($doctor_apponitment_date)) }}</h5>
                                            <p>at {{ date('h:i A',strtotime($doctor_apponitment_time))}}</p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="modal fade" id="select_diary">
        <div class="modal-dialog modal-xl modal-dialog-centered genModal">
            <div class="modal-content">
                <div class="modal-header">
                    <h4 class="modal-title">Add My Health Diary</h4>
                    <button type="button" class="close mclose" data-dismiss="modal"><img src="{{asset('images/cross_modal.svg')}}"/></button>
                 </div>
                <div class="modal-body">
                    <div class="health_diary">
                        <ul class="row">
                            @foreach($health_diaries as $Singlehealth_diaries)
                            <li class="col-sm-4">
                                <input id="diary_{{$Singlehealth_diaries->id}}" value="{{$Singlehealth_diaries->diary_id}}" class="form-check-input health_diary" name="health_diary" type="checkbox"   onclick="appenddiary(<?php echo $Singlehealth_diaries->diary_id;?>,this)" />
                                <label for="diary_{{$Singlehealth_diaries->id}}">
                                    <span class="diary_date">{{ date('j F Y',$Singlehealth_diaries->created_date)}}</span>
                                    <div class="diary_detail">
                                        @php
                                             $feeling_pic = ['admin/doctor/images/smilies/no_pain@2x.png','admin/doctor/images/smilies/mild@2x.png','admin/doctor/images/smilies/moderate@2x.png','admin/doctor/images/smilies/severe@2x.png','admin/doctor/images/smilies/very_severe@2x.png','admin/doctor/images/smilies/worst_pain@2x.png','admin/doctor/images/smilies/moderate@2x.png'];
                                            @endphp
                                        <span class="diary_icon"><img src="{{asset($feeling_pic[$Singlehealth_diaries->feeling_details])}}" alt="smilies"></span>
                                   @php 
                                     $put_disable_keys=array();

                                     $feeling = ['Feeling No Pain','Feeling Mild Pain','Feeling Moderate Pain','Feeling Severe Pain','Feeling Very Severe Pain','Feeling Worst Pain',"Other"];    
                                      $put_disable_keys[]=$Singlehealth_diaries->feeling_details;
                                     
                                  @endphp                              

                                     
                                       @foreach($feeling as $key=>$single_feeling) 
                                       @if($key==6)
                                       <h4> {{ trim($Singlehealth_diaries->describe_feeling_other)}}</h4> 
                                      @else
                                       @if(in_array($key,$put_disable_keys))                              
                                        <h4>{{$single_feeling}}</h4>                                      
                                         @endif
                                           @endif
                                        @endforeach 

                                        <h6>{{$Singlehealth_diaries->symptom_details}}</h6>
                                    </div>
                                </label>
                            </li>
                            @endforeach
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>       
</main>

@endsection