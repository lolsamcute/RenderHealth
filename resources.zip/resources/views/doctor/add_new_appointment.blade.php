<form method="post">
    <div class="alert alert-danger-outline alert-dismissible alert_icon fade show error_msg_search text-left mt-3" id="error_msg_search" role="alert" style="display:none;">
        <div class="d-flex align-items-center">
            <div class="alert-icon-col">
                <span class="fa fa-warning"></span>
            </div>
            <div class="alert_text error_text_search">
                Email field is required
            </div>
            <a href="#" class="close alert_close" data-dismiss="alert" aria-label="close"><i class="fa fa-close"></i></a>
        </div>
    </div>
    <div class="row">        
        <div class="col-6">
            <div class="picker">
                <div class="mb-2 datepicker schedule_time"></div>
                @php  date_default_timezone_set($timezone); @endphp
            </div>
        </div>
        <div class="col-6">
            <div class="patient_data_right pl-0 pt-0">
                <div class="patient_profile patient_profile_sm mb-3">
                    <div class="pp_image">
                         @if(!empty($patient_detail['patient_profile_img']))
                          <img src="{{ asset('uploads/patient/'.$patient_detail['patient_profile_img']) }}" alt="image">                                                 
                        @else
                          <img src="{{ asset('images/profile.svg') }}" alt="image">                                                      
                        @endif
                    </div>
                    <div class="pp_desc">
                        @if($patient_detail['patient_gender'] == 1)
                            <h4>Mr. {{ ucfirst($patient_detail['patient_first_name']) }} {{ ucfirst($patient_detail['patient_last_name']) }}</h4>
                            <h5>Location, {{$patient_detail['patient_address']}}</h5>
                        @elseif($patient_detail['patient_gender'] == 2)
                            <h4>Ms. {{ ucfirst($patient_detail['patient_first_name']) }} {{ ucfirst($patient_detail['patient_last_name']) }}</h4>
                            <h5>Location, {{$patient_detail['patient_address']}}</h5>
                        @else
                            <h4>{{ ucfirst($patient_detail['patient_first_name']) }} {{ ucfirst($patient_detail['patient_last_name']) }}</h4>
                            <h5>Location, {{$patient_detail['patient_address']}}</h5>
                        @endif 
                        
                    </div>
                </div>
                <div class="form-group mb-3">
                    <label>Type of appointment</label>
                    <div class="select_box">
                         <select class="form-control appointment_type" name="" onchange="scheduleAppointment(this); return false;">
                             <option value="2" <?php if($appointment_type == 2){ ?> selected <?php }?>>Hospital Appointment</option>
                             <option value="1" <?php if($appointment_type == 1){ ?> selected <?php }?>>Telemedical Appointment</option>                                             
                         </select>
                     </div>
                </div>
                <div class="form-group mb-3">
                    <label>Date</label>
                    <input type="text" class="form-control appoint_date_value" name="" value="{{ date('j F, Y',strtotime($appoint_date))}}" disabled>
                 
                </div>
                <div class="form-group mb-3">
                    <label>Time</label>
                    <div class="select_box">
                         <select class="form-control appoint_time" name="">
                             <option value="">Select appointment time</option>
                             @if(!empty($doctor_avail_time) && count($doctor_avail_time) > 0)
                                @php                                                                            
                                   $count =0;
                                @endphp
                                
                                    @foreach($doctor_avail_time['doctor_availability'] as $key=>$availability) 
                                @php
                                        $availability_time = $availability['availability_time'];               
                                      
                          
                                             if(date("Y-m-d H:i",strtotime($availability_time))  >= date('Y-m-d H:i')){
                                                         
                                                        if(count($doc_appoint_listing) > 0){
                                                        $inc =0;
                                                            foreach($doc_appoint_listing as $doc_appoint){
                                                                if($doctor_avail_time['doctor_id'] == $doc_appoint['doctor_id']){
                                                                    if(date("H:i",strtotime($availability_time)) ==  date('H:i',$doc_appoint['appointment_time'])){
                                                                        $inc = 1;
                                                                    }
                                                                }
                                                            }
                                                            if($inc == 1){                                                                                      
                                    @endphp
                                                               <option value ='{{ $availability_time }}'  disabled="disabled">{{ $availability_time }}</option>
                                    @php                        }else{
                                     @endphp                        
                                                                <option value ='{{ $availability_time}}'>{{ $availability_time }}</option>

                                    @php                            
                                                            }
                                                        }else{
                                    @endphp
                                                       <option value ='{{ $availability_time}}'>{{ $availability_time }}</option>

                                   @php
                                                        }
                                                    
                                                                                                                      
                                                $count++;
                                            } 
                                      
                                @endphp                                                             
                                    @endforeach
                                @else
                                 <option value =''>No available time set by doctor yet</option>
                            @endif
                         </select>
                     </div>
                </div>
                <!-- <div class="form-group mb-4">
                    <label>Hospital Name</label>
                    <div class="select_box">
                         <select class="form-control hospital_id" name="">
                            <option value="">Select Hospital</option>
                            @foreach($hospital_listing as $hospital_list)
                               <option value="{{$hospital_list->hosp_id}}">{{$hospital_list->hosp_name}}</option>
                            @endforeach
                         </select>
                     </div>
                </div>  -->               
                 <input type="hidden" id="hidden_date" class="hidden_date" value="{{ date('d-m-Y',strtotime($appoint_date)) }}">
                 <input type="hidden" id="patient_id" class="patient_id" value ="{{$patient_detail['patient_unique_id']}}">
                <button type="submit" class="btn btn-primary mb-3" onclick="addNewAppointment(this); return false;">Save Appointment</button>
            </div>
        </div>
    </div>
</form>