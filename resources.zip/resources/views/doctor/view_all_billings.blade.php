@extends('layouts.doctor')
@section('content')                
<main class="col-12 col-md-12 col-xl-12 bd-content">
    <div class="row">
        <div class="col-12">
            <div class="page_head">
                <h1 class="heading">
                    <div class="dropdown sorting">
                      <span class="sortby">Sort by:</span>
                      <a class="nav-link dropdown-toggle sort_bill" href="javascript:;" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                          Newest Billing
                      </a>
                      <div class="dropdown-menu dropdown-menu-right sort_options" aria-labelledby="navbarDropdown">
                          <a class="dropdown-item" href="javascript:;" onclick="sortbillings(this); return false;" data-id="1">Newest Billings</a>
                          <a class="dropdown-item" href="javascript:;" onclick="sortbillings(this); return false;" data-id="2">Highest Amount</a>
                          <a class="dropdown-item" href="javascript:;" onclick="sortbillings(this); return false;" data-id="3">Lowest Amount</a>
                      </div>
                    </div>
                </h1>
                <div class="appointment_type billing_type">
                    <ul class="nav nav-pills" role="tablist">
                        <li><a class="active" role="tab"  data-toggle="pill" data-type="all_page" href="#all_billings">All Billings @if($billing_count >0)<span>{{$billing_count}} </span>@endif</a></li>
                        <li><a role="tab" data-toggle="pill"  href="#outstanding_billings" data-type="out_billings">Outstanding Billings @if($outstanding_count >0)<span>{{$outstanding_count}}</span>@endif</a></li>
                        <li><a role="tab" data-toggle="pill"  href="#paid_billings" data-type="paid_billings">Paid Billings @if($paid_count >0)<span>{{$paid_count }}</span>@endif</a></li>
                     </ul>
                </div>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-12">            
            <div class="tab-content main_div">
                <div id="all_billings" class="tab-pane fade show active">
                    <div class="table_hospital pagination_fixed_bottom">
                          <div class="table-responsive">
                       <table class="table" cellspacing="10" id="biling_table">                          
                           <tr>
                               <th>DATE CREATED</th>
                               <th>INVOICE ID</th>
                               <th>HOSPITAL / LABS</th>
                               <th>HMO OFFICER</th>
                               <th>AMOUNT</th>
                               <th>PAID</th>
                               <th>BALANCE</th>
                               <th></th>
                           </tr>                          
                           @if(count($billing_detail) > 0)
                            @foreach($billing_detail as $billing_det)
                               <tr <?php if($billing_det['seen_status'] == 0){ ?> class="recent" <?php } else if($billing_det['payable_amount'] - $billing_det['paid_amount'] > 0){ ?> class="pending" <?php } ?>>
                                    <td>{{ date('j F Y',$billing_det['billing_date']) }}</td>
                                    <td>{{ $billing_det['invoice_number'] }}</td>
                                    <td>{{ $billing_det['hospital']['hosp_name'] }}</td>
                                    <td>Mrs. Rosetta Potter</td>
                                    <td>₦ {{ $billing_det['payable_amount'] }}</td>
                                    <td>₦ {{ $billing_det['paid_amount'] }}</td>
                                    <td>₦ {{ $billing_det['payable_amount'] - $billing_det['paid_amount'] }}</td>  
                                    <td><a href="{{ asset('doctor/billing_detail/'.$billing_det['billing_id'].'/'.$id) }}" class="btn btn-light btn-xs" name="button"><img class="icon" src="{{ asset('admin/doctor/images/eye.svg') }}" alt="icon">View Detail</a></td>                                  
                               </tr>
                              @endforeach
                            @else
                              <tr>
                                  <td colspan="7" class="text-center">No Bills Found</td>
                              </tr>
                            @endif                                                 
                        </table>
                      </div>
                       <div class="table_pagination">
                           <button type="button" class="btn btn-light btn-xs pre_bill" <?php if($billing_detail->previousPageUrl()){  } else{ echo "disabled"; } ?> data-url="<?php echo $billing_detail->previousPageUrl(); ?>&type=all_page">Previous Page</button>
                           <input type="hidden" class="all_hidden" value="{{$billing_detail->currentPage()}}">
                           <span>Page {{ $billing_detail->currentPage() }} of {{ $billing_detail->lastPage() }} Pages</span>
                           <button type="button" class="btn btn-light btn-xs next_bill"  <?php if($billing_detail->nextPageUrl()){  } else{ echo "disabled"; } ?>  data-url="<?php echo $billing_detail->nextPageUrl(); ?>&type=all_page">Next Page</button>
                       </div>
                    </div>
                </div>
                <div id="outstanding_billings" class="tab-pane fade">
                    <div class="table_hospital pagination_fixed_bottom">
                              <div class="table-responsive">
                       <table class="table" cellspacing="10">                          
                         <tr>
                             <th>DATE CREATED</th>
                             <th>INVOICE ID</th>
                             <th>HOSPITAL / LABS</th>
                             <th>HMO OFFICER</th>
                             <th>AMOUNT</th>
                             <th>PAID</th>
                             <th>BALANCE</th>
                         </tr>                          
                        @if(count($outstanding_detail) > 0)
                          @foreach($outstanding_detail as $outstanding_det)
                             <tr <?php if($outstanding_det['seen_status'] == 0){ ?> class="recent" <?php } else if($outstanding_det['payable_amount'] - $outstanding_det['paid_amount'] > 0){ ?> class="pending" <?php } ?>>
                                  <td>{{ date('j F Y',$outstanding_det['billing_date']) }}</td>
                                  <td>{{ $outstanding_det['invoice_number'] }}</td>
                                  <td>Geo Medical Center</td>
                                  <td>Mrs. Rosetta Potter</td>
                                  <td>₦ {{ $outstanding_det['payable_amount'] }}</td>
                                  <td>₦ {{ $outstanding_det['paid_amount'] }}</td>
                                  <td>₦ {{ $outstanding_det['payable_amount'] - $outstanding_det['paid_amount'] }}</td>  
                                  <td><a href="{{ asset('doctor/billing_detail/'.$outstanding_det['billing_id']) }}" class="btn btn-light btn-xs" name="button"><img class="icon" src="{{ asset('admin/doctor/images/eye.svg') }}" alt="icon">View Detail</a></td>                                  
                             </tr>
                            @endforeach
                          @else
                            <tr>
                                <td colspan="7" class="text-center">No Outstanding Bills Found</td>
                            </tr>
                          @endif                                                  
                       </table>
                     </div>
                       <div class="table_pagination">
                           <button type="button" class="btn btn-light btn-xs pre_bill" <?php if($outstanding_detail->previousPageUrl()){  } else{ echo "disabled"; } ?> data-url="<?php echo $outstanding_detail->previousPageUrl(); ?>&type=out_billings">Previous Page</button>
                           <input type="hidden" class="out_hidden" value="{{$outstanding_detail->currentPage()}}">
                           <span>Page {{ $outstanding_detail->currentPage() }} of {{ $outstanding_detail->lastPage() }} Pages</span>
                           <button type="button" class="btn btn-light btn-xs next_bill"  <?php if($outstanding_detail->nextPageUrl()){  } else{ echo "disabled"; } ?>  data-url="<?php echo $outstanding_detail->nextPageUrl(); ?>&type=out_billings">Next Page</button>
                       </div>
                    </div>
                </div>
                <div id="paid_billings" class="tab-pane fade">
                    <div class="table_hospital pagination_fixed_bottom">
                              <div class="table-responsive">
                       <table class="table" cellspacing="10">                        
                         <tr>
                             <th>DATE CREATED</th>
                             <th>INVOICE ID</th>
                             <th>HOSPITAL / LABS</th>
                             <th>HMO OFFICER</th>
                             <th>AMOUNT</th>
                             <th>PAID</th>
                             <th>BALANCE</th>
                         </tr>                            
                         @if(count($paid_detail) > 0)
                          @foreach($paid_detail as $paid_det)
                             <tr <?php if($paid_det['seen_status'] == 0){ ?> class="recent" <?php } else if($paid_det['payable_amount'] - $paid_det['paid_amount'] > 0){ ?> class="pending" <?php } ?>>
                                  <td>{{ date('j F Y',$paid_det['billing_date']) }}</td>
                                  <td>{{ $paid_det['invoice_number'] }}</td>
                                  <td>Geo Medical Center</td>
                                  <td>Mrs. Rosetta Potter</td>
                                  <td>₦ {{ $paid_det['payable_amount'] }}</td>
                                  <td>₦ {{ $paid_det['paid_amount'] }}</td>
                                  <td>₦ {{ $paid_det['payable_amount'] - $paid_det['paid_amount'] }}</td>    
                                  <td><a href="{{ asset('doctor/billing_detail/'.$paid_det['billing_id']) }}" class="btn btn-light btn-xs" name="button"><img class="icon" src="{{ asset('admin/doctor/images/eye.svg') }}" alt="icon">View Detail</a></td>                                
                             </tr>
                            @endforeach
                          @else
                            <tr>
                                <td colspan="7" class="text-center">No Paid Bills Found</td>
                            </tr>
                          @endif                            
                        </table>
                      </div>
                       <div class="table_pagination">
                           <button type="button" class="btn btn-light btn-xs pre_bill" <?php if($paid_detail->previousPageUrl()){  } else{ echo "disabled"; } ?> data-url="<?php echo $paid_detail->previousPageUrl(); ?>&type=paid_billings">Previous Page</button>
                           <input type="hidden" class="paid_hidden" value="{{$paid_detail->currentPage()}}">
                           <span>Page {{ $paid_detail->currentPage() }} of {{ $paid_detail->lastPage() }} Pages</span>
                           <button type="button" class="btn btn-light btn-xs next_bill"  <?php if($paid_detail->nextPageUrl()){  } else{ echo "disabled"; } ?>  data-url="<?php echo $paid_detail->nextPageUrl(); ?>&type=paid_billings">Next Page</button>
                       </div>
                    </div>
                </div>
              </div>
        </div>
    </div>
</main>
@endsection