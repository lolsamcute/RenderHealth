<?php 
//~ echo '<pre>'; print_r($appointments); die('here');
 ?>

@extends('layouts.admin_dashboard')
@section('content')


                <main class="col-12 col-md-12 col-xl-12 bd-content">
                    <div class="row">
                        <div class="col-12">
                            <div class="page_head">
                                <a href="{{ url('/doctor/view_all_billings')}}" class="back_button">Back to billings</a>
                                <h1 class="inner_heading">Disputed billing : {{$billing_detail['invoice_number']}} </h1>
                                <div class="btn_billing">
                                     <a href="javascript:;" class="btn btn-primary btn-sm">Send Reply</a>
                                </div>
                             </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-12">
                             <div class="widget padding-40">
                                 <div class="billing_person">
                                     <div class="bill_person">
                                         {{ csrf_field() }}
                                         <h6>Created by</h6>
                                           <h3>{{ $billing_detail['hospital']['hosp_name'] }}</h3>
                                         <h5>at {{ date('j F, Y',$billing_detail['billing_date'])}}, {{ date('H:i',$billing_detail['billing_date'])}} EST</h5>
                                     </div>
                                     <div class="separator"></div>
                                     <div class="bill_person">
                                         <h6>HMO Officer</h6>
                                         <h3>Mrs. Rosetta Potter (HMO)</h3>
                                         <h5>Company of HMO Name</h5>
                                     </div>
                                     <div class="separator"></div>
                                     <div class="bill_person">
                                         <h6>Doctor’s Name</h6>
                                         @if(!empty($billing_detail->doctor_id))
                            <h3>Dr. {{ $billing_detail['doctor']['doctor_first_name'] }} {{ $billing_detail['doctor']['doctor_last_name'] }}</h3>
                            <h5>{{ $billing_detail['doctor']['specialist_categories']['speciality_name'] }}</h5>
                        @elseif(!empty($billing_detail->nurse_id))
                            <h3>Mr. {{ $billing_detail['nurse']['nurse_first_name'] }} {{ $billing_detail['nurse']['nurse_last_name'] }}</h3>
                            <h5>{{ $billing_detail['nurse']['specialist_categories']['speciality_name'] }}</h5>
                        @elseif(!empty($billing_detail->employee_id))
                            <h3>Mr. {{ $billing_detail['employee']['nurse_first_name'] }} {{ $billing_detail['employee']['nurse_last_name'] }}</h3>
                            <h5>{{ $billing_detail['employee']['specialist_categories']['speciality_name'] }}</h5>
                        @elseif(!empty($billing_detail->hospital_id))
                            <h3>{{ $billing_detail['hospital']['hosp_name'] }}</h3>
                            <h5>{{ $billing_detail['hospital']['specialist_categories']['speciality_name'] }}</h5>
                        @endif
                                     </div>
                                 </div>
                                 <div class="patient_fettle mb-5">
                                     <h3>Disputed Billing Details <span></span></h3>
                                      <div class="activity_record mb-4">
                                          <h5>Laboratorium Service cost - Cholesterol LDL Test <span>₦ 50</span></h5>
                                          <div class="activity">
                                              <span>15 July 2018</span>
                                              <div class="activity_record_text">
                                                 Billing created by Dr. Ayotunde Akitsune from Geo Medical Center at 15 July 2018, 09.00 EST and assign to Mrs. Rosetta Potter (HMO Office)
                                              </div>
                                              <a href="javascript:;" class="reply_action">
                                                  <img src="{{asset('admin/doctor/images/reply.svg')}}" alt="icon"> Reply comment
                                              </a>
                                          </div>
                                      </div>
                                      <div class="activity_record">
                                          <h5>Medicines - Omeprazol Meds 50mg <span>₦ 250</span></h5>
                                          <div class="activity">
                                              <span>15 July 2018</span>
                                              <div class="activity_record_text">
                                                 Mrs. Rosetta Potter (HMO) Comment “The medicine amount goes over the amount for the patient, I think the patient only consume not more than 20 pills” for disputed bill ₦ 250
                                              </div>
                                              <div class="activity_reply">
                                                  <h4><b>Replied</b> by <b>Geo Medical Hospital’s Staff</b> at <b>16 July 2018</b></h4>
                                                  <p>Nam porttitor blandit accumsan. Ut vel dictum sem, a pretium dui. In malesuada enim in dolor euismod, id commodo mi consectetur. Curabitur at vestibulum nisi. Nullam vehicula nisi velit.</p>
                                              </div>
                                          </div>
                                      </div>
                                 </div>
                                 <div class="patient_fettle">
                     <h3 class="mb-3">Details of Services</h3>
                     @if(count($billing_detail['billing_service']) > 0)
                        <table class="fettle_table mb-2">                        
                          <tr>
                             <th>Date</th>
                             <th>Kind of Services</th>
                             <th>Amount</th>
                         </tr>
                          @php $sub_total = 0; @endphp
                          @foreach($billing_detail['billing_service'] as $billing_service)
                            <tr>
                              <td>{{ date('d/m/Y',$billing_service['service_date'])}}</td>
                              <td>{{ $billing_service['service_name'] }}</td>
                              <td>₦ {{ $billing_service['service_amount'] }}</td>
                            </tr>
                            @php $sub_total = $sub_total+ $billing_service['service_amount']; @endphp
                          @endforeach
                            <tr class="table_total">
                              <td colspan="2">Sub Total Amount</td>
                              <td>₦ {{ $sub_total }}</td>
                            </tr>                               
                        </table>
                        @endif
                     <h6>Last updated 20th July, 2018 by Deo Medical Center’s Officer</h6>
                 </div>
                                 <div class="patient_fettle">
                                     <h3 class="mb-3">Details of Medicines</h3>
                                     <table class="fettle_table mb-2">
                                         <tr>
                                             <th>Date</th>
                                             <th>Kind of Medicines</th>
                                             <th>Type</th>
                                             <th>Qty</th>
                                             <th>Amount</th>
                                         </tr>
                                         <tr>
                                             <td>12/02/2018</td>
                                             <td>Omeprazol Meds 50mg</td>
                                             <td>Capsule</td>
                                             <td>10</td>
                                             <td>₦ 400</td>
                                         </tr>
                                         <tr>
                                             <td>13/02/2018</td>
                                             <td>Penicilin</td>
                                             <td>Syrup</td>
                                             <td>5</td>
                                             <td>₦ 130</td>
                                         </tr>
                                         <tr class="table_total">
                                             <td colspan="4">Sub Total Amount</td>
                                             <td>₦ 530</td>
                                         </tr>
                                     </table>
                                     <h6 class="mb-0">Last updated 20th July, 2018 by Deo Medical Center’s Officer</h6>
                                      <h2>Total Amount : <span>₦ {{$billing_detail['payable_amount']}}</span></h2>
                                 </div>
                             </div>
                        </div>
                    </div>
                </main>


@endsection