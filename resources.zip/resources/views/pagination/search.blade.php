@if ($paginator->lastPage() > 1)


    <button type="button" class="btn btn-light btn-xs pre1" data-url="{{ $paginator->url($paginator->currentPage()-1) }}">
Previous
       
    </button> 

    <span>Page {{ $paginator->currentPage() }} of {{ $paginator->lastPage() }} Pages</span>  

    <button type="button" class="btn btn-light btn-xs next1" data-url="{{ $paginator->url($paginator->currentPage()+1) }}">

Next
    </button>

    <div><p id="current_page" style="display: none;">{{ $paginator->currentPage() }}</p></div>

    <div class="lol" style="display: none;"></span id="last_page"   style="display: none !important; color:#fff">{{ $paginator->lastPage() }} </span>
    </div>
   

@endif