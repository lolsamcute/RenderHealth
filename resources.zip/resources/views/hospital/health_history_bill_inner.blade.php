<div class="table_hospital">
    <table class="table" cellspacing="10">
        <tr>
            <th>DATE CREATED</th>
            <th>INVOICE ID</th>
            <th>HOSPITAL / LABS</th>
            <th>AMOUNT</th>
            <th>PAID</th>
            <th>Balance</th>
        </tr>
        @if(count($billing_detail) > 0)
            @foreach($billing_detail as $billing_det)
                <tr <?php if(($billing_det['payable_amount'] - $billing_det['paid_amount']) != 0){ ?> class="pending" <?php }?>>
                    <td>{{ date('j F Y',$billing_det['billing_date']) }}</td>
                    <td>{{ $billing_det['invoice_number'] }}</td>
                    <td>Geo Medical Center</td>
                    <td>₦ {{ $billing_det['payable_amount'] }}</td>
                    <td>₦ {{ $billing_det['paid_amount'] }}</td>
                    @if(($billing_det['payable_amount'] - $billing_det['paid_amount']) > 0)
                        <td>₦ {{ $billing_det['payable_amount'] - $billing_det['paid_amount'] }}</td> 
                    @else  
                        <td colspan="2"><span class="paid">PAID</span></td>   
                    @endif                                           
                    @if(($billing_det['payable_amount'] - $billing_det['paid_amount']) > 0)
                        <td>
                            <a href="javascript:;" class="btn btn-info btn-xs" onclick="payWithPaystack(this);" data-amt="{{$billing_det['payable_amount'] - $billing_det['paid_amount']}}" data-doc_id="{{ $billing_det['doctor_id'] }}" data-pt_id="{{ $billing_det['patient_id'] }}" data-bill_id="{{ $billing_det['billing_id'] }}">Pay Bill</a>
                        </td>
                    @endif                         
                </tr>
            @endforeach
        @else
                <tr>
                    <td colspan="6" class="text-center">No Bills Found</td>
                </tr>
        @endif                                
    </table>
    <div class="table_pagination">
       <button type="button" class="btn btn-light btn-xs pre1" <?php if($billing_detail->previousPageUrl()){  } else{ echo "disabled"; } ?> data-url="<?php echo $billing_detail->previousPageUrl(); ?>">Previous Page</button>
       <span>Page {{ $billing_detail->currentPage() }} of {{ $billing_detail->lastPage() }} Pages</span>
       <button type="button" class="btn btn-light btn-xs next1"  <?php if($billing_detail->nextPageUrl()){  } else{ echo "disabled"; } ?>  data-url="<?php echo $billing_detail->nextPageUrl(); ?>">Next Page</button>
    </div>
</div>