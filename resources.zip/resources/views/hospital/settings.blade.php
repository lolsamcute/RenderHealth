@extends('layouts.doctor')
@section('content')                
<main class="col-12 col-md-12 col-xl-12 bd-content">
    <div class="row">
        <div class="col-12">
            <div class="page_head">
                <h1 class="heading">Settings</h1>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-12">
            <div class="widget">
                <form method="post" name="doctorAccountSetting" id="doctorAccountSetting" action="" onsubmit="changeDocPassword(this); return false;">
                    {{csrf_field()}}
                    <div class="medical_header">
                        <ul class="nav nav-pills" role="tablist">
                            <li><a class="active" role="tab"  data-toggle="pill" href="#account_info">Account Info</a></li>
                            <li><a role="tab" data-toggle="pill"  href="#profile">Profile</a></li>
                        </ul>
                    </div>
                    <div class="medical_body padding-40">
                        <div class="tab-content">
                            <div id="account_info" class="tab-pane fade show active">
                                <div class="row">
                                    <div class="col-sm-6">
                                        <div class="alert alert-danger-outline alert-dismissible alert_icon fade show error_msg_settings text-left mb-5" id="error_msg_settings" role="alert" style="display:none;">
                                            <div class="d-flex align-items-center">
                                                <div class="alert-icon-col">
                                                    <span class="fa fa-warning"></span>
                                                </div>
                                                <div class="alert_text error_text_settings">
                                                    Email field is required
                                                </div>
                                                <a href="#" class="close alert_close" data-dismiss="alert" aria-label="close"><i class="fa fa-close"></i></a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-sm-6">
                                        <div class="form-group">
                                            <label>Email Account</label>
                                            <input class="form-control doctor_email" type="text">
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-sm-6">
                                        <div class="setting_heading">
                                            Change Password
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-sm-6">
                                        <div class="form-group">
                                            <label>Current Password</label>
                                            <input class="form-control crt_password" type="password">
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-sm-6">
                                        <div class="row">
                                            <div class="col-sm-6">
                                                <div class="form-group">
                                                    <label>New Password</label>
                                                    <input class="form-control new_password" type="password">
                                                </div>
                                            </div>
                                            <div class="col-sm-6">
                                                <div class="form-group">
                                                    <label>Re-type New Password</label>
                                                    <input class="form-control cnfrm_password" type="password">
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                </div>
                                <div class="row">
                                    <div class="col-sm-6">
                                        <button type="submit" class="btn btn-primary mt-4">Save Setting</button>
                                    </div>
                                </div>
                            </div>
                            <div id="profile" class="tab-pane fade">Profile</div>
                          </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</main>
@endsection