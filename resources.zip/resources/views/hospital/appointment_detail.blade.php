@extends('layouts.doctor')
@section('content')
<main class="col-12 col-md-12 col-xl-12 bd-content">
    <div class="row">
        <div class="col-12">
            <div class="page_head">
                <a href="{{ url('doctor/all_appointments') }}" class="back_button">Back to my schedule</a>
                <h1 class="inner_heading">Appointment Details</h1>
             </div>
        </div>
    </div>
    <div class="row">
        <div class="col-12">
             <div class="widget padding-40">
                <div class="appointment_detail">
                    <div class="patient_profile">
                    	@if($appointment[0]['patient_id'] != "")
                    		@if($appointment[0]->patient_detail->patient_profile_img != "")
                    		<div class="pp_image">
	                            <img src="{{ asset('uploads/patient/'.$appointment[0]->patient_detail->patient_profile_img) }}" alt="image">
	                        </div>
                    		@else
			                <div class="pp_image">
			                    <img src="{{ asset('admin/doctor/images/profile.svg') }}" alt="image"/>
			                </div>
			                @endif                        
	                        <div class="pp_desc">
	                        	@if($appointment[0]->patient_detail->patient_gender == 1)
	                            	<h4>Mr. {{ ucfirst($appointment[0]->patient_detail->patient_first_name) }} {{ ucfirst($appointment[0]->patient_detail->patient_last_name) }}</h4>
	                            	<h5>29 y/o, Male</h5>
	                            @elseif($appointment[0]->patient_detail->patient_gender == 2)
	                            	<h4>Ms. {{ ucfirst($appointment[0]->patient_detail->patient_first_name) }} {{ ucfirst($appointment[0]->patient_detail->patient_last_name) }}</h4>
	                            	<h5>29 y/o, Female</h5>
	                            @else
	                            	<h4>{{ ucfirst($appointment[0]->patient_detail->patient_first_name) }} {{ ucfirst($appointment[0]->patient_detail->patient_last_name) }}</h4>
	                           	@endif
	                        </div>
	                    </div>
	               	@endif
                    <div class="d-flex">
                         <div class="patient_more">
                            <img src="{{ asset('admin/doctor/images/loc.svg') }}" alt="icon">
                            <div>
                                @if(empty($appointment[0]->hospital_id))
                                    <h4>{{ $appointment[0]->hospital_name }}</h4>
                                    <h5>Oshodi Isolo, Lagos, Nigeria</h5>
                                @else
                                    <h4>{{ $appointment[0]->hospital_detail->hosp_name }}</h4>
                                    <h5>{{ $appointment[0]->hospital_detail->hosp_address }}</h5>
                                @endif
                            </div>
                        </div>
                         <div class="patient_more">
                            <img src="{{ asset('admin/doctor/images/clock.svg') }}" alt="icon">
                            <div>
                                @php  date_default_timezone_set($timezone); @endphp
                                <h4>{{ date('D',$appointment[0]->appointment_time) }}, {{ date('j M Y',$appointment[0]->appointment_time) }}</h4>
                                <h5>at {{ date('h:i A',$appointment[0]->appointment_time) }}</h5>
                            </div>
                        </div>
                    </div>
                    <button type="button" class="btn btn-primary btn-sm">View Medical Records</button>
                </div>
                <div class="cause">
                    <h5>Reason for visit :</h5>
                    <p>{{ $appointment[0]->symptoms }}</p>
                </div>
                <div class="patient_fettle">
                    <h3>Patient Health Diary <span></span></h3>
                    <div class="row">
                        <div class="col-sm-8">
                            <div class="ailing">
                                <h5><img src="{{ asset('admin/doctor/images/smilies/face-with-thermometer.png') }}" alt="image">Feeling Sick</h5>
                                <p>The monkey-rope is found in all whalers; but it was only in the Pequod that the monkey and his holder were ever tied together. This improvement upon the original</p>
                            </div>
                            <div class="infirmary_pic">
                                <img src="{{ asset('admin/doctor/images/img1.png') }}" alt="image">
                                <img src="{{ asset('admin/doctor/images/img2.png') }}" alt="image">
                            </div>
                        </div>
                        <div class="col-sm-4">
                            <div class="supplementary">
                                <h6>Diary created :</h6>
                                <h5>09 February 2018, 12.45 PM</h5>
                            </div>
                            <div class="supplementary">
                                <h6>Medications :</h6>
                                <h5>Panadol, Ampicillin, Benadyl</h5>
                            </div>
                        </div>
                    </div>
                </div>
             </div>
        </div>
    </div>
</main>
@endsection