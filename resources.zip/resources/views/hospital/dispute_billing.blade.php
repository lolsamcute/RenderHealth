<?php 
//~ echo '<pre>'; print_r($appointments); die('here');
 ?>

@extends('layouts.doctor')
@section('content')


                <main class="col-12 col-md-12 col-xl-12 bd-content">
                    <div class="row">
                        <div class="col-12">
                            <div class="page_head">
                                <h1 class="heading">
                                    Disputed Billing
                                </h1>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-12">
                            <div class="tab-content">
                                <div class="table_hospital pagination_fixed_bottom">
                                   <table class="table" cellspacing="10">
                                       <tr>
                                           <th>DATE CREATED</th>
                                           <th>INVOICE ID</th>
                                           <th>HOSPITAL / LABS</th>
                                           <th>HMO OFFICER</th>
                                           <th>AMOUNT</th>
                                           <th>PAID</th>
                                           <th>BALANCE</th>
                                       </tr>
                                       <tr class="pending">
                                           <td>20 July 2018</td>
                                           <td>XV110/13022018/009</td>
                                           <td>Geo Medical Center</td>
                                           <td>Mrs. Rosetta Potter</td>
                                           <td>₦ 1,645</td>
                                           <td>₦ 645</td>
                                           <td>₦ 1,000</td>
                                           <td><a href="dispute_billing_detail" class="btn btn-light btn-xs" name="button"><img class="icon" src="{{asset('admin/doctor/images/eye.svg')}}" alt="icon">View Detail</a></td>
                                       </tr>
                                       <tr>
                                           <td>20 July 2018</td>
                                           <td>XV110/13022018/009</td>
                                           <td>Geo Medical Center</td>
                                           <td>Mrs. Rosetta Potter</td>
                                           <td>₦ 1,645</td>
                                           <td>₦ 645</td>
                                           <td>₦ 1,000</td>
                                           <td><a href="dispute_billing_detail" class="btn btn-light btn-xs" name="button"><img class="icon" src="{{asset('admin/doctor/images/eye.svg')}}" alt="icon">View Detail</a></td>
                                       </tr>
                                   </table>
                                   <div class="table_pagination">
                                       <button type="button" class="btn btn-light btn-xs" disabled>Previous Page</button>
                                       <span>Page 1 of 3 Pages</span>
                                       <button type="button" class="btn btn-light btn-xs">Next Page</button>
                                   </div>
                                </div>
                              </div>
                        </div>
                    </div>
                </main>

@endsection