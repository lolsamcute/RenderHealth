<div>
Someone just contacted us:</div>
<div> Subject: {{ $subject }}</div>
<div> Message: {{ $emailmessage }}</div>