@extends('layouts.app')

<!-- Main Content -->
@section('content')
<div class="page">
     <div class="page-single">
        <div class="container">
            <div class="row">
                <div class="col col-login mx-auto">
                    <div class="text-center mb-6">
                        <h3><i class="fe fe-map-pin mr-2"></i>Location Plotting</h3>
                    </div>
                    @if (session('status'))
                        <div class="alert alert-success">
                            {{ session('status') }}
                        </div>
                    @endif
                    
                    @if(isset($msg))
                         <div class="alert alert-success">
                              <a href="#" class="close" data-dismiss="alert" aria-label="close"></a>
                              {{$msg}}
                         </div>
                    @endif
                                   
                    <form class="form-horizontal card" role="form" method="POST" action="{{ url('/password/email') }}">
                        <div class="card-body p-6">
                            {{ csrf_field() }}
                            <div class="card-title">Forgot password</div>
                            <p class="text-muted">Enter your email address and we will send you a password reset email.</p>
                            <div class="form-group{{ isset($email) ? ' has-error' : '' }}">
                                <label for="email" class="form-label">E-Mail Address</label>
        
                                <input id="email" type="email" class="form-control" name="email" value="{{ old('email') }}" aria-describedby="emailHelp" placeholder="Enter email" required>
    
                                @if (isset($email))
                                    <span class="help-block error">
                                        <p>{{ $email }}</p>
                                    </span>
                                @endif
                            </div>
                            <div class="form-footer">
                                <button type="submit" class="btn btn-primary btn-block">Send Password Reset Link</button>
                            </div>
                        </div>
                    </form>
                    <div class="text-center text-muted">
                        Forget it, <a href="{{ url('login') }}">send me back</a> to the sign in screen.
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
