<div class="table_hospital pagination_fixed_bottom">
                <div class="table-responsive">
                    <table class="table" cellspacing="10">
                        <tr>
                            <th>Image</th>
                            <th>Name of facility</th>
                            <th>Deal Category</th>
                            <th>Deal Start Date</th>
                            <th>Deal End Date</th>
                            <th>Deal Status</th>
                            <th>Action</th>
                        </tr>
                        @if(count($deals) > 0)
                        @foreach($deals as $deal)
                        <tr>
                            <td>
                                <div class="photo_profile_place">
                                    <img src="{{ $deal->image ? asset('dealsimages/'.$deal->image) : asset('admin/adminimages/thumb.svg') }}" alt="image" id="preview-image" width="100px" height="100px">
                                </div>
                            </td>
                            <td>{{$deal->facility_details['hosp_name']}}</td>
                            <td>{{$deal->categories_details['name']}}</td>
                            <td>@if(!empty($deal->start_date)) {{ date('d M, Y', strtotime($deal->start_date))}} @else {{"--"}} @endif </td>
                            <td>@if(!empty($deal->end_date)) {{ date('d M, Y', strtotime($deal->end_date))}} @else {{"--"}} @endif </td>
                            <td>
                                <span class="badge badge-pill 
                                    <?php if ($deal['status'] == 'Active') {
                                    echo 'badge-success';
                                    } else if ($deal['status'] == 'Approved') {
                                    echo 'badge-success';
                                    }else if ($deal['status'] == 'New') {
                                        echo 'badge-secondary';
                                    }?>" id="status_row_{{$deal['id']}}">
                                    
                                    <?php if ($deal['status'] == 'Active') {
                                    echo 'Active';
                                    } else if ($deal['status'] == 'Approved') {
                                    echo 'Approved';
                                    }else if ($deal['status'] == 'New') {
                                        echo 'New';
                                    }?>
                                </span>
                            </td>
                            <td>
                                <a href="#" onclick="viewDeal(<?php echo $deal['id'] ?>)" class="btn btn-light btn-xs btn_view_deal" name="button">
                                    <img class="icon" src="{{ asset('admin/adminimages/eye.svg') }}" alt="icon">View
                                </a>
                                <a href="#" onclick="removeDeal(<?php echo $deal['id'] ?>)" class="btn btn-light btn-xs btn_delete_deal" name="button">
                                    <img class="icon" src="{{ asset('admin/adminimages/delete.svg') }}" alt="icon">Delete
                                </a>
                                <a href="#" onclick="editDeal(<?php echo $deal['id'] ?>)" class="btn btn-light btn-xs btn_edit_deal" name="button">
                                    <img class="icon" src="{{ asset('admin/adminimages/btn-edit.svg') }}" alt="icon">Edit
                                </a>
                            </td>
                        </tr>
                        @endforeach
                        @else
                        <tr>
                            <td colspan="7" class="text-center">No Deals Found</td>
                        </tr>
                        @endif
                    </table>
                </div>

                <div class="table_pagination">
                    <button type="button" class="btn btn-light btn-xs pre_emp" 
                    <?php if ($deals->previousPageUrl()) {
                    }else {
                        echo "disabled";
                    } ?> data-url="<?php echo $deals->previousPageUrl(); ?>&type=doc_page">Previous Page
                    </button>
                    <input type="hidden" class="doc_page_hidden" value="{{$deals->currentPage()}}">
                    <span>Page {{ $deals->currentPage() }} of {{ $deals->lastPage() }} Pages</span>
                    <button type="button" class="btn btn-light btn-xs next_emp" 
                        <?php if ($deals->nextPageUrl()) {
                        } else {
                        echo "disabled";
                        } ?> data-url="<?php echo $deals->nextPageUrl(); ?>&type=doc_page">Next Page
                    </button>
                </div> 
            </div>