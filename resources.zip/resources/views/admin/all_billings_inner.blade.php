<div id="all_billings" class="tab-pane fade <?php if($_GET['type'] == 'all_page') { ?> show active <?php } ?>">
  <div class="table_hospital pagination_fixed_bottom">
     <table class="table" cellspacing="10">        
       <tr>
           <th>DATE CREATED</th>
           <th>INVOICE ID</th>
           <th>HOSPITAL / LABS</th>
           <th>HMO OFFICER</th>
           <th>AMOUNT</th>
           <th>PAID</th>
           <th>BALANCE</th>
       </tr>        
       @if(count($billing_detail) > 0)
        @foreach($billing_detail as $billing_det)
           <tr <?php if($billing_det['seen_status'] == 0){ ?> class="recent" <?php } else if($billing_det['payable_amount'] - $billing_det['paid_amount'] > 0){ ?> class="pending" <?php } ?>>
                <td>{{ date('j F Y',$billing_det['billing_date']) }}</td>
                <td>{{ $billing_det['invoice_number'] }}</td>
                <td>{{ $billing_det['hospital']['hosp_name'] }}</td>
                <td>Mrs. Rosetta Potter</td>
                <td>₦ {{ $billing_det['payable_amount'] }}</td>
                <td>₦ {{ $billing_det['paid_amount'] }}</td>
                <td>₦ {{ $billing_det['payable_amount'] - $billing_det['paid_amount'] }}</td>   
                <td><a href="{{ asset('admin/billing_detail/'.$billing_det['billing_id'].'/'.$billing_det['doctor_id']) }}" class="btn btn-light btn-xs" name="button"><img class="icon" src="{{ asset('admin/doctor/images/eye.svg') }}" alt="icon">View Detail</a></td>                                 
           </tr>
          @endforeach
        @else
          <tr>
              <td colspan="7" class="text-center">No Bills Found</td>
          </tr>
        @endif                                  
      </table>
     <div class="table_pagination">
         <button type="button" class="btn btn-light btn-xs pre_labs" <?php if($billing_detail->previousPageUrl()){  } else{ echo "disabled"; } ?> data-url="<?php echo $billing_detail->previousPageUrl(); ?>&type=all_page">Previous Page</button>
         <input type="hidden" class="all_hidden" value="{{$billing_detail->currentPage()}}">
         <span>Page {{ $billing_detail->currentPage() }} of {{ $billing_detail->lastPage() }} Pages</span>
         <button type="button" class="btn btn-light btn-xs next_labs"  <?php if($billing_detail->nextPageUrl()){  } else{ echo "disabled"; } ?>  data-url="<?php echo $billing_detail->nextPageUrl(); ?>&type=all_page">Next Page</button>
     </div>
  </div>
</div>
<div id="outstanding_billings" class="tab-pane fade <?php if($_GET['type'] == 'out_billings') { ?> show active <?php } ?>">
  <div class="table_hospital pagination_fixed_bottom">
     <table class="table" cellspacing="10">        
       <tr>
           <th>DATE CREATED</th>
           <th>INVOICE ID</th>
           <th>HOSPITAL / LABS</th>
           <th>HMO OFFICER</th>
           <th>AMOUNT</th>
           <th>PAID</th>
           <th>BALANCE</th>
       </tr>        
      @if(count($outstanding_detail) > 0)
        @foreach($outstanding_detail as $outstanding_det)
           <tr <?php if($outstanding_det['seen_status'] == 0){ ?> class="recent" <?php } else if($outstanding_det['payable_amount'] - $outstanding_det['paid_amount'] > 0){ ?> class="pending" <?php } ?>>
                <td>{{ date('j F Y',$outstanding_det['billing_date']) }}</td>
                <td>{{ $outstanding_det['invoice_number'] }}</td>
                <td>{{ $billing_det['hospital']['hosp_name'] }}</td>
                <td>Mrs. Rosetta Potter</td>
                <td>₦ {{ $outstanding_det['payable_amount'] }}</td>
                <td>₦ {{ $outstanding_det['paid_amount'] }}</td>
                <td>₦ {{ $outstanding_det['payable_amount'] - $outstanding_det['paid_amount'] }}</td>     
                <td><a href="{{ asset('admin/billing_detail/'.$billing_det['billing_id']) }}" class="btn btn-light btn-xs" name="button"><img class="icon" src="{{ asset('admin/doctor/images/eye.svg') }}" alt="icon">View Detail</a></td>                               
           </tr>
          @endforeach
        @else
          <tr>
              <td colspan="7" class="text-center">No Outstanding Bills Found</td>
          </tr>
        @endif                                 
     </table>
     <div class="table_pagination">
         <button type="button" class="btn btn-light btn-xs pre_labs" <?php if($outstanding_detail->previousPageUrl()){  } else{ echo "disabled"; } ?> data-url="<?php echo $outstanding_detail->previousPageUrl(); ?>&type=out_billings">Previous Page</button>
         <input type="hidden" class="out_hidden" value="{{$outstanding_detail->currentPage()}}">
         <span>Page {{ $outstanding_detail->currentPage() }} of {{ $outstanding_detail->lastPage() }} Pages</span>
         <button type="button" class="btn btn-light btn-xs next_labs"  <?php if($outstanding_detail->nextPageUrl()){  } else{ echo "disabled"; } ?>  data-url="<?php echo $outstanding_detail->nextPageUrl(); ?>&type=out_billings">Next Page</button>
     </div>
  </div>
</div>
<div id="paid_billings" class="tab-pane fade <?php if($_GET['type'] == 'paid_billings') { ?> show active <?php } ?>">
  <div class="table_hospital pagination_fixed_bottom">
     <table class="table" cellspacing="10">        
       <tr>
           <th>DATE CREATED</th>
           <th>INVOICE ID</th>
           <th>HOSPITAL / LABS</th>
           <th>HMO OFFICER</th>
           <th>AMOUNT</th>
           <th>PAID</th>
           <th>BALANCE</th>
       </tr>          
       @if(count($paid_detail) > 0)
        @foreach($paid_detail as $paid_det)
           <tr <?php if($paid_det['seen_status'] == 0){ ?> class="recent" <?php } else if($paid_det['payable_amount'] - $paid_det['paid_amount'] > 0){ ?> class="pending" <?php } ?>>
                <td>{{ date('j F Y',$paid_det['billing_date']) }}</td>
                <td>{{ $paid_det['invoice_number'] }}</td>
                <td>{{ $billing_det['hospital']['hosp_name'] }}</td>
                <td>Mrs. Rosetta Potter</td>
                <td>₦ {{ $paid_det['payable_amount'] }}</td>
                <td>₦ {{ $paid_det['paid_amount'] }}</td>
                <td>₦ {{ $paid_det['payable_amount'] - $paid_det['paid_amount'] }}</td>   
                <td><a href="{{ asset('admin/billing_detail/'.$billing_det['billing_id']) }}" class="btn btn-light btn-xs" name="button"><img class="icon" src="{{ asset('admin/doctor/images/eye.svg') }}" alt="icon">View Detail</a></td>                                 
           </tr>
          @endforeach
        @else
          <tr>
              <td colspan="7" class="text-center">No Paid Bills Found</td>
          </tr>
        @endif           
      </table>
     <div class="table_pagination">
         <button type="button" class="btn btn-light btn-xs pre_labs" <?php if($paid_detail->previousPageUrl()){  } else{ echo "disabled"; } ?> data-url="<?php echo $paid_detail->previousPageUrl(); ?>&type=paid_billings">Previous Page</button>
         <input type="hidden" class="paid_hidden" value="{{$paid_detail->currentPage()}}">
         <span>Page {{ $paid_detail->currentPage() }} of {{ $paid_detail->lastPage() }} Pages</span>
         <button type="button" class="btn btn-light btn-xs next_labs"  <?php if($paid_detail->nextPageUrl()){  } else{ echo "disabled"; } ?>  data-url="<?php echo $paid_detail->nextPageUrl(); ?>&type=paid_billings">Next Page</button>
     </div>
  </div>
</div>