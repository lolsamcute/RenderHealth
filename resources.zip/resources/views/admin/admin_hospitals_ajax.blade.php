<div id="pending_hospital_labs" class="tab-pane fade <?php if($_GET['type'] == 'pen_page') { ?> show active <?php } ?>"">
<div class="table_hospital pagination_fixed_bottom">
                        <div class="table-responsive">
                            <table class="table" cellspacing="10">
                                <tr>
                                    <th>MEMBER DATA</th>
                                    <th>ADDRESS</th>
                                    <th>PHONE NUMBER</th>
                                    <th>DATE CREATED</th>
                                    <th></th>
                                </tr>
                                @if(count($pending_hospitals) > 0)
                                @foreach($pending_hospitals as $pending_hospital)
                                <tr>
                                    <td>
                                        <div class="d_profile">
                                            <div class="d_pro_text">
                                                <h4>{{ $pending_hospital['hosp_name'] }}</h4>
                                                <a href="javascript:;">{{ $pending_hospital['hosp_state'] }}, {{ $pending_hospital['hosp_country'] }}</a>
                                            </div>
                                        </div>
                                    </td>
                                    <td>{{ $pending_hospital['hosp_address'] }}</td>
                                    <td>{{ $pending_hospital['hosp_phone'] }}</td>
                                    <td>{{ date('d M Y',$pending_hospital['hosp_created_date']) }}</td>
                                    <td>
                                        <button type="button" class="btn btn-blue btn-sm mr-2" name="button" onclick="accept_hosp('{{ $pending_hospital->id }}','{{ $pending_hospital->hosp_id }}');">Accept</button>
                                        <button type="button" class="btn btn-danger btn-sm" name="button" onclick="ignore_hosp('{{ $pending_hospital->id }}','{{ $pending_hospital->hosp_id }}');">Ignore</button>
                                    </td>
                                </tr>
                                @endforeach
                                @else
                                <tr>
                                    <td colspan="7" class="text-center">No Pending Hospitals Found</td>
                                </tr>
                                @endif
                            </table>
                        </div>
                        <div class="table_pagination">
                            <button type="button" class="btn btn-light btn-xs pre_labs" <?php if ($pending_hospitals->previousPageUrl()) {
                                                                                        } else {
                                                                                            echo "disabled";
                                                                                        } ?> data-url="<?php echo $pending_hospitals->previousPageUrl(); ?>&type=pen_page">Previous Page</button>
                            <input type="hidden" class="pen_page_hidden" value="{{$pending_hospitals->currentPage()}}">
                            <span>Page {{ $pending_hospitals->currentPage() }} of {{ $pending_hospitals->lastPage() }} Pages</span>
                            <button type="button" class="btn btn-light btn-xs next_labs" <?php if ($pending_hospitals->nextPageUrl()) {
                                                                                            } else {
                                                                                                echo "disabled";
                                                                                            } ?> data-url="<?php echo $pending_hospitals->nextPageUrl(); ?>&type=pen_page">Next Page</button>
                        </div>
                    </div>
</div>
<div id="search_hospital" class="tab-pane fade <?php if($_GET['type'] == 'all_page') { ?> show active <?php } ?>">
<div class="table_hospital pagination_fixed_bottom">
                        <div class="table-responsive">
                            <table class="table" cellspacing="10">
                                <tr>
                                    <th>MEMBER DATA</th>
                                    <th>HOSPITAL ID</th>
                                    <th class="text-center">DOCTORS</th>
                                    <th class="text-center">NURSES</th>
                                    <th class="text-center">ADMIN</th>
                                    <th class="text-right"></th>
                                </tr>
                                @if(count($all_hospitals) > 0)
                                @foreach($all_hospitals as $all_hospital)
                                <tr>
                                    <td>
                                        <div class="d_profile">
                                            <div class="d_pro_text">
                                                <h4>{{ $all_hospital['hosp_name'] }}</h4>
                                                <a href="javascript:;">{{ $all_hospital['hosp_state'] }}, {{ $all_hospital['hosp_country'] }}</a>
                                            </div>
                                        </div>
                                    </td>
                                    <td>Hospital-{{ $all_hospital['hosp_id'] }}</td>
                                    <td class="text-center">{{ $all_hospital['doctorsCount'] }}</td>
                                    <td class="text-center">{{ $all_hospital['nurseCount'] }}</td>
                                    <td class="text-center">{{ $all_hospital['administratorsCount'] }}</td>
                                    <td class="text-right">
                                        <a href="#" onclick="viewHospital(<?php echo $all_hospital['hosp_id'] ?>)" class="btn btn-light btn-xs btn_view_deal" name="button">
                                            <img class="icon" src="{{ asset('admin/adminimages/eye.svg') }}" alt="icon">View
                                        </a>
                                        <a href="#" onclick="editHospital(<?php echo $all_hospital['hosp_id'] ?>)" class="btn btn-light btn-xs btn_edit_deal" name="button">
                                            <img class="icon" src="{{ asset('admin/adminimages/btn-edit.svg') }}" alt="icon">Edit
                                        </a>
                                        <a href="#" onclick="removeHospital(<?php echo $all_hospital['hosp_id'] ?>)" class="btn btn-light btn-xs btn_delete_deal" name="button">
                                            <img class="icon" src="{{ asset('admin/adminimages/delete.svg') }}" alt="icon">Delete
                                        </a>
                                        <a class="btn btn-light btn-xs" href="{{ url('admin/hospital_detail/'.$all_hospital['hosp_id'])}}"><img class="icon" src="{{ asset('admin/doctor/images/eye.svg') }}" alt="icon">More</a>
                                    </td>
                                </tr>
                                @endforeach
                                @else
                                <tr>
                                    <td colspan="7" class="text-center">No Hospitals Found</td>
                                </tr>
                                @endif
                            </table>
                        </div>
                        <div class="table_pagination">
                            <button type="button" class="btn btn-light btn-xs pre_labs" <?php if ($all_hospitals->previousPageUrl()) {
                                                                                        } else {
                                                                                            echo "disabled";
                                                                                        } ?> data-url="<?php echo $all_hospitals->previousPageUrl(); ?>&type=all_page">Previous Page</button>
                            <input type="hidden" class="all_page_hidden" value="{{$all_hospitals->currentPage()}}">
                            <span>Page {{ $all_hospitals->currentPage() }} of {{ $all_hospitals->lastPage() }} Pages</span>
                            <button type="button" class="btn btn-light btn-xs next_labs" <?php if ($all_hospitals->nextPageUrl()) {
                                                                                            } else {
                                                                                                echo "disabled";
                                                                                            } ?> data-url="<?php echo $all_hospitals->nextPageUrl(); ?>&type=all_page">Next Page</button>
                        </div>
                    </div>
</div>