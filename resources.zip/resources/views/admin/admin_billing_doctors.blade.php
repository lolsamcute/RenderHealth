@extends('layouts.admin_dashboard')
@section('content')
<main class="col-12 col-md-12 col-xl-12 bd-content">
  <div class="row">
    <div class="col-12">
      <div class="page_head">
        <h1 class="heading">Doctors Billing
         
        </h1>
        
      </div>
    
    </div>
  </div>
  <div class="row">
    <div class="col-12">
      <div class="tab-content main_div">
        <div id="hostpital_appointment" class="tab-pane fade show active">
          <div class="table_hospital pagination_fixed_bottom">
            <div id="accordion" class="lookalike_table mb-4">
              <div class="lookalike_table_head">
                <ul>
                  <li style="width:22%">Doctor Data
                  </li>
                  <li style="width:19%">Doctor ID
                  </li>
               
                  <li style="width:13%">Phone Number
                  </li>
                  <li style="width:12%">Status
                  </li>
                  <li>
                  </li>
                </ul>
              </div>
              @if(count($all_doctors) > 0)
              @foreach($all_doctors as $single_doctor)

              <?php //print_r($all_doctors);die;?>
              <div class="lookalike_table_row">
                <div class="lookalike_table_body" id="head_one{{$single_doctor['doctor_id']}}">
                  <ul>
                    <li style="width:22%">
                      <div class="d_profile">
                        <div class="d_pro_img">
                          <img src="{{ asset('doctorimages/' . $single_doctor
                                    ['doctor_picture']) }}" alt="image">
                        </div>
                        <div class="d_pro_text">
                          <h4>  {{$single_doctor['doctor_title']}} {{ucfirst($single_doctor['doctor_first_name'])}} {{$single_doctor['doctor_last_name']}}
                          </h4>
                          <a href="javascript:;">{{$single_doctor['doctor_address']}}
                          </a>
                        </div>
                      </div>
                    </li>
                    <li style="width:19%">ID-Doctor-{{$single_doctor['doctor_id']}}
                    </li>
                   
                    <li style="width:13%">{{$single_doctor['doctor_phone']}}
                    </li>
                   <li style="width:12%">
                      <span class="badge badge-pill 
                                   <?php if($single_doctor['active_status']==0) { echo 'badge-danger'; } elseif($single_doctor['active_status']==1) { echo 'badge-success'; } ?>" id="status_row_{{$single_doctor['doctor_id']}}">
                        <?php if($single_doctor['active_status']==0){ echo 'Suspend';} else if($single_doctor['active_status']==1){ echo 'Active User';}?>
                      </span>
                    </li> 
                    <li>
                       <a href="{{url('/admin/view_all_billings')}}/{{$single_doctor['doctor_id']}}" class="btn btn-light btn-xs btn_view_appointment" data-id="{{$single_doctor['doctor_id']}}" name="button"><img class="icon" src="{{ asset('admin/adminimages/eye.svg') }}" alt="icon">View Billing
                      </a>
                    </li>
                  </ul>
                </div>
              
              </div>
              @endforeach
              @else
              No Doctor Found
              @endif 
            </div>
            <div class="table_pagination">
              <button type="button" class="btn btn-light btn-xs pre_emp" 
                      <?php if($all_doctors
              ->previousPageUrl()){  } else{ echo "disabled"; } ?> data-url="
              <?php echo $all_doctors->previousPageUrl(); ?>&type=doc_page">Previous Page
              </button>
            <input type="hidden" class="doc_page_hidden" value="{{$all_doctors
                                                                ->currentPage()}}">
            <span>Page {{ $all_doctors
              ->currentPage() }} of {{ $all_doctors
              ->lastPage() }} Pages
            </span>
            <button type="button" class="btn btn-light btn-xs next_emp"  
                    <?php if($all_doctors->nextPageUrl()){  } else{ echo "disabled"; } ?>  data-url="
            <?php echo $all_doctors->nextPageUrl(); ?>&type=doc_page">Next Page
            </button>
        </div>
      </div>
    </div>
  </div>
  </div>
</main>

@endsection
