@extends('layouts.admin_dashboard')
@section('content')

<main class="col-12 col-md-12 col-xl-12 bd-content">
    <div class="row">
        <div class="col-12">
            <div class="page_head">
            
                <a href="{{ url('admin/view_all_billings/'.$did)}}" class="back_button">Back to billings</a>
                <h1 class="inner_heading">{{$billing_detail['invoice_number']}}</h1>
                <div class="btn_billing">
                    @if($billing_detail['payable_amount'] - $billing_detail['paid_amount'] > 0)
                          @if($billing_detail['disputed']=="0")
                        <a href="javascript:;" class="btn btn-blue btn-sm mr-2 disputed" onclick="makebillingdispute(<?php echo $billing_detail['billing_id'];?>,1);">Dispute Billing</a>
                        <a href="javascript:;" class="btn btn-blue btn-sm mr-2 undisputed" onclick="makebillingdispute(<?php echo $billing_detail['billing_id'];?>,0);" style="display:none;">Undisputed Billing</a>
                        @else
                        <a href="javascript:;" class="btn btn-blue btn-sm mr-2 undisputed" onclick="makebillingdispute(<?php echo $billing_detail['billing_id'];?>,0);">Undisputed Billing</a>
                        <a href="javascript:;" class="btn btn-blue btn-sm mr-2 disputed" onclick="makebillingdispute(<?php echo $billing_detail['billing_id'];?>,1);" style="display:none;">Dispute Billing</a>
                        @endif 
                        <button class="btn btn-primary btn-sm  pay_bill" onclick="selectpaytype(this,event)">Pay billing</button> 
                 <div class="radio_div" style="display: none;">
     
                  <label class="radio-inline"><input type="radio" name="pay_by" value="1" onclick="getselectedvalue(this,event)">Pay by Cash</label>
                 
              
                  <label class="radio-inline"><input type="radio" name="pay_by" value="2" onclick="getselectedvalue(this,event)">Pay by Card</label>
                
                  </div>    
                  <div class="cash_input" style="display:none;">
                  <div id="myModal" class="modal fade" role="dialog">
                  <div class="modal-dialog modal-md modal-dialog-centered genmodal genmodal_custom custom_width1">

                  <!-- Modal content-->
                  <div class="modal-content">
                  <div class="modal-header">
                  <?php  $amount=$billing_detail['payable_amount'] - $billing_detail['paid_amount'];?>
                  <p>Amount to pay: ₦ {{$amount}}</p>
                  <button type="button" class="close" data-dismiss="modal" onclick="getpaypopup();" >&times;</button>    
                  </div>
                  <div class="modal-body">
                  <div class="row">
                  <div class="col-sm-6">
                  <div class="form-group">
                  <label>Enter Amount to pay by cash</label> 

                  <input type="number" name="pay_amount" value="{{$billing_detail['payable_amount'] - $billing_detail['paid_amount']}}"  max="{{$billing_detail['payable_amount'] - $billing_detail['paid_amount']}}" class="form-control"  onkeydown="limitmax(event,<?php echo $amount;?>);"  onkeyup="limitmax(event,<?php echo $amount;?>);" id="pay_amount">                     
                      </div>
                      </div>
                      </div> 
                       <div class="row">
                      <div class="col-sm-6">
                      <div class="form-group">
                       <button class="btn btn-primary btn-sm  pay_bill"  data-bill_id="{{ $billing_detail['billing_id'] }}" data-doc_id="{{ $billing_detail->doctor->doctor_id }}" data-pt_id="{{ $billing_detail['patient_id'] }}" onclick="paybycash(this)">PAY BILL</button>      
                       </div>
                       </div>
                       </div>           
                  </div>
                  </div>
                  </div>
                   </div> 
                
                <button class="btn btn-primary btn-sm  pay_bill" id="pay_bill_popup" style="display:none;" onclick="payWithPaystack(this);" data-amt="{{$billing_detail['payable_amount'] - $billing_detail['paid_amount']}}" data-doc_id="{{ $billing_detail->doctor->doctor_id }}" data-pt_id="{{ $billing_detail['patient_id'] }}" data-bill_id="{{ $billing_detail['billing_id'] }}">PAY BILL</button>
                 </div>
                    @else
                         @if($billing_detail['disputed']=="0")
                        <a href="javascript:;" class="btn btn-blue btn-sm mr-2 disputed" onclick="makebillingdispute(<?php echo $billing_detail['billing_id'];?>,1);">Dispute Billing</a>
                        <a href="javascript:;" class="btn btn-blue btn-sm mr-2 undisputed" onclick="makebillingdispute(<?php echo $billing_detail['billing_id'];?>,0);" style="display:none;">Undisputed Billing</a>
                        @else
                        <a href="javascript:;" class="btn btn-blue btn-sm mr-2 undisputed" onclick="makebillingdispute(<?php echo $billing_detail['billing_id'];?>,0);">Undisputed Billing</a>
                        <a href="javascript:;" class="btn btn-blue btn-sm mr-2 disputed" onclick="makebillingdispute(<?php echo $billing_detail['billing_id'];?>,1);" style="display:none;">Dispute Billing</a>
                        @endif 
                        <a href="javascript:;" class="btn btn-primary btn-sm disabled">Paid</a>
                    @endif
                </div>
             </div>
        </div>
    </div>
    <div class="row">
        <div class="col-12">

             <div class="widget padding-40">
                 <div class="billing_person">
                     <div class="bill_person">
                        {{ csrf_field() }}
                         <h6>Created by</h6>                        
                         <h3>{{ $billing_detail['hospital']['hosp_name'] }}</h3>
                         <h5>at {{ date('j F, Y',$billing_detail['billing_date'])}}, {{ date('H:i',$billing_detail['billing_date'])}} EST </h5>
                     </div>
                     <div class="separator"></div>
                     <div class="bill_person">
                         <h6>HMO Officer</h6>
                         <h3>Mrs. Rosetta Potter (HMO)</h3>
                         <h5>Company of HMO Name</h5>
                     </div>
                     <div class="separator"></div>
                     <div class="bill_person">
                        <h6>Doctor’s Name</h6>
                        @if(!empty($billing_detail->doctor_id))
                            <h3>Dr. {{ $billing_detail['doctor']['doctor_first_name'] }} {{ $billing_detail['doctor']['doctor_last_name'] }}</h3>
                            <h5>{{ $billing_detail['doctor']['specialist_categories']['speciality_name'] }}</h5>
                        @elseif(!empty($billing_detail->nurse_id))
                            <h3>Mr. {{ $billing_detail['nurse']['nurse_first_name'] }} {{ $billing_detail['nurse']['nurse_last_name'] }}</h3>
                            <h5>{{ $billing_detail['nurse']['specialist_categories']['speciality_name'] }}</h5>
                        @elseif(!empty($billing_detail->employee_id))
                            <h3>Mr. {{ $billing_detail['employee']['nurse_first_name'] }} {{ $billing_detail['employee']['nurse_last_name'] }}</h3>
                            <h5>{{ $billing_detail['employee']['specialist_categories']['speciality_name'] }}</h5>
                        @elseif(!empty($billing_detail->hospital_id))
                            <h3>{{ $billing_detail['hospital']['hosp_name'] }}</h3>
                            <h5>{{ $billing_detail['hospital']['specialist_categories']['speciality_name'] }}</h5>
                        @endif

                     </div>
                 </div>
                 <div class="patient_fettle">
                     <h3 class="mb-3">Details of Services</h3>
                     @if(count($billing_detail['billing_service']) > 0)
                        <table class="fettle_table mb-2">                        
                          <tr>
                             <th>Date</th>
                             <th>Kind of Services</th>
                             <th>Amount</th>
                         </tr>
                          @php $sub_total = 0; @endphp
                          @foreach($billing_detail['billing_service'] as $billing_service)
                            <tr>
                              <td>{{ date('d/m/Y',$billing_service['service_date'])}}</td>
                              <td>{{ $billing_service['service_name'] }}</td>
                              <td>₦ {{ $billing_service['service_amount'] }}</td>
                            </tr>
                            @php $sub_total = $sub_total+ $billing_service['service_amount']; @endphp
                          @endforeach
                            <tr class="table_total">
                              <td colspan="2">Sub Total Amount</td>
                              <td>₦ {{ $sub_total }}</td>
                            </tr>                               
                        </table>
                        @endif
                     <h6>Last updated 20th July, 2018 by Deo Medical Center’s Officer</h6>
                 </div>
                 <div class="patient_fettle">
                     <h3 class="mb-3">Details of Medicines</h3>
                     <table class="fettle_table mb-2">
                         <tr>
                             <th>Date</th>
                             <th>Kind of Medicines</th>
                             <th>Type</th>
                             <th>Qty</th>
                             <th>Amount</th>
                         </tr>
                         <tr>
                             <td>12/02/2018</td>
                             <td>Omeprazol Meds 50mg</td>
                             <td>Capsule</td>
                             <td>10</td>
                             <td>₦ 400</td>
                         </tr>
                         <tr>
                             <td>13/02/2018</td>
                             <td>Penicilin</td>
                             <td>Syrup</td>
                             <td>5</td>
                             <td>₦ 130</td>
                         </tr>
                         <tr class="table_total">
                             <td colspan="4">Sub Total Amount</td>
                             <td>₦ 530</td>
                         </tr>
                     </table>
                     <h6>Last updated 20th July, 2018 by Deo Medical Center’s Officer</h6>
                     <h2>Total Amount : <span>₦ {{$billing_detail['payable_amount']}}</span></h2>
                 </div>
                <div class="patient_fettle">
                    <h3>Activity Records <span></span></h3>
                     <div class="activity_record">
                         <div class="activity">
                             <span>{{ date('j F, Y',$billing_detail['billing_date'])}}</span>
                             <div class="activity_record_text">
                                Billing created by  @if(!empty($billing_detail->doctor_id))
                            Dr. {{ $billing_detail['doctor']['doctor_first_name'] }} {{ $billing_detail['doctor']['doctor_last_name'] }}
                           
                        @elseif(!empty($billing_detail->nurse_id))
                            Mr. {{ $billing_detail['nurse']['nurse_first_name'] }} {{ $billing_detail['nurse']['nurse_last_name'] }}
                          
                        @elseif(!empty($billing_detail->employee_id))
                           Mr. {{ $billing_detail['employee']['nurse_first_name'] }} {{ $billing_detail['employee']['nurse_last_name'] }}
                           
                        @elseif(!empty($billing_detail->hospital_id))
                            {{ $billing_detail['hospital']['hosp_name'] }}                          
                        @endif from {{ $billing_detail['hospital']['hosp_name'] }} at {{ date('j F, Y',$billing_detail['billing_date'])}}, {{ date('H:i',$billing_detail['billing_date'])}} EST  <!-- and assign to Mrs. Rosetta Potter (HMO Office) -->
                             </div>

                         </div>
                         </div>
                               @if(!empty($billing_detail->paid_date))                  
                      <div class="activity_record">
                         <div class="activity">
                             <span>{{ date('j F, Y',$billing_detail['paid_date'])}}</span>
                             <div class="activity_record_text">
                                @if($billing_detail['payable_amount'] - $billing_detail['paid_amount'] > 0)
                              ₦{{ $billing_detail['paid_amount'] ." Paid."}}
                              @elseif($billing_detail['payable_amount'] - $billing_detail['paid_amount'] == 0)
                                Bill Paid
                                @endif
                             </div>
                         </div>
                     </div>
                     @endif
                </div>
             </div>
        </div>
    </div>
</main>

@endsection
