@extends('layouts.admin_dashboard')
@section('content')
<main class="col-12 col-md-12 col-xl-12 bd-content">
    <div class="row">
        <div class="col-12">
            <div class="page_head">
        <h1 class="heading">Hospitals Billing
         
        </h1>
        
      </div>
           
 
        </div>
    </div>
    <div class="row">
        <div class="col-12">
            <div class="tab-content main_div">
                <div id="all_hospitals" class="tab-pane fade show active">
                    <div class="table_hospital pagination_fixed_bottom">
                       <table class="table" cellspacing="10">
                           <tr>
                               <th>MEMBER DATA</th>
                               <th>HOSPITAL ID</th>
                               <th class="text-center">DOCTORS</th>
                               <th class="text-center">NURSES</th>
                               <th class="text-center">ADMIN</th>
                               <th class="text-right"></th>
                           </tr>
                            @if(count($all_hospitals) > 0)
                            @foreach($all_hospitals as $all_hospital)
                           <tr>
                               <td>
                                   <div class="d_profile">
                                       <div class="d_pro_text">
                                           <h4>{{ $all_hospital['hosp_name'] }}</h4>
                                           <a href="javascript:;">{{ $all_hospital['hosp_state'] }}, {{ $all_hospital['hosp_country'] }}</a>
                                       </div>
                                   </div>
                               </td>
                               <td>Hospital-{{ $all_hospital['hosp_id'] }}</td>
                               <td class="text-center">{{ $all_hospital['doctorsCount'] }}</td>
                               <td class="text-center">0</td>
                               <td class="text-center">0</td>
                               <td class="text-right">
                                   <a class="btn btn-light btn-xs" href="{{ url('admin/hospital_billing/'.$all_hospital['hosp_id'])}}"><img class="icon" src="{{ asset('admin/doctor/images/eye.svg') }}" alt="icon">View Billing</a>
                                </td>
                           </tr>
                           @endforeach
                            @else
                              <tr>
                                  <td colspan="7" class="text-center">No Hospitals Found</td>
                              </tr>
                            @endif 
                       </table>
                       <div class="table_pagination">
                           <button type="button" class="btn btn-light btn-xs pre_labs" <?php if($all_hospitals->previousPageUrl()){  } else{ echo "disabled"; } ?> data-url="<?php echo $all_hospitals->previousPageUrl(); ?>&type=all_page">Previous Page</button>
                           <input type="hidden" class="all_page_hidden" value="{{$all_hospitals->currentPage()}}">
                           <span>Page {{ $all_hospitals->currentPage() }} of {{ $all_hospitals->lastPage() }} Pages</span>
                           <button type="button" class="btn btn-light btn-xs next_labs"  <?php if($all_hospitals->nextPageUrl()){  } else{ echo "disabled"; } ?>  data-url="<?php echo $all_hospitals->nextPageUrl(); ?>&type=all_page">Next Page</button>
                       </div>
                    </div>
                </div>
              </div>
        </div>
    </div>
</main>

@endsection