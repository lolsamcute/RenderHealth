@extends('layouts.admin_dashboard')
@section('content')
<main class="col-12 col-md-12 col-xl-12 bd-content">
  <div class="row">
    <div class="col-12">
      <div class="page_head">
        <h1 class="heading">Dispute Billing according to Doctors
         
        </h1>
        
      </div>
      <div class="alert alert-danger-outline alert-dismissible alert_icon fade show" role="alert" style="display: none;">
        <div class="d-flex align-items-center">
          <div class="alert-icon-col">
            <span class="fa fa-warning">
            </span>
          </div>
          <div class="alert_text pending_danger">
          </div>
          <a href="#" class="close alert_close" data-dismiss="alert" aria-label="close">
            <i class="fa fa-close">
            </i>
          </a>
        </div>
      </div>
      <div class="alert alert-success-outline alert-dismissible alert_icon fade show" role="alert" style="display: none;">
        <div class="d-flex align-items-center">
          <div class="alert-icon-col">
            <span class="fa fa-check">
            </span>
          </div>
          <div class="alert_text pending_success">
          </div>
          <a href="#" class="close alert_close" data-dismiss="alert" aria-label="close">
            <i class="fa fa-close">
            </i>
          </a>
        </div>
      </div>
    </div>
  </div>
  <div class="row">
    <div class="col-12">
      <div class="tab-content main_div">
        <div id="hostpital_appointment" class="tab-pane fade show active">
          <div class="table_hospital pagination_fixed_bottom">
            <div id="accordion" class="lookalike_table mb-4">
              <div class="lookalike_table_head">
                <ul>
                  <li style="width:22%">Doctor Data
                  </li>
                  <li style="width:19%">Doctor ID
                  </li>
               
                  <li style="width:13%">Phone Number
                  </li>
                  <li style="width:12%">Status
                  </li>
                  <li>
                  </li>
                </ul>
              </div>
              @if(count($all_doctors) > 0)
              @foreach($all_doctors as $single_doctor)

              <?php //print_r($all_doctors);die;?>
              <div class="lookalike_table_row">
                <div class="lookalike_table_body" id="head_one{{$single_doctor->doctor->doctor_id}}">
                  <ul>
                    <li style="width:22%">
                      <div class="d_profile">
                        <div class="d_pro_img">
                          <img src="{{ asset('doctorimages/' . $single_doctor->doctor->doctor_picture) }}" alt="image">
                        </div>
                        <div class="d_pro_text">
                          <h4>{{$single_doctor->doctor->doctor_title}} {{ucfirst($single_doctor->doctor->doctor_first_name)}} {{$single_doctor->doctor->doctor_last_name}}
                          </h4>
                          <a href="javascript:;">{{$single_doctor->doctor->doctor_address}}
                          </a>
                        </div>
                      </div>
                    </li>
                    <li style="width:19%">ID-Doctor-{{$single_doctor->doctor->doctor_id}}
                    </li>
                   
                    <li style="width:13%">{{$single_doctor->doctor->doctor_phone}}
                    </li>
                   <li style="width:12%">
                      <span class="badge badge-pill 
                                   <?php if($single_doctor->doctor->active_status==0) { echo 'badge-danger'; } elseif($single_doctor->doctor->active_status==1) { echo 'badge-success'; } ?>" id="status_row_{{$single_doctor['doctor_id']}}">
                        <?php if($single_doctor->doctor->active_status==0){ echo 'Suspend';} else if($single_doctor->doctor->active_status==1){ echo 'Active User';}?>
                      </span>
                    </li> 
                    <li>
                       <a href="{{url('/admin/view_dispute_billing')}}/{{$single_doctor->doctor->doctor_id}}" class="btn btn-light btn-xs btn_view_appointment" data-id="{$single_doctor->doctor->doctor_id}}" name="button"><img class="icon" src="{{ asset('admin/adminimages/eye.svg') }}" alt="icon">View Billing
                      </a>
                    </li>
                  </ul>
                </div>
              
              </div>
              @endforeach
              @else
              No Doctor Found
              @endif 
            </div>
            <div class="table_pagination">
              <button type="button" class="btn btn-light btn-xs pre_emp" 
                      <?php if($all_doctors
              ->previousPageUrl()){  } else{ echo "disabled"; } ?> data-url="
              <?php echo $all_doctors->previousPageUrl(); ?>&type=doc_page">Previous Page
              </button>
            <input type="hidden" class="doc_page_hidden" value="{{$all_doctors
                                                                ->currentPage()}}">
            <span>Page {{ $all_doctors
              ->currentPage() }} of {{ $all_doctors
              ->lastPage() }} Pages
            </span>
            <button type="button" class="btn btn-light btn-xs next_emp"  
                    <?php if($all_doctors->nextPageUrl()){  } else{ echo "disabled"; } ?>  data-url="
            <?php echo $all_doctors->nextPageUrl(); ?>&type=doc_page">Next Page
            </button>
        </div>
      </div>
    </div>
  </div>
  </div>
</main>
<!-- Add employee screen -->
<div class="modal fade" id="add_doctor">
  <div class="modal-dialog modal-md modal-dialog-centered genmodal genmodal_custom custom_width3">
    <div class="modal-content">
      <div class="modal-header">
        <h3>Add Doctor
        </h3>
        <button type="button" class="close" data-dismiss="modal">
          <img src="{{ asset('admin/adminimages/popup_close.svg') }}"/>
        </button>
      </div>
      <div class="modal-body">
        <div class="alert alert-danger-outline alert-danger-outline-adddr alert-dismissible alert_icon fade show" role="alert" style="display: none;">
          <div class="d-flex align-items-center">
            <div class="alert-icon-col">
              <span class="fa fa-warning">
              </span>
            </div>
            <div class="alert_text adddr_danger_pop">
            </div>
            <a href="#" class="close alert_close" data-dismiss="alert" aria-label="close">
              <i class="fa fa-close">
              </i>
            </a>
          </div>
        </div>
        <div class="alert alert-success-outline alert-success-outline-adddr alert-dismissible alert_icon fade show" role="alert" style="display: none;">
          <div class="d-flex align-items-center">
            <div class="alert-icon-col">
              <span class="fa fa-check">
              </span>
            </div>
            <div class="alert_text adddr_success_pop">
            </div>
            <a href="#" class="close alert_close" data-dismiss="alert" aria-label="close">
              <i class="fa fa-close">
              </i>
            </a>
          </div>
        </div>
        <form id="add_dr_form" name="add_dr_form" enctype="multipart/form-data">
          <div class="row">
            <div class="col-sm-6">
              <div class="form-group">
                <label>First Name
                </label>
                <input type="text" placeholder="Akintude" class="form-control"  name="dr_first_name" id="dr_first_name">
              </div>
            </div>
            <div class="col-sm-6">
              <div class="form-group">
                <label>Last Name
                </label>
                <input type="text" placeholder="Lala" class="form-control"  name="dr_last_name" id="dr_last_name">
              </div>
            </div>
          </div>
           <div class="row">
            <div class="col-sm-6">
              <div class="form-group">
                <label>Email
                </label>
                <input type="text" placeholder="doctor@gmail.com" class="form-control"  name="dr_email" id="dr_email">
              </div>
            </div>
             <div class="col-sm-6">
              <div class="form-group">
                <label>Password
                </label>
                <input type="text" placeholder="Password" class="form-control"  name="dr_password" id="dr_password">
              </div>
            </div>
           
          </div>
          <div class="row">
             <div class="col-sm-6">
              <div class="form-group">
                <label>Phone Number
                </label>
                <input type="text" placeholder="Phone Number" maxlength="15" class="form-control"  name="dr_ph" id="dr_ph">
              </div>
            </div>
            <div class="col-sm-6">
              <div class="form-group">
                <label>Folio Number
                </label>
                <input type="text" placeholder="78945" class="form-control"  name="folio_number" id="folio_number">
              </div>
            </div>
          </div>
           <div class="row">
            <div class="col-sm-6">
              <div class="form-group">
                <label>State
                </label>
                <input type="text" placeholder="California" class="form-control"  name="dr_state" id="dr_state">
              </div>
            </div>

            <div class="col-sm-6">
              <div class="form-group">
                <label>Country
                </label>
                <input type="text" placeholder="USA"  class="form-control"  name="dr_country" id="dr_country">
              </div>
            </div>
          </div>
           <div class="row">
            <div class="col-sm-6">
              <div class="form-group">
                <label>Education School
                </label>
                <input type="text" placeholder="University of lagos" class="form-control"  name="edu_school" id="edu_school">
              </div>
            </div>

            <div class="col-sm-6">
              <div class="form-group">
                <label>Degree
                </label>
                <input type="text" placeholder="MD"  class="form-control"  name="degree" id="degree">
              </div>
            </div>
          </div>

           <div class="row">
            <div class="col-sm-6">
              <div class="form-group">
                <label>Speciality
                </label>
                <input type="text" placeholder="Heart Specialist" class="form-control"  name="speciality" id="speciality">
              </div>
            </div>

            <div class="col-sm-6">
              <div class="form-group">
                <label>Languages
                </label>
                <input type="text" placeholder="English, French, Hindi" class="form-control"  name="languages" id="languages">
              </div>
            </div>
          </div>
           <div class="row">
            <div class="col-sm-6">
              <div class="form-group">
                <label>Religion
                </label>
                <input type="text" placeholder="Chritisian" class="form-control"  name="religion" id="religion">
              </div>
            </div>

            <div class="col-sm-6">
              <div class="form-group">
                <label>Ethnicity
                </label>
                <input type="text" placeholder="Ethnicity" class="form-control"  name="ethnicity" id="ethnicity">
              </div>
            </div>
          </div>
           <div class="row">
            <div class="col-sm-6">
              <div class="form-group">
                <label>Years Practised
                </label>
                <input type="text" placeholder="10" class="form-control"  name="years_practised" id="years_practised">
              </div>
            </div>
              <div class="col-sm-6">
              <div class="form-group">
                <label>Doctor ID
                </label>
                <input type="text" placeholder="Doctor ID" class="form-control"  name="dr_id" id="dr_id" readonly value="<?php echo time();?>">
              </div>
            </div>
            
          </div>

          <div class="row">          
              <div class="col-sm-6">
              <div class="form-group">
                <label>Status User
                </label>
                <div class="select_box width220">
                  <select class="form-control" name="dr_status" id="dr_status" >
                    <option value="1">Active 
                    </option>
                    <option value="0">Not Active
                    </option>
                  </select>
                </div>
              </div>
            </div>
             <div class="col-sm-6">
              <div class="doctor_table_record mt-2">        
                 <label>Doctor Info
                </label>
                <div class="form-check">
                 <textarea class="form-control" name="dr_info" id="dr_info"></textarea>
                </div>
              </div>
            </div>
          </div>
          <div class="row">
            <div class="col-sm-6">
              <div class="add_photo_profile mt-2">
                <div class="photo_profile_place">
                  <img src="{{ asset('admin/adminimages/thumb.svg') }}" alt="image" id="preview-image" width="100px" height="100px">
                </div>
                <div class="add_pro_picture">
                  <h3>Add Photo Profile
                  </h3>
                  <span>jpg/png with size maximum 500kb
                  </span>
                  <label class="btn btn-light btn-sm" for="select_photo_file">Select Photo File
                  </label>
                  <input type="file" id="select_photo_file" accept="image/jpeg,image/jpg,image/png"/>
                </div>
              </div>
            </div>
          </div>
          <div class="row">
            <div class="col-12 text-center">
              <button type="submit" class="btn btn-primary mb-3 mt-3" name="button">Add Doctor
              </button>
            </div>
          </div>
          <input type="hidden" id="default_image" value="{{ asset('admin/adminimages/thumb.svg') }}">
        </form>
      </div>
    </div>
  </div>
</div>
<!-- Search Employee -->
<div class="modal fade" id="search_doctor">
  <div class="modal-dialog modal-md modal-dialog-centered genmodal genmodal_custom custom_width1">
    <div class="modal-content">
      <div class="modal-header">
        <h3>Search Doctor
        </h3>
        <button type="button" id="search_emp_modal" class="close" data-dismiss="modal">
          <img src="{{ asset('admin/adminimages/popup_close.svg') }}"/>
        </button>
      </div>
      <div class="modal-body plr-96">
        <form id="search_dr_form" name="search_dr_form">
          <div class="row">
            <div class="col-12">
              <div class="input-group mb-4">
                <div class="input-group-prepend">
                  <span class="input-group-text">
                    <img src="{{ asset('admin/adminimages/search_input.svg') }}" alt="icon">
                  </span>
                </div>
                <input type="text" class="form-control" placeholder="Search by name or ID" name="name_or_id" id="name_or_id">
              </div>
            </div>
          </div>
          <div class="row">
            <div class="col-12 text-center">
              <button type="submit" class="btn btn-primary mb-3 mt-3" name="button">Search Doctor
              </button>
            </div>
          </div>
          <input type="hidden" id="name_or_id_hidden">
        </form>
      </div>
    </div>
  </div>
</div>
@endsection
