<div class="table_hospital pagination_fixed_bottom">
       <table class="table" cellspacing="10">
           <tr>
               <th>MEMBER DATA</th>
               <th>HOSPITAL ID</th>
               <th class="text-center">DOCTORS</th>
               <th class="text-center">NURSES</th>
               <th class="text-center">ADMIN</th>
               <th class="text-right"></th>
           </tr>
          
            @if(count($all_hospitals['data']) > 0)

            @foreach($all_hospitals['data'] as $all_hospital)
           <tr>
               <td>
                   <div class="d_profile">
                       <div class="d_pro_text">
                           <h4>{{$all_hospital['hosp_name']}}</h4>
                           <a href="javascript:;">{{ $all_hospital['hosp_state'] }}, {{ $all_hospital['hosp_country'] }}</a>
                       </div>
                   </div>
               </td>
               <td>Hospital-{{ $all_hospital['hosp_id'] }}</td>
               <td class="text-center">{{ $all_hospital['doctorsCount'] }}</td>
               <td class="text-center">{{ $all_hospital['nurseCount'] }}</td>
               <td class="text-center">{{ $all_hospital['administratorsCount'] }}</td>
               <td class="text-right">
                   <a class="btn btn-light btn-xs" href="{{ url('admin/hospital_detail/'.$all_hospital['hosp_id'])}}"><img class="icon" src="{{ asset('admin/doctor/images/eye.svg') }}" alt="icon">View Detail</a>
                </td>
           </tr>
           @endforeach
            @else
              <tr>
                  <td colspan="7" class="text-center">No Hospitals Found</td>
              </tr>
            @endif 
       </table>
       <div class="table_pagination">
       <button type="button" class="btn btn-light btn-xs pre_search_emp" <?php if($all_hospitals['prev_page_url']){  } else{ echo "disabled"; } ?> data-url="<?php echo $all_hospitals['prev_page_url']; ?>&type=emp_page">Previous Page</button>
       <input type="hidden" class="emp_page_hidden" value="{{$all_hospitals['current_page']}}">
       <span>Page {{ $all_hospitals['current_page'] }} of {{ $all_hospitals['last_page'] }} Pages</span>
       <button type="button" class="btn btn-light btn-xs next_search_emp"  <?php if($all_hospitals['next_page_url']){  } else{ echo "disabled"; } ?>  data-url="<?php echo $all_hospitals['next_page_url'] ?>&type=emp_page">Next Page</button>
      </div>
    </div>