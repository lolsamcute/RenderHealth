<div class="table_hospital pagination_fixed_bottom">
	<div class="table-responsive">
   <table class="table appointment_scehdule" cellspacing="10">
	   <tr>
		   <th>DATE</th>
		   <th>TYPE OF APPOINTMENT</th>
		   <th>Patient profile</th>
		   <th>TIME SCHEDULED</th>
		   <th></th>
	   </tr>
	   <?php //echo count($appointments);?>
	  	@if(count($appointments) > 0) 
	  		@php date_default_timezone_set($timezone); @endphp
	  		@php $i = 1; @endphp
		  	@foreach($appointments as $key=>$appointment)
			    <tr <?php if($appointment->st_status==1){ echo 'class="recent"'; } ?>>
				   	<td>@if(date('Y-m-d' ,$appointment['appointment_time'])==date('Y-m-d'))
						{{ 'Today' }}<br>
						@elseif(date('Y-m-d' ,$appointment['appointment_time'])==date('Y-m-d',strtotime('+1 day')))
						{{ 'Tomorrow' }}<br>
						@endif
						{{ date('d F Y' ,$appointment['appointment_time']) }}
				   	</td>
				   	<td>
				   		@if($appointment['appointment_type']==2)
							<div class="med_center">	
								<h5>{{ $appointment['hospital_name'] }}</h5>
								<input type="hidden" class="a_id" name="a_id" id="a_id" value="{{$appointment['appointment_id']}}"> 
						   		<input type="hidden" class="doctor_id" name="doctor_id" id="doctor_id" value="123456"> 
						   		<input type="hidden" class="p_id" name="p_id" id="p_id" value="{{$appointment['patient_id']}}">
						   		<span id="table_date{{($i)}}" class="appt_time" style="display: none;">{{ $appointment['appointment_time'] }}</span>
								<p>{{ 'Hospital Appointment' }}</p>
							</div>
						@php $i++; @endphp
						@else
							<div class="tel_center">
                                <h5><img src="{{ asset('admin/doctor/images/tele_video.svg') }}" alt="icon">Teleconsultan Call</h5>
                                <input type="hidden" class="a_id" name="a_id" id="a_id" value="{{$appointment['appointment_id']}}"> 
						   		<input type="hidden" class="doctor_id" name="doctor_id" id="doctor_id" value="123456"> 
						   		<input type="hidden" class="p_id" name="p_id" id="p_id" value="{{$appointment['patient_id']}}">
                                <span id="table_date{{($i)}}" class="appt_time" style="display: none;">{{ $appointment['appointment_time'] }}</span>
                                @if($appointment['appointment_time'] >=  strtotime('now'))
                                	<span id="demo{{($i)}}" class="demo" style="display: none;"></span>   
                                @endif                                         
                           	</div>
                        @php $i++; @endphp
                        @endif					   
				   	</td>
				  	<td>
					   <div class="d_profile">
						   <div class="d_pro_img">
						   		 @if($appointment['patient_profile_img'] != "" && file_exists(getcwd().'/uploads/patient/'.$appointment['patient_profile_img']))
				                    <img src="{{ asset('uploads/patient/'.$appointment['patient_profile_img']) }}" alt="image"/>
				                @else
				                    <img src="{{ asset('images/profile.svg') }}" alt="image"/>
				                @endif						   
						   </div>
						   <div class="d_pro_text">
							   <h4>{{ ucfirst($appointment['patient_first_name']).' '.ucfirst($appointment['patient_last_name']) }}</h4>
							   <a href="javascript:;">View Profile</a>
						   </div>
					   </div>
				   	</td>
					<td>{{ date('h:i A' ,$appointment['appointment_time']) }}</td>
				   <td>
				   		@if($appointment['appointment_type']==1)
					   		@if($disabled > 0)
					   			<button type="button"  class="btn btn-light btn-xs mr-2 call_btn" name="button" onclick="callPatient(this); return false;" data-doctor_id="123456" data-call_type="{{$appointment['telemedical_type']}}" data-appoint_id="{{$appointment['appointment_id']}}" data-patient_id="{{$appointment['patient_id']}}"><img class="icon" src="{{ asset('admin/doctor/images/call_blue.svg') }}" alt="icon">Call</button>
					   		@elseif(date('Y-m-d',$appointment['appointment_time']) >= date('Y-m-d'))
						  	 	<button type="button" class="btn btn-light btn-xs mr-2 call_btn" name="button" onclick="callPatient(this); return false;" data-doctor_id="123456" data-call_type="{{$appointment['telemedical_type']}}" data-appoint_id="{{$appointment['appointment_id']}}" data-patient_id="{{$appointment['patient_id']}}"><img class="icon" src="{{ asset('admin/doctor/images/call_blue.svg') }}" alt="icon">Call</button>

						  	@else
						  		<button type="button"  class="btn btn-light btn-xs mr-2 call_btn" name="button" onclick="callPatient(this); return false;" data-doctor_id="123456" data-call_type="{{$appointment['telemedical_type']}}" data-appoint_id="{{$appointment['appointment_id']}}" data-patient_id="{{$appointment['patient_id']}}"><img class="icon" src="{{ asset('admin/doctor/images/call_blue.svg') }}" alt="icon">Call</button>
						  	
						  	@endif
						@else
							@if($appointment['booking_id'] != "")
								<a href="{{ url('admin/appointment_detail/'.$appointment['booking_id'])}}" class="btn btn-light btn-xs mr-2" name="button"><img class="icon" src="{{ asset('admin/doctor/images/eye.svg') }}" alt="">View</a>
							@else
								<a href="javascript:;" class="btn btn-light btn-xs mr-2" name="button"><img class="icon" src="{{ asset('admin/doctor/images/eye.svg') }}" alt="icon">View</a>
							@endif
						@endif

					   	<div class="dropdown d-inline-block">					   		
					   		@if(date('Y-m-d H:i',$appointment['appointment_time']) <= date('Y-m-d H:i',strtotime('-15 min')))
								<a class="btn btn-danger no_caret btn-xs dropdown-toggle disabled_cancel" href="javascript:;" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" >
							  	Cancel
								</a>
							@else
								<a class="btn btn-danger no_caret btn-xs dropdown-toggle" href="javascript:;" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
							  	Cancel
								</a>
							@endif
							<div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdown">
								<div class="sure">
									<h5>Are you sure want to cancel the appointment?</h5>
									<button type="button" class="btn btn-light btn-xs mr-2" onclick="cancelBooking(this); return false;" data-booking_id="{{$appointment['booking_id']}}" data-patient_id="{{$appointment['patient_id']}}">Yes, I am Sure</button>
									<button type="button" class="btn btn-blue btn-xs mr-2 reschedule_book" data-appoint_date="{{ date('Y-m-d' ,$appointment['appointment_time']) }}" data-appoint_time="{{ date('h:i A' ,$appointment['appointment_time']) }}" data-booking_id="{{$appointment['booking_id']}}" onclick="resheduleBooking(this); return false;">Reschedule</button>
								</div>
							</div>
						</div>
				   </td>
			   	</tr>
	   		@endforeach
	   	@else
	   		<tr>
	   			<td colspan="5" align="center"> No appointments Found</td>
	   		</tr>
		@endif    
		<!--div id="page11">
		{{ $appointments->links() }}
		</div-->
   	</table>
   </div>
   	<div class="table_pagination">
	   <button type="button" class="btn btn-light btn-xs pre2" <?php if($appointments->previousPageUrl()){  } else{ echo "disabled"; } ?> data-url="<?php echo $appointments->previousPageUrl(); ?>">Previous Page</button>
	   <span>Page {{ $appointments->currentPage() }} of {{ $appointments->lastPage() }} Pages</span>
	   <button type="button" class="btn btn-light btn-xs next2"  <?php if($appointments->nextPageUrl()){  } else{ echo "disabled"; } ?>  data-url="<?php echo $appointments->nextPageUrl(); ?>">Next Page</button>
   	</div>
</div>