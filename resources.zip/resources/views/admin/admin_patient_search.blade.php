@extends('layouts.admin_dashboard')
@section('content')
 <main class="col-12 col-md-12 col-xl-12 bd-content">
    <div class="row">
        <div class="col-12">
            <div class="page_head">
                <h1 class="heading">Patient search results</h1>
                
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-12">
            <div class="widget widget_search mb-4">
                <form class="search_content" action="search_patient">                             
                <?php $emp ="-";?>
                    <dl>
                      <dt>First Name :</dt>
                      <dd>@if(!empty($form_data['patient_name'])){{$form_data['patient_name']}}@else{{'----'}}@endif</dd>
                    </dl>
                    <dl>
                      <dt>Surname :</dt>
                      <dd>@if(!empty($form_data['surename'])){{$form_data['surename']}}@else{{'----'}}@endif</dd>
                    </dl>
                    <dl>
                      <dt>Date of Birth :</dt>                     
                      <dd>@if(!empty($form_data['dob']))  @php    $date = str_replace('/', '-', $form_data['dob']);  echo date('d F,Y',strtotime($date)) @endphp @else{{'----'}}@endif</dd>
                    </dl>
                    <dl>
                      <dt>Patient ID</dt>
                      <dd>@if(!empty($form_data['medical_record'])){{$form_data['medical_record']}}@else{{'----'}}@endif</dd>
                    </dl>
                    <dl>
                     <button type="button" id="page_url_change" class="btn btn-primary btn-sm">Change Search</button>
                    </dl>
                    
                </form>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-12">
<div class="table_hospital pagination_fixed_bottom">
   <table class="table" cellspacing="10">
       <tr>
           <th>MEMBER DATA</th>
           <th>PATIENT ID</th>
           <th>DATE  OF BIRTH</th>
           <th>CURRENT PLAN</th>
           <th>ENDED SUBRIPTIONS</th>
           <th></th>
       </tr>
        @if(count($all_patients) > 0)
          @foreach($all_patients as $all_patient)
           <tr>
               <td>
                   <div class="d_profile">
                       <div class="d_pro_img">
                            @php if(file_exists(getcwd().'/uploads/patient/'.basename($all_patient['patient_profile_img'])) && !empty($all_patient['patient_profile_img'])) { @endphp                          
                                     <img src="{{ asset('uploads/patient/'.$all_patient['patient_profile_img']) }}" alt="image">
                                   @php   } else {  @endphp 
                                       <img src="{{ asset('images/profile.svg') }}" alt="image">
                                      @php }   @endphp
                       </div>
                       <div class="d_pro_text">
                           <h4>{{$all_patient['patient_title']}} {{$all_patient['patient_first_name']}} {{$all_patient['patient_last_name']}}</h4>
                           <a href="javascript:;">View Profile</a>
                       </div>
                   </div>
               </td>
               <td>PATIENT-{{$all_patient['patient_unique_id']}}</td>
               <td>{{ date('d M, Y',$all_patient['patient_date_of_birth']) }}</td>
               <td>{{$all_patient['patient_insurance']}}</td>
               <td>{{ date('d M, Y',$all_patient['patient_end_subscription']) }}</td>
                <td>
                    <a href="{{url('/admin/medical_records/'.$all_patient['patient_unique_id'])}}" class="btn btn-light btn-xs mr-2" name="button"><img class="icon" src="{{ asset('admin/adminimages/eye.svg') }}" alt="icon">View Record(s)</a>
                </td>
           </tr>
         @endforeach
        @else
          <tr>
              <td colspan="7" class="text-center">No Members Found</td>
          </tr>
        @endif 
   </table>
    <div class="table_pagination">
     <button type="button" class="btn btn-light btn-xs pre_search_mem" <?php if($all_patients->previousPageUrl()){  } else{ echo "disabled"; } ?> data-url="<?php echo $all_patients->previousPageUrl(); ?>&type=mem_page">Previous Page</button>
     <input type="hidden" class="mem_page_hidden" value="{{$all_patients->currentPage()}}">
     <span>Page {{ $all_patients->currentPage() }} of {{ $all_patients->lastPage() }} Pages</span>
     <button type="button" class="btn btn-light btn-xs next_search_mem"  <?php if($all_patients->nextPageUrl()){  } else{ echo "disabled"; } ?>  data-url="<?php echo $all_patients->nextPageUrl(); ?>&type=mem_page">Next Page</button>
    </div>
</div>
              
 </div>
    </div>
</main>
@endsection