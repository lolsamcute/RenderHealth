<div class="table_hospital pagination_fixed_bottom">
 <div class="table-responsive">
   <table class="table" cellspacing="10">
       <tr>
           <th>MEMBER DATA</th>
           <th>PATIENT ID</th>
           <th>DATE  OF BIRTH</th>
           <th>CURRENT PLAN</th>
           <th>ENDED SUBRIPTIONS</th>
           <th></th>
       </tr>
        @if(count($all_patients) > 0)
          @foreach($all_patients as $all_patient)
           <tr>
               <td>
                   <div class="d_profile">
                        <div class="d_pro_img">
                           @php if(file_exists(getcwd().'/uploads/patient/'.basename($all_patient['patient_profile_img'])) && !empty($all_patient['patient_profile_img'])) { @endphp                          
                                     <img src="{{ asset('uploads/patient/'.$all_patient['patient_profile_img']) }}" alt="image">
                                   @php   } else {  @endphp 
                                       <img src="{{ asset('images/profile.svg') }}" alt="image">
                                      @php }   @endphp 
                                   </div>
                       <div class="d_pro_text">
                           <h4> {{$all_patient['patient_title']}} {{$all_patient['patient_first_name']}} {{$all_patient['patient_last_name']}}</h4>
                           <a href="javascript:;">View Profile</a>
                       </div>
                   </div>
               </td>
               <td>PATIENT-{{$all_patient['patient_unique_id']}}</td>
              <td>@if(!empty($all_patient['patient_date_of_birth'])) {{ date('d M, Y',$all_patient['patient_date_of_birth'])}}   @else {{ "--" }} @endif </td>
               <td>{{$all_patient['patient_insurance']}}</td>
              <td>@if(!empty($all_patient['patient_end_subscription'])){{ date('d M, Y',$all_patient['patient_end_subscription']) }} @else {{ "--" }} @endif</td>
                <td>
                    <a href="{{url('/admin/medical_records/'.$all_patient['patient_unique_id'])}}" class="btn btn-light btn-xs mr-2" name="button"><img class="icon" src="{{ asset('admin/adminimages/eye.svg') }}" alt="icon">View Record(s)</a>
                </td>
                
           </tr>
         @endforeach
        @else
          <tr>
              <td colspan="7" class="text-center">No Members Found</td>
          </tr>
        @endif 
   </table>
 </div>
    <div class="table_pagination">
     <button type="button" class="btn btn-light btn-xs pre_mem" <?php if($all_patients->previousPageUrl()){  } else{ echo "disabled"; } ?> data-url="<?php echo $all_patients->previousPageUrl(); ?>&type=mem_page">Previous Page</button>
     <input type="hidden" class="mem_page_hidden" value="{{$all_patients->currentPage()}}">
     <span>Page {{ $all_patients->currentPage() }} of {{ $all_patients->lastPage() }} Pages</span>
     <button type="button" class="btn btn-light btn-xs next_mem"  <?php if($all_patients->nextPageUrl()){  } else{ echo "disabled"; } ?>  data-url="<?php echo $all_patients->nextPageUrl(); ?>&type=mem_page">Next Page</button>
    </div>
</div>
              
