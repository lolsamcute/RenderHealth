Hi {!! $name !!}
<br>
<br>
you can reset password from below link 
<br>
<br>
<a href="{!! $recoverurl !!}">Reset Password</a>
<br>
<br>
thanks
<br>
 