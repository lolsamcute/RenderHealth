Hi {!! $name !!}
<br>
<br>
Thanks for registration in Render Health
<br>
<br>
Username : {!! $email !!}<br>
Password : {!! $password !!}
<br>
<br>
thanks