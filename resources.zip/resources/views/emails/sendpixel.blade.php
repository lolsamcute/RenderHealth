<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<meta name="HandheldFriendly" content="true" />
	<meta name="MobileOptimized" content="320" />
	<meta name="viewport" content="initial-scale=1.0, maximum-scale=1.0, width=device-width, user-scalable=no" />
	<title>Render Health</title>
	<link rel="icon" type="image/png" href="images/fav.png">
<link href="https://fonts.googleapis.com/css?family=Roboto:400,500,700" rel="stylesheet"> </head>
<body style="background-color:#eff2f7; 
			 font-family: 'Roboto', sans-serif;
			 padding:0;
			 margin:0;
			 font-weight: normal;
			 font-size: 15px;
			 color: #2e2e2e;
			 line-height: 1.6em;
			 vertical-align:middle;
			 padding:20px;">
	<table style="width:100%;
			      max-width:700px;
			      margin:0px auto;
			      background-color:#fff;
			      border-collapse: collapse;
			      box-sizing: border-box;
				  display:block;
				  padding:30px;
				  border-radius:5px;
 				  text-align:left;">
			<thead style="display:block">
			<tr  style="display:block">
				<th colspan="1"
					style="font-weight: normal;
						   text-align:center;
						   display:block">	
					<img style="width:114px;
								margin:10px auto 30px;"
						 src="{{asset('assets/images/logo.jpg')}}";
						/>
				</th>
			</tr>
			</thead>
			<tbody  style="display:block">
			<tr  style="display:block">
				<td colspan="1"
					style="font-weight: normal;
						   display:block">	
					<p style="font-size: 15px;                               
                               margin:0 0 20px;
							   font-weight: normal;
							   text-align:left;
							   ">Follow these instructions to collect data from website which can be used by Render Health. 
					</p>
					<p style="font-size: 15px;                               
                               margin:0 0 20px;
							   font-weight: normal;
							   text-align:left;">To complete this process, you must have access to your website source code and be relatively comfortable with HTML (or have a developer that can help you). 
					</p>
					
					<p style="font-size: 15px;                               
                               margin:0 0 20px;
							   font-weight: normal;
							   text-align:left;">1.Copy the snippet<br>
							   Don't edit your snippet. Just copy it. You might want to paste it into a text document if you're worried about accidentally losing or changing the snippet from your clipboard.
					</p>
					
					
					<p style="margin:0 0 22px;">
							   <span style="font-size:13px;
									 color:#888888;									 
									 display:block;
									 line-height:1.5;
									 margin-bottom:10px;
									 border:1px solid #ececec;
									 padding: 5px;">
								{!! nl2br(e($content))!!}
							   </span>
							   
					</p>
					<p style="font-size: 15px;                               
                               margin:0 0 22px;
							   font-weight: normal;
							   text-align:left;">2.Paste your snippet (unaltered, in it's entirety) into every web page you want to track. Paste it immediately before closing </head> tag.<br>
If you use templates to dynamically generate pages for your site, you can paste the tracking code snippet into it's own file, then include it in your page header.
					</p>
					<p style="font-size: 15px;                               
                               margin:0 0 20px;
							   font-weight: normal;
							   text-align:left;">If you have any questions, please visit <a href="javascript:void(0);" >renderhealth.com </a>website and contact our support. 
					</p>
					<p style="font-size: 15px;                               
                               padding-top:15px;
							   font-weight: normal;
							   text-align:left;
							   border-top:1px solid #ececec;
							   "><span>© 2018 Render Health </span> 
					</p>
				 
				 
				</td>
			</tr>
			</thead>
	</table>
 
 
	
</body>
</html>