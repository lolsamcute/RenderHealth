@extends('layouts.nurse')
@section('content')
<main class="col-12 col-md-12 col-xl-12 bd-content">
    <div class="row">
        <div class="col-12">
            <div class="page_head">
                <h1 class="heading">Telemedical Appointment</h1>

            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-12">
            <div class="tab-content">
             <div class="table_hospital pagination_fixed_bottom">
              <div class="table-responsive">
               <table class="table" cellspacing="10">
                <tr>
                   <th>DATE</th>
                   <th>TYPE OF APPOINTMENT</th>
                   <th>Patient profile</th>
                   <th>TIME SCHEDULED</th>
                   <th></th>
                </tr>
               
                  <?php $i = "1"?>
                  @foreach($PatientAppointment_details as $patient_details)
                    <tr <?php if($patient_details->st_status==1){ echo 'class="recent"'; } ?>>
                      <td>
                        @php date_default_timezone_set($timezone); @endphp

                        @if(date('Y-m-d' ,$patient_details->appointment_time)==date('Y-m-d'))
                            {{ 'Today' }}<br>
                        @elseif(date('Y-m-d' ,$patient_details->appointment_time)==date('Y-m-d',strtotime('+1 day')))
                            {{ 'Tomorrow' }}<br>
                        @endif
                            {{ date('d F Y' ,$patient_details->appointment_time) }}                 
                      </td>
                      <td>
                        <div class="tel_center">
                           <h5><img src="{{ asset('admin/doctor/images/tele_video.svg')}}" alt="icon"/>Teleconsultan Call</h5>
                            <span id="table_date{{$i}}" style="display: none;">
                              <?php                                   
                                echo $end_date = $patient_details->appointment_time;
                              ?>                              
                           </span>                               
                          @if($patient_details->appointment_time >=  strtotime('now'))
                              <span id="demo{{($i)}}" style="display: none;"></span>   
                          @endif 
                        </div>
                      </td>
                      <td>
                        <div class="d_profile">
                           <div class="d_pro_img">
                               <img src="{{ asset('admin/doctor/images/doc1.png')}}" alt="image">
                           </div>
                           <div class="d_pro_text">
                               <h4>Mr.{{$patient_details->patient_detail->patient_first_name}}</h4>
                               <a href="javascript:;">View Profile</a>
                           </div>
                        </div>
                      </td>
                      <td>{{ $newdate = date('h:i:A', $patient_details->appointment_time)}}</td>                        
                      <td>
                        @if($patient_details->patient_appoint->appointment_type==1)
                          @if($disabled > 0)
                            <button type="button" disabled class="btn btn-light btn-xs mr-2 call_btn" name="button" onclick="callPatient(this); return false;" data-doctor_id="123456" data-call_type="{{$patient_details->patient_appoint->telemedical_type}}" data-appoint_id="{{$patient_details->patient_appoint->appointment_id }}" data-patient_id="{{$patient_details->patient_id}}"><img class="icon" src="{{ asset('admin/doctor/images/call_blue.svg') }}" alt="icon">Call</button>
                          @elseif(date('Y-m-d',$patient_details->appointment_time) >= date('Y-m-d'))
                            <button type="button" class="btn btn-light btn-xs mr-2 call_btn" name="button" onclick="callPatient(this); return false;" data-doctor_id="123456" data-call_type="{{$patient_details->patient_appoint->telemedical_type}}" data-appoint_id="{{$patient_details->patient_appoint->appointment_id}}" data-patient_id="{{$patient_details->patient_id}}"><img class="icon" src="{{ asset('admin/doctor/images/call_blue.svg') }}" alt="icon">Call</button>
                          @else
                            <button type="button" disabled class="btn btn-light btn-xs mr-2 call_btn" name="button" onclick="callPatient(this); return false;" data-doctor_id="123456" data-call_type="{{$patient_details->patient_appoint->telemedical_type}}" data-appoint_id="{{$patient_details->patient_appoint->appointment_id}}" data-patient_id="{{$patient_details->patient_id}}"><img class="icon" src="{{ asset('admin/doctor/images/call_blue.svg') }}" alt="icon">Call</button>                          
                          @endif
                        @endif
                      </td>
                    </tr>
                    <?php $i++ ?>
                @endforeach()
              </table>
            </div>
              <div class="table_pagination">
               <span>
                  {{ $PatientAppointment_details->links('pagination.default') }} 
                </span>
              </div>
            </div>
        </div>
    </div>
</main>
@endsection


