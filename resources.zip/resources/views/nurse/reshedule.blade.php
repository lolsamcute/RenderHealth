<form method="post">
    <div class="row">
        <div class="col-6">
            <div class="picker">
                 @php  date_default_timezone_set($timezone); @endphp
                <div class="datepicker_input mb-2 reshedule_time" data-date="{{ date('d-m-Y',strtotime($appoint_date)) }}" data-date-format="dd-mm-yyyy" id="reshedule_time"></div>
            </div>
        </div>
        <div class="col-6">
            <div class="patient_data_right">
                <div class="patient_profile">
                    <div class="pp_image">
                        <img src="{{ asset('admin/doctor/images/doc2.png') }}" alt="image">
                    </div>
                    <div class="pp_desc">
                        @if($appointment['patient_detail']['patient_gender'] == 1)
                            <h4>Mr. {{ ucfirst($appointment['patient_detail']['patient_first_name']) }} {{ ucfirst($appointment['patient_detail']['patient_last_name']) }}</h4>
                            <h5>29 y/o, Male</h5>
                        @elseif($appointment['patient_detail']['patient_gender'] == 2)
                            <h4>Ms. {{ ucfirst($appointment['patient_detail']['patient_first_name']) }} {{ ucfirst($appointment['patient_detail']['patient_last_name']) }}</h4>
                            <h5>29 y/o, Female</h5>
                        @else
                            <h4>{{ ucfirst($appointment['patient_detail']['patient_first_name']) }} {{ ucfirst($appointment['patient_detail']['patient_last_name']) }}</h4>
                        @endif                        
                    </div>
                </div>
                <div class="patient_detail">
                    <ul>
                        <li>
                            <img src="{{ asset('admin/doctor/images/loc.svg') }}" alt="icon">
                            <div>
                                <h5>Location :</h5>
                                @if(!empty($appointment['hospital_name']))
                                    <h4>{{ $appointment['hospital_name'] }}</h4>
                                @else
                                    <h4>-</h4>
                                @endif
                            </div>
                        </li>
                        <li>
                            <img src="{{ asset('admin/doctor/images/app.svg') }}" alt="icon">
                            <div>
                                <h5>Type of appointment :</h5>
                                @if($appointment['patient_appoint']['appointment_type'] ==2)
                                    <h4>Hospital Appointment</h4>
                                @elseif($appointment['patient_appoint']['appointment_type'] ==1)
                                    <h4>Telemedical Appointment</h4>
                                @endif
                            </div>
                        </li>
                    </ul>
                </div>
                <div class="form-group mb-4">
                    <label>Time</label>
                    <div class="select_box">
                        
                         <select class="form-control appoint_time" name="">

                             @if(!empty($doctor_avail_time) && count($doctor_avail_time) > 0)
                                @php                                                
                                   $count =0;
                                @endphp
                                    @foreach($doctor_avail_time['doctor_availability'] as $key=>$availability) 
                                @php
                                        $availability_time = $availability['availability_time'];               
                                        $availability = explode("-",$availability_time[0]); 
                                        $start_time = date('Y-m-d H:i',$availability[0]);                               
                                        $end_time = date('Y-m-d H:i',$availability[1]);                                         
                                        $begin = new DateTime($start_time);
                                        $end   = new DateTime($end_time);
                                        $interval = DateInterval::createFromDateString('60 min');
                                        $times    = new DatePeriod($begin, $interval, $end);
                                        foreach ($times as $i_key => $time) {    
                                             if(date("Y-m-d H:i",strtotime($time->format("Y-m-d H:i")))  >= date('Y-m-d H:i')){
                                                if(count($doctor_avail_time['doctor_availability']) == ($key+1) && ($i_key+1) == count($availability)){        if($time->format("Y-m-d H:i") <= $end->sub($interval)->format('Y-m-d H:i')){        
                                                        if(count($doc_appoint_listing) > 0){
                                                        $inc =0;
                                                            foreach($doc_appoint_listing as $doc_appoint){
                                                                if($doctor_avail_time['doctor_id'] == $doc_appoint['doctor_id']){
                                                                    if(date("H:i",strtotime($time->format("Y-m-d H:i"))) ==  date('H:i',$doc_appoint['appointment_time'])){
                                                                        $inc = 1;
                                                                    }
                                                                }
                                                            }
                                                            if($inc == 1){                                                                                      
                                    @endphp
                                                               <option value ='{{ date("h:i A",strtotime($time->format("Y-m-d H:i"))) }}' <?php if(date("h:i A",strtotime($time->format("Y-m-d H:i"))) == date('h:i A',$appointment['appointment_time'])){ echo 'selected';} ?> disabled="disabled">{{ date("h:i A",strtotime($time->format("Y-m-d H:i"))) }}</option>
                                    @php                        }else{
                                     @endphp                        
                                                                <option value ='{{ date("h:i A",strtotime($time->format("Y-m-d H:i"))) }}' <?php if(date("h:i A",strtotime($time->format("Y-m-d H:i"))) == date('h:i A',$appointment['appointment_time'])){ echo 'selected';} ?> >{{ date("h:i A",strtotime($time->format("Y-m-d H:i"))) }}</option>

                                    @php                            
                                                            }
                                                        }else{
                                    @endphp
                                                       <option value ='{{ date("h:i A",strtotime($time->format("Y-m-d H:i"))) }}' <?php if(date("h:i A",strtotime($time->format("h:i A"))) == date('h:i A',$appointment['appointment_time'])){ echo 'selected';} ?> >{{ date("h:i A",strtotime($time->format("Y-m-d H:i"))) }}</option>
   
                                   @php
                                                        }
                                                    }
                                                }else if($time->format("Y-m-d H:i") <= $end){   
                                                    if(count($doc_appoint_listing) > 0){
                                                        $index =0;
                                                        foreach($doc_appoint_listing as $doc_appoint){                                          
                                                            if($doctor_avail_time['doctor_id'] == $doc_appoint['doctor_id']){                          
                                                                if(date("H:i",strtotime($time->format("Y-m-d H:i"))) ==  date('H:i',$doc_appoint['appointment_time'])){
                                                                    $index = 1;
                                                                }
                                                            }
                                                        }
                                                        if($index == 1){                                                    
                                    @endphp
                                                            <option value ='{{ date("h:i A",strtotime($time->format("Y-m-d H:i"))) }}' disabled="disabled" <?php if(date("h:i A",strtotime($time->format("Y-m-d H:i"))) == date('h:i A',$appointment['appointment_time'])){ echo 'selected';} ?> >{{ date("h:i A",strtotime($time->format("Y-m-d H:i"))) }}</option>


                                    @php                }else{
                                    @endphp
                                                            <option value ='{{ date("h:i A",strtotime($time->format("Y-m-d H:i"))) }}' <?php if(date("h:i A",strtotime($time->format("Y-m-d H:i"))) == date('h:i A',$appointment['appointment_time'])){ echo 'selected';} ?> >{{ date("h:i A",strtotime($time->format("Y-m-d H:i"))) }}</option>


                                    @php                }
                                                    }else{
                                    @endphp
                                                        <option value ='{{ date("h:i A",strtotime($time->format("Y-m-d H:i"))) }}' <?php if(date("h:i A",strtotime($time->format("Y-m-d H:i"))) == date('h:i A',$appointment['appointment_time'])){ echo 'selected';} ?> >{{ date("h:i A",strtotime($time->format("Y-m-d H:i"))) }}</option>

                                    @php
                                                    }
                                                    $time->add($interval)->format('Y-m-d H:i');                                                     
                                                }                                                                       
                                                $count++;
                                            } 
                                        }  
                                @endphp                                                             
                                    @endforeach
                                @else
                                 <option value =''>No available time set by doctor yet</option>
                            @endif
                         </select>
                     </div>
                </div>
                <input type="hidden" id="hidden_date" class="hidden_date" value="{{ date('d-m-Y',strtotime($appoint_date)) }}">
                <input type="hidden" id="hidden_book_id" class="hidden_book_id" value="{{ $appointment['booking_id'] }}">
                <button type="button" class="btn btn-primary" onclick="updateAppointment(this); return false;">Update Appointment</button>
            </div>
        </div>
    </div>
</form>