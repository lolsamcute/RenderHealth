<form method="post">
    <div class="row">
        <div class="col-6">
            <div class="picker">
                <div class="mb-2 datepicker schedule_time"></div>
                @php  date_default_timezone_set($timezone); @endphp
            </div>
        </div>
        <div class="col-6">
            <div class="patient_data_right pl-0 pt-0">
                <div class="patient_profile patient_profile_sm mb-3">
                    <div class="pp_image">
                         @if(!empty($patient_detail['patient_profile_img']))
                          <img src="{{ asset('uploads/patient/'.$patient_detail['patient_profile_img']) }}" alt="image">                                                 
                        @else
                          <img src="{{ asset('images/profile.svg') }}" alt="image">                                                      
                        @endif
                    </div>
                    <div class="pp_desc">
                        @if($patient_detail['patient_gender'] == 1)
                            <h4>Mr. {{ ucfirst($patient_detail['patient_first_name']) }} {{ ucfirst($patient_detail['patient_last_name']) }}</h4>
                            <h5>Location, {{$patient_detail['patient_address']}}</h5>
                        @elseif($patient_detail['patient_gender'] == 2)
                            <h4>Ms. {{ ucfirst($patient_detail['patient_first_name']) }} {{ ucfirst($patient_detail['patient_last_name']) }}</h4>
                            <h5>Location, {{$patient_detail['patient_address']}}</h5>
                        @else
                            <h4>{{ ucfirst($patient_detail['patient_first_name']) }} {{ ucfirst($patient_detail['patient_last_name']) }}</h4>
                            <h5>Location, {{$patient_detail['patient_address']}}</h5>
                        @endif 
                        
                    </div>
                </div>
                <div class="form-group mb-3">
                    <label>Type of appointment</label>
                    <div class="select_box">
                         <select class="form-control appointment_type" name="" onchange="scheduleAppointment(this); return false;">
                             <option value="2" <?php if($appointment_type == 2){ ?> selected <?php }?>>Hospital Appointment</option>
                             <option value="1" <?php if($appointment_type == 1){ ?> selected <?php }?>>Telemedical Appointment</option>                                             
                         </select>
                     </div>
                </div>
                <div class="form-group mb-3">
                    <label>Date</label>
                    <input type="text" class="form-control" name="" value="">
                 
                </div>
                <div class="form-group mb-3">
                    <label>Time</label>
                    <div class="select_box">
                         <select class="form-control appoint_time" name="">
                             @if(!empty($doctor_avail_time) && count($doctor_avail_time) > 0)
                                @php  
                                    echo "<pre>"; print_R($doctor_avail_time);                                              
                                   $count =0;
                                @endphp
                                    @foreach($doctor_avail_time['doctor_availability'] as $key=>$availability) 
                                @php
                                        $availability_time = $availability['availability_time'];               
                                        $availability = explode("-",$availability_time[0]); 
                                        $start_time = date('Y-m-d H:i',$availability[0]);                               
                                        $end_time = date('Y-m-d H:i',$availability[1]);                                         
                                        $begin = new DateTime($start_time);
                                        $end   = new DateTime($end_time);
                                        $interval = DateInterval::createFromDateString('60 min');
                                        $times    = new DatePeriod($begin, $interval, $end);
                                        foreach ($times as $i_key => $time) {    
                                             if(date("Y-m-d H:i",strtotime($time->format("Y-m-d H:i")))  >= date('Y-m-d H:i')){
                                                if(count($doctor_avail_time['doctor_availability']) == ($key+1) && ($i_key+1) == count($availability)){        if($time->format("Y-m-d H:i") <= $end->sub($interval)->format('Y-m-d H:i')){        
                                                        if(count($doc_appoint_listing) > 0){
                                                        $inc =0;
                                                            foreach($doc_appoint_listing as $doc_appoint){
                                                                if($doctor_avail_time['doctor_id'] == $doc_appoint['doctor_id']){
                                                                    if(date("H:i",strtotime($time->format("Y-m-d H:i"))) ==  date('H:i',$doc_appoint['appointment_time'])){
                                                                        $inc = 1;
                                                                    }
                                                                }
                                                            }
                                                            if($inc == 1){                                                                                      
                                    @endphp
                                                               <option value ='{{ date("h:i A",strtotime($time->format("Y-m-d H:i"))) }}'  disabled="disabled">{{ date("h:i A",strtotime($time->format("Y-m-d H:i"))) }}</option>
                                    @php                        }else{
                                     @endphp                        
                                                                <option value ='{{ date("h:i A",strtotime($time->format("Y-m-d H:i"))) }}'>{{ date("h:i A",strtotime($time->format("Y-m-d H:i"))) }}</option>

                                    @php                            
                                                            }
                                                        }else{
                                    @endphp
                                                       <option value ='{{ date("h:i A",strtotime($time->format("Y-m-d H:i"))) }}'>{{ date("h:i A",strtotime($time->format("Y-m-d H:i"))) }}</option>

                                   @php
                                                        }
                                                    }
                                                }else if($time->format("Y-m-d H:i") <= $end){   
                                                    if(count($doc_appoint_listing) > 0){
                                                        $index =0;
                                                        foreach($doc_appoint_listing as $doc_appoint){                                          
                                                            if($doctor_avail_time['doctor_id'] == $doc_appoint['doctor_id']){                          
                                                                if(date("H:i",strtotime($time->format("Y-m-d H:i"))) ==  date('H:i',$doc_appoint['appointment_time'])){
                                                                    $index = 1;
                                                                }
                                                            }
                                                        }
                                                        if($index == 1){                                                    
                                    @endphp
                                                            <option value ='{{ date("h:i A",strtotime($time->format("Y-m-d H:i"))) }}' disabled="disabled">{{ date("h:i A",strtotime($time->format("Y-m-d H:i"))) }}</option>


                                    @php                }else{
                                    @endphp
                                                            <option value ='{{ date("h:i A",strtotime($time->format("Y-m-d H:i"))) }}'>{{ date("h:i A",strtotime($time->format("Y-m-d H:i"))) }}</option>


                                    @php                }
                                                    }else{
                                    @endphp
                                                        <option value ='{{ date("h:i A",strtotime($time->format("Y-m-d H:i"))) }}'>{{ date("h:i A",strtotime($time->format("Y-m-d H:i"))) }}</option>

                                    @php
                                                    }
                                                    $time->add($interval)->format('Y-m-d H:i');                                                     
                                                }                                                                       
                                                $count++;
                                            } 
                                        }  
                                @endphp                                                             
                                    @endforeach
                                @else
                                 <option value =''>No available time set by doctor yet</option>
                            @endif
                         </select>
                     </div>
                </div>
                <div class="form-group mb-4">
                    <label>Hospital Name</label>
                    <div class="select_box">
                         <select class="form-control hospital_id" name="">
                            <option value="">Select Hospital</option>
                            @foreach($hospital_listing as $hospital_list)
                               <option value="{{$hospital_list->hosp_id}}">{{$hospital_list->hosp_name}}</option>
                            @endforeach
                         </select>
                     </div>
                </div>
                 <input type="hidden" id="hidden_date" class="hidden_date" value="{{ date('d-m-Y',strtotime('now')) }}">
                 <input type="hidden" id="patient_id" class="patient_id" value ="{{$patient_detail['patient_unique_id']}}">
                <button type="submit" class="btn btn-primary mb-3" onclick="addNewAppointment(this); return false;">Save Appointment</button>
            </div>
        </div>
    </div>
</form>