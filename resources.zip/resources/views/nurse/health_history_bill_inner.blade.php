<div class="table_hospital">
     <div class="table-responsive">
    <table class="table" cellspacing="10">
        <tr>
            <th>DATE CREATED</th>
            <th>INVOICE ID</th>
            <th>HOSPITAL / LABS</th>
            <th>AMOUNT</th>
            <th>PAID</th>
            <th>Balance</th>
            <th></th>
            <th>View Billing Detail</th>
        </tr>
        @if(count($billing_detail) > 0)
            @foreach($billing_detail as $billing_det)
                <tr <?php if(($billing_det['payable_amount'] - $billing_det['paid_amount']) != 0){ ?> class="pending" <?php }?>>
                    <td>{{ date('j F Y',$billing_det['billing_date']) }}</td>
                    <td>{{ $billing_det['invoice_number'] }}</td>
                    <td>Geo Medical Center</td>
                    <td>₦ {{ $billing_det['payable_amount'] }}</td>
                    <td>₦ {{ $billing_det['paid_amount'] }}</td>
                    @if(($billing_det['payable_amount'] - $billing_det['paid_amount']) > 0)
                        <td>₦ {{ $billing_det['payable_amount'] - $billing_det['paid_amount'] }}</td> 
                    @else  
                        <td colspan="2" align="center"><span class="paid">PAID</span></td>   
                    @endif                                           
                   @if(($billing_det['payable_amount'] - $billing_det['paid_amount']) > 0)
                                                <td>  
                                            <button class="btn btn-info btn-xs paybill_type" onclick="selectpaytype(this,event)" id="paybill_type">PAY BILL</button> 
                                            <div class="radio_div" style="display: none;">

                                            <label class="radio-inline"><input type="radio" name="pay_by" value="1" onclick="getselectedvalue(this,event)">Pay by Cash</label>


                                            <label class="radio-inline"><input type="radio" name="pay_by" value="2" onclick="getselectedvalue(this,event)">Pay by Card</label>

                                            </div>    

                                            <div class="cash_input" style="display:none;">
                                            <div id="myModal" class="modal fade" role="dialog">
                                            <div class="modal-dialog modal-md modal-dialog-centered genmodal genmodal_custom custom_width1">

                                            <!-- Modal content-->
                                            <div class="modal-content">
                                            <div class="modal-header">
                                            <?php $amount=$billing_det['payable_amount'] - $billing_det['paid_amount'];?>
                                            <h3>Amount to pay: ₦ {{$amount}}</h3>
                                            <button type="button" class="close" data-dismiss="modal" onclick="getpaypopup();">&times;</button>    
                                            </div>
                                            <div class="modal-body">
                                            <div class="row">
                                            <div class="col-sm-6">
                                            <div class="form-group">
                                            <label>Enter Amount to pay by cash</label>

                                            <input type="number" name="pay_amount" value="{{$billing_det['payable_amount'] - $billing_det['paid_amount']}}" class="form-control" placeholder="Enter Amount" min="1" max="{{$billing_det['payable_amount'] - $billing_det['paid_amount']}}"   onkeydown="limitmax(event,<?php echo $amount;?>);" onkeyup="limitmax(event,<?php echo $amount;?>);" id="pay_amount">

                                            </div>
                                            </div>
                                            </div> 
                                            <div class="row">
                                            <div class="col-sm-6">
                                            <div class="form-group">
                                            <a href="javascript:;" class="btn btn-info btn-xs"  data-bill_id="{{ $billing_det['billing_id'] }}" data-doc_id="{{  $billing_det['nurse_id'] }}" data-pt_id="{{ $billing_det['patient_id'] }}" onclick="paybycash(this)">PAY BILL</a>      
                                            </div>
                                            </div>
                                            </div>           

                                            </div>
                                            </div>
                                            </div> 
                                            </div>

                                            <a href="javascript:;" class="btn btn-info btn-xs" id="pay_bill_popup"  onclick="payWithPaystack(this);" data-amt="{{$billing_det['payable_amount'] - $billing_det['paid_amount']}}"  data-doc_id="{{  $billing_det['nurse_id'] }}"data-pt_id="{{ $billing_det['patient_id'] }}" data-bill_id="{{ $billing_det['billing_id'] }}">Pay Bill</a>
                                            </div>
                                            </td>
                                            @else
                                            @endif 
                                            <td><a href="{{ asset('nurse/billing_detail/'.$billing_det['billing_id']) }}" class="btn btn-light btn-xs" name="button"><img class="icon" src="{{ asset('admin/doctor/images/eye.svg')}}" alt="icon">View Detail</a></td>                       
                </tr>
            @endforeach
        @else
                <tr>
                    <td colspan="8" class="text-center">No Bills Found</td>
                </tr>
        @endif                                
    </table>
</div>
    <div class="table_pagination">
       <button type="button" class="btn btn-light btn-xs pre1" <?php if($billing_detail->previousPageUrl()){  } else{ echo "disabled"; } ?> data-url="<?php echo $billing_detail->previousPageUrl(); ?>">Previous Page</button>
       <span>Page {{ $billing_detail->currentPage() }} of {{ $billing_detail->lastPage() }} Pages</span>
       <button type="button" class="btn btn-light btn-xs next1"  <?php if($billing_detail->nextPageUrl()){  } else{ echo "disabled"; } ?>  data-url="<?php echo $billing_detail->nextPageUrl(); ?>">Next Page</button>
    </div>
</div>