
@if(count($diary_details) == 0)
    <div class="col-12">
        <div class="main_diary_div1">
            <div class="widget_body">
                <div class="no_data">
                    <img src="{{ asset('images/no_data.svg') }}" alt="images">
                    <h4>No Health Diary Available</h4>
                </div>
            </div>
        </div>
    </div>
@endif     

@if(count($diary_details) > 0)   
    <div class="row">                                
        @foreach($diary_details as $diary_detail)
            <div class="col-12 col-sm-6 col-md-4">
                <div class="health_diary_box">
                    <div class="health_option">
                        <div class="btn-group">
                            <div class="dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                <img src="{{asset('admin/doctor/images/options.svg')}}" alt="options">
                            </div>
                            <div class="dropdown-menu dropdown-menu-right">
                                <a class="dropdown-item" href="javascript:;">Action 1</a>
                                <a class="dropdown-item" href="javascript:;">Action 2</a>
                                <a class="dropdown-item" href="javascript:;">Action 3</a>
                            </div>
                        </div>
                    </div>
                    @php date_default_timezone_set($timezone); @endphp
                    <span class="diary_date">{{ date('j F Y',$diary_detail['created_date'] )}}</span>
                    <div class="diary_detail">
                        @php
                             $feeling_pic = ['admin/doctor/images/smilies/no_pain@2x.png','admin/doctor/images/smilies/mild@2x.png','admin/doctor/images/smilies/moderate@2x.png','admin/doctor/images/smilies/severe@2x.png','admin/doctor/images/smilies/very_severe@2x.png','admin/doctor/images/smilies/worst_pain@2x.png','admin/doctor/images/smilies/moderate@2x.png'];                                    
                        @endphp                            
                        <span class="diary_icon"><img src="{{asset($feeling_pic[$diary_detail['feeling_details']] )}}" alt="icon"></span>
                        @php
                           $feeling = ['Feeling No Pain','Feeling Mild Pain','Feeling Moderate Pain','Feeling Severe Pain','Feeling Very Severe Pain','Feeling Worst Pain',$diary_detail['describe_feeling_other']];                                                        
                        @endphp                                                        
                        <h4>{{ $feeling[$diary_detail['feeling_details']] }}</h4>
                        @if(strlen($diary_detail['symptom_details']) > 70)
                            <h6>{{ substr($diary_detail['symptom_details'],0,70) }}...</h6>
                        @else
                            <h6>{{ substr($diary_detail['symptom_details'],0,70) }}</h6>
                        @endif
                        <a data-toggle="modal" class="btn btn-black btn-xs mt-2 mb-3" href="javascript:;" data-id="{{ $diary_detail['diary_id'] }}" onclick="viewhealthdiary(this); return false;">View Details</a>
                    </div>
                </div>
            </div>
        @endforeach                                                            
    </div>             
    <div class="row"> 
        <div class="col-12">  
            <div class="widget_footer">
                @if($diary_details->total() > $diary_details->perPage())                  
                    {{ $diary_details->links() }}
                @endif
            </div>
        </div>
    </div>
@endif 
