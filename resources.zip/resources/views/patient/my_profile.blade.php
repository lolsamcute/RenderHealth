@extends('layouts.patient')
@section('content')
<main class="col-12 col-md-12 col-xl-12 bd-content">
    <div class="row">
        <div class="col-12">
            <div class="widget">
                <div class="widget_header mb-4">
                    <h2>My Profile</h2>                               
                </div>
                <div class="row">
                    <div class="col-12">
                        <div class="widget_body mb-4">
                            <div class="my_profile_section">
                                @foreach($myprofile as $myprofile)
                                    <div class="profile_name">
                                        <div class="profile_d_image">                                        
                                            @if($myprofile->patient_profile_img == 0)
                                                <img id="uploadPreview" src="{{ asset('images/profile.svg') }}" alt="image">
                                            @else
                                                <img src="{{asset('uploads/patient/'.$myprofile->patient_profile_img)}}" alt="image">
                                            @endif
                                        </div>
                                        <h4>@if($myprofile->patient_gender == 1)
                                                @if($myprofile->patient_martial_status == 1)
                                                  {{ 'Mrs.' }}
                                                @else
                                                  {{ 'Miss' }}
                                                @endif
                                            @else
                                              {{ 'Mr.'}}
                                            @endif
                                            {{$myprofile->patient_first_name}} {{$myprofile->patient_last_name}}</h4>
                                        <h6>
                                            @php 
                                                if(!empty($myprofile->patient_date_of_birth)){
                                                $date = $myprofile->patient_date_of_birth;
                                                $databasedate = date("Y-m-d",$date);
                                                $current_date = date("Y-m-d");
                                                $diff = abs(strtotime($current_date) - strtotime($databasedate));
                                                $years = floor($diff / (365*60*60*24));
                                                $months = floor(($diff - $years * 365*60*60*24) / (30*60*60*24));
                                                $days = floor(($diff - $years * 365*60*60*24 - $months*30*60*60*24)/ (60*60*24));
                                                printf("%d", $years);
                                                echo "y/o,"; }
                                                @endphp  @if($myprofile->patient_gender == 0) Male @else Female @endif
                                        </h6>
                                        <a href="{{url('patient/settings')}}" class="btn btn-primary">EDIT MY PROFILE</a>
                                    </div>
                                    <div class="widget_profile_desc mb-0">
                                        <ul>
                                            <li><span><img src="{{asset('admin/doctor/images/location.svg')}}" alt="icon"></span>
                                                @if(!empty($myprofile->patient_address))
                                                  <p>{{ucfirst($myprofile->patient_address)}}</p>
                                                @else
                                                  <p>-</p>
                                                @endif
                                            </li>
                                            <li>
                                                <span><img src="{{asset('admin/doctor/images/gender.svg')}}" alt="icon"></span>
                                                <p> @if($myprofile->patient_martial_status == 0) Single @else Married @endif </p>
                                            </li>
                                            <li>
                                                <span><img src="{{asset('admin/doctor/images/mic.svg')}}" alt="icon"></span>
                                                @if(!empty($myprofile->patient_languages))
                                                  <p>{{join(',', array_map('ucfirst', explode(',', $myprofile->patient_languages)))}}</p>
                                                @else
                                                  <p>-</p>
                                                @endif
                                            </li>
                                            <li>
                                                <span><img src="{{asset('admin/doctor/images/bday.svg')}}" alt="icon"></span>
                                                @if(!empty($myprofile->patient_date_of_birth))
                                                  <p>{{ date("dS M Y", $myprofile->patient_date_of_birth) }} (Birthday)</p>
                                                @else
                                                  <p>-</p>
                                                @endif
                                            </li>
                                            <li>
                                                <span><img src="{{asset('admin/doctor/images/drop.svg')}}" alt="icon"></span>
                                                @if(!empty($myprofile->patient_blood_type))
                                                    <p>Blood type : {{$myprofile->patient_blood_type}}</p>
                                                @else
                                                    <p>Blood type : -</p>
                                                @endif
                                            </li>
                                            <li>
                                                <span><img src="{{asset('admin/doctor/images/group.svg')}}" alt="icon"></span>
                                                @if(!empty($myprofile->patient_blood_type))
                                                    <p>State Of Origin : {{ucfirst($myprofile->patient_origin_state)}}</p>
                                                @else
                                                    <p>State Of Origin : -</p>
                                                @endif
                                            </li>
                                        </ul>
                                    </div>
                                @endforeach
                                <div class="profile_data">
                                    <div class="data_unit">
                                        <img src="{{asset('admin/doctor/images/attended.svg')}}" alt="icon">
                                            <h2>{{$apt_cnt}}</h2>
                                            <h5>Appointment Attended</h5>
                                    </div>
                                    <div class="data_unit">
                                        <img src="{{asset('admin/doctor/images/created.svg')}}" alt="icon">
                                        <h2>{{$hstry_cnt}}</h2>
                                        <h5>Medical History Created</h5>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-4">
                        <div class="widget">
                            <div class="widget_body">
                                <a class="widget_link" href="javascript:void(0)" onclick="blockPopupFn()">
                                    <div class="widget_link_icon">
                                        <img src="{{asset('admin/doctor/images/appoint.svg')}}" alt="icon">
                                    </div>
                                    <div class="widget_link_text">
                                        <h4>Schedule Telelconsultation Appointment</h4>
                                        <p>Make appointment with doctor.</p>
                                    </div>
                                </a>
                                <!-- <a class="widget_link" href="{{url('/patient/dashboard/1')}}">
                                    <div class="widget_link_icon">
                                        <img src="{{asset('admin/doctor/images/appoint.svg')}}" alt="icon">
                                    </div>
                                    <div class="widget_link_text">
                                        <h4>Schedule Telelconsultation Appointment</h4>
                                        <p>Make appointment with doctor.</p>
                                    </div>
                                </a> -->
                            </div>
                        </div>
                    </div>
                    <div class="col-4">
                        <div class="widget">
                            <div class="widget_body">
                                <a class="widget_link" href="{{url('/patient/appointment')}}">
                                    <div class="widget_link_icon">
                                        <img src="{{asset('admin/doctor/images/hospital.svg')}}" alt="icon">
                                    </div>
                                    <div class="widget_link_text">
                                        <h4>Schedule Hospital Appointment</h4>
                                        <p>Set schedule to make appointment with doctor.</p>
                                    </div>
                                </a>
                            </div>
                        </div>
                    </div>
                    <div class="col-4">
                        <div class="widget">
                            <div class="widget_body">
                                <a class="widget_link" href="{{url('/patient/add_new_diary')}}">
                                    <div class="widget_link_icon">
                                        <img src="{{asset('admin/doctor/images/red_heart.svg')}}" alt="icon">
                                    </div>
                                    <div class="widget_link_text">
                                        <h4>Add New Health Diary</h4>
                                        <p>Set schedule to make appointment with doctor.</p>
                                    </div>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</main>
@endsection