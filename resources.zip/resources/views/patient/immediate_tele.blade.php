@extends('layouts.patient')

@section('content')
<main class="col-12 col-md-12 col-xl-12 bd-content">
    <div class="row">
        <div class="col-12">
            <div class="widget">
                <div class="widget_header">
                    <h2>Telemedical Appointment</h2>
                </div>                
                <div id="accordion">
                    <div class="widget_body mb-3">
                        <div class="widget_card" id="headingOne">
                            <h5 class="mb-0">
                                <button data-toggle="collapse" data-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
                                  <span>1</span>Fill Registration Form
                                </button>
                              </h5>
                        </div>
                        <div id="collapseOne" class="collapse show" aria-labelledby="headingOne" data-parent="#accordion">
                            <div class="widget_card_body">
                            	<div class="alert alert-danger-outline alert-dismissible alert_icon fade show error_msg_tele text-left" id="error_msg_tele" role="alert" style="display:none;">
	                                <div class="d-flex align-items-center">
	                                    <div class="alert-icon-col">
	                                        <span class="fa fa-warning"></span>
	                                    </div>
	                                    <div class="alert_text error_text_tele">
	                                        Email field is required
	                                    </div>
	                                    <a href="#" class="close alert_close" data-dismiss="alert" aria-label="close"><i class="fa fa-close"></i></a>
	                                </div>
	                            </div>
                                <form action="" method="POST" onsubmit="savetelebooking(this); return false;" id="save_tele_book">
                                	{{ csrf_field() }}
                                	<input type="hidden" class="submit_status" value="<?php if(isset($book_details) && count($book_details) > 0){ echo 1; }else{ echo 0; } ?>">
                                	<input type="hidden" class="submit_id" value="<?php if(isset($book_details[0])){if(isset($book_details[0]->booking_id)){echo trim($book_details[0]->booking_id); }} ?>">
                                    <input type="hidden" class="appointment_id" value="{{$appointment_id}}">
                                    <input type="hidden" class="speciality_id" name="speciality_id" value="<?php if(!empty($speciality)){ echo $speciality; } ?>">
                                    <div class="row">
                                        <div class="col-sm-12">
                                            <div class="form-group">
                                                <label>Consultation Requested for</label>
                                                <input <?php if(count($BillingInfo)>0) { echo "disabled"; } ?> class="form-control patient_name" placeholder="Enter patient name" type="text" value ="<?php if(isset($book_details[0])){if(isset($book_details[0]->booking_name)){ echo trim($book_details[0]->booking_name); }} ?>">
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-sm-4">
                                            <div class="form-group">
                                                <label>Mobile Number</label>
                                                <input <?php if(count($BillingInfo)>0) { echo "disabled"; } ?> class="form-control mobile_no" placeholder="Enter mobile number" type="text" value="<?php if(isset($book_details[0])){if(isset($book_details[0]->mobile_number)){ echo trim($book_details[0]->mobile_number);}} ?>">
                                            </div>
                                        </div>
                                        <div class="col-sm-8">
                                            <div class="form-group">
                                                <label>Name of Primary Hospital</label>                                            
                                                <input <?php if(count($BillingInfo)>0) { echo "disabled"; } ?> class="form-control hospital_name" placeholder="Enter Hospital Name" type="text" value="<?php if(isset($book_details[0])){if(isset($book_details[0]->hospital_name)){ echo trim($book_details[0]->hospital_name);}} ?>">
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-sm-12">
                                            <div class="form-group">
                                                <label>Describe Symptoms</label>
                                                <textarea <?php if(count($BillingInfo)>0) { echo "disabled"; } ?> class="form-control symptoms" name="name" rows="4" cols="40" placeholder="Enter text here.." ><?php if(isset($book_details[0])){if(isset($book_details[0]->symptoms)){ echo trim($book_details[0]->symptoms);}} ?></textarea>
                                             </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-sm-12">
                                              @if(count($health_diaries)>0)
                                        <a class="attachment mb-4 mt-2" href="javascript:;" data-toggle="modal" data-target="#select_diary">
                                                  <img src="{{ asset('images/attachment.svg') }}" alt="icon">
                                                  Attach My Health Diary
                                             </a> 
                                                        @else
                                                        <a class="attachment mb-4 mt-2" href="javascript:;" onClick="(function(){
                                                        alert('No health diary found');
                                                        return false;
                                                        })();return false;">
                                                        <img src="{{ asset('images/attachment.svg') }}" alt="icon">
                                                        Attach My Health Diary
                                                        </a> 
                                                        @endif

                                             <div class="attachdoaries">
                                         
                                             </div>

                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-sm-12">
                                            <div class="form-group form-check">
                                                <input <?php if(count($BillingInfo)>0) { echo "disabled"; } ?> class="form-check-input form-check-custom sharing_status" id="sharing_status" name ="sharing_status" type="checkbox" value="1" <?php if(isset($book_details[0])){ if($book_details[0]->sharing_status == 1){ echo 'checked="checked"'; }} ?>/>
                                                <label class="form-check-label" for="sharing_status">Would you like to share your detail with primary hospital?</label>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-sm-12">
                                            <div class="form-group form-check">
                                                <input <?php if(count($BillingInfo)>0) { echo "disabled"; } ?> class="form-check-input form-check-custom terms_cond" id="terms_cond" name ="terms_cond" type="checkbox" value="1" <?php if(isset($book_details[0])){ if($book_details[0]->terms_conditions == 1){ echo 'checked="checked"'; }} ?>/>
                                                <label class="form-check-label" for="terms_cond">I’ve read the term & conditions. I Agree & Accept Render Terms and Condition</label>
                                            </div>
                                        </div>
                                    </div>                                   

                                    <div class="row mt-4">
                                        <div class="col-sm-7">
                                            <a href="{{url('patient/dashboard')}}" class="btn btn-danger btn-min-width-auto mr-2">Cancel</a>
                                            <button class="btn btn-primary" type="submit">Continue next step</button>
                                        </div>
                                        <div class="col-sm-5 text-right">
                                            <div class="time_appointment">
                                                <div class="time_appointment_icon">
                                                    <img src="{{ asset('images/cal_time.svg') }}" alt="icon">
                                                </div>
                                                <div class="time_appointment_text">   
                                                    @php date_default_timezone_set($timezone); @endphp 
                                                    <input type="hidden" class="doctor_appoint_date" value="{{ date('d-m-Y H:i:s') }}">                                                
                                                    <h5>Today, {{ date('j M,Y') }}</h5>
                                                    <p>at {{ date('h:i a') }}</p>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                                                 <!-- Diary Modal -->
    <div class="modal fade" id="select_diary">
        <div class="modal-dialog modal-xl modal-dialog-centered genModal">
            <div class="modal-content">
                <div class="modal-header">
                    <h4 class="modal-title">Add My Health Diary</h4>
                    <button type="button" class="close mclose" data-dismiss="modal"><img src="{{asset('images/cross_modal.svg')}}"/></button>
                 </div>
                <div class="modal-body">
                    <div class="health_diary">
                        <ul class="row">
                            @foreach($health_diaries as $Singlehealth_diaries)
                            <li class="col-sm-4">
                                <input id="diary_{{$Singlehealth_diaries->id}}" value="{{$Singlehealth_diaries->diary_id}}" class="form-check-input health_diary" name="health_diary" type="checkbox"   onclick="appenddiary(<?php echo $Singlehealth_diaries->diary_id;?>,this)" />
                                <label for="diary_{{$Singlehealth_diaries->id}}">
                                    <span class="diary_date">{{ date('j F Y',$Singlehealth_diaries->created_date)}}</span>
                                    <div class="diary_detail">
                                        @php
                                             $feeling_pic = ['admin/doctor/images/smilies/no_pain@2x.png','admin/doctor/images/smilies/mild@2x.png','admin/doctor/images/smilies/moderate@2x.png','admin/doctor/images/smilies/severe@2x.png','admin/doctor/images/smilies/very_severe@2x.png','admin/doctor/images/smilies/worst_pain@2x.png','admin/doctor/images/smilies/moderate@2x.png'];
                                            @endphp
                                        <span class="diary_icon"><img src="{{asset($feeling_pic[$Singlehealth_diaries->feeling_details])}}" alt="smilies"></span>
                                   @php 
                                     $put_disable_keys=array();

                                     $feeling = ['Feeling No Pain','Feeling Mild Pain','Feeling Moderate Pain','Feeling Severe Pain','Feeling Very Severe Pain','Feeling Worst Pain',"Other"];    
                                      $put_disable_keys[]=$Singlehealth_diaries->feeling_details;
                                     
                                  @endphp                              

                                     
                                       @foreach($feeling as $key=>$single_feeling) 
                                       @if($key==6)
                                       <h4> {{ trim($Singlehealth_diaries->describe_feeling_other)}}</h4> 
                                      @else
                                       @if(in_array($key,$put_disable_keys))                              
                                        <h4>{{$single_feeling}}</h4>                                      
                                         @endif
                                           @endif
                                        @endforeach 

                                        <h6>{{$Singlehealth_diaries->symptom_details}}</h6>
                                    </div>
                                </label>
                            </li>
                            @endforeach
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>

                                </form>
                            </div>
                        </div>
                    </div>
   
                    <div class="widget_body mb-3">
                        <div class="widget_card" id="headingTwo">
                            <h5 class="mb-0">
                                <button class="collapsed" data-toggle="collapse" data-target="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
                                   <span>2</span>Payment Process
                                </button>
                              </h5>
                        </div>
                        <div id="collapseTwo" class="collapse" aria-labelledby="headingTwo" data-parent="#accordion">
                            <div class="widget_card_body">                                
                                <button type="button" <?php if(count($BillingInfo)>0) { echo "disabled"; } ?> class="btn btn-primary" name="button" onclick="payWithPaystack(this);" data-amt="50" data-doc_id="" data-pt_id="{{ $user->patient_unique_id }}" data-bill_id="">Pay Now</button>
                                <h3 class="order_ID">₦ 50</h3>
                            </div>
                        </div>
                    </div>
                    <div class="widget_body mb-3">
                        <div class="widget_card" id="headingThree">
                            <h5 class="mb-0">
                                <button class="collapsed" data-toggle="collapse" data-target="#collapseThree" aria-expanded="false" aria-controls="collapseThree">
                                  <span>3</span>Order Confirmation
                                </button>
                              </h5>
                        </div>
                        <div id="collapseThree" class="collapse" aria-labelledby="headingThree" data-parent="#accordion">
                            <div class="widget_card_body">
                                <div class="table_profile_header mb-3">
                                    <div class="tprofile_image">
                                        @if(!empty($book_details[0]->doctor->doctor_picture))
                                            <img src="{{ asset('doctorimages/'.$book_details[0]->doctor->doctor_picture) }}" class="doc_image" alt="image">
                                        @else
                                            <img src="{{ asset('images/doc.png') }}" class="doc_image" alt="image">
                                        @endif
                                    </div>
                                    <div class="tprofile_text">
                                        
                                            <h3 class="doc_name">
                                                @if(isset($book_details[0]->doctor->first_name))
                                                    Dr. {{$book_details[0]->doctor->first_name}} {{$book_details[0]->doctor->last_name}}, {{$book_details[0]->doctor->doc_degree}}
                                                @endif
                                            </h3>
                                            <p class="doc_spe">
                                                 @if(isset($book_details[0]->doctor->specialist_categories->speciality_name))
                                                    {{$book_details[0]->doctor->specialist_categories->speciality_name}}
                                                @endif    
                                            </p>                                      
                                    </div>
                                </div>
                                <h4 class="appointment_date">Today, {{ date('j M,Y') }}</h4>
                                <p class="appointment_time">just now</p>

                                <h3 class="order_ID">Order ID : <span class="order_no"><?php if(isset($book_details[0])){if(isset($book_details[0]->booking_id)){ echo trim($book_details[0]->booking_id);}} ?></span></h3>
                            </div>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </div>
</main>
@endsection