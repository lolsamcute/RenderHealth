@extends('layouts.patient')

@section('content')
<main class="col-12 col-md-12 col-xl-12 bd-content">
    <div class="row">
        <div class="col-12">
            <div class="widget">
                <div class="widget_header">
                <?php //echo "<pre>";print_r($appointment[0]);?>               
                	@if($appointment[0]['patient_appoint']['appointment_type'] == 1)
                  	 <h5>Telemedical Appointment Details</h5>
                   @else
                  	 <h5>Hospital Appointment Details</h5>
                   @endif                   
                </div>
                <div class="row">
                    <div class="col-12">
                        <div class="widget_body mb-3">
                            <div class="widget_doctor_list">
                                <div class="hospital_appointment_detail">
                                    <div class="hdd_inner">
                                    	@if($appointment[0]['doctor_id'] != "")
	                                        <div class="hdd_detail">
	                                            <div class="hdd_image">
	                                                @php if((file_exists(getcwd().'/doctorimages/'.$appointment[0]['doctor']['doctor_picture'])) && (!empty($appointment[0]['doctor']['doctor_picture']))){
                                      @endphp
                                      <img src="{{ asset('/doctorimages/'.$appointment[0]['doctor']['doctor_picture']) }}" alt="image">
                                      @php     }
                                      else { @endphp
                                      <img src="{{ asset('admin/doctor/images/doc1.png') }}" alt="image">
                                      @php   } @endphp
	                                            </div>
	                                            <div class="hdd_desc">
	                                                <span class="hdd_type">{{ $appointment[0]['doctor']['specialist_categories']['speciality_name']}}</span>
	                                                <h3>Dr. {{ $appointment[0]['doctor']['doctor_first_name']}} {{ $appointment[0]['doctor']['doctor_last_name']}}</h3>
	                                                <a href="javascript:;" onclick="viewDoctorProfile({{$appointment[0]['doctor']['doctor_id']}});">View Profile</a>
	                                            </div>
	                                        </div>
	                                    @else
	                                    <div class="hdd_detail">
                                            <div class="hdd_desc">
	                                            <h3>No doctor assigned</h3>
	                                        </div>
                                        </div>
	                                    @endif
                                        <div class="hdd_other">
                                            <div class="hdd_other_box">
                                                <div class="hdd_other_box_img">
                                                    <img src="{{ asset('images/geo_medical.svg') }}" alt="icon">
                                                </div>
                                                <div class="hdd_other_desc">
                                                    @if(!empty($appointment[0]['hospital_id']))
                                                        <h4>{{ $appointment[0]['hospital_detail']['hosp_name'] }}</h4>
                                                        <p>{{ $appointment[0]['hospital_detail']['hosp_address'] }}</p>
                                                    @elseif($appointment[0]['hospital_name'] != "")
                                                        <h4>{{ $appointment[0]['hospital_name'] }}</h4>
                                                        <p>-</p>
                                                    @else
                                                         <h4>-</h4>
                                                        <p>-</p>
                                                    @endif
                                                </div>
                                            </div>
                                            <div class="hdd_other_box">
                                                <div class="hdd_other_box_img">
                                                    <img src="{{ asset('images/time_date.svg') }}" alt="icon">
                                                </div>
                                                <div class="hdd_other_desc">
                                                    @php date_default_timezone_set($timezone); @endphp
                                                    <h4>{{ date('j F,Y',$appointment[0]['appointment_time']) }}</h4>
                                                    <p>at {{ date('h:i A',$appointment[0]['appointment_time']) }}</p>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="reason">
                                        <h5>Reason for visit :</h5>
                                        <p>{{ $appointment[0]['symptoms']}}</p>
                                    </div>

                                     <div class="patient_health_diary">
                                        <?php //print_r($appointment[0]['diary_detail']);?>
                                            <h2>Patient Health Diary</h2>
                                            @if(count($diary_details)>0)
                                            @foreach($diary_details as $diary_detail)
                                            @php $feeling_pic = ['admin/doctor/images/smilies/no_pain@2x.png','admin/doctor/images/smilies/mild@2x.png','admin/doctor/images/smilies/moderate@2x.png','admin/doctor/images/smilies/severe@2x.png','admin/doctor/images/smilies/very_severe@2x.png','admin/doctor/images/smilies/worst_pain@2x.png','admin/doctor/images/smilies/moderate@2x.png'];
                                            $source=$feeling_pic[$diary_detail->feeling_details];@endphp
                                            <div class="phd_inner">
                                            <span class="feeling_emoji"><img src="{{ asset($source) }}" alt="image"></span>                        

                                            @php
                                            $feeling = ['Feeling No Pain','Feeling Mild Pain','Feeling Moderate Pain','Feeling Severe Pain','Feeling Very Severe Pain','Feeling Worst Pain','other'];  
                                            if($diary_detail['feeling_details']==6){
                                            $feeling_other=$diary_detail->describe_feeling_other;
                                            }
                                            else{
                                            $feeling_other=$feeling[$diary_detail->feeling_details];
                                            }
                                            @endphp
                                            <h3>{{$feeling_other}}</h3>
                                            <p>{{$diary_detail->symptom_details}}</p>
                                            <div class="phd_detail">
                                                <div class="phd_detail_type">
                                                    <h5>Diary created :</h5>
                                                    <h4>{{date('d F Y h:i A',$diary_detail->created_date)}}</h4>
                                                </div>
                                                <div class="phd_detail_type">
                                                    <h5>Medications :</h5>
                                                    <h4>{{$diary_detail->medication_details}}</h4>
                                                </div>
                                                <div class="phd_detail_type">
                                                    <h5>Attachment Image</h5>
                                                    <div class="phd_detail_attached">
                                                    @if(isset($diary_detail['diary_attachment']) && count($diary_detail['diary_attachment']) > 0)
                        @foreach($diary_detail['diary_attachment'] as $attachment)
                                            <img src="{{asset($attachment['attachment_path'])}}" alt="image">
                                            @endforeach   
                                            @else
                                            <p>No Attachments Attached</p>     
                                            @endif 
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        @endforeach
                                        @else
                                          <p> No Patient Diary attached</p>
                                          @endif
                                    </div>
                                   
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</main>

<!-- Modal -->
<div class="modal fade" id="view_user" role="dialog">
  <div class="modal-dialog modal-md modal-dialog-centered genmodal genmodal_custom custom_width3">
    <div class="modal-content">
      <div class="modal-header">
        <h3>View Details
        </h3>
        <button type="button" class="close" data-dismiss="modal">
          <img src="{{ asset('admin/adminimages/popup_close.svg') }}" />
        </button>
      </div>

      <div class="modal-body">
        <div class="alert alert-danger-outline alert-danger-outline-adddr alert-dismissible alert_icon fade show" role="alert" style="display: none;">
          <div class="d-flex align-items-center">
            <div class="alert-icon-col">
              <span class="fa fa-warning">
              </span>
            </div>
            <div class="alert_text adddr_danger_pop">
            </div>
            <a href="#" class="close alert_close" data-dismiss="alert" aria-label="close">
              <i class="fa fa-close">
              </i>
            </a>
          </div>
        </div>
        <div class="alert alert-success-outline alert-success-outline-adddr alert-dismissible alert_icon fade show" role="alert" style="display: none;">
          <div class="d-flex align-items-center">
            <div class="alert-icon-col">
              <span class="fa fa-check">
              </span>
            </div>
            <div class="alert_text adddr_success_pop">
            </div>
            <a href="#" class="close alert_close" data-dismiss="alert" aria-label="close">
              <i class="fa fa-close">
              </i>
            </a>
          </div>
        </div>

        <div class="row" id="view_user_body">
            
        </div>
      </div>
    </div>
  </div>
</div>
@endsection