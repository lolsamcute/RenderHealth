<!DOCTYPE html>
<html>
<head>
	<title>Render Health</title>
	<link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
</head>
<body>
	<style>
	@import url('https://fonts.googleapis.com/css?family=Rubik:300,300i,400,400i,500,500i,700,700i,900,900i');
	body h1 {
		font-size: 25px;
		font-weight: 400;
	}
	.round i {
		color: #fff;
       font-size:40px;
	}
	.round {
		width: 70px;
		height: 70px;
		background-color: #1fa8a0;
		border-radius: 50%;
		text-align: center;
		line-height: 100px;
	}
	.center_page {
		display: flex;
		flex-direction: column;
		align-items: center;
		color: #1fa8a0;
	}
	body {
		font-family: 'Rubik', sans-serif;
		display: flex;
		align-items: center;
		justify-content: center;
		height: 100vh;
		margin: 0;
		background-color: #fff;
	}
	</style>
	<div class="center_page">
		<div class="round"><i class="material-icons">check</i></div><h1>{{ $message }}</h1>
	</div>	
</body>
</html>