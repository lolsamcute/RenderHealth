@extends('layouts.patient_fluid')
@section('content')
<main class="col-12 col-md-12 col-xl-12 bd-content">
    <div class="row">
        <div class="col-12 col-xl-9">
            <div class="widget">
                <div class="widget_header widget_flex_header mb-2">
                    <h2>Health History</h2>
                 
                    <div class="select_box select_black">
                          @if(isset($start_date->created_date))    
                            @php 
                                date_default_timezone_set($time_zone);
                                $startDate = $start_date->created_date; 
                                $endDate = date("Y-m-t 23:59:59",strtotime('now'));
                                $presentStartDate = date("Y-m-01 00:00:00",strtotime('now'));    
                                $dates = array();                                            
                            @endphp                                               
                            @while($startDate <= strtotime($endDate)) 
                            @php    $dates[] = $startDate;
                                    $startDate = strtotime("+1 month", $startDate); 
                                    $final_dates = array_reverse($dates);
                                    
                            @endphp
                            @endwhile 
                            <select class="form-control history_mnth" name="" onchange="sortHealthHistory(this); return false;">                                                  
                                @foreach($final_dates as $date_arr)
                                    <option value="{{ date('Y-m-01',$date_arr) }}" <?php if($date_arr >= strtotime($presentStartDate) &&  $date_arr <= strtotime($endDate)){ echo 'selected' ; } ?>>{{ date('F',$date_arr) }} {{date('Y',$date_arr) }}</option>
                                @endforeach
                             </select>
                        @endif                         
                     </div>
                </div>
                <div class="main_history_div">
                  <div class="widget_body minheight500 mb-3">
                    <div class="table-responsive">
                      <table class="table theme_table">
                        <thead>
                          <tr>
                            <th scope="col">Hospital</th>
                            <th scope="col">Doctor Name</th>
                            <th scope="col">Date & Time</th>
                            <th scope="col" class="text-center">Attachment</th>
                          </tr>
                        </thead>
                        <tbody>
                          @if(count($health_history) >0)
                            @foreach($health_history as $health_hist)
                              <tr class="history_div cursor_pointer" data-id="{{ $health_hist->history_id }}" onclick="historydetail(this); return false;">
                                <td>
                                    <div class="center_type">
  @if(isset($health_hist->doctor))
                                        <h5>{{ $health_hist->doctor->doctor_hospital_details->hosp_name }}</h5>
                                        @endif
                                        <a class="hospital_appointment" href="javascript:;">Hospital Appointment</a>
                                    </div>
                                </td>
                                <td>
                                    <div class="table_profile_header">
                                      <div class="tprofile_image">
                                          @php
                                          if(isset($health_hist->doctor)){

                                           if((file_exists(getcwd().'/doctorimages/'.$health_hist->doctor->doctor_picture)) && (!empty($health_hist->doctor->doctor_picture))){
                                      @endphp
                                      <img src="{{ asset('/doctorimages/'.$health_hist->doctor->doctor_picture) }}" alt="image">
                                      @php     }
                                      else { @endphp
                                      <img src="{{ asset('images/profile.svg') }}" alt="image">
                                      @php   } }else{ @endphp
                                       <img src="{{ asset('images/profile.svg') }}" alt="image">
                                       @php } @endphp
                                      </div>
                                      <div class="tprofile_text">
                                        @if(isset($health_hist->doctor))
                                          <h3>Dr. {{ $health_hist->doctor->doctor_first_name }} {{ $health_hist->doctor->doctor_last_name }}, {{ $health_hist->doctor->doctor_degree }}</h3>
                                          <p>{{ $health_hist->doctor->specialist_categories['speciality_name'] }}</p>
                                          @endif
                                      </div>
                                  </div>
                                </td>
                                <td>
                                    <div class="appointment_time">
                                        <h5>{{ date('D', $health_hist->updated_date) }}, {{ date('j M Y ', $health_hist->updated_date) }} {{ date('h:i A ', $health_hist->updated_date) }}</h5>
                                     </div>
                                </td>
                                <td class="text-center">
                                    <div class="attachment">
                                        <img src="{{ asset('images/attachment.svg') }}" alt="icon">
                                        @php $i=0; @endphp
                                    @foreach($health_hist['history_attachments'] as $history_attachments) 
                                    @if($history_attachments->type == 2)
                                  @php $i++;@endphp
                                   @endif
                                    @endforeach


                                        {{ $i }} Files
                                    </div>
                                </td>
                              </tr>
                            @endforeach
                          @else
                            <tr>
                              <td colspan="4" class="text-center">No History Found</td>
                            </tr>
                          @endif                        
                        </tbody>

                      </table>
                    </div>
                      <div class="showing_data">
                          Showing you {{ count($health_history) }} datas from your health history, stay health! <img src="{{ asset('images/smilies/raised-hand.png') }}" alt="icon">
                      </div>
                  </div>
                  @if ($health_history->lastPage() > 1)
                    <div class="widget_footer">
                        @if ($health_history->hasPages())
                          <ul class="pagination">
                              {{-- Previous Page Link --}}
                              @if ($health_history->onFirstPage())
                                  <li class="disable"><a href="javascript:;"><img src="{{ asset('images/left_page.svg') }}" alt="icon"></a></li>
                              @else
                                  <li><a href="{{ $health_history->previousPageUrl() }}"><img src="{{ asset('images/left_page.svg') }}" alt="icon"></a></li>
                              @endif
                              {{-- Next Page Link --}}
                              @if ($health_history->hasMorePages())
                                  <li><a href="{{ $health_history->nextPageUrl() }}"><img src="{{ asset('images/right_page.svg') }}" alt="icon"></a></li>        
                              @else
                                  <li class="disable"><a href="javascript:;"><img src="{{ asset('images/right_page.svg') }}" alt="icon"></a></li>
                              @endif
                        </ul>@endif
                    </div>
                  @endif
                </div>
            </div>

        </div>
        <div class="col-12 col-xl-3">
            <div class="filter mt-5 pt-2">
                <div class="filter_heading">
                    <h4>Filter</h4>
                    <a class="filter_reset" onclick="resetfilters(this); return false;" href="javascript:;">Reset Filter</a>
                </div>
                <div class="filter_body">
                    @if(count($speciality_detail) > 0)
                        <div class="filter_row">
                            <h5>Doctor Speciality</h5>
                            @foreach($speciality_detail as $key=>$speciality_det)
                              <div class="checkbox" onclick="sortHealthHistory(this); return false;">
                                  <input id="speaciality{{ ($key+1) }}" type="checkbox" class="form-check-custom doc_speciality" value="{{ $speciality_det['speciality_id'] }}"/>
                                  <label for="speaciality{{ ($key+1) }}">{{ $speciality_det['speciality_name'] }}</label>
                              </div>
                          @endforeach                       
                        </div>
                    @endif
                    <div class="filter_row">
                        <h5>Hospital</h5>
                        <div class="select_box">
                            <select class="form-control hosp_list" name="" onchange="sortHealthHistory(this); return false;">
                                <option value="">All Hospitals</option>
                                @if(count($hospitals) > 0)
                                  @foreach($hospitals as $hospital)
                                    <option value ="{{ $hospital->hosp_id }}">{{$hospital->hosp_name}}</option>
                                  @endforeach
                                @endif
                            </select>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</main>
@endsection