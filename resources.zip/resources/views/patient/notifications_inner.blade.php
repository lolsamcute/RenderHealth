<div class="widget">
  <div class="widget_header">
      <h2>Your Notifications</h2>
  </div>
  <div class="widget_body mb-3">
      <ul class="notification_list">
          @if(count($notifications) > 0)
              @foreach($notifications as $notification)
                  <li class="<?php if($notification['status'] == 0){ echo 'unread'; } ?> cursor_pointer" id="notify_{{$notification['notification_id']}}" data-id="{{$notification['event_id']}}" data-type="{{$notification['notification_type']}}" onclick="notificationDetail(this); return false;">
                      <div class="notify_list">                                         
                        <div class="notify_image">
                            @if(!empty($notification['doctor_id']))
                              @if(!empty($notification['doctor']['doctor_picture']))
                                  <img src="{{asset('admin/doctor/uploads/profile/'.$notification['doctor']['doctor_picture'])}}" alt="image" style="height:100%">
                              @else
                                  <img src="{{ asset('admin/doctor/images/profile.svg') }}" alt="image" style="height:100%">
                                  
                              @endif
                            @else
                               @if(!empty($notification['patient']['patient_profile_img']))
                                  <img src="{{asset('uploads/patient/'.$notification['patient']['patient_profile_img'])}}" alt="image" style="height:100%">
                              @else
                                  <img src="{{ asset('images/profile.svg') }}" alt="image" style="height:100%">
                                  
                              @endif
                            @endif
                        </div>
                        <div class="notify_text">                             
                            @if(!empty($notification['doctor_id']))
                              @if($notification['notification_type'] == "appt")
                                  <h3><span>Dr. {{ $notification['doctor']['doctor_first_name'] }} {{ $notification['doctor']['doctor_last_name'] }}, {{ $notification['doctor']['doctor_degree'] }}</span> {{$notification['change_type'] }} an <span>appointment</span></h3>
                              @elseif($notification['notification_type'] == "health_history")
                                  <h3><span>Dr. {{ $notification['doctor']['doctor_first_name'] }} {{ $notification['doctor']['doctor_last_name'] }}, {{ $notification['doctor']['doctor_degree'] }}</span> {{$notification['change_type'] }} a <span>heath history</span> </h3>
                              @elseif($notification['notification_type'] == "bill")
                                  <h3><span>Dr. {{ $notification['doctor']['doctor_first_name'] }} {{ $notification['doctor']['doctor_last_name'] }}, {{ $notification['doctor']['doctor_degree'] }}</span> {{$notification['change_type'] }} a <span>bill</span></h3>
                              @endif
                            @else
                              @if($notification['notification_type'] == "appt")
                                  <h3><span>You</span> {{$notification['change_type'] }} an <span>appointment</span></h3>
                              @elseif($notification['notification_type'] == "health_history")
                                  <h3><span>You</span> {{$notification['change_type'] }} a <span>heath history</span></h3>
                              @elseif($notification['notification_type'] == "bill")
                                  <h3><span>You</span> {{$notification['change_type'] }} a <span>bill</span></h3>
                              @elseif($notification['notification_type'] == "cron")
                                  <h3><span>You</span> have an <span>appointment</span></h3>
                              @endif
                            @endif
                            @php
                                $intial_date = date("Y-m-d H:i:s",$notification['created_date']);
                                $date = new DateTime($intial_date);
                                $now = new DateTime();
                            @endphp
                            <p><img src="{{asset('admin/doctor/images/ic_time_access.svg')}}" alt="icon"/>{{ $date->diff($now)->format("%h hours") }} ago</p>
                        </div>                                           
                    </div>
                  </li>
              @endforeach
          @endif                        
      </ul>
  </div>
  @if ($notifications->lastPage() > 1)
      <div class="widget_footer">
          @if ($notifications->hasPages())
            <ul class="pagination">
                {{-- Previous Page Link --}}
                @if ($notifications->onFirstPage())
                    <li class="disable"><a href="javascript:;"><img src="{{ asset('images/left_page.svg') }}" alt="icon"></a></li>
                @else
                    <li><a href="{{ $notifications->previousPageUrl() }}"><img src="{{ asset('images/left_page.svg') }}" alt="icon"></a></li>
                @endif
                {{-- Next Page Link --}}
                @if ($notifications->hasMorePages())
                    <li><a href="{{ $notifications->nextPageUrl() }}"><img src="{{ asset('images/right_page.svg') }}" alt="icon"></a></li>        
                @else
                    <li class="disable"><a href="javascript:;"><img src="{{ asset('images/right_page.svg') }}" alt="icon"></a></li>
                @endif
          </ul>@endif
      </div>
    @endif
</div>