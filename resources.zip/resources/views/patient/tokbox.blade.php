<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href="{{ asset('images/favicon.png') }}">
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <meta http-equiv="cache-control" content="no-cache" />
    <meta http-equiv="Pragma" content="no-cache" />
    <meta http-equiv="Expires" content="-1" />
    <title> Render Health </title>
    <link href="css/app.css" rel="stylesheet" type="text/css">
    <script src="https://ajax.aspnetcdn.com/ajax/jQuery/jquery-3.3.1.min.js"></script>
    <script src="https://static.opentok.com/v2/js/opentok.min.js"></script>
    <link href="{{ asset('admin/doctor/css/style.css') }}" rel="stylesheet" type="text/css">
    <link href="{{ asset('admin/doctor/css/video.css') }}" rel="stylesheet" type="text/css">
</head>
<body>
    <?php
        if(isset($expire)){
    ?>
        <script type="text/javascript">
           window.close();
        </script>
    <?php 
        }
    ?>
	<input type="hidden" class="api_key" name="api_key" value="46168842">
	<input type="hidden" class="sessionId" name="sessionId" value="{{ $sessionId }}">
    <input type="hidden" class="token" name="token" value="{{ $token }}">
    <input type="hidden" class="call_type" name="call_type" value="{{ $type }}">
    <input type="hidden" class="a_id" name="a_id" value="{{ $a_id }}">
    <input type="hidden" class="d_id" name="d_id" value="{{ $d_id }}">
    <input type="hidden" class="call_id" name="call_id" value="{{ $call_id }}">
    <input type="hidden" class="p_id" name="p_id" value="{{ $patient_details->patient_unique_id }}">
    <input type="hidden" class="site_url" name="site_url" id="site_url" value="{{ url('/') }}">
    {{ csrf_field() }}
    <div id="videos">
        <div class="video_ringing">
            <div class="video_profile">
                @if($patient_details->patient_profile_img != "")
                    <img src="{{ asset('uploads/patient/'.$patient_details->patient_profile_img) }}" alt="image"/>
                @else
                    <img src="{{ asset('images/profile.svg') }}" alt="image"/>
                @endif
            </div>
            <h4>Ringing..</h4>
        </div>
        <div id="subscriber"></div>
        <div class="shade_video">
            <img src="{{ asset('admin/doctor/images/shade.svg') }}" alt="shade">
        </div>
        <div class="tel_box">
            <div class="tb_desc">
                <h4>Dr. Chinedu ikechukwu, MD</h4>
                <h6><span></span>online</h6>
            </div>
            <div class="contols">
                <ul>
                    @if($type == 2)
                         <li class="video_tel_btn"><a href="javascript:;" onclick="removePatientVideo();">
                             <img src="{{ asset('admin/doctor/images/video_call_mute@2x.png') }}" alt="shade" class="add_video">
                             <img src="{{ asset('admin/doctor/images/video_call@2x.png') }}" alt="shade" class="remove_video">
                            </a>
                          </li>
                    @endif
                    <li><a class="end_call_btn" href="javascript:;" onclick="disconnect(); return false;">End Call</a></li>
                    <li class="audio_tel_btn"><a href="javascript:;" onclick="removePatientAudio();">
                        <img src="{{ asset('admin/doctor/images/mic_mute@2x.png') }}" alt="shade" class="add_audio">
                        <img src="{{ asset('admin/doctor/images/mic@2x.png') }}" alt="shade" class="remove_audio">
                        </a>
                    </li>
                </ul>
            </div>            
                <div class="publisher_parent">
                    @if($type == 2)
                     <div id="publisher"></div>
                    @endif
                </div>
                 <audio id="myAudio" hidden loop>
                    <source src="{{asset('uploads/ringtone.mp3')}}" type="audio/ogg">
                    <source src="{{asset('uploads/ringtone.mp3')}}" type="audio/mpeg">
                    Your browser does not support the audio element.
                </audio> 
            
        </div>

    <script type="text/javascript" src="{{ asset('/js/tokbox.js') }}"></script>
    
</body>
</html>
