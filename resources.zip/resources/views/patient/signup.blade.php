@extends('layouts.app') 
@section('content')

  <div class="image_section">
      <img src="{{ asset('images/lady_doctor@2x.png') }}" alt="Doctor" class="img-fluid">
    </div>
    <div class="container">
        <form method="POST" action="" class="form-signin form-signup" onsubmit="signup(this); return false;">
                {{ csrf_field() }}
           <div class="input_section">
             <h1><img src="{{ asset('images/ic_register.svg') }}" alt="icon">Register account</h1>
             <div class="alert alert-success-outline alert-dismissible alert_icon fade show success_msg" id="success_msg" role="alert" style="display:none;">
               <div class="d-flex align-items-center">
                   <div class="alert-icon-col">
                       <span class="fa fa-check"></span>
                   </div>
                   <div class="alert_text success_text">
                       You have been successfully registered
                   </div>
                   <a href="#" class="close alert_close" data-dismiss="alert" aria-label="close"><i class="fa fa-close"></i></a>
               </div>
           </div>
           <div class="alert alert-danger-outline alert-dismissible alert_icon fade show error_msg" id="error_msg" role="alert" style="display:none;">
              <div class="d-flex align-items-center">
                  <div class="alert-icon-col">
                      <span class="fa fa-warning"></span>
                  </div>
                  <div class="alert_text error_text">
                      Email field is required
                  </div>
                  <a href="#" class="close alert_close" data-dismiss="alert" aria-label="close"><i class="fa fa-close"></i></a>
              </div>
          </div>
             <div class="row">

               <div class="col-sm-6">
                 <div class="form-group">
                   <label>Username</label>
                   <input type="text" class="form-control patient_username" placeholder="Username" name="patient_username">
                 </div>
               </div>
               <div class="col-sm-6">
                <div class="form-group">
                  <label>First name</label>
                  <input type="text" class="form-control patient_first_name" placeholder="First name" name="patient_first_name">
                </div>
              </div>
              <div class="col-sm-6">
               <div class="form-group">
                 <label>Middle name</label>
                 <input type="text" class="form-control patient_middle_name" placeholder="Middle name" name="patient_middle_name">
               </div>
              </div>
               <div class="col-sm-6">
               <div class="form-group">
                 <label>Last name</label>
                 <input type="text" class="form-control patient_last_name" placeholder="Last name" name="patient_last_name">
               </div>
              </div>
            </div>
            <div class="row">
              <div class="col-sm-6">
                <div class="form-group">
                  <label>Email</label>
                  <input type="text" class="form-control patient_email" placeholder="Your email" name="patient_email">
                </div>
              </div>
              <div class="col-sm-6">
               <div class="form-group">
                 <label>Phone Number</label>
             
                 <input type="tel" class="form-control patient_phone" placeholder="Phone number" name="patient_phone" id="phone" value="+234">
               </div>
             </div>
             <div class="col-sm-6">
              <div class="form-group">
                <label>Password</label>
                <input type="password" class="form-control patient_password" placeholder="Your password" name="patient_password">
              </div>
             </div>
             <div class="col-sm-6">
              <div class="form-group">
                <label>Confirm password</label>
                <input type="password" class="form-control c_password re_pass" placeholder="Re-enter password" name="c_password">
                <input type="hidden" name="patient_martial_status" value="2">
              </div>
             </div>
              <div class="col-sm-12">
             <div class="form-group">
                                                    <label>Birthday</label>
                                                    <div class="row">
                                                        <div class="col-3">
                                                            <div class="select_box">
                                                                <select id="select_num" class="form-control" name="day" style="background-color: #fff;">  
                                                                     <option value="">Day</option>                                
                                                                    <?php for($i=1;$i<=31;$i++){ 
                                                                    echo '<option value="'.$i.'">'.$i.'</option>';
                                                                  }   ?>
                                                                   </select>
                                                            </div>
                                                        </div>
                                                        <div class="col-6 px-0">
                                                            <div class="select_box">
                                                                <select id="select_day" class="form-control" name="month"  style="background-color: #fff;">               <option value="">Month</option>                   
                                                                   <?php  for ($m=1; $m<=12; $m++) {
                                                                      $month = date('F', mktime(0,0,0,$m, 1, date('Y')));
                                                                        echo '<option value="'.$month.'">'.$month.'</option>';
                                                                                 } ?>
                                                                </select>
                                                            </div>
                                                        </div>
                                                        <div class="col-3">
                                                            <div class="select_box">
                                                                <select class="form-control" id="year" name="years"  style="background-color: #fff;">
                                                                    <option value="">Year</option> 
                                                                    @php  
                                                                    $date = date('Y');
                                                                    $new_date =$date-12;
                                                                    $range = 1900;
                                                                    for($i=$range;$i<=$new_date; $i++){
                                                                        $year = $range++;                                                                        
                                                                    @endphp
                                                                        <option id="year_get" value="{{$year}}" >{{$year}}</option>
                                                                    @php
                                                                    }
                                                                    @endphp    

                                                                </select>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
           </div>
           <div class="row form-bottom">
             <div class="col-sm-7">
               <div class="form-group form-check">
                 <input type="checkbox" class="form-check-input patient_terms_cond" id="terms" name="patient_terms_cond" value ="1">
                 <label class="form-check-label" for="terms" >I’ve read the <a href="javascript:;">term & conditions</a></label>
               </div>
             </div>
             <div class="col-sm-5 text-right">
               <button class="btn btn-primary updateBtn" type="submit">Register</button>
             </div>
           </div>
           </div>

      </form>
    </div>
    <div class="login_footer">
      Have an account?<a href="{{ url('patient/login') }}">Login to my account</a>
    </div>
  
  @endsection
  