<div class="widget_body minheight500 mb-3">
  <div class="table-responsive">
    <table class="table theme_table">
      <thead>
        <tr>
          <th scope="col">Hospital</th>
          <th scope="col">Doctor Name</th>
          <th scope="col">Date & Time</th>
          <th scope="col" class="text-center">Attachment</th>
        </tr>
      </thead>
      <tbody>
        @if(count($health_history) >0)
          @foreach($health_history as $health_hist)
            <tr class="history_div cursor_pointer" data-id="{{ $health_hist->history_id }}" onclick="historydetail(this); return false;">
              <td>
                  <div class="center_type">
                      <h5>{{ $health_hist->doctor->doctor_hospital_details->hosp_name }}</h5>
                      <a class="hospital_appointment" href="javascript:;">Hospital Appointment</a>
                  </div>
              </td>
              <td>
                  <div class="table_profile_header">
                    <div class="tprofile_image">
                       @php if((file_exists(getcwd().'/doctorimages/'.$health_hist->doctor->doctor_picture)) && (!empty($health_hist->doctor->doctor_picture))){
                                      @endphp
                                      <img src="{{ asset('/doctorimages/'.$health_hist->doctor->doctor_picture) }}" alt="image">
                                      @php     }
                                      else { @endphp
                                      <img src="{{ asset('admin/doctor/images/doc1.png') }}" alt="image">
                                      @php   } @endphp
                    </div>
                    <div class="tprofile_text">
                        <h3>Dr. {{ $health_hist->doctor->doctor_first_name }} {{ $health_hist->doctor->doctor_last_name }}, {{ $health_hist->doctor->doctor_degree }}</h3>
                        <p>{{ $health_hist->doctor->specialist_categories->speciality_name }}</p>
                    </div>
                </div>
              </td>
              <td>
                  <div class="appointment_time">
                      <h5>{{ date('D', $health_hist->created_date) }}, {{ date('j M Y', $health_hist->created_date) }}</h5>
                   </div>
              </td>
              <td class="text-center">
                  <div class="attachment">
                      <img src="{{ asset('images/attachment.svg') }}" alt="icon">
                      {{ count($health_hist->history_attachments) }} Files
                  </div>
              </td>
            </tr>
          @endforeach
          @else
            <tr>
              <td colspan="4" class="text-center">No History Found</td>
            </tr>
        @endif                        
      </tbody>

    </table>
  </div>
    <div class="showing_data">
        Showing you {{count($health_history)}} datas from your health history, stay health! <img src="{{ asset('images/smilies/raised-hand.png') }}" alt="icon">
    </div>
</div>
@if ($health_history->lastPage() > 1)
  <div class="widget_footer">
      @if ($health_history->hasPages())
        <ul class="pagination">
            {{-- Previous Page Link --}}
            @if ($health_history->onFirstPage())
                <li class="disable"><a href="javascript:;"><img src="{{ asset('images/left_page.svg') }}" alt="icon"></a></li>
            @else
                <li><a href="{{ $health_history->previousPageUrl() }}"><img src="{{ asset('images/left_page.svg') }}" alt="icon"></a></li>
            @endif
            {{-- Next Page Link --}}
            @if ($health_history->hasMorePages())
                <li><a href="{{ $health_history->nextPageUrl() }}"><img src="{{ asset('images/right_page.svg') }}" alt="icon"></a></li>        
            @else
                <li class="disable"><a href="javascript:;"><img src="{{ asset('images/right_page.svg') }}" alt="icon"></a></li>
            @endif
      </ul>@endif
  </div>
@endif