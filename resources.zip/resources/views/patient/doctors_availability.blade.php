@if(count($doctors_availability) > 0)
    @php           
        $count = 0;                                                     
        date_default_timezone_set($timezone);
    @endphp
        @foreach($doctors_availability as $key1=>$availability) 
    @php
           $doct_id=$availability['doctor_id'];
                        if(count($doc_appoint_listing) > 0){
                        $inc =0;
                            foreach($doc_appoint_listing as $doc_appoint){
                                if($doct_id == $doc_appoint['doctor_id']){
                                    if(date("H:i",strtotime($availability['availability_time'])) ==  date('H:i',$doc_appoint['appointment_time'])){
                                        $inc = 1;
                                    }
                                }
                            }
                            if($inc == 1){
    @endphp
                                <li>
                                <div class="time-button disabled-time">
                                    <input id="time{{$count}}" type="radio" name="doctor_apponitment_time{{($key+1)}}" class="form-check-custom appointment_time_sel time_set doctor_apponitment_time" value='{{$availability["availability_time"]}}' data-value='{{$availability["availability_time"]}}' data-doctor_id="{{ $doct_id }}" disabled>
                                    <p>{{$availability['availability_time']}}</p>
                                </div>
                                    <!-- <input id="time{{$count}}" type="radio" name="doctor_apponitment_time{{($key+1)}}" class="doctor_apponitment_time" value='{{$availability["availability_time"]}}' data-doctor_id="{{ $doct_id }}" disabled>
                                    <label for="time{{$count}}">{{$availability['availability_time']}}</label> -->
                                </li>
                                
    @php                             
                            }else{
     @endphp                        
                                <li>
                                <div class="time-button">
                                <input id="time{{$count}}" type="radio" name="doctor_apponitment_time{{($key+1)}}" class="form-check-custom appointment_time_sel time_set doctor_apponitment_time" value='{{$availability["availability_time"]}}' data-value='{{$availability["availability_time"]}}'  data-doctor_id="{{ $doct_id }}">
                                    <p>{{$availability['availability_time']}}</p>
                                    <!-- <input id="time{{$count}}" type="radio" name="doctor_apponitment_time{{($key+1)}}" class="doctor_apponitment_time" value='{{$availability["availability_time"]}}' data-doctor_id="{{ $doct_id }}">
                                    <label for="time{{$count}}">{{$availability['availability_time']}}</label> -->
                                </div>
                                </li>
    @php                            
                            }
                        }else{
    @endphp
                        <li>
                        <div class="time-button">
                        <input id="time{{$count}}" type="radio" name="doctor_apponitment_time{{($key+1)}}" class="form-check-custom appointment_time_sel time_set doctor_apponitment_time" value='{{$availability["availability_time"]}}' data-value='{{$availability["availability_time"]}}'  data-doctor_id="{{ $doct_id }}">
                                <p>{{$availability['availability_time']}}</p>
                            <!-- <input id="time{{$count}}" type="radio" name="doctor_apponitment_time{{($key+1)}}" class="doctor_apponitment_time" value='{{$availability["availability_time"]}}' data-doctor_id="{{ $doct_id }}">
                            <label for="time{{$count}}">{{$availability['availability_time']}}</label> -->
                        </div>
                        </li>   
   @php
                        }
                   
         $count++;        
    @endphp                                                             
        @endforeach
    @else
     <li>
        <span>No available time set by doctor yet</span>
        
    </li>
@endif                                                          
