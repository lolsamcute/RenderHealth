@extends('layouts.app')

@section('content')
<form class="form-signin" role="form" method="POST" action="" onsubmit="resetpassword(this); return false;">
    {{ csrf_field() }}
	<input type="hidden" name="FPtoken" class="FPtoken" value="<?php echo $FPtoken; ?>">
	<input type="hidden" name="user_id" class="user_id" value="<?php echo $user_id; ?>">
    <div class="text-center">
        <img class="mb-4" src="{{ asset('images/logo.svg') }}" alt="logo" width="94">
    </div>
    <h1>Change Password</h1>
    
    <div class="alert alert-danger-outline alert-dismissible alert_icon fade show error_msg" role="alert" style="display: none;">
        <div class="d-flex align-items-center">
            <div class="alert-icon-col">
                <span class="fa fa-warning"></span>
            </div>
            <div class="alert_text error_text">
                Email field is required
            </div>
            <a href="#" class="close alert_close" data-dismiss="alert" aria-label="close"><i class="fa fa-close"></i></a>
        </div>
    </div>

    <div class="form-group">
        <label>New Password</label>
        <div class="input-group">
            <div class="input-group-prepend">
                <span class="input-group-text"><img src="{{ asset('images/lock.svg') }}" alt="icon"></span>
            </div>
           <input type="password" class="form-control new_password" placeholder="New password" value="" name ="new_password" autocomplete="off">
        </div>
        <!-- <small class="invalid-feedback">Email field is required</small> -->
    </div>
    <div class="form-group">        
        <label>Confirm Password</label>
        <div class="input-group">
            <div class="input-group-prepend">
                <span class="input-group-text"><img src="{{ asset('images/lock.svg') }}" alt="icon"></span>
            </div>
            <input type="password" class="form-control confirm_new_password co_pass" placeholder="Confirm password" value="" name ="confirm_new_password" autocomplete="off">            
        </div>
    </div>
    <div class="row form-bottom">        
        <div class="col-sm-12 text-right">
            <button class="btn btn-primary updateBtn" type="submit">Submit</button>
        </div>
    </div>
</form>
<div class="login_footer">
    Don't have account?<a href="{{ url('patient/signup') }}">Get Started here</a>
</div>
@endsection           
