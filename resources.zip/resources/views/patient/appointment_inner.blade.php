<div class="widget_header mb-4">
    <h2>My Appointment</h2>
</div>
<div class="widget_body mb-3">
    <div class="table-responsive" style="max-height:500px;">
    <table class="table theme_table">
      <thead>
        <tr>
          <th scope="col">Hospital</th>
          <th scope="col">Doctor Name</th>
          <th scope="col">Date & Time</th>
          <th scope="col" class="text-center">Status</th>
        </tr>
      </thead>
      <tbody class="data_div">
      	@if(count($appointments) > 0)	                  		
      		@foreach($appointments as $appointment)	                  		
                <tr class="appointment_div cursor_pointer" data-id="{{ $appointment['booking_id'] }}" >
                  <td onclick="appointmentdetail(this); return false;">
                      <div class="center_type">
                          <h5>@if(!empty($appointment['hospital_id']))
                              {{ $appointment['hospital_detail']['hosp_name'] }}
                              @elseif($appointment['hospital_name'] != "") {{$appointment['hospital_name']}}
                              @else - @endif</h5>
                          @if($appointment['patient_appoint']['appointment_type'] == 1)
                          	<a class="hospital_appointment" href="javascript:;">Telemedical Appointment</a>
                          @else
                          	<a class="hospital_appointment" href="javascript:;">Hospital Appointment</a>
                          @endif
                      </div>
                  </td>
                  <td onclick="appointmentdetail(this); return false;">
                      <div class="table_profile_header">
                      	@if(isset($appointment['doctor_id']))
                        	<div class="tprofile_image">
                        @php
                        if(!empty($appointment['doctor_picture'])){
                        if(file_exists(getcwd().'/doctorimages/'.$appointment['doctor_picture'])){
                        @endphp
                        <img src="{{ asset('/doctorimages/'.basename($appointment['doctor_picture'])) }}" alt="image">
                        @php     }
                        else { @endphp
                        <img src="{{ asset('admin/doctor/images/doc1.png') }}" alt="image">
                        @php   }
                        }
                        else { @endphp
                        <img src="{{ asset('admin/doctor/images/doc1.png') }}" alt="image">
                        @php   }
                        @endphp
                        	</div>
                        	<div class="tprofile_text">			                            	
                                <h3>Dr., {{ $appointment['doctor']['doctor_first_name']}} {{ $appointment['doctor']['doctor_last_name']}}</h3>
                                <p>{{ $appointment['doctor']['specialist_categories']['speciality_name']}}</p>				                            
                        	</div>
                        @else
                        	<div class="tprofile_text">	                   	
                                <h3>Not available</h3>				                            
                        	</div>
                        @endif
                    </div>
                  </td>
                  <td onclick="appointmentdetail(this); return false;"> 
                      <div class="appointment_time">
                          @php date_default_timezone_set($timezone); @endphp
                          <h5>{{ date('j F,Y',$appointment['appointment_time']) }} </h5>
                          <p>at {{ date('h:i A',$appointment['appointment_time']) }}</p>
                      </div>
                  </td>
                  <td class="text-center">
                  	 @if(date('Y-m-d H:i',$appointment['appointment_time']) <= date('Y-m-d H:i',strtotime('-15 min')))
              <a class="btn btn-danger no_caret btn-xs dropdown-toggle disabled_cancel" href="javascript:;" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" >
              Cancel
              </a>
              @else
              <a class="btn btn-danger no_caret btn-xs dropdown-toggle" href="javascript:;" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
              Cancel
              </a>
              @endif
              <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdown">
              <div class="sure">
              <h5>Are you sure want to cancel the appointment?</h5>
              <button type="button" class="btn btn-light btn-xs mr-2" onclick="cancelBooking(this); return false;"  data-patient_id="{{$appointment['patient_id']}}" data-booking_id="{{$appointment['booking_id']}}"  data-doctor_id="{{$appointment['doctor_id']}}">Yes, I am Sure</button>
              <button type="button" class="btn btn-blue btn-xs mr-2 reschedule_book" data-appoint_date="{{ date('Y-m-d' ,$appointment['appointment_time']) }}" data-appoint_time="{{ date('h:i A' ,$appointment['appointment_time']) }}" data-booking_id="{{$appointment['booking_id']}}" onclick="resheduleBooking(this); return false;">Reschedule</button>
              </div>
              </div>
                  </td>
                </tr>
             @endforeach
             @else
             	<tr><td colspan="4" class="text-center">No appointments Found</td></tr>
        @endif			                    
      </tbody>
    </table>
  </div>
</div>
<div class="widget_footer">
	@if($appointments->total() > $appointments->perPage())            		
        {{ $appointments->links() }}
    @endif
</div>