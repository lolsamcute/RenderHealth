@extends('layouts.patient')
@section('content')
<main class="col-12 col-md-12 col-xl-12 bd-content">
  <div class="row">
    <div class="col-12">
      <div class="widget">
        <div class="widget_header widget_flex_header mb-4">
          <h2 class="mb-0">Inv. {{$billing_detail['invoice_number']}}</h2>
            <div class="d-flex">
                <a href="{{url('patient/download_pdf/'.$billing_detail['billing_id'])}}" class="btn btn-iconed btn-black mr-3 dispute_bill">
                  <img src="{{asset('admin/doctor/images/down_ic.svg')}}" alt="icon">DOWNLOAD PDF
                </a>
              @if($billing_detail['payable_amount'] - $billing_detail['paid_amount'] > 0)   
                 <button class="btn btn-primary pay_bill" onclick="selectpaytype(event)">PAY BILL</button> 
                 <div class="radio_div" style="display: none;">
     
                  <label class="radio-inline"><input type="radio" name="pay_by" value="1" onclick="getselectedvalue(event)">Pay by Cash</label>
                 
              
                  <label class="radio-inline"><input type="radio" name="pay_by" value="2" onclick="getselectedvalue(event)">Pay by Card</label>
                
                  </div>    
                  <div class="cash_input" style="display:none;">
                  <div id="myModal" class="modal fade" role="dialog">
                  <div class="modal-dialog modal-md modal-dialog-centered genmodal genmodal_custom custom_width1">

                  <!-- Modal content-->
                  <div class="modal-content">
                  <div class="modal-header">
                  <?php  $amount=$billing_detail['payable_amount'] - $billing_detail['paid_amount'];?>
                  <p>Amount to pay: ₦ {{$amount}}</p>
                  <button type="button" class="close" data-dismiss="modal" onclick="getpaypopup();" >&times;</button>    
                  </div>
                  <div class="modal-body">
                  <div class="row">
                  <div class="col-sm-6">
                  <div class="form-group">
                  <label>Enter Amount to pay by cash</label> 

                  <input type="number" name="pay_amount" value="{{$billing_detail['payable_amount'] - $billing_detail['paid_amount']}}"  max="{{$billing_detail['payable_amount'] - $billing_detail['paid_amount']}}" class="form-control"  onkeydown="limitmax(event,<?php echo $amount;?>);"  onkeyup="limitmax(event,<?php echo $amount;?>);" id="pay_amount">                     
                      </div>
                      </div>
                      </div> 
                       <div class="row">
                      <div class="col-sm-6">
                      <div class="form-group">
                       <button class="btn btn-primary pay_bill"  data-bill_id="{{ $billing_detail['billing_id'] }}" data-doc_id="{{ $billing_detail->doctor->doctor_id }}" data-pt_id="{{ $billing_detail['patient_id'] }}" onclick="paybycash(this)">PAY BILL</button>      
                       </div>
                       </div>
                       </div>           
                  </div>
                  </div>
                  </div>
                   </div> 
                 </div>
                <button class="btn btn-primary pay_bill" id="pay_bill_popup" style="display:none;" onclick="payWithPaystack(this);" data-amt="{{$billing_detail['payable_amount'] - $billing_detail['paid_amount']}}" data-doc_id="{{ $billing_detail->doctor->doctor_id }}" data-pt_id="{{ $billing_detail['patient_id'] }}" data-bill_id="{{ $billing_detail['billing_id'] }}">PAY BILL</button>
              @else
                <button type="button" class="btn btn-primary button_approved disabled">Paid</button>
              @endif
            </div>
        </div>
        <div class="row">
          <div class="col-12">
            <div class="widget_body mb-4">
              <div class="invoice genModal">
                <div class="billing_person_data">
                  <div class="bill_person_data">
                    {{ csrf_field() }}
                    Summary : <span>₦ {{$billing_detail['payable_amount'] - $billing_detail['paid_amount']}}</span>
                  </div>
                  <div class="separator"></div>
                  <div class="bill_person_data">
                      Paid : <span>₦ {{$billing_detail['paid_amount']}}</span>
                  </div>
                  <div class="separator"></div>
                    <div class="bill_person_data">
                      Total Amount : <span>₦ {{$billing_detail['payable_amount']}}</span>
                    </div>
                </div>
                <h3>Details of Services</h3>
                @if(count($billing_detail['billing_service']) > 0)
                  <table class="modal_table table table-bordered mb-4">
                    <thead>
                      <tr>
                        <th>Date</th>
                        <th>Kind of Services</th>
                        <th>Amount</th>
                      </tr>
                    </thead>
                    @php $sub_total = 0; @endphp
                    <tbody>                    
                        @foreach($billing_detail['billing_service'] as $billing_service)
                          <tr>
                            <td>{{ date('d/m/Y',$billing_service['service_date'])}}</td>
                            <td>{{ $billing_service['service_name'] }}</td>
                            <td>₦ {{ $billing_service['service_amount'] }}</td>
                          </tr>
                          @php $sub_total = $sub_total+ $billing_service['service_amount']; @endphp
                        @endforeach
                        <tr class="table_total">
                          <td colspan="2">Sub Total Amount</td>
                          <td>₦ {{ $sub_total }}</td>
                        </tr>                                       
                  </tbody>
                </table>
              @endif
              <h3>Details of Medicines</h3>
              <table class="modal_table table table-bordered mb-4">
                <thead>
                  <tr>
                      <th>Date</th>
                      <th>Kind of Services</th>
                      <th>Type</th>
                      <th>Qty</th>
                      <th>Amount</th>
                  </tr>
                </thead>
                <tbody>
                  <tr>
                    <td>12/02/2018</td>
                      <td>Omeprazol Meds 50mg</td>
                      <td>Capsule</td>
                      <td>10</td>
                      <td>₦ 10,000</td>
                  </tr>
                  <tr>
                      <td>13/02/2018</td>
                      <td>Penicilin</td>
                      <td>Syrup</td>
                      <td>5</td>
                      <td>₦ 10,000</td>
                  </tr>
                  <tr class="table_total">
                      <td colspan="4">Sub Total Amount</td>
                      <td>₦ 20,000</td>
                  </tr>
                </tbody>
              </table>
              <div class="billing_person">
                <div class="bill_person">
                  <h6>Hospital Details</h6>
                    <h3>{{ $billing_detail['doctor']['doctor_hospital_details']['hosp_name'] }}</h3>
                    <h5>{{ $billing_detail['doctor']['doctor_hospital_details']['hosp_address'] }}</h5>
                </div>
                <div class="separator"></div>
                <div class="bill_person">
                    <h6>Invoice Number</h6>
                    <h3>{{$billing_detail['invoice_number']}}</h3>
                    <h5>Created : {{ date('j F, Y',$billing_detail['billing_date'])}}</h5>
                </div>
                <div class="separator"></div>
                <div class="bill_person">
                  <h6>Doctor’s Name</h6>
                  <h3>Dr. {{ $billing_detail['doctor']['doctor_first_name'] }} {{ $billing_detail['doctor']['doctor_last_name'] }}</h3>
                  <h5>{{ $billing_detail['doctor']['specialist_categories']['speciality_name'] }}</h5>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
</main>

<div class="modal fade" id="paybill">
  <div class="modal-dialog modal-md-575 modal-dialog-centered genModal">
    <div class="modal-content">
      <div class="modal-header">
          <h4 class="modal-title">Pay Invoice 110/13022018/009</h4>
          <button type="button" class="close mclose" data-dismiss="modal"><img src="{{asset('admin/doctor/images/cross_modal.svg')}}"/></button>
      </div>
      <div class="modal-body">
        <h3 class="mb-1">General Notes</h3>
      <div class="d-flex mb-2">
        <p class="pr-5 pb-0">Safe money transfer using your bank account. Visa, master card are compatible with our payment process.
        </p>
      <div class="d-flex">
          <img class="mr-2" src="{{asset('admin/doctor/images/visa.svg')}}" alt="image">
          <img src="{{asset('admin/doctor/images/mastercard.svg')}}" alt="image">
      </div>
      </div>
      <form>
        <div class="form-group">
            <label>Credit Card Number</label>
            <input class="form-control valid_card" value="" type="text">
        </div>
        <div class="row">
            <div class="col-6">
              <div class="form-group">
                <label>CVV Code</label>
                  <input class="form-control cvv" value="" type="text">
              </div>
            </div>
            <div class="col-6">
              <div class="form-group">
                <label>Expired Date</label>
                  <div class="row position-relative">
                    <div class="col-6">
                      <input class="form-control" value="" type="text" placeholder="Month">
                    </div>
                    <span class="hash">/</span>
                    <div class="col-6">
                      <input class="form-control" value="" type="text" placeholder="Year">
                    </div>
                  </div>
              </div>
            </div>
        </div>
        <div class="form-group mb-4">
          <label>Name On Card</label>
            <input class="form-control" value="" type="text">
        </div>
        <div class="genModalfooter">
          <button type="button" data-dismiss="modal" class="btn btn-danger mt-3">CANCEL</button>
          <button type="submit" class="btn btn-primary mt-3">PROCESS PAYMENT</button>
        </div>
      </form>
      </div>
    </div>
  </div>
</div>
@endsection