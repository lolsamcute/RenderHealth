<div class="modal-header">
     @php date_default_timezone_set($timezone); @endphp
    <h4 class="modal-title">{{ date('j F Y', $diary_detail[0]['created_date'])}}, {{ date('h:i A', $diary_detail[0]['created_date'])}}</h4>
    <button type="button" class="close mclose" data-dismiss="modal"><img src="{{asset('admin/doctor/images/cross_modal.svg')}}"/></button>
 </div>
<div class="modal-body modal-body-overflow">
    <div class="health_diary_view">
        @php $feeling_pic = ['admin/doctor/images/smilies/no_pain@2x.png','admin/doctor/images/smilies/mild@2x.png','admin/doctor/images/smilies/moderate@2x.png','admin/doctor/images/smilies/severe@2x.png','admin/doctor/images/smilies/very_severe@2x.png','admin/doctor/images/smilies/worst_pain@2x.png','admin/doctor/images/smilies/moderate@2x.png'];  @endphp
        <div class="diary_emoji"><img src="{{asset($feeling_pic[$diary_detail[0]['feeling_details']])}}" alt="icon"></div>
        <div class="diary_desc">
            <div class="diary_desc_step mb-4">
                @php
                    $feeling = ['Feeling No Pain','Feeling Mild Pain','Feeling Moderate Pain','Feeling Severe Pain','Feeling Very Severe Pain','Feeling Worst Pain',$diary_detail[0]->describe_feeling_other];                                                        
                @endphp 
                <h2>{{ $feeling[$diary_detail[0]['feeling_details']] }}</h2>
                <p>{{ $diary_detail[0]['symptom_details'] }}</p>
            </div>
            @if(!empty($diary_detail[0]['medication_details']))
                <div class="phd_detail_type mb-4">
                    <h5>Medications :</h5>
                    <h4>{{ $diary_detail[0]['medication_details'] }}</h4>
                </div>
            @else
                <div class="phd_detail_type mb-4">
                    <h5>Medications :</h5>
                    <h4>No Medication</h4>
                </div>
            @endif
            @if(isset($diary_detail[0]['diary_attachment']) && count($diary_detail[0]['diary_attachment']) > 0)
                <div class="phd_detail_type">
                    <h5>Attachment Image</h5>
                    <div class="phd_detail_attached">                   
                            @foreach($diary_detail[0]['diary_attachment'] as $attachment)
                                <img src="{{asset($attachment['attachment_path'])}}" alt="image">
                            @endforeach                                           
                    </div>
                </div>
            @else
               <div class="phd_detail_type">
                    <h5>Attachment Image</h5>
                    <div class="phd_detail_attached">                   
                            <p>No Attachments Attached</p>                                       
                    </div>
                </div>
            @endif 
        </div>
    </div>
    <div class="genModalfooter">
        <button type="button" class="btn btn-iconed  btn-min-width-auto btn-danger" name="button" data-id="{{ $diary_detail[0]['diary_id'] }}" onclick="deletehealthdiary(this); return false;">
            <img src="{{asset('admin/doctor/images/delete.svg')}}" alt="icon"> DELETE
        </button>
        <button type="button" class="btn btn-iconed btn-min-width-auto btn-black" name="button" data-id="{{ $diary_detail[0]['diary_id'] }}" onclick="edithealthdiary(this); return false;">
            <img src="{{asset('admin/doctor/images/edit.svg')}}" alt="icon">EDIT INFO
        </button>
    </div>
</div>