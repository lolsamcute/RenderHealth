<p>Hello Sir/Ma'm</p>
<p>Please find below the attachments of  Medical Record for patient {{$patient_name}}.</p>



<p>Thanks<p>
<p>RenderHealth</p>