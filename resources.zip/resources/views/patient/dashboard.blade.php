@extends('layouts.patient_fluid')

@section('content')
<main class="col-12 col-md-12 col-xl-12 bd-content">
    <div class="row">
        <div class="col-12 col-xl-3">
            <div class="widget">
                <div class="widget_header">
                    <h3>My Profile</h3>
                    <div class="btn-group">
                        <div class="dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                            <img src="{{ asset('images/options.svg') }}" alt="options"/>
                        </div>
                        <div class="dropdown-menu dropdown-menu-right">
                            <a class="dropdown-item" href="{{ url('/patient/my_profile') }}">View my profile</a>
                            <a class="dropdown-item" href="{{ url('/patient/settings') }}">Edit my profile</a>
                            <!-- <a class="dropdown-item" href="javascript:;">Share</a> -->
                        </div>
                    </div>
                </div>
                <div class="widget_body widget_profile">
                    <div class="widget_profile_header">
                        <div class="wprofile_image">
                      
                            @if((file_exists(getcwd().'/uploads/patient/'.$patient_detail->patient_profile_img)) && !empty($patient_detail->patient_profile_img))                            
                                 <img src="{{asset('uploads/patient/'.$patient_detail->patient_profile_img)}}" alt="image">
                            @else
                                <img id="uploadPreview" src="{{ asset('images/profile.svg') }}" alt="image">                               
                            @endif
                        </div>
                        <div class="wprofile_text">
                            <h3>@if($patient_detail->patient_gender == 1)
                                  @if($patient_detail->patient_martial_status == 1)
                                    {{ 'Mrs.' }}
                                  @else
                                    {{ 'Miss' }}
                                  @endif
                              @else
                                {{ 'Mr.'}}
                              @endif
                              {{$patient_detail->patient_first_name}} {{$patient_detail->patient_last_name}}</h3>
                            <p>@php
                                if(!empty($patient_detail->patient_date_of_birth)){
                                $date = $patient_detail->patient_date_of_birth;
                                $databasedate = date("Y-m-d",$date);
                                $current_date = date("Y-m-d");
                                $diff = abs(strtotime($current_date) - strtotime($databasedate));
                                $years = floor($diff / (365*60*60*24));
                                $months = floor(($diff - $years * 365*60*60*24) / (30*60*60*24));
                                $days = floor(($diff - $years * 365*60*60*24 - $months*30*60*60*24)/ (60*60*24));
                                printf("%d", $years);
                                echo "y/o,"; }
                            @endphp @if($patient_detail->patient_gender == 0) Male @else Female @endif</p>
                        </div>
                    </div>
                    <div class="widget_profile_desc">
                        <ul>
                            <li>
                                <span>
                                    <img src="{{ asset('images/location.svg') }}" alt="icon">
                                </span>
                                @if(!empty($patient_detail->patient_address))
                                  <p>{{ucfirst($patient_detail->patient_address)}}</p>
                                @else
                                  <p>-</p>
                                @endif
                            </li>
                            <li>
                                <span>
                                    <img src="{{ asset('images/gender.svg') }}" alt="icon">
                                </span>
                                <p>@if($patient_detail->patient_martial_status == 0) Single @elseif($patient_detail->patient_martial_status == 1)Married @else - @endif</p>
                            </li>
                            <li>
                                <span>
                                    <img src="{{ asset('images/mic.svg') }}" alt="icon">
                                </span>
                                @if(!empty($patient_detail->patient_languages))
                                  <p>{{join(',', array_map('ucfirst', explode(',', $patient_detail->patient_languages)))}}</p>
                                @else
                                  <p>-</p>
                                @endif
                                
                            </li>
                            <li>
                                <span>
                                    <img src="{{ asset('images/bday.svg') }}" alt="icon">
                                </span>
                                @if(!empty($patient_detail->patient_date_of_birth))
                                  <p>{{ date("dS M Y", $patient_detail->patient_date_of_birth) }} (Birthday)</p>
                                @else
                                  <p>-</p>
                                @endif
                                
                            </li>
                        </ul>
                    </div>
                    <div class="widget_profile_footer">
                        <ul>
                            <li>
                                <h5>Blood Type :</h5>
                                @if(!empty($patient_detail->patient_blood_type))
                                  <h4>{{$patient_detail->patient_blood_type}}</h4>
                                @else
                                  <h4>-</h4>
                                @endif
                                
                            </li>
                            <li>
                                <h5>State Of Origin :</h5>
                                @if(!empty($patient_detail->patient_origin_state))
                                  <h4>{{ucfirst($patient_detail->patient_origin_state)}}</h4>
                                @else
                                  <h4>-</h4>
                                @endif
                                
                            </li>
                            <li>
                                <h5>Insurance :</h5>
                                @if(!empty($patient_detail->patient_insurance))
                                  <h4>{{ucfirst($patient_detail->patient_insurance)}}</h4>
                                @else
                                  <h4>-</h4>
                                @endif                                
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
            <div class="widget">
                <div class="widget_body">
                    <a class="widget_link teleconslt_href" href="javascript:;" onclick="blockPopupFn()">
                        <div class="widget_link_icon">
                            <img src="{{ asset('images/appoint.svg') }}" alt="icon">
                        </div>
                        <div class="widget_link_text">
                            <h4>Schedule Telelconsultation Appointment</h4>
                            <!-- <p>Set schedule to make appointment with doctor.</p> -->
                        </div>
                    </a>
                    <!-- <a class="widget_link teleconslt_href" href="javascript:;" data-toggle="modal" data-target="#Telelconsultation">
                        <div class="widget_link_icon">
                            <img src="{{ asset('images/appoint.svg') }}" alt="icon">
                        </div>
                        <div class="widget_link_text">
                            <h4>Schedule Telelconsultation Appointment</h4>
                            <p>Set schedule to make appointment with doctor.</p> 
                        </div>
                    </a> -->
                </div>
            </div>
            <div class="widget">
                <div class="widget_body">
                    <a class="widget_link" href="{{ url('patient/appointment')}}">
                        <div class="widget_link_icon">
                            <img src="{{ asset('images/hospital.svg') }}" alt="icon">
                        </div>
                        <div class="widget_link_text">
                            <h4>Schedule Hospital Appointment</h4>
                            <!-- <p>Set schedule to make appointment with doctor.</p> -->
                        </div>
                    </a>
                </div>
            </div>
            <div class="widget">
                <div class="widget_body">
                    <a class="widget_link" href="{{url('/patient/add_new_diary')}}">
                        <div class="widget_link_icon">
                            <img src="{{ asset('images/red_heart.svg') }}" alt="icon">
                        </div>
                        <div class="widget_link_text">
                            <h4>Add New Health Diary</h4>
                            <!-- <p>Set schedule to make appointment with doctor.</p> -->
                        </div>
                    </a>
                </div>
            </div>
        </div>
        <div class="col-12 col-xl-9">
            <div class="widget">
                <div class="widget_header">
                    <h3>Current Appointments</h3>
                </div>
                <div class="widget_body">
                    <table class="table theme_table">
                      <thead>
                        <tr>
                          <th scope="col">Hospital</th>
                          <th scope="col">Doctor Name</th>
                          <th scope="col">Date & Time</th>
                          <th scope="col" class="text-center"></th>
                        </tr>
                      </thead>
                      <tbody>
                        @if(count($appoint_listing) > 0)                       
                          @foreach($appoint_listing as $appointment)  
                            <tr class="appointment_div cursor_pointer" data-id="{{ $appointment['booking_id'] }}" >
                              <td onclick="appointmentdetail(this); return false;">
                                  <div class="center_type">
                                      <h5>@if(!empty($appointment['hospital_id']))
                                      {{ $appointment['hospital_detail']['hosp_name'] }}
                                      @elseif($appointment['hospital_name'] != "") {{$appointment['hospital_name']}}
                                      @else - @endif</h5>
                                      @if($appointment['patient_appoint']['appointment_type'] == 1)
                                        <a class="hospital_appointment" href="javascript:;">Hospital Appointment</a>
                                      @else
                                        <a class="hospital_appointment" href="javascript:;">Hospital Appointment</a>
                                      @endif
                                  </div>
                              </td>
                              <td onclick="appointmentdetail(this); return false;">
                                  <div class="table_profile_header">
                                    <div class="tprofile_image">
                                    
                                      @php 
                                    if(isset($appointment['doctor'])){
                                      if((file_exists(getcwd().'/doctorimages/'.$appointment['doctor']['doctor_picture'])) && (!empty($appointment['doctor']['doctor_picture']))){
                                      @endphp
                                      <img src="{{ asset('/doctorimages/'.$appointment['doctor']['doctor_picture']) }}" alt="image">
                                      @php     }
                                      else { @endphp
                                      <img src="{{ asset('images/profile.svg') }}" alt="image">
                                      @php   } }@endphp

                                    </div>
                                    <div class="tprofile_text">
                                       @if(!empty($appointment['doctor']['doctor_first_name']))
                                        <h3>Dr. {{ $appointment['doctor']['doctor_first_name']}} {{ $appointment['doctor']['doctor_last_name']}}</h3>
                                        @endif
                                  @if(isset($appointment->doctor))
                                <p>{{ $appointment->doctor->specialist_categories['speciality_name']}}</p>
                                @else
                                <p>Not avaliable</p>
@endif
                                        <!--p>{{ $appointment['doctor']['specialist_categories']['speciality_name']}}</p-->
                                        
                                    </div>
                                </div>
                              </td>
                              <td onclick="appointmentdetail(this); return false;">
                                  <div class="appointment_time">
                                      @php date_default_timezone_set($timezone); @endphp
                                      <h5>{{ date('j F,Y',$appointment['appointment_time']) }} </h5>
                                      <p>at {{ date('h:i A',$appointment['appointment_time']) }}</p>
                                  </div>
                              </td>
                              <td class="text-center">
                              
                  @if(date('Y-m-d H:i',$appointment['appointment_time']) <= date('Y-m-d H:i',strtotime('-15 min')))
                  <a class="btn btn-danger no_caret btn-xs dropdown-toggle disabled_cancel" href="javascript:;" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" >
                  Cancel
                  </a>
                  @else
                  <a class="btn btn-danger no_caret btn-xs dropdown-toggle" href="javascript:;" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                  Cancel
                  </a>
                  @endif
                  <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdown">
                  <div class="sure">
                    <h5>Are you sure want to cancel the appointment?</h5>
                    <button type="button" class="btn btn-light btn-xs mr-2" onclick="cancelBooking(this); return false;"  data-patient_id="{{$appointment['patient_id']}}" data-booking_id="{{$appointment['booking_id']}}"  data-doctor_id="{{$appointment['doctor_id']}}">Yes, I am Sure</button>
                    <button type="button" class="btn btn-blue btn-xs mr-2 reschedule_book" data-appoint_date="{{ date('Y-m-d' ,$appointment['appointment_time']) }}" data-appoint_time="{{ date('h:i A' ,$appointment['appointment_time']) }}" data-booking_id="{{$appointment['booking_id']}}" onclick="resheduleBooking(this); return false;">Reschedule</button>
                  </div>
                </div>
                                 <!--  <button type="button" class="button_sm button_approved">Approved</button> -->
                              </td>
                            </tr>
                          @endforeach
                            @else
                              <tr ><td colspan="4" class="text-center">No appointments Found</td></tr>
                        @endif                        
                      </tbody>
                      @if($appoint_count > 0)
                        <tfoot>
                            <tr>
                                <td colspan="4" class="text-center">
                                    <div class="tfooter">                                    
                                        <img src="{{ asset('images/calender.svg') }}" alt="icon">There @if($appoint_count>1)are @else is @endif {{ $appoint_count }} Appointment ahead.<a href="{{ url('patient/my_appointments')}}">View All</a>
                                    </div>
                                </td>
                            </tr>
                        </tfoot>
                      @endif
                    </table>
                </div>
            </div>
            <div class="widget">
                <div class="widget_header">
                    <h3>Health History</h3>
                </div>
                <div class="widget_body">
                    <table class="table theme_table">
                      <thead>
                        <tr>
                          <th scope="col">Hospital</th>
                          <th scope="col">Doctor Name</th>
                          <th scope="col">Date & Time</th>
                          <th scope="col" class="text-center">Attachment</th>
                        </tr>
                      </thead>
                      <tbody>

                        @if(count($health_history) >0)
                            @foreach($health_history as $health_hist)
                              <tr class="history_div cursor_pointer" data-id="{{ $health_hist->history_id }}" onclick="historydetail(this); return false;">
                                <td>
                                    <div class="center_type">
                                      @if(isset($health_hist->doctor->doctor_hospital_details))
                                        <h5>{{ $health_hist->doctor->doctor_hospital_details->hosp_name }}</h5>
                                        @endif
                                        <a class="hospital_appointment" href="javascript:;">Hospital Appointment</a>
                                    </div>
                                </td>
                                <td>
                                    <div class="table_profile_header">
                                      <div class="tprofile_image">
                                        @php 
                                  if(isset($health_hist->doctor)){
                                        if((file_exists(getcwd().'/doctorimages/'.$health_hist->doctor->doctor_picture)) && (!empty($health_hist->doctor->doctor_picture))){
                                      @endphp
                                      <img src="{{ asset('/doctorimages/'.$health_hist->doctor->doctor_picture) }}" alt="image">
                                      @php     }
                                      else { @endphp
                                      <img src="{{ asset('images/profile.svg') }}" alt="image">
                                      @php   }
                                    }
                                    else{@endphp
                                     <img src="{{ asset('images/profile.svg') }}" alt="image">
                                 @php }

                                       @endphp

                                         
                                      </div>
                                      <div class="tprofile_text">
                                          <h3>Dr.
                                      @if(isset($health_hist->doctor))
                                      {{ $health_hist->doctor->doctor_first_name }} {{ $health_hist->doctor->doctor_last_name }}, {{ $health_hist->doctor->doctor_degree }}</h3>

                                          <p>{{ $health_hist->doctor->specialist_categories['speciality_name'] }}</p>
                                            @endif
                                      </div>
                                  </div>
                                </td>
                                <td>
                                    <div class="appointment_time">
                                        <h5>{{ date('D', $health_hist->created_date) }}, {{ date('j M Y', $health_hist->created_date) }}</h5>
                                     </div>
                                </td>
                                <td class="text-center">
                                    <div class="attachment">
                                        <img src="{{ asset('images/attachment.svg') }}" alt="icon">
                                        @php $i=0; @endphp
                                    @foreach($health_hist['history_attachments'] as $history_attachments) 
                                    @if($history_attachments->type == 2)
                                  @php $i++;@endphp
                                   @endif
                                    @endforeach


                                        {{ $i }} Files
                                    </div>
                                </td>
                              </tr>
                            @endforeach
                          @else
                              <tr><td colspan="4" class="text-center">No Health History Found</td></tr>
                          @endif                       
                      </tbody>
                      @if(count($health_history) >0)
                        <tfoot>
                            <tr>
                                <td colspan="4" class="text-center">
                                    <div class="tfooter">
                                        <!-- <img src="{{ asset('images/list.png') }}" alt="icon"><a class="ml-0" href="{{ url('patient/health_history_list')}}">View All Health History</a> -->
                                        <img src="{{ asset('images/list.png') }}" alt="icon"><a class="ml-0" href="javascript:void(0)" onclick="blockPopupFn()">View All Health History</a>
                                    </div>
                                </td>
                            </tr>
                        </tfoot>
                      @endif
                    </table>
                </div>
            </div>
        </div>
    </div>
</main>
<!-- Schedule Telelconsultation Appointment Modal -->
<div class="modal fade" id="Telelconsultation">
    <div class="modal-dialog modal-md modal-dialog-centered genModal">
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title">Schedule Telelconsultation Appointment</h4>
                <button type="button" class="close mclose" data-dismiss="modal"><img src="{{ asset('images/cross_modal.svg') }}"/></button>
             </div>
            <div class="modal-body">
                <!-- <div class="consultation py-5 first_step" >
                    <div class=" col-sm-12">
                        <img src="{{ asset('images/video_consult.svg') }}" alt="icon">
                        <h5 class="mb-3">Video Consultation</h5>
           
                        <button type="button" class="btn btn-black btn-sm text-capitalize consult_btn" name="button" data-id="Video">Use Video Call</button>
                    </div>
                    <div class="consult_type w-50" style="display: none;">
                        <img src="{{ asset('images/audio_consult.svg') }}" alt="icon">
                        <h5 class="mb-3">Audio Consultation</h5>
                
                        <button type="button" class="btn btn-black btn-sm text-capitalize consult_btn" name="button"  data-id="Audio">Use Phone Call</button>
                    </div>
                </div>   -->            

                <div class="consultation py-3 second_step">
                    <div class="video_consult_detail">
                    	 {{ csrf_field() }}
                        <img src="{{ asset('images/video_consult.svg') }}" alt="icon">
                        <h5 class="second_head mb-3">Video Consultation</h5>
                        <input type="hidden" class="second_text" value="Video">
                       <!--  <p>You can make conversation use our <span class="second_text">Video</span> call API</p>    -->                     
                        <div class="form-group">
                            <div class="alert alert-danger-outline alert-dismissible alert_icon fade show error_msg select_fxwidth mb-3 text-left" id="error_msg" role="alert" style="display:none;">
                                <div class="d-flex align-items-center">
                                    <div class="alert-icon-col">
                                        <span class="fa fa-warning"></span>
                                    </div>
                                    <div class="alert_text error_text">
                                        Email field is required
                                    </div>
                                    <a href="#" class="close alert_close" data-dismiss="alert" aria-label="close"><i class="fa fa-close"></i></a>
                                </div>
                            </div>
                             <div class="select_box select_fxwidth mb-2">
                                 <select class="form-control consult_type1" name="consult_type" onchange="disableoption(this)">
                                     <option value="1">General Consultation</option>
                                     <option value="2">Speciality Consultation</option>                                     
                                 </select>
                             </div>
                             <div class="select_box select_fxwidth">
                                 <select class="form-control consult_time" name="consult_time">
                                     <option value="1" data-id="1">Immediate Appointment</option>
                                     <option value="2" data-id="2">Future Appointment</option>                                     
                                 </select>
                             </div>
                        </div>
                        <button type="button" class="btn btn-primary find_doctor" name="button" onclick="savetelemedicaldetails(this); return false;">Find Doctor</button>
                    </div>
                </div>
                <div class="consultation py-3 third_step"  style="display:none;">
                    <div class="video_consult_detail consult_datepicker">
                        <div class="picker">
                            <div class="datepicker_input mb-4 tele_appoint" data-date="{{ date('d F Y') }}" data-date-format="dd-mm-yyyy"></div>
                        </div>
                        <button type="button" class="btn btn-primary appointment_next" name="button" data-appoint_id="" data-consult_type="" onclick="appointemntnext(this); return false;">Next</button>
                     </div>

                </div>

            </div>
        </div>
    </div>
</div>
<!-- reschedule screen -->
<div class="modal fade" id="reschedule_appointment" data-backdrop="static" data-keyboard="false">
    <div class="modal-dialog modal-md modal-dialog-centered genmodal genmodal_custom custom_width2">
        <div class="modal-content">
            <div class="modal-header">
                <h3>Reschedule Appointment</h3>
                <button type="button" class="close" data-dismiss="modal"><img src="{{ asset('admin/doctor/images/popup_close.svg') }}"/></button>
            </div>
            <div class="modal-body reshedule_detail">                
            </div>
        </div>
    </div>
</div>
@endsection