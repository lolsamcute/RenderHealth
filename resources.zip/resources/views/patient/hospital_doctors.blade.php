@if(isset($hospital_doctors) && count($hospital_doctors) > 0)
    <div id="accordion" class="widget_doctor">    
        @php $count =0; @endphp
        @foreach($hospital_doctors as $key=>$hospital_doctor)
            <div class="widget_body doctor_exists_main mb-3" data-doct_id="{{ $hospital_doctor['doctor_id'] }}">
                <div class="widget_doctor_list" id="heading{{($key+1)}}">
                    <button class="widget_doctor_list_button collapsed doctor_expand" data-toggle="collapse" data-target="#collapse{{($key+1)}}" aria-expanded="true" aria-controls="collapse{{($key+1)}}">
                       <img src="{{ asset('images/open.svg') }}" alt="open">
                       <img src="{{ asset('images/close.svg') }}" alt="close">
                    </button>
                    <div class="doctor_list">
                        <div class="doc_detail">
                            <div class="doc_data_outer">
                                <div class="doc_name">
                                    <div class="doc_img">
                                        @php if(file_exists(getcwd().'/doctorimages/'.basename($hospital_doctor['doctor_picture'])) && !empty($hospital_doctor['doctor_picture'])){
                                        @endphp
                                                        <img src="{{ asset('/doctorimages/'.basename($hospital_doctor['doctor_picture'])) }}" alt="image">
                                                @php     }
                                                     else { @endphp
                                                           <img src="{{ asset('admin/doctor/images/doc1.png') }}" alt="image">
                                                  @php   } @endphp
                                                         
                                    </div>
                                    <div class="doc_desc">
                                        <h5>Dr. {{ $hospital_doctor['doctor_first_name'] }} {{ $hospital_doctor['doctor_last_name'] }}, {{ $hospital_doctor['doctor_degree'] }}</h5>
                                        <a href="javascript:;">{{ $hospital_doctor['specialist_categories']['speciality_name'] }} </a>
                                        
                                    </div>
                                </div>
                                <div class="doc_experience">
                                    <img src="{{ asset('images/briefcase.svg') }}" alt="icon">Praticing for {{ $hospital_doctor['doctor_years_practised'] }} years
                                </div>
                            </div>
                            <div class="doc_other_outer">
                                <div class="doc_other">
                                    <h6>Languages</h6>
                                    <h4>{{ $hospital_doctor['doctor_languages'] }}</h4>
                                </div>
                                <div class="doc_other">
                                    <h6>Education</h6>
                                    <h4>{{ $hospital_doctor['doctor_education_school'] }}</h4>
                                </div>
                            </div>
                            <div class="doc_other_outer">
                                <div class="doc_other">
                                    <h6>Religion</h6>
                                    <h4>{{ $hospital_doctor['doctor_religion'] }}</h4>
                                </div>
                                <div class="doc_other">
                                    <h6>Ethnicity</h6>
                                    <h4>{{ $hospital_doctor['doctor_ethnicity'] }}</h4>
                                </div>
                            </div>
                        </div>

                        <div class="doc_brief">
                          @if(!empty( $hospital_doctor['doctor_info']))
                          {{ $hospital_doctor['doctor_info'] }}
                          @else
                          {{ "No description added"}}
                          @endif
                        </div>
                    </div>

                </div>
                <div id="collapse{{($key+1)}}" class="collapse" aria-labelledby="heading{{($key+1)}}" data-parent="#accordion">
                    <div class="doc_extra_detail widget_profile {{($key)}}" id="{{($key)}}">
                        <div class="doc_data">
                            <div class="doc_appoint_date">                                
                                <input type="text" class="datepicker_input hosp_datepicker" readonly value="{{ date('d-m-Y') }}" id="datepicker" data-doct_id="{{ $hospital_doctor['doctor_id'] }}"  data-key="{{ $key }}" onchange="doctorAvailabilityListing(this); return false;">
                            </div>
                            <div class="time_indicators">
                                <ul>
                                    <li>
                                        <span class="red"></span> Not Available
                                    </li>
                                    <li>
                                        <span class="green"></span> Available
                                    </li>
                                </ul>
                            </div>
                        </div>
                        <div class="availability_listing_list" style="display: none" >
                                            <ul class="availability_listing" ></ul>
                                            
                                        </div>
                        <div class="doc_appoint_time">
                            <ul class="availability_listing">

                                @if(count($hospital_doctor['doctor_availability']) > 0)
                                    @php                                                                
                                        date_default_timezone_set($timezone);
                                    @endphp
                                        @foreach($hospital_doctor['doctor_availability'] as $key1=>$availability) 
                                    @php
                                             
                                           
                                                    if(count($doc_appoint_listing) > 0){
                                                        $index =0;
                                                        foreach($doc_appoint_listing as $doc_appoint){                                          
                                                            if($hospital_doctor['doctor_id'] == $doc_appoint['doctor_id']){                       
                                                                if(date("H:i",strtotime($availability['availability_time'])) ==  date('H:i',$doc_appoint['appointment_time'])){
                                                                    $index = 1;
                                                                }
                                                            }
                                                        }
                                                        if($index == 1){                                                    
                                                        @endphp
                                                            <li aa>
                                                                <input id="time{{$count}}" type="radio" name="doctor_apponitment_time{{($key+1)}}" class="doctor_apponitment_time" value='{{ $availability["availability_time"] }}' data-doctor_id="{{ $hospital_doctor['doctor_id'] }}" disabled>
                                                                <label for="time{{$count}}">{{ $availability['availability_time'] }}</label>
                                                            </li>

                                    @php                }else{

                if(strtotime("now") > strtotime($availability["availability_time"])){  
                @endphp

                <li dd>
                <input id="time{{$count}}" type="radio" name="doctor_apponitment_time{{($key+1)}}" class="doctor_apponitment_time" value='{{ $availability["availability_time"] }}' data-doctor_id="{{ $hospital_doctor['doctor_id'] }}" disabled>
                <label for="time{{$count}}">{{ $availability['availability_time'] }}</label>
                </li>
                @php } else{ @endphp
                <li bb>
                <input id="time{{$count}}" type="radio" name="doctor_apponitment_time{{($key+1)}}" class="doctor_apponitment_time" value='{{ $availability["availability_time"] }}' data-doctor_id="{{ $hospital_doctor['doctor_id'] }}">
                <label for="time{{$count}}">{{ $availability['availability_time'] }}</label>
                </li>

                @php                }
                                        }

}
                                        else{

                                        if(strtotime("now") < strtotime($availability["availability_time"])){  @endphp
                                        <li cc>
                                            <input id="time{{$count}}" type="radio" name="doctor_apponitment_time{{($key+1)}}" class="doctor_apponitment_time" value='{{$availability["availability_time"]}}' data-doctor_id="{{ $hospital_doctor['doctor_id'] }}">
                                            <label for="time{{$count}}">{{ $availability['availability_time'] }}</label>
                                        </li>
                                        @php
                                    }
                                    else{ 
                                    @endphp
                                    <li dd>
                                        <input id="time{{$count}}" type="radio" name="doctor_apponitment_time{{($key+1)}}" class="doctor_apponitment_time" value='{{$availability["availability_time"]}}' data-doctor_id="{{ $hospital_doctor['doctor_id'] }}" disabled>
                                        <label for="time{{$count}}">{{ $availability['availability_time'] }}</label>
                                    </li>
                                    @php     }
                                }                                                                                                     

                                                $count++; 
                                            
                                    @endphp                                                             
                                        @endforeach
                                    @else
                                     <li>
                                        <span>No available time set by doctor yet</span>
                                        
                                    </li>
                                @endif                                                          
                            </ul>
                        </div>
                    </div>

                </div>
            </div>
        @endforeach    
    </div>
@else
   <div class="widget_body">
        <div class="no_data">
            <img src="{{ asset('images/no_data.svg') }}" alt="images">
            <h4>No doctor available for this hospital, Please select another hospital</h4>
        </div>
    </div> 
@endif    
