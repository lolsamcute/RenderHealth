@extends('layouts.patient_fluid')

@section('content')
<link href="{{ asset('/css/appoiment.css') }}" rel="stylesheet">
<main class="col-12 col-md-12 col-xl-12 bd-content appointment-padding">
    <div class="row">
        <div class="col-12">
            <div class="widget">
                <!-- <div class="widget_header">
                    <h2>Hospital appointment</h2>
                </div> -->

                <div class="row Hospital_appointment">
                    <!-- Left Side -->
                    <div class="col-12 col-xl-4">
                        <form method="GET">
                            <div class="row">
                                <div class="col-sm-8">
                                    <div class="form-group search-box">
                                        <i class="fa fa-search search-icon" aria-hidden="true"></i>
                                        <input type="input" class="form-control" placeholder="Search" name="hospital_name" id="hospital_name" />
                                        <input type="hidden" class="form-control" placeholder="Search" name="hosp_id" id="hosp_id" />
                                        <input type="hidden" class="form-control" placeholder="Search" name="doctor_id" id="doctor_id" />
                                        <!-- <i class="fa fa-microphone microphone-set " aria-hidden="true"></i> -->
                                        <!-- <button type="submit" class="btn btn-primary">Search</button> -->
                                    </div>
                                </div>
                                <div class="col-sm-4">
                                    <div class="form-group search-box">
                                        <button type="button" data-toggle="modal" data-target="#search_schedule_appointment" class="btn btn-primary btn-sm"> Filter</button>
                                    </div>
                                </div>
                            </div>
                        </form>
                        @if(count($hospitals) > 0)
                        

                        <form mothod="GET">
                            {{ csrf_field() }}
                            @foreach($hospitals as $key => $hospital)
                            <p class="text-title">{{$key}}</p>
                            @if(count($hospital) > 0)
                            @foreach($hospital as $row => $item)
                            <div class="widget_body doctor_exists_main widget_profile mb-2 {{isset($_GET['hosp_id']) && $_GET['hosp_id'] == $item->hosp_id? 'active' : ''}}">
                                <div class="row">
                                    <div class="col-sm-12 round-set">
                                        <div class="">
                                            <input id="today" {{isset($_GET['hosp_id']) && $_GET['hosp_id'] == $item->hosp_id? 'checked' : ''}} onChange="getDoctors({{$item->hosp_id}},'{{isset($search_hospital_appointment)?$search_hospital_appointment:''}}','{{isset($search_doctor)?$search_doctor:''}}','{{isset($_GET['type_of_speciality'])?$_GET['type_of_speciality']:''}}','{{isset($_GET['state'])?$_GET['state']:''}}','{{isset($_GET['lga'])?$_GET['lga']:''}}','{{isset($_GET['hospital_name'])?$_GET['hospital_name']:''}}')" type="radio" name="ad" class="form-check-custom appointment_time_sel" value="1" style="display: none;">
                                            <label for="today"></label>
                                        </div>
                                        <div class="form-group" id="appointment_details" data-id="{{$item->id ? $item->id : '--'}}">
                                            <p>{{$item->hosp_name ? $item->hosp_name : '--'}}</p>
                                        </div>
                                        <span class="form-control-static">{{$item->hosp_address ? $item->hosp_address.", " : ''}}<br />{{$item->hosp_city ? $item->hosp_city.", " : ''}}{{$item->hosp_state ? $item->hosp_state." " : ''}}</span>
                                    </div>
                                </div>
                            </div>
                            @endforeach
                            @endif
                            @endforeach
                        </form>
                        @else
                        <div class="widget_body doctor_exists_main widget_profile mb-4">
                            <div class="row">
                                <div class="col-sm-12">
                                    <div class="form-group">
                                        No Specialist found!
                                    </div>
                                </div>
                            </div>
                        </div>
                        @endif
                    </div>

                    <!-- Right Side -->
                    @if(count($doctors) > 0)
                    <div class="col-12 col-xl-8 doctors_listing">
                        <div class="widget_body">
                            @foreach($doctors as $key => $doctor)

                            @if(count($doctor) > 0)
                            @foreach($doctor as $row => $item)

                            <div class="no_data">
                                <!-- <img src="{{ asset('images/no_data.svg') }}" alt="images">
                                <h4>No doctor available, Please select hospital</h4> -->
                                <div class="information-doctor {{isset($_GET['doctor_id']) && $_GET['doctor_id'] == $item->doctor_id? 'active' : ''}}">
                                    <div class="row set-pad">
                                        <div class="col-md-5 docter-set">
                                            <div class="media">
                                                <img style="background-image: url(../doctorimages/{{$item->doctor_picture}})"  alt="">
                                                <div class="media-body">
                                                    <p>{{$item->doctor_title ? $item->doctor_title : ''}} {{$item->doctor_first_name ? $item->doctor_first_name : ''}} {{$item->doctor_middle_name ? $item->doctor_middle_name : ''}} {{$item->doctor_last_name ? $item->doctor_last_name : ''}}</p>
                                                    <p>{{$item->doctor_speciality ? $item->doctor_speciality : ''}}</p>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-md-4">
                                            <div class="languages-list">
                                                <p>Languages</p>
                                                <p>{{$item->doctor_languages ? str_replace(',',', ',$item->doctor_languages) : '--'}}</p>
                                            </div>
                                        </div>
                                        <div class="col-md-3">
                                            <div class="languages-list">
                                                <p>Education</p>
                                                <p>{{$item->doctor_education_school ? $item->doctor_education_school : '--'}}</p>
                                                <div class="clearfix prettyradio labelright  blue side-btn">
                                                    <input id="today" {{isset($_GET['doctor_id']) && $_GET['doctor_id'] == $item->doctor_id? 'checked' : ''}} onChange="getDoctorsDetail({{$item->hospital_id}},'{{isset($search_hospital_appointment)?$search_hospital_appointment:''}}',{{isset($item)?$item->doctor_id:''}},'{{isset($_GET['type_of_speciality'])?$_GET['type_of_speciality']:''}}','{{isset($_GET['state'])?$_GET['state']:''}}','{{isset($_GET['lga'])?$_GET['lga']:''}}','{{isset($_GET['hospital_name'])?$_GET['hospital_name']:''}}')" type="radio" name="doctor" class="form-check-custom appointment_time_sel" value="1" style="display: none;">
                                                </div>
                                                
                                            </div>
                                        </div>
                                        <div class="col-md-12">
                                            <div class="mention-year">
                                                <img src="http://renderhealth.themezones.com/images/briefcase.svg" alt="">
                                                <p> {{$item->doctor_years_practised ? $item->doctor_years_practised : '0'}} Year{{$item->doctor_years_practised && $item->doctor_years_practised>1 ? "s" : ''}} of experience</p>
                                            </div>
                                            <div class="cantant-p">
                                                <p>{{$item->biography ? $item->biography : ''}}</p>
                                            </div>
                                        </div>
                                    </div>
                                     
                                    @if(count($item->doctor_availability) > 0)
                                    
                                    <hr class="doctor-hr">
                                    <div class="row pad-set-2">
                                        <div class="col-md-6" id="{{$row}}">
                                        <div class="doc_appoint_date">                                
                                            <input type="text" class="datepicker_input hosp_datepicker" readonly value="{{ date('l d F Y') }}" id="datepicker" data-doct_id="{{$item->doctor_id ? $item->doctor_id : ''}}"  data-key="{{$row}}" onchange="doctorAvailabilityListing(this); return false;">
                                        </div>
                                    </div>
                                   
                                        <div class="col-md-6">
                                            <div class="set-available">
                                                <div class="not-availabal">
                                                    <div class="round-set-icon"></div>
                                                    <p>Not Available</p>
                                                </div>
                                                <div class="not-availabal availabal">
                                                    <div class="round-set-icon"></div>
                                                    <p>Available</p>
                                                </div>

                                            </div>
                                        </div>
                                        <div class="availability_listing_list" style="display: none" >
                                            <ul class="availability_listing" ></ul>
                                        </div>
                                        <div class="col-md-12" id="schudule-btn-show" >
                                           
                                           @if($user)
                                            <div class="btn-doctor" data-target="#scheduleAppointmentModel" data-toggle="modal" onClick="scheduleAppointmentDetail({{$item->doctor_id}});">
                                                <a href="#">SCHEDULE APPOINTMENT</a>
                                            </div>
                                            @else
                                           
                                            <div class="btn-doctor" >
                                                <a href="http://renderhealth.themezones.com/patient/login">SCHEDULE APPOIMENT</a>
                                            </div>
                                            @endif
                                            <!-- Modal -->
                                            <div class="modal fade" id="scheduleAppointmentModel" tabindex="-1" role="dialog" aria-labelledby="scheduleAppointmentModelTitle" aria-hidden="true">
                                                <div class="modal-dialog modal-dialog-centered doctor-modal" role="document">
                                                    <div class="modal-content">
                                                        <div class="modal-header">
                                                            <div class="header-text">
                                                                <div class="btn-doctor m-0" data-target="#scheduleAppointmentModel" data-toggle="modal">
                                                                    <a href="#">Cancel</a>
                                                                </div>
                                                                <p>Appoiment Confirmations</p>
                                                                <div class="btn-doctor m-0" onClick="saveAppointmentDetail({{$row}})">
                                                                    <a href="#">Confirm</a>
                                                                </div>

                                                            </div>
                                                        </div>
                                                        <div class="modal-body">
                                                            <div class="row detail-1">
                                                                <div class="col-md-8">
                                                                    <div class="detail-pation">
                                                                        <div class="media">
                                                                            <img clas="patient-img" id="patient_image" src="" alt="">
                                                                            <div class="media-body">
                                                                                <p class="text-media" id="patient_name"></p>
                                                                                <p class="text-media-1"><span id="patient_age"></span> y/o, <span id="patient_gender"></span></p>
                                                                                <ul class="patient-address">
                                                                                    <li><img src="http://renderhealth.themezones.com/images/location.svg" alt=""></li>
                                                                                    <li id="patient_address"></li>
                                                                                </ul>
                                                                                <ul class="patient-address brithday">
                                                                                    <li><img src="http://renderhealth.themezones.com/images/bday.svg" alt=""></li>
                                                                                    <li><span id="patient_dob"></span> (Brithday)</li>
                                                                                </ul>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                <div class="col-md-4">
                                                                    <div class="appoiment-date text-center">
                                                                        <div>
                                                                            <p class="appoiment-banner"><span id="patient_month_year"></span> <br> <b id="patient_date"></b> <br> <span id="patient_time"></span></p>
                                                                            <div class="appoiment-text">
                                                                                <p>Hospital Appointment</p>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <hr>
                                                            <div class="row detail-set-pad">
                                                                <div class="col-md-12">
                                                                    <div class="media p-3">
                                                                        <img clas="" id="doctor_picture"  alt="" width="70px">
                                                                        <div class="media-body">
                                                                            <div class="set-doctor">
                                                                                <p id="doctor_name"></p>
                                                                                <p id="doctor_speciality"></p>
                                                                            </div>
                                                                            <div class="location-detail">
                                                                                <p>Location:</p>
                                                                                <p id="doctor_address"></p>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                    <div class="reanson-for">
                                                                        <p>Reanson for visit</p>
                                                                        <textarea class="w-100" name="reanson_for_visit" id="reanson_for_visit" cols="30" rows="1" placeholder="Reanson for visit..."></textarea>
                                                                        <p class="text-bottom">
                                                                        @if(count($health_diaries)>0)
                                                                        <a class="attachment mb-4 mt-2" href="javascript:;" data-toggle="modal" data-target="#select_diary" >
                                                                            <img src="{{ asset('images/attachment.svg') }}" alt="icon">
                                                                            Attach My Health Diary
                                                                        </a> 
                                                                        @else
                                                                            <a class="attachment mb-4 mt-2" href="javascript:;" onClick="(function(){
                                                                            alert('No health diary found');
                                                                            return false;
                                                                            })();return false;">
                                                                            <img src="{{ asset('images/attachment.svg') }}" alt="icon">
                                                                            Attach My Health Diary
                                                                            </a> 
                                                                        @endif
                                                                        </p>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    @endif

                                </div>
                            </div>
                            <!-- Diary Modal -->
                            <div class="modal fade" id="select_diary">
                                <div class="modal-dialog modal-xl modal-dialog-centered genModal">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <h4 class="modal-title">Add My Health Diary</h4>
                                            <button type="button" class="close mclose" data-dismiss="modal"><img src="{{asset('images/cross_modal.svg')}}"/></button>
                                        </div>
                                        <div class="modal-body">
                                            <div class="health_diary">
                                                <ul class="row">
                                                    @foreach($health_diaries as $Singlehealth_diaries)
                                                    <li class="col-sm-4">
                                                        <input id="diary_{{$Singlehealth_diaries->id}}" value="{{$Singlehealth_diaries->diary_id}}" class="form-check-input health_diary" name="health_diary" type="checkbox"   onclick="appenddiary(<?php echo $Singlehealth_diaries->diary_id;?>,this)" />
                                                        <label for="diary_{{$Singlehealth_diaries->id}}">
                                                            <span class="diary_date">{{ date('j F Y',$Singlehealth_diaries->created_date)}}</span>
                                                            <div class="diary_detail">
                                                                @php
                                                                    $feeling_pic = ['admin/doctor/images/smilies/no_pain@2x.png','admin/doctor/images/smilies/mild@2x.png','admin/doctor/images/smilies/moderate@2x.png','admin/doctor/images/smilies/severe@2x.png','admin/doctor/images/smilies/very_severe@2x.png','admin/doctor/images/smilies/worst_pain@2x.png','admin/doctor/images/smilies/moderate@2x.png'];
                                                                    @endphp
                                                                <span class="diary_icon"><img src="{{asset($feeling_pic[$Singlehealth_diaries->feeling_details])}}" alt="smilies"></span>
                                                        @php 
                                                            $put_disable_keys=array();

                                                            $feeling = ['Feeling No Pain','Feeling Mild Pain','Feeling Moderate Pain','Feeling Severe Pain','Feeling Very Severe Pain','Feeling Worst Pain',"Other"];    
                                                            $put_disable_keys[]=$Singlehealth_diaries->feeling_details;
                                                            
                                                        @endphp                              

                                                            
                                                            @foreach($feeling as $key=>$single_feeling) 
                                                            @if($key==6)
                                                            <h4> {{ trim($Singlehealth_diaries->describe_feeling_other)}}</h4> 
                                                            @else
                                                            @if(in_array($key,$put_disable_keys))                              
                                                                <h4>{{$single_feeling}}</h4>                                      
                                                                @endif
                                                                @endif
                                                                @endforeach 

                                                                <h6>{{$Singlehealth_diaries->symptom_details}}</h6>
                                                            </div>
                                                        </label>
                                                    </li>
                                                    @endforeach
                                                </ul>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            @endforeach
                            @endif
                            @endforeach
                        </div>
                    </div>
                    @else
                    <div class="col-12 col-xl-8 doctors_listing text-center">
                        <div class="widget_body">
                            <div class="no_data">
                                <img src="{{ asset('images/no_data.svg') }}" alt="images">
                                <h4>No availability, Please check another Facility</h4>
                            </div>
                        </div>
                    </div>
                    @endif
                </div>

            </div>
        </div>
    </div>
</main>
<div class="modal fade" id="search_schedule_appointment">
    <div class="modal-dialog modal-md modal-dialog-centered genmodal genmodal_custom custom_width1 doctor-modal " style="width:650px">
        <div class="modal-content">
            <div class="modal-header" style="padding-top:10px">
                <div class="header-text">
                    <div class="btn-doctor m-0" data-target="#scheduleAppointmentModel" data-toggle="modal" >
                        
                    </div>
                    <p>Filter</p>
                    <div class="btn-doctor m-0" >
                    <button type="button" id="search_patient_modal" class="close" data-dismiss="modal"><img src="{{ asset('admin/doctor/images/popup_close_w.svg') }}" /></button>
                    </div>

                </div>
            </div>
            <div class="modal-body" style="padding: 40px;">
                <form id="search_patient_form" name="search_patient_form" method="GET">


                    
                    @if(count($serviceOffered) > 0)
                    
                    <div class=" row">
                        @foreach($serviceOffered as $row_serviceOffered => $Offered)
                        
                        <div class="col-sm-6 row">
                            <div class="col-sm-9">{{$Offered->name}}</div>
                            <div class="col-sm-3">
                            <div class="">
                                <input id="today"  type="checkbox" name="offered" class="form-check-custom appointment_time_sel" value="{{$Offered->name}}" style="display: none;">
                            </div>
                            </div>
                        </div>
                        @endforeach
                    </div>
                    <div class="form-group">
                            <label>Specialities</label>
                            <div class="select_box">
                                <select class="form-control" name="type_of_speciality" id="type_of_speciality">
                                    <option value="" data-id="0" selected>Select Specialities</option>
                                    @if(count($speciality) > 0)
                                    @foreach($speciality as $speciality)
                                    <option data-id="{{ $speciality['id'] }}" value="{{ $speciality['name'] }}">{{ $speciality['name'] }}</option>
                                    @endforeach
                                    @endif
                                </select>
                            </div>
                        </div>
                    @endif
                    <div class="form-group">
                        <label>HMO Accepted</label>
                        <div class="select_box">
                            <select class="form-control" name="HMO" id="hosp_speciality">
                                <option value="" data-id="0" selected>Select HMO</option>
                                @if(count($Hmolist) > 0)
                                @foreach($Hmolist as $hmo)
                                <option data-id="{{ $hmo['id'] }}" value="{{ $hmo['name'] }}">{{ $hmo['name'] }}</option>
                                @endforeach
                                @endif
                            </select>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-12 text-center">
                            <button type="submit" class="btn btn-primary mb-3 mt-3" name="button">Search</button>
                        </div>
                    </div>
                    <input type="hidden" id="patient_name_hidden">
                    <input type="hidden" id="patient_surname_hidden">
                    <input type="hidden" id="patient_recno_hidden">
                    <input type="hidden" id="patient_dob_hidden">
                </form>
            </div>
        </div>
    </div>
</div>
@endsection