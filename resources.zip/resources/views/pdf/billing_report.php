<!doctype html>
<html lang="en">

<head>
    <meta http-equiv="Content-Type" content="text/html; charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href="images/favicon.png">
    <title>Render Health</title>
  
    <style>

    body {

      font-family:serif;
      font-size: 1rem;
       font-weight: 400;
      line-height: 1.5;
      color: #212529;
      text-align: left;
    }

    .col-12 {
      -ms-flex: 0 0 100%;
      flex: 0 0 100%;
      max-width: 100%;
    }
    th {
        text-align: inherit;
    }

    .widget {
      display: block;
      margin-bottom: 22px;
    }

    .modal_table .table_total td {
      background-color: #FAFAFA;
      padding: 0.45rem .75rem;
      font-weight: 700;
      border-top: 1px solid #E1E1E1;
     
    }

    .widget_flex_header {
    display: flex;
    justify-content: space-between;
    margin-bottom: 15px;
    }
    .widget_header h2 {
      font-size: 21px;
      font-weight: 600;
      margin-bottom: 13px;
    }
    .d-flex {
      display: -ms-flexbox !important;
      display: flex !important;
    }


    .widget_body {
      background-color: #fff;
      box-shadow: 0px 2px 4px rgba(0,0,0,0.02);
      border: 1px solid #EEEEEE;
      border-radius: 4px;
    }
    .mb-4, .my-4 {
      margin-bottom: 1.5rem !important;
    }
    *, ::after, ::before {
      box-sizing: border-box;
    }
    .invoice {
      padding: 30px;
    }
    .billing_person_data {

    display: inline-block;
    margin-bottom:15px;
    margin-top: 0;
    text-align: center;
    width: 100%;

}
.bill_person_data {

    font-size: 15px;
    color: #023532;
    font-weight: 600;
    width: 32%;
    display: inline-block;

}
    .bill_person_data span {
      font-size: 15px;
      font-weight: 800;
      color: #01BBAE;
    }
    .separator {

    width: 1px;
    background-color: #E1E1E1;
    height: 18px;
    display: inline-block;

}
    .genModal h3 {

    font-size: 14px;
    color: #353638;
    font-weight: 600;
    margin-bottom: 12px;
    display: block;

}
    .table-bordered {
      border: 1px solid #dee2e6;
    }
    .table {
      font-size: 12px;
      margin: 0;
      color: #353638;
    }

    .table {
      width: 100%;
      max-width: 100%;
      margin-bottom: 1rem;
      background-color: transparent;
        border-collapse: collapse;
    }
    .modal_table thead th {
      background-color: #FAFAFA;
    }
    .table-bordered td, .table-bordered th {
      border: 1px solid #dee2e6;
    }

    .table thead th {
      vertical-align: bottom;
      border-bottom: 2px solid #dee2e6;
    }

    .modal_table td, .modal_table th {
      padding: 0.45rem .75rem;
    }
    .modal_table thead td, .modal_table thead th {
      border-bottom-width: 1px;
    }
    .table-bordered td, .table-bordered th {
      border: 1px solid #dee2e6;
    }
    .modal_table td {
      border-top: none;
      border-bottom: none;
      padding: .45rem .75rem;
    }
  
    .billing_person {
      display: flex;
      justify-content: space-between;
      margin-bottom: 10px;
      margin-top: 35px;
    }
    .bill_person h6 {
      font-size: 12px;
      font-weight: 400;
      margin-bottom: 5px;
      margin-top: 0;
    }
    .bill_person h3 {
      font-size: 18px;
      font-weight: 700;
      margin-bottom: 2px;
        margin-top: 0;
    }
    .bill_person h5 {
      font-size: 12px;
      font-weight: 400;
      color: #B1B1B1;
      margin-bottom: 0;
        margin-top: 0;
    }


  .billing_person {

    display: inline-block;
    justify-content: space-between;
    margin-bottom: 10px;
    margin-top: 35px;
    width: 100%;

}
.bill_person {
    display: inline-block;
    width: 32%;
    vertical-align: top;
}
    </style>
</head>

<body>   

    <div class="container">
        <div class="row flex-xl-nowrap">
            <main class="col-12 col-md-12 col-xl-12 bd-content">
                <div class="row">
                    <div class="col-12">
                        <div class="widget">
                            <div class="widget_header widget_flex_header mb-4">
                                <h2 class="mb-0">Inv. <?php echo $billing_detail['invoice_number']; ?></h2>                                
                            </div>
                            <div class="row">
                                <div class="col-12">
                                    <div class="widget_body mb-4">
                                        <div class="invoice genModal">
                                            <div class="billing_person_data">
                                              <div class="bill_person_data">
                                                  Summary : <span style="font-family: DejaVu Sans;">₦ <?php echo $billing_detail['payable_amount'] - $billing_detail['paid_amount']; ?></span>
                                               </div>
                                              <div class="separator"></div>
                                              <div class="bill_person_data">
                                                  Paid : <span style="font-family: DejaVu Sans;">₦ <?php echo  $billing_detail['paid_amount']; ?></span>
                                              </div>
                                              <div class="separator"></div>
                                              <div class="bill_person_data">
                                                  Total Amount : <span style="font-family: DejaVu Sans;">₦ <?php echo $billing_detail['payable_amount']; ?></span>
                                              </div>
                                          </div>
                                           <h3>Details of Services</h3>
                                           <table class="modal_table table table-bordered mb-4">
                                               <thead>
                                                   <tr>
                                                       <th>Date</th>
                                                       <th>Kind of Services</th>
                                                       <th>Amount</th>
                                                   </tr>
                                               </thead>
                                               <?php $sub_total = 0; ?>
                                              <tbody>                    
                                                  <?php foreach($billing_detail['billing_service'] as $billing_service){ ?>
                                                    <tr>
                                                      <td><?php echo  date('d/m/Y',$billing_service['service_date']); ?></td>
                                                      <td><?php echo $billing_service['service_name']; ?></td>
                                                      <td style="font-family: DejaVu Sans;">₦ <?php echo $billing_service['service_amount']; ?></td>
                                                    </tr>
                                                    <?php $sub_total = $sub_total+ $billing_service['service_amount'];
                                                    } ?>
                                                  <tr class="table_total">
                                                    <td colspan="2">Sub Total Amount</td>
                                                    <td style="font-family: DejaVu Sans;">₦ <?php echo $sub_total; ?></td>
                                                  </tr>                                       
                                            </tbody>
                                           </table>
                                           <h3>Details of Medicines</h3>
                                           <table class="modal_table table table-bordered mb-4">
                                               <thead>
                                                   <tr>
                                                       <th>Date</th>
                                                       <th>Kind of Services</th>
                                                       <th>Type</th>
                                                       <th>Qty</th>
                                                       <th>Amount</th>
                                                   </tr>
                                               </thead>
                                               <tbody>
                                                   <tr>
                                                       <td>12/02/2018</td>
                                                       <td>Omeprazol Meds 50mg</td>
                                                       <td>Capsule</td>
                                                       <td>10</td>
                                                       <td style="font-family: DejaVu Sans;">₦ 10,000</td>
                                                   </tr>
                                                   <tr>
                                                       <td>13/02/2018</td>
                                                       <td>Penicilin</td>
                                                       <td>Syrup</td>
                                                       <td>5</td>
                                                       <td style="font-family: DejaVu Sans;">₦ 10,000</td>
                                                   </tr>
                                                   <tr class="table_total">
                                                         <td colspan="4">Sub Total Amount</td>
                                                         <td style="font-family: DejaVu Sans;">₦ 20,000</td>
                                                     </tr>
                                               </tbody>
                                           </table>
                                           <div class="billing_person">
                                             <div class="bill_person">
                                                 <h6>Hospital Details</h6>
                                                 <h3><?php echo $billing_detail['doctor']['doctor_hospital_details'][0]['hospital_detail']['hosp_name']; ?></h3>
                                                 <h5><?php echo $billing_detail['doctor']['doctor_hospital_details'][0]['hospital_detail']['hosp_address']; ?></h5>
                                             </div>
                                            
                                             <div class="bill_person">
                                                 <h6>Invoice Number</h6>
                                                 <h3><?php echo $billing_detail['invoice_number']; ?></h3>
                                                 <h5>Created : <?php echo date('j F, Y',$billing_detail['billing_date']); ?></h5>
                                             </div>
                                             
                                             <div class="bill_person">
                                                 <h6>Doctor’s Name</h6>
                                                 <h3>Dr. <?php echo $billing_detail['doctor']['doctor_first_name']; ?> <?php echo $billing_detail['doctor']['doctor_last_name']; ?></h3>
                                                 <h5><?php echo $billing_detail['doctor']['specialist_categories']['speciality_name']; ?></h5>
                                             </div>
                                         </div>

                                       </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </main>

        </div>
    </div>


    


    <script src="https://code.jquery.com/jquery-3.3.1.js" integrity="sha256-2Kok7MbOyxpgUVvAk/HJ2jigOSYS2auK4Pfzbm7uH60=" crossorigin="anonymous">
    </script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.0/umd/popper.min.js" integrity="sha384-cs/chFZiN24E4KMATLdqdvsezGxaGsi4hLGOzlXwp5UZB1LY//20VyM2taTB4QvJ" crossorigin="anonymous">
    </script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.0/js/bootstrap.min.js" integrity="sha384-uefMccjFJAIv6A+rW+L4AHf99KvxDjWSu1z9VI8SKNVmz4sk7buKt/6v9KI65qnm" crossorigin="anonymous">
    </script>
    <script src="js/bootstrap-datepicker.js" type="text/javascript"></script>
    <script src="js/prettyCheckable.min.js"></script>
    <script src="js/main.js"></script>

</body>

</html>
